﻿@echo off
setlocal
title CaptivPortal Lab - Update

set "CLEAN=C:\CaptivPortal-UI-Preview"
set "WORK=C:\CaptivPortal-UI-Work"

echo ============================================================
echo CaptivPortal Local Lab - UPDATE
echo ============================================================
echo.

echo [1/4] Checking Clean Main...
cd /d "%CLEAN%" || goto :error
git status --porcelain
for /f "delims=" %%A in ('git status --porcelain') do (
    echo.
    echo ERROR: Clean Main has local changes.
    echo Path: %CLEAN%
    echo Nothing was updated.
    goto :fail
)

echo [2/4] Updating Clean Main from origin/main...
git fetch origin || goto :error
git pull --ff-only || goto :error

echo.
echo [3/4] Checking ui-work...
cd /d "%WORK%" || goto :error
for /f "delims=" %%A in ('git status --porcelain') do (
    echo.
    echo STOP: ui-work contains local changes.
    echo Clean Main has already been updated.
    echo ui-work was NOT rebased.
    echo.
    git status --short
    goto :dirtywork
)

echo [4/4] Rebasing ui-work onto origin/main...
git fetch origin || goto :error
git rebase origin/main || goto :error

echo.
echo ============================================================
echo PASS: Local Lab is up to date.
echo ============================================================
echo.
echo Clean Main:
cd /d "%CLEAN%"
git status -sb
echo.
echo ui-work:
cd /d "%WORK%"
git status -sb
echo.
pause
exit /b 0

:dirtywork
echo.
echo Finish, save, commit, or discard the current PATCH first,
echo then run lab-update again.
echo.
pause
exit /b 2

:error
echo.
echo ============================================================
echo ERROR: Update command failed.
echo ============================================================
echo Check the message above.
echo.
pause
exit /b 1

:fail
echo.
pause
exit /b 1
