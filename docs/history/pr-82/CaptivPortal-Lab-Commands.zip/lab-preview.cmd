﻿@echo off
setlocal
title CaptivPortal Lab - Admin Preview

set "PYTHON=C:\CaptivPortal-UI-Preview\.venv\Scripts\python.exe"
set "PREVIEW=C:\CaptivPortal-UI-Preview-Tools\preview.py"
set "WORK=C:\CaptivPortal-UI-Work"

echo ============================================================
echo CaptivPortal Local Lab - ADMIN PREVIEW
echo ============================================================
echo.
echo Repository:
echo   %WORK%
echo.
echo Browser:
echo   http://127.0.0.1:5055/
echo.
echo Stop preview with Ctrl+C.
echo ============================================================
echo.

if not exist "%PYTHON%" (
    echo ERROR: Python virtual environment was not found:
    echo %PYTHON%
    pause
    exit /b 1
)

if not exist "%PREVIEW%" (
    echo ERROR: preview.py was not found:
    echo %PREVIEW%
    pause
    exit /b 1
)

if not exist "%WORK%\.git" (
    rem Worktrees usually have a .git FILE, not a directory.
    if not exist "%WORK%\.git" (
        echo ERROR: ui-work worktree was not found:
        echo %WORK%
        pause
        exit /b 1
    )
)

cd /d "%WORK%" || exit /b 1

echo Current ui-work state:
git status -sb
echo.

start "" "http://127.0.0.1:5055/"
"%PYTHON%" "%PREVIEW%"

echo.
echo Preview stopped.
pause
