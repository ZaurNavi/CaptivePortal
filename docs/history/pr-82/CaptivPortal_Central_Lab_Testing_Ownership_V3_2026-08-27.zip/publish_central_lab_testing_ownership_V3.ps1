﻿$ErrorActionPreference = "Stop"

$Repo = "$env:USERPROFILE\Downloads\CaptivPortal-KB-Work"
$Expected = "f5887758898b512747d2ea8bd51763389230dc2d"
$Branch = "docs/central-lab-testing-ownership-2026-08-27"
$GhRepo = "ZaurNavi/CaptivePortal"
$Title = "Docs: canonicalize Central Lab testing ownership"

$Allowed = @(
    ".github/copilot-instructions.md",
    ".github/instructions/tests.instructions.md",
    "AGENTS.md",
    "docs/agents/handoff.md",
    "docs/agents/task-contract.md",
    "docs/agents/workflow.md",
    "docs/deployment.md",
    "docs/plans/PLAN-template.md",
    "docs/tasks/TASK-template.md",
    "docs/testing.md"
)

function Read-Lf([string]$Path) {
    return [IO.File]::ReadAllText($Path).Replace("`r`n","`n")
}

function Write-Lf([string]$Path,[string]$Text) {
    [IO.File]::WriteAllText(
        $Path,
        $Text.Replace("`r`n","`n"),
        (New-Object Text.UTF8Encoding($false))
    )
}

function Replace-Once([string]$Rel,[string]$Old,[string]$New) {
    $Path = Join-Path $Repo $Rel
    $Text = Read-Lf $Path
    $Count = ([regex]::Matches($Text,[regex]::Escape($Old))).Count
    if ($Count -ne 1) {
        throw "STOP: expected exactly one literal target in $Rel; found $Count"
    }
    Write-Lf $Path ($Text.Replace($Old,$New))
}

function Replace-Section([string]$Rel,[string]$Start,[string]$Next,[string]$NewSection) {
    $Path = Join-Path $Repo $Rel
    $Text = Read-Lf $Path
    $Pattern = "(?ms)^" + [regex]::Escape($Start) + "\n.*?(?=^" + [regex]::Escape($Next) + "\n)"
    $Matches = [regex]::Matches($Text,$Pattern)
    if ($Matches.Count -ne 1) {
        throw "STOP: section '$Start' in $Rel matched $($Matches.Count) times"
    }
    $Replacement = $NewSection.TrimEnd() + "`n`n"
    Write-Lf $Path ([regex]::Replace($Text,$Pattern,[System.Text.RegularExpressions.MatchEvaluator]{ param($m) $Replacement },1))
}

function Write-Whole([string]$Rel,[string]$Content) {
    $Path = Join-Path $Repo $Rel
    if (-not (Test-Path $Path)) { throw "STOP: missing $Rel" }
    Write-Lf $Path ($Content.TrimEnd() + "`n")
}

Write-Host "=== PRECHECK / RECOVER V2 PARTIAL ATTEMPT ==="

if (-not (Test-Path (Join-Path $Repo ".git"))) {
    throw "STOP: repository not found: $Repo"
}

git -C $Repo fetch origin main
if ($LASTEXITCODE -ne 0) { throw "STOP: fetch failed" }

$Remote = (git -C $Repo rev-parse origin/main).Trim()
Write-Host "origin/main: $Remote"
if ($Remote -ne $Expected) {
    throw "STOP: origin/main changed; governance update must be rebound"
}

$Current = (git -C $Repo branch --show-current).Trim()
$Head = (git -C $Repo rev-parse HEAD).Trim()
Write-Host "current branch: $Current"
Write-Host "current HEAD:   $Head"

if ($Current -eq $Branch) {
    if ($Head -ne $Expected) {
        throw "STOP: failed governance branch HEAD moved; refusing recovery"
    }

    $Dirty = @(git -C $Repo status --porcelain)
    foreach ($Line in $Dirty) {
        $Rel = $Line.Substring(3).Trim()
        if ($Allowed -notcontains $Rel) {
            throw "STOP: unexpected dirty path on failed branch: $Rel"
        }
    }

    $RemoteBranch = @(git -C $Repo ls-remote --heads origin "refs/heads/$Branch" 2>$null)
    if ($LASTEXITCODE -ne 0) { throw "STOP: remote branch lookup failed" }
    if ($RemoteBranch.Count -gt 0) {
        throw "STOP: remote governance branch already exists; refusing local reset"
    }

    Write-Host "Recovering failed V2 attempt; discarding only generated governance changes:"
    $Dirty | ForEach-Object { Write-Host "  $($_.Substring(3).Trim())" }

    git -C $Repo reset --hard origin/main
    if ($LASTEXITCODE -ne 0) { throw "STOP: recovery reset failed" }
}
elseif ($Current -eq "main") {
    if (@(git -C $Repo status --porcelain).Count -ne 0) {
        throw "STOP: main working tree is not clean"
    }
    if ($Head -ne $Expected) {
        git -C $Repo merge --ff-only origin/main
        if ($LASTEXITCODE -ne 0) { throw "STOP: main fast-forward failed" }
    }

    $LocalBranch = @(git -C $Repo branch --list $Branch 2>$null)
    if ($LASTEXITCODE -ne 0) { throw "STOP: local branch lookup failed" }

    if ($LocalBranch.Count -gt 0) {
        git -C $Repo switch $Branch
        if ($LASTEXITCODE -ne 0) { throw "STOP: cannot switch existing local governance branch" }
        if ((git -C $Repo rev-parse HEAD).Trim() -ne $Expected) {
            throw "STOP: existing governance branch not at exact base"
        }
    } else {
        git -C $Repo switch -c $Branch
        if ($LASTEXITCODE -ne 0) { throw "STOP: branch creation failed" }
    }
}
else {
    throw "STOP: run only from main or the known failed governance branch; current=$Current"
}

if ((git -C $Repo rev-parse HEAD).Trim() -ne $Expected) {
    throw "STOP: exact base not restored"
}
if (@(git -C $Repo status --porcelain).Count -ne 0) {
    throw "STOP: worktree not clean after recovery"
}

Write-Host "PASS: exact clean governance branch restored"

Write-Host "=== APPLY CURRENT GOVERNANCE ==="

# .github/copilot-instructions.md
Replace-Once ".github/copilot-instructions.md" "Updated: 2026-08-04" "Updated: 2026-08-28`nCentral Lab governance effective: 2026-08-27"
Replace-Once ".github/copilot-instructions.md" `
"Перед изменением открой только документы, перечисленные в TASK, проверь фактические связанные файлы и тесты и не расширяй scope." `
"Перед изменением открой только документы, перечисленные в TASK, проверь фактические связанные файлы и тесты и не расширяй scope.`n`nTesting boundary: Coder/Copilot запускает только focused/minimal TASK-scoped automated tests изменяемого модуля и может создавать/изменять tests этого implementation scope. Unrelated-module, cross-module, broader/full repository regression, release/differential gates и официальный PASS/FAIL принадлежат Owner/Tech Lead/Central Lab. Если cross-module proof нужен, Coder либо запрашивает внешний запуск, либо подготавливает test без запуска. ``C:\CaptivPortal-Lab`` не запускается Coder как официальный gate."

# .github/instructions/tests.instructions.md — small canonical path-specific file.
$TestsInstructions = @'
---
applyTo: "tests/**/*.py"
---

# Tests

- TASK-scoped test responsibility берётся из TASK: agent, owner, shared или not-applicable.
- Coder/agent запускает только focused/minimal TASK/module группу и новые regression cases своего изменения; повторные локальные прогоны этой же группы разрешены.
- Coder/agent может создавать/изменять automated tests своего implementation scope.
- Не запускай unrelated-module, cross-module, broader или full CaptivPortal regression. Если такой proof нужен, запроси Owner/Tech Lead/Central Lab execution или подготовь test без запуска.
- `C:\CaptivPortal-Lab` не запускается Coder/agent как официальный gate. Prep-only изменение Lab directory допустимо только по явному Owner/Tech Lead поручению и заканчивается до official execution.
- Не удаляй тесты, не ослабляй assertions и не исправляй несвязанные failures ради green result.
- Для внешних API используй deterministic fakes/fixtures; production network запрещён без отдельного TASK.
- Handoff содержит точную focused/minimal команду и числа passed, skipped, failed; cross-module/broader evidence и Central Lab evidence указываются отдельно и не приписываются agent.
- Environment failure отделяй от product failure.
'@
Write-Whole ".github/instructions/tests.instructions.md" $TestsInstructions

# AGENTS.md
Replace-Once "AGENTS.md" "Updated: 2026-08-26" "Updated: 2026-08-28`nCentral Lab governance effective: 2026-08-27"

Replace-Once "AGENTS.md" `
"- Coder/исполнитель запускает TASK/module-scoped targeted tests, новые regression cases и релевантные static/syntax checks; он может повторять эти targeted-прогоны в процессе разработки.`n- Официальный full repository regression / current baseline / final Test Evidence является централизованной функцией Central Lab и не дублируется Coder или Tech Lead без отдельной причины.`n- Tech Lead проверяет архитектуру, TASK/ADR, DIFF и targeted evidence; полный suite не является его обычной ручной обязанностью.`n- Windows Local Gate не заменяет отдельный Linux/production-compatible gate, когда такой gate требуется release/deploy contract." `
"- Coder/исполнитель выполняет минимальные automated tests непосредственно в пределах текущего TASK / изменяемого модуля: focused tests, новые regression cases этого изменения и релевантные static/syntax checks; эти targeted-прогоны можно повторять в процессе разработки.`n- Coder может создавать/изменять automated tests только в пределах реализуемого изменения и не расширяет execution на unrelated modules, cross-module regression, broader regression или full repository suite.`n- Если proof требует test вне TASK/module boundary, Coder либо сообщает Owner/Tech Lead точный дополнительный test/gate для внешнего запуска, либо подготавливает/реализует такой test, но не запускает его.`n- ``C:\CaptivPortal-Lab`` и официальный Central Lab full repository regression cycle контролируются Owner / Tech Lead: Tech Lead определяет exact artifact, commands/gate procedure и acceptance criteria; Owner физически управляет Lab и запускает официальный regression; Owner + Tech Lead анализируют evidence и выдают PASS / FAIL / return-to-coder.`n- Coder не запускает официальный Central Lab gate, не выдаёт официальный PASS/FAIL и не считает собственные tests repository regression gate. По явному поручению Owner/Tech Lead Coder может только подготовить candidate/artifacts или пропатчить указанную Lab working directory; после подготовки цикл возвращается Owner/Tech Lead до запуска gate.`n- Windows Local Gate не заменяет отдельный Linux/production-compatible gate, когда такой gate требуется release/deploy contract."

$AgentsChecks = @'
## Проверки

Targeted commands для Coder/исполнителя определяет TASK. Они ограничены изменяемым модулем/TASK scope и проверяют непосредственные контракты, новые regression-сценарии этого изменения и необходимые static/syntax checks.

Статические проверки, такие как `compileall`, проверка синтаксиса изменённого frontend-кода и `git diff --check`, не превращают targeted workflow Coder в официальный full regression.

Cross-module/broader/full execution не относится к Coder local self-check. Если такой test нужен, Coder передаёт точную необходимость Owner/Tech Lead либо подготавливает test без запуска.

Официальный Central Lab cycle для exact artifact направляет Tech Lead, физически запускает Owner, а PASS/FAIL принимает Owner + Tech Lead.

Current approved Windows Local Gate и его compatibility baseline описаны в `docs/testing.md`.

Если перед production требуется Linux/full production-compatible gate, он выполняется отдельно по deploy/release contract. Windows gate его не заменяет.

Если environment запрещает назначенную стороне проверку, укажи команду/требуемый gate, причину и owner action.
'@
Replace-Section "AGENTS.md" "## Проверки" "## Повторное использование результатов тестирования" $AgentsChecks
Replace-Once "AGENTS.md" `
"Full repository suite выполняется централизованно Central Lab и не повторяется другими ролями без новой причины после успешного gate на неизменённом exact artifact. Отдельный Linux production-compatible gate не считается дублированием, когда он требуется как platform-specific release acceptance." `
"Cross-module/broader/full repository suite и официальный acceptance выполняются Owner/Tech Lead/Central Lab, а не Coder. После успешного gate на неизменённом exact artifact его не повторяют без новой причины. Отдельный Linux production-compatible gate не считается дублированием, когда он требуется как platform-specific release acceptance."

# docs/testing.md — detailed source of truth
Replace-Once "docs/testing.md" "Updated: 2026-08-26" "Updated: 2026-08-28`nCentral Lab governance effective: 2026-08-27"

$TestingResponsibility = @'
## Responsibility model

`AGENTS.md` is the universal entry contract. This document is the detailed testing authority.

The current project model is:

```text
Coder / executor
→ minimal TASK/module-scoped automated tests
→ tests created/changed for the implementation
→ exact candidate / patch

Tech Lead
→ defines exact artifact, official gate procedure/commands and acceptance criteria

Owner
→ physical operator of C:\CaptivPortal-Lab
→ prepares/verifies exact Lab artifact
→ physically launches official regression

Owner + Tech Lead
→ analyze evidence
→ PASS / FAIL / return to Coder
```

Cross-module regression, broader regression, full repository suite, release gate, differential baseline/candidate gate and official acceptance are outside Coder test execution.

### Coder / executor

The Coder keeps both the right and the responsibility to perform the **minimum local automated verification of the work being implemented**.

Allowed Coder verification:

- focused tests for the module/component changed by the TASK;
- the minimum TASK-scoped set needed for local self-check;
- tests for files/classes/scenarios directly affected by the change;
- regression cases created with the implementation;
- repeated local runs of those same TASK/module-scoped tests during development/fixes;
- relevant static/syntax/frontend checks;
- `git diff --check`.

Coder may create and modify automated tests that belong to the implemented change.

Coder must **not** independently expand execution to:

- unrelated modules;
- cross-module regression;
- broader regression;
- full `pytest` / full repository suite;
- release gate;
- differential baseline/candidate gate;
- official acceptance.

If a required proof test crosses the TASK/module boundary, exactly two normal paths exist:

1. Coder identifies the additional test/gate and requests Owner/Tech Lead/Central Lab execution.
2. Coder implements or prepares the required cross-module/regression test, but does **not** execute it; execution remains Owner/Tech Lead/Central Lab responsibility.

### Tech Lead / Reviewer

The Tech Lead normally verifies architecture, TASK/ADR conformance, implementation boundaries/DIFF, contracts, risk, Coder focused evidence and whether changed tests cover the intended behavior.

The Tech Lead owns the technical direction of broad/system testing: exact artifact, gate procedure/commands, acceptance criteria and evidence analysis. The Owner is the default physical Central Lab operator.

Owner / Tech Lead / Central Lab own:

- cross-module regression;
- broader regression;
- full `pytest` / full repository suite;
- release gate;
- differential baseline/candidate gate;
- official PASS / FAIL and acceptance.

### Central Lab ownership rule

**CURRENT governance state, effective 2026-08-27.**

`C:\CaptivPortal-Lab` and the official full repository regression cycle are controlled exclusively by **Owner / Tech Lead**.

```text
Tech Lead
→ exact artifact
→ gate procedure / commands
→ acceptance criteria
→ evidence analysis

Owner
→ physical Lab operator
→ prepares / verifies C:\CaptivPortal-Lab exact artifact
→ launches official regression
→ captures raw result/evidence

Owner + Tech Lead
→ PASS / FAIL / return to Coder
```

Coder is not an operator of the official Central Lab gate.

Coder may touch `C:\CaptivPortal-Lab` only after an explicit Owner/Tech Lead prep-only instruction, for example to prepare an exact candidate, patch a specified Lab working directory, or place required artifacts. After that preparation Coder stops; the official cycle returns to Owner/Tech Lead **before execution**.

Coder-run focused/module tests are development evidence, never the official repository regression gate.

A successful full gate on an unchanged exact artifact must not be duplicated merely for formality.
'@
Replace-Section "docs/testing.md" "## Responsibility model" "## Official Windows Local Gate" $TestingResponsibility

Replace-Once "docs/testing.md" `
"``````text`nC:\CaptivPortal-Lab\lab-test-v4-fixed.cmd`n``````" `
"``````text`nC:\CaptivPortal-Lab\lab-test-v4-fixed.cmd`n```````n`nThis is an Owner-operated official Lab tool. Tech Lead directs the exact-artifact gate; Owner physically runs it. Coder does not execute it as the official gate."

# docs/agents/workflow.md
Replace-Once "docs/agents/workflow.md" "Updated: 2026-08-26" "Updated: 2026-08-28`nCentral Lab governance effective: 2026-08-27"

$WorkflowVerification = @'
## 4. Verification responsibility

### Coder / executor

Runs only minimum task-scoped verification:

- focused tests for changed modules/components;
- the minimum TASK-scoped automated set needed for local self-check;
- new regression tests belonging to the implementation;
- repeated runs of those same targeted tests during implementation/fixes;
- relevant static/syntax/frontend checks;
- `git diff --check`.

Coder may create/change tests belonging to the implementation.

Coder does not execute unrelated-module, cross-module, broader or full repository regression. If such proof is needed, Coder requests Owner/Tech Lead/Central Lab execution or prepares the test without running it.

### Tech Lead / Reviewer

Reviews architecture, TASK/ADR conformance, DIFF, contracts, risk and the Coder's focused test evidence.

The Tech Lead owns technical direction of cross-module/broader/full testing and acceptance. The Owner is the default physical Central Lab operator.

### Central Lab

Canonical ownership is in `../testing.md`.

```text
Coder → TASK/module-scoped tests only
Tech Lead → exact artifact / commands / criteria
Owner → physical C:\CaptivPortal-Lab preparation + official execution
Owner + Tech Lead → evidence analysis + PASS/FAIL
```

Cross-module regression, broader regression, full repository suite, release/differential gates and official acceptance are not delegated to Coder.

### Linux pre-production

When production acceptance requires Linux/production-compatible execution, that is a separate exact-artifact gate defined by the deploy/release contract. Windows Local Gate does not replace it.

Detailed policy and current Windows V4 baseline: `../testing.md`.
'@
Replace-Section "docs/agents/workflow.md" "## 4. Verification responsibility" "## 5. Promotion flow" $WorkflowVerification

$WorkflowPromotion = @'
## 5. Promotion flow

Normal flow:

```text
Coder implementation
→ minimal TASK/module test evidence
→ exact candidate / patch
→ Tech Lead review
→ Tech Lead defines broader/full gate when required
→ Owner prepares/verifies C:\CaptivPortal-Lab exact artifact
→ Owner physically launches official Central Lab regression
→ Owner + Tech Lead analyze evidence and issue PASS/FAIL
→ owner/release decision
→ separate Linux production-compatible gate when required
→ deploy/activation
```

Do not repeat an identical test run unless the rerun supplies new evidence: changed artifact, new risk, different platform, investigation or explicit release requirement.
'@
Replace-Section "docs/agents/workflow.md" "## 5. Promotion flow" "## 6. Repository actions" $WorkflowPromotion
Replace-Once "docs/agents/workflow.md" `
"State exact artifact, files changed, Coder targeted checks, any Central Lab evidence reference, any separate Linux pre-production evidence, actual repository actions, open risks and owner actions. Never claim an operation that was not executed." `
"State exact artifact, files changed, Coder focused/minimal checks, any cross-module test requested or prepared-but-not-run, any prep-only Central Lab action explicitly delegated to Coder, Owner/Tech Lead Central Lab evidence reference, any separate Linux pre-production evidence, actual repository actions, open risks and owner actions. Never claim an operation that was not executed."

# docs/agents/task-contract.md
Replace-Once "docs/agents/task-contract.md" "Updated: 2026-08-26" "Updated: 2026-08-28`nCentral Lab governance effective: 2026-08-27"

$TaskScoped = @'
## TASK-scoped test responsibility

Значения относятся только к минимальному тестированию конкретного TASK/изменяемого модуля:

- `agent`: агент создаёт/обновляет и запускает focused/minimal TASK/module tests своего изменения;
- `owner`: агент не запускает назначенные tests и описывает необходимые cases/actions;
- `shared`: TASK делит конкретные TASK-scoped cases/actions;
- `not-applicable`: TASK объясняет, почему TASK-scoped tests не требуются.

`agent` никогда не означает право запуска unrelated-module, cross-module, broader или full repository regression.

Если необходим test вне границ текущего модуля, TASK должен выбрать: `request external execution` или `agent prepares test but does not run it`.

Исторические TASK не переписываются только из-за новой governance-модели; current rule имеет приоритет для новых execution handoff.
'@
Replace-Section "docs/agents/task-contract.md" "## TASK-scoped test responsibility" "## Official full regression" $TaskScoped

$OfficialRegression = @'
## Official full regression

Официальный cross-module/broader/full regression / current baseline / final Test Evidence следует ownership rule из `docs/testing.md`.

TASK должен указать:

```text
fresh Central Lab baseline required: yes/no
exact artifact to validate: <SHA/patch identity when known>
cross-module test needed: yes/no
if yes: external execution OR agent prepares-without-running
Coder Lab preparation delegated: yes/no
if yes: exact prep-only scope
official Lab operator: Owner
gate direction / PASS-FAIL ownership: Tech Lead + Owner
```

TASK не назначает Coder исполнителем official Central Lab gate, broader/full regression или official acceptance.
'@
Replace-Section "docs/agents/task-contract.md" "## Official full regression" "## Linux / production-compatible gate" $OfficialRegression

# docs/agents/handoff.md
Replace-Once "docs/agents/handoff.md" "Updated: 2026-08-26" "Updated: 2026-08-28`nCentral Lab governance effective: 2026-08-27"

$HandoffTests = @'
### TASK-scoped проверки исполнителя

Точные focused/minimal TASK/module/static команды и результат: passed, skipped, failed. Не выполненные проверки — с причиной.

Если для доказательства нужен test вне module/TASK boundary, указать отдельно одно из:

```text
cross-module test requested from Owner/Tech Lead/Central Lab
```

```text
cross-module test prepared by Coder but NOT executed
```

Не писать, что Coder выполнил broader/full regression или official gate.

### Central Lab / official Test Evidence

Указать одно из:

```text
not required for this handoff
pending Owner/Tech Lead Central Lab gate
Coder Lab preparation only: <explicit delegated action>
Central Lab evidence: <artifact/date/result/reference>
```

Coder не заявляет official Central Lab execution или PASS/FAIL. Если Coder получил prep-only доступ к `C:\CaptivPortal-Lab`, handoff перечисляет только подготовительные действия и явно возвращает gate Owner/Tech Lead.

Для official evidence указывать exact artifact, Owner physical execution и Owner + Tech Lead PASS/FAIL.
'@
Replace-Section "docs/agents/handoff.md" "### TASK-scoped проверки исполнителя" "### Linux / production-compatible evidence" $HandoffTests

Replace-Once "docs/agents/handoff.md" `
"    Targeted/module tests:`n    Central Lab full regression: not-run-by-agent / evidence reference / not-required`n    Linux pre-production gate: separate / evidence reference / not-required" `
"    Targeted/module tests:`n    Cross-module/broader test: requested / prepared-not-run / not-required`n    Central Lab preparation: none / explicitly delegated prep-only action`n    Central Lab full regression: not-run-by-agent / Owner+Tech Lead evidence reference / not-required`n    Linux pre-production gate: separate / evidence reference / not-required"

# TASK template
$TaskTemplate5 = @'
## 5. TASK-scoped test responsibility

agent / owner / shared / not-applicable

> `agent` означает только focused/minimal automated tests текущего TASK/модуля. Cross-module/broader/full execution и official acceptance принадлежат Owner/Tech Lead/Central Lab.
'@
Replace-Section "docs/tasks/TASK-template.md" "## 5. TASK-scoped test responsibility" "## 6. Текущее состояние" $TaskTemplate5

$TaskTemplate24 = @'
## 24. Cross-module / broader / full regression

Указать:

```text
cross-module test needed: yes/no
if yes: external execution OR agent prepares-without-running
fresh Central Lab baseline required: yes/no
exact artifact: <SHA/patch identity when known>
Coder Lab preparation delegated: yes/no
if yes: exact prep-only action
official Lab operator: Owner
gate direction / PASS-FAIL: Tech Lead + Owner
```

Не назначать Coder исполнителем cross-module/broader/full regression или official Central Lab gate.
'@
Replace-Section "docs/tasks/TASK-template.md" "## 24. Official full regression / Central Lab" "## 25. Linux / production-compatible gate" $TaskTemplate24

# PLAN template
$PlanTests = @'
## Targeted/module tests исполнителя

Только focused/minimal TASK/module execution.

## Cross-module / broader / Central Lab

```text
cross-module test: requested externally / prepared-not-run / not-required
Central Lab: required / not-required
exact artifact/evidence reference
Coder Lab preparation delegated: yes/no + exact prep-only scope
official Lab operator: Owner
gate direction / PASS-FAIL: Tech Lead + Owner
```
'@
Replace-Section "docs/plans/PLAN-template.md" "## Targeted/module tests исполнителя" "## Linux / production-compatible gate" $PlanTests

# deployment
$DeploymentTesting = @'
## Testing responsibility

Coder focused/minimal TASK/module evidence is reused by Tech Lead and the release process. Coder does not execute cross-module/broader/full regression as part of implementation handoff.

The official cross-module/broader/full-regression baseline / Full Regression Gate / final Test Evidence follows `docs/testing.md`: Tech Lead defines the exact artifact, commands and acceptance criteria; Owner physically operates `C:\CaptivPortal-Lab` and launches the official regression; Owner + Tech Lead issue PASS/FAIL.

Before production deployment/activation, the release owner decides whether the exact artifact requires a fresh Central Lab gate and whether a separate Linux/production-compatible gate is mandatory. Official gate execution is not delegated to Coder.

The Windows Local Gate does **not** replace Linux acceptance when the deploy contract requires Linux. The Linux gate is executed separately by the executor named by the deploy/release TASK; it is not automatically Coder or Tech Lead responsibility.
'@
Replace-Section "docs/deployment.md" "## Testing responsibility" "## Feature activation" $DeploymentTesting

Write-Host "=== SCOPE / CONTRADICTION CHECK ==="

$Actual = @(git -C $Repo status --porcelain | ForEach-Object { $_.Substring(3).Trim() } | Sort-Object -Unique)
$ExpectedPaths = @($Allowed | Sort-Object -Unique)

Write-Host "Changed files:"
$Actual | ForEach-Object { Write-Host "  $_" }

if (($Actual -join "`n") -ne ($ExpectedPaths -join "`n")) {
    throw "STOP: changed-file scope mismatch"
}

$Stale = @(
    "A TASK may explicitly require an exceptional broader run",
    "Exceptional broader/full run in agent workflow",
    "The Coder does not run the whole CaptivPortal regression suite by default."
)

foreach ($Needle in $Stale) {
    $Hit = git -C $Repo grep -n -F -- "$Needle" -- $Allowed 2>$null
    if ($LASTEXITCODE -eq 0 -and $Hit) {
        Write-Host $Hit
        throw "STOP: stale governance phrase remains: $Needle"
    }
}

$MustHave = @(
    "Coder may create and modify automated tests that belong to the implemented change.",
    "cross-module/regression test, but does **not** execute it",
    "physical operator of C:\CaptivPortal-Lab",
    "official PASS / FAIL and acceptance"
)

foreach ($Needle in $MustHave) {
    $Hit = git -C $Repo grep -n -F -- "$Needle" -- docs/testing.md
    if ($LASTEXITCODE -ne 0 -or -not $Hit) {
        throw "STOP: required canonical phrase missing from docs/testing.md: $Needle"
    }
}

git -C $Repo diff --check
if ($LASTEXITCODE -ne 0) { throw "STOP: git diff --check failed" }

Write-Host "PASS: 10-file governance scope"
Write-Host "PASS: contradiction guards"
Write-Host "PASS: canonical ownership assertions"
Write-Host "PASS: git diff --check"

Write-Host "=== STAGE / COMMIT ==="
git -C $Repo add -- $Allowed
if ($LASTEXITCODE -ne 0) { throw "STOP: git add failed" }

git -C $Repo diff --cached --check
if ($LASTEXITCODE -ne 0) { throw "STOP: staged diff check failed" }

git -C $Repo commit `
    -m "docs: canonicalize Central Lab testing ownership" `
    -m "Coder runs focused/minimal TASK-module tests; Owner/Tech Lead/Central Lab own cross-module, broader, full regression and official acceptance."
if ($LASTEXITCODE -ne 0) { throw "STOP: commit failed" }

$Commit = (git -C $Repo rev-parse HEAD).Trim()

Write-Host "=== PUSH ==="
git -C $Repo push -u origin $Branch
if ($LASTEXITCODE -ne 0) { throw "STOP: push failed" }

Write-Host "=== CREATE DRAFT PR ==="
gh auth status
if ($LASTEXITCODE -ne 0) { throw "STOP: gh auth unavailable" }

$Body = @"
## Purpose

Canonicalize CaptivPortal testing ownership effective 2026-08-27.

### Coder
- runs focused/minimal automated tests only inside the current TASK/module scope;
- may create/change tests belonging to the implementation;
- does not execute unrelated-module, cross-module, broader or full repository regression;
- if cross-module proof is needed, requests external execution or prepares the test without running it.

### Owner / Tech Lead / Central Lab
- own cross-module and broader regression;
- own full pytest / full repository suite;
- own release and differential baseline/candidate gates;
- own official PASS/FAIL and acceptance.

### Central Lab physical ownership
- Tech Lead defines exact artifact, commands/gate procedure and acceptance criteria.
- Owner physically operates `C:\CaptivPortal-Lab` and launches the official regression.
- Owner + Tech Lead analyze evidence and issue PASS/FAIL/return-to-coder.
- Coder may patch the Lab directory only under an explicit prep-only instruction and stops before official execution.

## Scope
10 governance/documentation files only.
No runtime code changes.
No test-code changes.
No production changes.
Historical FINAL TASKs and reports are unchanged.

Base: `$Expected`
Commit: `$Commit`

Created as Draft. Merge remains Owner-controlled.
"@

$PrUrl = gh pr create `
    --repo $GhRepo `
    --base main `
    --head $Branch `
    --title $Title `
    --body $Body `
    --draft

if ($LASTEXITCODE -ne 0) { throw "STOP: Draft PR creation failed" }

Write-Host "=== FINAL ==="
Write-Host "Branch: $Branch"
Write-Host "Commit: $Commit"
Write-Host "Draft PR: $PrUrl"
Write-Host "Changed files: 10 governance/documentation files only"
Write-Host "Runtime code changed: NO"
Write-Host "Test code changed: NO"
Write-Host "Production changed: NO"
Write-Host "git diff --check: PASS"
Write-Host "Merge performed: NO"
