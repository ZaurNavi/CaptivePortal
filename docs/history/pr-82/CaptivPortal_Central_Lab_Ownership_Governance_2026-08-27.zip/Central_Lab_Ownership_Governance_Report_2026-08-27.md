# CaptivPortal — Central Lab ownership governance update

**Governance effective:** 2026-08-27
**Patch prepared against:** `main@f5887758898b512747d2ea8bd51763389230dc2d`
**Type:** documentation / governance only

## Canonical source

`docs/testing.md` remains the single detailed source of truth because it already declares itself the detailed testing authority.

`AGENTS.md` remains the universal mandatory entry contract.

`docs/README.md` already routes `Testing responsibility/gates` to `testing.md`; no new governance document or README duplication is introduced.

## Canonical ownership

- Tech Lead: exact artifact, official gate procedure/commands, acceptance criteria, evidence analysis.
- Owner: physical operator of `C:\CaptivPortal-Lab`; prepares/verifies the exact Lab artifact and physically launches the official regression.
- Owner + Tech Lead: official PASS / FAIL / return-to-coder.
- Coder: TASK/module-scoped tests and exact candidate/patch.
- Coder may touch the Lab directory only for an explicit prep-only assignment and must return control before official gate execution.

## Files changed

1. `docs/testing.md` — canonical detailed ownership rule.
2. `AGENTS.md` — mandatory short enforcement summary.
3. `docs/agents/workflow.md` — actor-explicit promotion flow.
4. `docs/agents/task-contract.md` — TASK cannot delegate official Lab gate to Coder.
5. `docs/agents/handoff.md` — evidence attribution and prep-only handoff.
6. `docs/tasks/TASK-template.md` — future TASK fields enforce ownership.
7. `docs/plans/PLAN-template.md` — future PLAN fields enforce ownership.
8. `.github/instructions/tests.instructions.md` — coding-agent path-specific enforcement.
9. `docs/deployment.md` — release/deploy reference to the canonical ownership rule.

## Deliberately not changed

- `docs/README.md`: already points testing governance to `docs/testing.md`.
- root README files: human-facing project overview; governance detail would duplicate source of truth.
- `docs/project-inventory.md`: its current summary does not assign official Lab execution to Coder.
- `docs/agents/repository-actions.md`: repository permissions are a different governance dimension.
- historical TASKs / postmortems / old reports: preserved as historical evidence.

## Contradiction review

Current canonical documents already separated Coder targeted tests from Central Lab full regression, but the physical/operator ownership was ambiguous.

The patch removes that ambiguity:
- no standard workflow can say `Coder run Central Lab`;
- any Coder Lab access is prep-only and explicit;
- official gate launch is Owner physical operation;
- Tech Lead directs the gate;
- PASS/FAIL belongs to Owner + Tech Lead;
- Coder-run broader/full diagnostics never become official Central Lab evidence.

Historical wording is not rewritten; current governance effective date is explicit.

## PR-ready metadata

Suggested branch:
`docs/central-lab-ownership-governance-2026-08-27`

Suggested commit:
`docs: canonicalize Central Lab ownership`

Suggested Draft PR title:
`Docs: canonicalize Central Lab ownership`

Scope:
9 documentation/instruction files only.

Runtime/code changed: NO
Test code changed: NO
Production changed: NO
Merge performed: NO

## Project Instructions

See `Project_Instructions_Central_Lab_Ownership.txt`.

## Verdict

CENTRAL LAB OWNERSHIP RULE — CANONICALIZED: YES
