@echo off
setlocal
title CaptivPortal Lab - Full Test Gate

set "CLEAN=C:\CaptivPortal-UI-Preview"
set "PYTHON=C:\CaptivPortal-UI-Preview\.venv\Scripts\python.exe"
set "PYTHONPYCACHEPREFIX=%TEMP%\captivportal-pyc"

echo ============================================================
echo CaptivPortal Local Lab - FULL TEST GATE
echo ============================================================
echo.
echo Target:
echo   %CLEAN%
echo.

cd /d "%CLEAN%" || goto :error

echo [PRECHECK] Git state
git status -sb
echo.

for /f "delims=" %%A in ('git status --porcelain') do (
    echo ERROR: Clean Main contains local changes.
    echo Tests were not started.
    echo.
    git status --short
    goto :fail
)

if not exist "%PYTHON%" (
    echo ERROR: Python virtual environment was not found:
    echo %PYTHON%
    goto :fail
)

echo [1/3] pytest
"%PYTHON%" -m pytest -q -rs
if errorlevel 1 goto :testfail

echo.
echo [2/3] compileall
"%PYTHON%" -m compileall -q app
if errorlevel 1 goto :testfail

echo.
echo [3/3] git diff --check
git diff --check
if errorlevel 1 goto :testfail

echo.
echo ============================================================
echo PASS: FULL LOCAL TEST GATE
echo ============================================================
echo.
git status -sb
echo.
pause
exit /b 0

:testfail
echo.
echo ============================================================
echo FAIL: FULL LOCAL TEST GATE
echo ============================================================
echo See the failing command above.
echo.
pause
exit /b 1

:error
echo.
echo ERROR: Could not enter Clean Main:
echo %CLEAN%
echo.
pause
exit /b 1

:fail
echo.
pause
exit /b 1
