CaptivPortal Central Lab Testing Ownership publisher V2

Fix:
- handles a non-existent local branch without calling .Trim() on $null;
- handles a non-existent remote branch as an empty result;
- preserves exact origin/main guard, clean-tree guard, 10-file scope guard,
  governance contradiction checks, git diff --check, commit/push and Draft PR creation;
- performs no merge.

Expected baseline:
f5887758898b512747d2ea8bd51763389230dc2d

Expected branch:
docs/central-lab-testing-ownership-2026-08-27
