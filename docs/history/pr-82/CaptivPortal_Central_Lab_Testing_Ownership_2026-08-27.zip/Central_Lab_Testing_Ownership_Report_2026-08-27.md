# CaptivPortal — Central Lab testing ownership governance update

**Effective current governance:** 2026-08-27
**Prepared against:** `main@f5887758898b512747d2ea8bd51763389230dc2d`
**Type:** documentation / governance only

## Canonical source

`docs/testing.md` remains the single detailed testing authority.

`AGENTS.md` remains the universal mandatory entry contract.

No new duplicate governance document is introduced.

## Corrected rule

Coder is not test-disabled.

Coder runs the minimum automated verification of the implementation inside the current TASK/module boundary and may create/change tests belonging to that implementation.

Coder does not execute:
- unrelated-module tests;
- cross-module regression;
- broader regression;
- full repository suite;
- release/differential gates;
- official acceptance.

If cross-module proof is required:
1. request execution by Owner/Tech Lead/Central Lab; or
2. prepare/implement the test without executing it.

Central Lab ownership:
- Tech Lead: exact artifact, commands/procedure, acceptance criteria;
- Owner: physical operator of `C:\CaptivPortal-Lab`, official execution;
- Owner + Tech Lead: evidence analysis, PASS/FAIL/return-to-coder.

## Changed files

- `.github/copilot-instructions.md`
- `.github/instructions/tests.instructions.md`
- `AGENTS.md`
- `docs/agents/handoff.md`
- `docs/agents/task-contract.md`
- `docs/agents/workflow.md`
- `docs/deployment.md`
- `docs/plans/PLAN-template.md`
- `docs/tasks/TASK-template.md`
- `docs/testing.md`

## Deliberately not changed

- historical FINAL TASKs and old reports;
- runtime/application code;
- automated test code;
- production configuration;
- architecture/business logic.

## Contradiction resolution

The previous current KB already allowed Coder targeted/module tests but still contained language allowing an exceptional broader/full Coder-side run. That allowance is removed.

Future TASK/PLAN templates now force cross-module tests to be either externally executed or prepared-without-running.

Copilot adapter now carries the same concise boundary.

## Project Instructions block

See `Project_Instructions_Central_Lab_Testing_Ownership.txt`.

## Publication

A fail-closed publisher is included. It requires exact `origin/main@f5887758898b512747d2ea8bd51763389230dc2d`, a clean worktree, changes only the listed governance files, runs `git diff --check`, commits/pushes a dedicated branch and creates a Draft PR. It never merges.

CENTRAL LAB OWNERSHIP RULE — CANONICALIZED: YES
CODER MINIMAL TASK/MODULE TEST EXECUTION — CANONICALIZED: YES
