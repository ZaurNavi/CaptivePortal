# CaptivPortal — NI-02B Core V2 + NI-04 Dev Reset
## Operator-only staged reset / activation runbook v1

**Date:** 2026-10-14 (Asia/Baku)  
**Status:** `RUNBOOK DRAFT — NOT AUTHORIZED FOR EXECUTION`  
**Owner intent:** discard NI-02B/NI-04 experimental history (including ~160k old pending) rather than migrate/replay it; preserve upstream authority and guest production operations.  
**Precondition:** Coder V2 PR independently accepted/merged; exact new release SHA/TREE and tested staging/reset helper available. **Nothing in this runbook is a request to execute now.**

## 0. Authorization / execution gates

```text
ARCHITECT_NARROW_EXCEPTION  = APPROVED
TECHLEAD_CODE_ADMISSION     = PENDING
OWNER_CODE_DEPLOY_GO        = NOT_GRANTED
OWNER_DESTRUCTIVE_RESET_GO  = NOT_GRANTED
OWNER_NI04_SERVE_GO         = NOT_GRANTED
PROD_ACTIONS               = HOLD
```

Require distinct recorded actions:

1. **`GO_DEPLOY_CODE`** — approve deploying tested V2-compatible code, without activation against old V1 DBs.
2. **`GO_NI02B_NI04_RESET`** — Owner approves **exact resolved destructive paths**, current physical capture scope and a maintenance reader-drain plan. This consent is separate from agreeing that old data lack value.
3. **`GO_NI04_SERVE`** — after bounded shadow/new-data check, approve Admin/worker serve.

No implicit permission from this document, from a successful CI run, or from ownership of the historical data.

## 1. Pinned baseline, known host and reserved paths

At architecture review on 2026-10-14, read-only checks confirmed:

```text
HOST                         192.168.0.202 (Ubuntu)
PRODUCTION_HEAD              f324c1e157b71802acda14a797c0e0f6747b6276
PRODUCTION_TREE              cbe9ac1d3efed53a3d66b60915b9f1c21e7caa5c
BASE_TRACKED_DIRTY           0
OLD_NI02B_CORE               V1 + Service Extension V1
OLD_NI04_MATERIALIZATION     V1, mode serve
NI02B_WRITER_UNIT            network-metadata-projection.service
NI04_WRITER_UNIT             network-service-recognition.service
PORTAL_UNIT                  captive-portal.service
NI01_WRITER_UNIT             network-metadata.service
```

**Do not use this old SHA as the new release SHA.** Before deployment record actual new `main`/release HEAD+TREE and systemd effective `ExecStart`, env paths, owner/user, drops and restart policies. If these differ from the admitted Coder candidate: `HOLD_BASELINE_MISMATCH`.

### EXACT ALLOWLIST FOR DESTRUCTION (resolve from effective config)

```text
NI02B_DB = value of NETWORK_METADATA_PROJECTION_DB_PATH
  default /opt/CaptivePortal/data/network_metadata_projection.sqlite3
NI04_DB  = value of NETWORK_SERVICE_MATERIALIZATION_DB_PATH
  default /opt/CaptivePortal/data/network_service_intelligence.sqlite3
```

Only after safe quiescence may the operator replace the *two selected* SQLite database file groups (`DB`, `-wal`, `-shm`, `-journal`), using the admitted paired-staging helper. The `.writer.lock` files are coordination objects; **do not remove a held lock**. They are not a license to overwrite a live database.

**KEEP / NEVER DELETE OR MODIFY:**

```text
NETWORK_METADATA_DB_PATH (NI-01 observations)
NETWORK_ATTRIBUTION_DB_PATH (NI-02A DHCP authority, often under /var/lib/captive-portal/fingerprint-sensor/)
VISITOR_REGISTRY_DB_PATH (Visitor Registry)
CaptivPortal Auth/session/visit stores, CAPPORT, Omada Controller,
Admin Settings/credentials, main Portal records,
Fingerprint capture/evidence, Suricata producers,
traffic-projection/current-state databases and all unrelated stores
```

Do not recursively remove `/opt/CaptivePortal/data` or the fingerprint-sensor data directory. No historical backup is a required gate; **accuracy of the wipe allowlist is a gate**.

## 2. G0 — Read-only preflight and admission evidence

Operator collects a written `NI02B_V2_DEVRESET_EXECUTION_MANIFEST`:

- exact new code HEAD/TREE, Coder PR/test/admission and build/runtime identity, detached/base comparisons;
- effective realpaths, filesystem/mount, mode, owner and sizes of the 2 writable DBs plus sidecars; verify there are no aliases/symlinks/hardlink overlaps with KEEP paths and no unexpected SQLite attachment consumers;
- current MainPIDs, restart policies, and open file handles for **both** DBs **and sidecars** from NI-02B, NI-04, CaptivPortal/NI-03 Admin readers, plus any other process; record drain approach;
- current NI-01 source generation count, source version, NI-02A version/authority, Site/network scope, capture pre-NAT topology and `CaptureScopeBinding` identity/digest + exact guest CIDRs + event-time valid-from;
- Owner/SysAdmin acceptance of this **physical pre-NAT** placement. `within_intended_scope` alone is not enough; changed NAT, unmatched scope or ambiguous Site → `HOLD_SCOPE_ADMISSION`;
- disk pressure and free space for **two fresh staging DBs** + WAL headroom; no unbounded copy of the old 1.3 GB/NI-04 files;
- Admin `/admin/login` HTTPS and Portal/Guest/Auth/CAPPORT control smoke before any change; current IP/cookies/identity not recorded in logs;
- no unwanted scheduled restart/automation that could reopen either store mid-reset.

**Gate G0 PASS** only with exact SHA, typed scope proof, unique file identities, ability to quiesce all DB consumers and explicit Owner `GO_DEPLOY_CODE` and `GO_NI02B_NI04_RESET`. `HOLD` if any required proof is missing. This runbook does not imply a 24-hour data migration or backup.

## 3. G1 — Code staging; no writer against wrong Core version

- Deploy/build all **mutually compatible** V2 modules and extension V1/NI-04 interop, with deployment-level `NI-02B writer` and `NI-04 worker` held **OFF** until replacement stores are ready.
- Old V1 Core + new V2 code must be rejected by exact signatures. Existing runtime process binaries and long-lived readers must not silently mix V1/V2 against one store.
- If Admin needs a temporary read-disable: disable the NI-03 and Service Intelligence *features*, not merely change `serve -> off` (off/shadow may compose legacy readers). Admin may display `unavailable` during the window, but **must not show old data as fresh**.
- Keep guest authentication/CAPPORT available. A Portal restart is **not** authorized merely to simplify deletion; if no safe reader-drain mechanism exists, request Owner's separate short controlled Portal-reader window or `HOLD_READERS`.

## 4. G2 — Quiescent barrier; NI writers only

**Order:**

1. Stop NI-04 writer (`network-service-recognition.service`); verify inactive, PID exited, no child writer or auto-restart in progress.
2. Stop NI-02B writer (`network-metadata-projection.service`); verify inactive, PID exited, single-writer lock released.
3. Disable/drain NI-03 and NI-04 **reader paths** from Portal/Admin and other known consumers. Verify absence of all open descriptors for DB, WAL, SHM and journal; repeat check after a short quiet interval. Do not assume a transient reader is absent just because one `lsof` snapshot is empty.
4. If any known/future connection can race with replacement, fail with `HOLD_READER_DRAIN` and leave old stores intact/offline; request explicit owner window rather than unlinking an in-use database.

**KEEP RUNNING:** NI-01 writer, NI-02A/sensor, Omada, Visitor Registry, guest Portal Auth/CAPPORT. Admin NI widgets may be unavailable, not falsely healthy. Do not run cleanup command yet.

## 5. G3 — Single NI-01 read snapshot / reset boundary

- With NI-02B stopped and NI-01 still running, invoke the **tested read-only snapshot helper** under a single NI-01 SQLite transaction. Capture all existing source generation IDs and each generation's **last retained normalized observation identity and offset**, plus exact generation/source/binding lineage.
- Persist an auditable reset epoch, scope admission digest, source snapshot identity and per-generation **discard floors** in new V2 staging DB. The floors **do not indicate processed observations**.
- Verify that the **first new event after snapshot** (including append to an existing generation) has an offset greater than its captured last normalized observation and will be selected. New generations start naturally; an empty generation has an explicit null tail, never guessed file length.
- If the source changed beyond assumptions, the snapshot cannot be made consistent, or the source binding changed to an unadmitted digest: `HOLD_SOURCE_FLOOR` with no replacement. NI-01 is not edited or reset.

**No reuse** of the old `projection_source_checkpoints`; do not seed them from floors or advance them to an invented timestamp.

## 6. G4 — Offline prepare and atomic-within-each-store validation

Use the **Coder-supplied tested offline bootstrap**, with a staging directory on the appropriate filesystem and no production activation:

1. Initialize Core V2 exactly (`user_version=2`, `schema_version=2`, projection_contract=2, algorithm V2, new reset-floor table, empty processed checkpoints/edges/pending). Persist reset metadata and admitted scope matching G3.
2. Install/validate **Service Extension V1** against this **new** Core V2 staging schema; empty feed and binding-change index.
3. Initialize fresh **NI-04 V1** store with empty materialization generation/rollups/jobs/cursors; no stale old client data.
4. Read-only **independent validation** of each staged DB: exact `sqlite_master` signatures, `PRAGMA quick_check='ok'`, zero `foreign_key_check` findings, metadata/DB version, floor integrity, no old pending, no pre-reset service positives and cross-pair reset manifest consistency.
5. Hash every staged file, record exact staging paths + resolved target paths, owner/mode, complete floor list digest and reset epoch in `PREPARED` manifest; securely sync/finalize staging. Do not include raw endpoint/IP/MAC/SNI in output.

If any test fails, stop at `HOLD_STAGING`; do **not** remove a running/old DB, do not start V2 worker.

## 7. G5 — Destructive paired switch (separate Owner GO only)

**This is the sole destructive stage. It is not executable until `GO_NI02B_NI04_RESET` is on record and Coder reset helper passed tests.**

- Revalidate G2 quiescence **immediately** before action and exact G0 allowlist; record `PREPARED` manifest. Lock against a second operator/reset instance.
- Replace the **two exact** SQLite file groups using the admitted helper; never `rm -rf` a directory or remove an open SQLite WAL file. The old derived history is disposable, so no historical backup/replay is required.
- A pair of SQLite DB file swaps is **not transactional across files**. Keep *all NI dependent readers and writers stopped/disabled* until the pair matches the same manifest: state `REPLACED_NOT_STARTED` is a strict offline barrier.
- Crash/power-loss after first replacement: **do not start anything**. On recovery, verify current manifest, recreate/replace *both* fresh DBs deterministically from a new consistent NI-01 reset snapshot if required, and proceed only after both validate. Do not mix one old and one new store.
- Independently re-check schema/FK/quick_check, epoch/floors, empty feed/cursors/rollups, and **protected DB realpaths/inode identities** before any NI startup. Log the manifest state `VERIFIED` only after this passes.
- No opportunistic `VACUUM`, forced WAL checkpoint of active NI-01/02A stores, or changes to SQLite synchronous/durability settings.

## 8. G6 — Start readers/writers in version-safe order

1. Start **NI-02B V2 writer first** using ONLY the pair-verified fresh V2 projection DB. Ensure no one-time V1 install flag was accidentally carried over. Assert exact V2+Extension V1 signature and startup PID/error-free state. Verify real new NI-01 observations **after floors** create authentic processed checkpoints; no pre-reset replay, no false old pending. New feed can start at its own fresh sequence.
2. Start **NI-04 worker in `shadow`**, pointed at exactly the fresh matching NI-04 DB and V2 projection extension. Observe one bounded backfill of **new-only** evidence, cursor/highwater convergence, new generation promotion and full source/identity/positive-materialization validation. Do not import old rollups or replay jobs.
3. Re-enable NI-03/NI-04 Admin query paths in the admitted version-safe mode; enforce reader version gating. Allow empty cards until actual post-reset evidence is collected; return `unavailable` if the source/worker is still unavailable.
4. **Only on separate Owner `GO_NI04_SERVE`**, use a controlled Admin/worker configuration transition to `serve`, restarting only required long-lived readers and verifying HTTPS/Admin/Guest/Auth/CAPPORT independently. Do not publish old materialized facts or fallback to pre-V2 recognition readers.

If a writer fails: stop NI-04 if running; present `unavailable` to NI users, preserve Portal guest auth, inspect and repair *new V2* or repeat the separately authorized clean reset. **Never** rollback to old Core V1 code against Core V2 DBs.

## 9. G7 — Short 15-minute live acceptance

Precondition: tested Owner-controlled client (stable MAC), verified pre-NAT Site/capture scope, NI-01/02A healthy enough to provide evidence; no production visitors/employee device perturbation.

Capture baseline at start and every bounded interval in this 15-minute window:

| Metric | Expected evaluation |
|---|---|
| Trusted outside-peer NI-02A lookups | **Exactly zero per endpoint**; instrument/test counter keyed by classification only, no identifying payload. |
| Trusted outside-peer pending roles | **Exactly zero** on **new** records. |
| Guest in-scope pending | May remain non-zero where real DHCP coverage is missing; identify true reason and monitor trend. |
| NI-02B source poll lag | p95 and trend reported; no pretending healthy if stale beyond configured freshness. |
| NI-02B edge/feed count | New authentic guest-bound edges and outbound feed candidate appear, no phantom remote Device. |
| NI-04 | Backfill `complete`, active generation, highwater equals committed cursor under stable load, positives only from new records. |
| NI-03 / NI-04 cards | V1 protocol and V3 service public responses; honest `degraded/limited` on real gaps. |
| HDD | `iostat` IOPS/await/%util and `/proc/pressure/io`; compare with pre-reset baseline, do not assert full cure without differential. |
| Portal/Auth/CAPPORT/Omada | Existing guest authorization/HTTPS unaffected, no security errors or unexpected restarts. |

**Fix PASS** is scoped: outside-guest endpoint exclusion holds, genuine guest gaps are not masked, no old source history replay, no extra incorrect identity, and version-safe NI clients respond. Overall I/O or all-cards-usable is **not** guaranteed by this fix; file an independent performance issue if physical stalls persist.

**Recovery condition:** fail or regressing test → stop new NI workers and keep NI Admin unavailable, preserve auth/other stores, record evidence, request a new authorization for next reset/forward repair. No silent old Core V1 rollback.

## 10. Final operator checklist / evidence bundle

```text
[ ] G0 SHA/TREE/config/scope/DB allowlist/KEEP proof
[ ] Explicit GO_DEPLOY_CODE and GO_NI02B_NI04_RESET recorded
[ ] Coder V2 PR, tests, offline bootstrap and read-drain methods accepted
[ ] NI-04 writer stopped, then NI-02B stopped
[ ] All NI02B/NI04 SQLite readers/WAL handles quiesced
[ ] One NI-01 consistent read snapshot with exact discard floors
[ ] Fresh Core V2+Extension V1 and NI04 V1 stage built/validated
[ ] Two-store pair replaced and VERIFIED offline
[ ] NI-02B started; only post-floor events processed
[ ] NI-04 shadow caught up on new data
[ ] Guest Auth/CAPPORT/Admin smoke; NI-03 and NI-04 positive/coverage honesty
[ ] 15-minute natural-load metrics and negative tests recorded
[ ] Separate GO_NI04_SERVE received; serve transition validated
[ ] Closeout includes old pending discarded, no accidental KEEP mutation
```

**Owner priority respected:** no historical recovery, no expensive migration of 160k pending, no compulsory backup, no multi-day shadow gate. **Safety boundary respected:** do not damage the still-authoritative NI-01/NI-02A, Registry, Guest Auth or Omada by deleting broad directories or live SQLite sidecars.
