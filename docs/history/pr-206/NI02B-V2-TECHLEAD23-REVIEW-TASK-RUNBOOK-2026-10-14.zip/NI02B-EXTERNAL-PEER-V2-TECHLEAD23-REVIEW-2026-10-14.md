# CaptivPortal — NI-02B External-Peer V2 / Dev Reset
## TechLead23 Independent Architecture Exception Review

**Date:** 2026-10-14 (Asia/Baku)  
**Status:** `TECHLEAD23_REVIEW = ACCEPTED_WITH_IMPLEMENTATION_GATES`  
**Source:** `NI02B-EXTERNAL-PEER-DEV-RESET-ARCHITECTURE-EXCEPTION-v1.md` (Architect, 2026-10-14)  
**Supersedes only:** the mandatory DHCP attempt for a *trusted, out-of-guest-scope* endpoint in Attribution Recovery Contract v1 §11/§16.  
**GitHub `main` at review:** `f324c1e157b71802acda14a797c0e0f6747b6276`; production verified read-only at same `HEAD`, tree `cbe9ac1d3efed53a3d66b60915b9f1c21e7caa5c`, tracked files clean.  
**Authorization:** documents only. `CODER=HOLD`, `MERGE=HOLD`, `DEPLOY=HOLD`, `DESTRUCTIVE_RESET=HOLD` until their separate owner/Tech Lead approvals.

## 1. Verdict

**ACCEPT** the Architect's narrow frozen-contract exception as sufficient basis to draft an implementation task. No additional change in *desired attribution semantics* is required. The implementation must fail closed on unknown capture scope and preserve authoritative Site+MAC+time DHCP identity for in-scope guest endpoints.

**Do not interpret ACCEPT as code/test acceptance or destructive authorization.** This review does not certify the currently running NI pipeline as healthy and does not override unrelated NI-01, NI-02A, NI-03, NI-04, CAPPORT/Auth, Omada, or Visitor Registry contracts.

### Confirmed source-code facts

| Current code (pinned commit) | Consequence |
|---|---|
| `network_metadata_projection/service.py::_resolve()` tries temporal NI-02A resolution for each present IPv4 endpoint, before deciding peer `local/external` in `_edge()` | The observed external-peer pending scenario is explained by current control flow. |
| `models.py::ATTRIBUTION_STATES`, `schema.py::TABLES` use closed SQLite CHECKs for `peer_attribution_state` and pending snapshot states | A new terminal value cannot safely be inserted into Core V1. |
| `schema.py::validate_core_schema_v1()` and `validate_schema()` compare strict signatures, `user_version=1` and V1 identities | Fresh Core V2 + matching readers/validators is required; no blind compatibility toggle. |
| `projection_source.py::_record()` validates binding digest/Site/source/network scope and generation lineage, but verifies canonical `event_at` without an explicit `event_at >= binding.valid_from_utc` assertion | Add that strict temporal admission proof; do not replace the event-time binding with current env CIDRs. |
| `repository.py::commit_dispositions()` expects its `checkpoint['after']` to equal the *durably processed* checkpoint, and rejects a non-null `after` when the checkpoint is absent | Dev-reset floors require a separate read cursor and an explicit modification of this guard, **not** a forged processed checkpoint. |
| `service_delivery_read_service.py::_candidate()` rejects projection contract !=1 | A V2 projection must update downstream strict acceptance while keeping NI-04 service evidence constraints. |
| `service_extension.py` retains a separately closed Extension Contract V1; NI-04 materialization schema is its own V1 | May retain these extension/materialization contract numbers **only** if exact Core-V2+Extension-V1 validation and cross-reader tests pass. |
| `network_protocol_intelligence` returns its own V1 public DTO | Preserve the NI-03 public API/DTO version; update only its V2 source compatibility. |

## 2. Critical implementation gates (all mandatory)

**G1 — Trusted negative scope must be admitted, not guessed.**

- Pin the exact approved `(site_id, capture_source_id, network_scope_id, capture_scope_binding_digest, IPv4 CIDRs, binding_valid_from_utc)` set for the run. It must originate from a deployment-reviewed **pre-NAT guest DHCP attribution-domain** statement. This is an operator admission, **not** a value inferred from `within_intended_scope` alone.
- Require NI-01 observation generation/source/binding lineage and event time match the pinned entry; unknown/change/mismatch/ambiguous placement → distinct safe fail-closed projection blocker, no Device edge, checkpoint, or invented completeness.
- A non-guest/private/management/router peer need not be called public Internet: its terminal means **guest DHCP not applicable**, no claim about Internet routing.
- In-scope guest endpoint still resolves against NI-02A with exact Site and event time; real gaps remain pending.

**G2 — The new terminal is NI-02B-owned.**

- Required value: `not_applicable_outside_guest_scope`, distinct from `resolved`, `unattributed`, `endpoint_absent`, `unsupported_address_family`, and `unavailable`.
- Do not fabricate this as an NI-02A `NetworkMetadataAttributionResultV1` response. Use an NI-02B-local endpoint outcome/typed internal disposition. Preserve exact proof of any positive edge.
- Assert **zero `resolve_ipv4()` calls for the trusted outside endpoint** and no pending for that role, in new observations **and retry cases**. A guest-side authority horizon read may still occur for the real guest endpoint.

**G3 — New Core V2, all contract readers.**

- Exact fresh Core/Projection V2 schema, algorithm, checkpoint/reset tables, runtime and data validation; V1 DB + V2 code must fail closed and vice versa. `projection_contract_version=2` in schema/run/edge; preserve edge data shape only where justified by tests.
- Preserve NI-04 feed/edge integrity, NI-03 V1 output, NI-04 V3 output, materialized-reader isolation. No silent fallback to V1 or old facts.
- Test extension V1 against new Core V2 exact signatures, all FK/trigger/immutable invariants. Never accept a partially upgraded store.

**G4 — Separate explicit source discard floors.**

- From **one consistent read-only NI-01 SQLite snapshot**, enumerate pre-existing generations and their last *retained normalized observation identities/offsets*; persist durable per-generation reset floors and reset epoch in fresh NI-02B V2.
- `read-after = max(processed_checkpoint, explicit_reset_floor)` only as a source-selection cursor; advancement of `projection_source_checkpoints` means **actually committed processing only**.
- New observations appended after the snapshot to an existing generation must not be skipped; new generations must begin naturally; restart, retention, crash and no-observation-generation cases need deterministic tests.
- Refuse to bootstrap from file byte size, wall-clock cutoff, arbitrary MAX(source offset) of the raw file, or guessed checkpoint.

**G5 — Exactly two owned DB groups, quiescent.**

- Destructive operator scope: NI-02B DB + SQLite sidecars and NI-04 materialization DB + SQLite sidecars **only**, resolved from current effective config.
- **KEEP** NI-01 observations; NI-02A DHCP authority; Visitor Registry; auth/session/CAPPORT; Omada; Admin Settings/credentials; other stores; Suricata/sensor.
- Stop NI-04 writer first, NI-02B writer second, and deliberately drain Admin NI-03/NI-04 readers. Stopping systemd writers alone does not prove SQLite-safe file replacement while Portal still has transient readers.
- Stage and validate both replacement DBs offline before switching them. A two-file switch is **not atomic**; an interrupted or partially switched pair must remain offline until both stores validate as one reset generation. No `unlink` of live WAL/SHM database.
- No mandatory backup/old-pending migration; the owner explicitly accepts loss of the selected derived history. This does **not** authorize deleting any protected DB.

**G6 — 15-minute new-data acceptance.**

- Deterministic tests T01–T11 from owner request plus V2 reset-floor, strict schema, cross-reader and fail-stop negative cases.
- One Owner-controlled guest client and a confirmed pre-NAT scope; 15-minute short natural-load gate, excluding historical data. Outside-guest endpoints: zero NI-02A per-endpoint lookups and zero associated pending.
- Report true guest DHCP gaps, limited DNS/SNI recognition, stale NI-01/02B freshness and physical I/O **separately**. Do not force every card into `usable` or claim I/O recovery without causal measurement.

## 3. Specific cautions / residual risks

1. **Topology proof is manual and time-bound.** Repository source identity alone cannot prove physical switch placement/NAT has not changed. Operator must record positive admission with a durable identity; otherwise block.
2. **NI-02B polling is already disk-bound in production.** Observed source lag was 531 seconds while NI-04 independently caught up with its delivered feed. Fixing peer lookups *may* reduce work; actual improvement is not yet measured. Existing source-health failures remain a distinct problem.
3. **`recognition_state=limited` is not a false-positive defect.** DNS/SNI limitations, genuine guest coverage gaps or stale source can still keep `degraded` after a clean reset; tests must preserve this honesty.
4. **Old code cannot safely read new V2.** After destructive reset, rollback means disable NI readers, repair/redeploy new V2 forward, or repeat authorized clean initialization—not checkout to pre-V2 code against V2 stores.
5. **One-time extension install remains separate from core reset bootstrap unless the new offline bootstrap is explicitly designed, validated and locked.** Do not reuse a live V1 migration procedure on a fresh V2 staging DB by assumption.

## 4. Decision / responsibilities

```text
ARCHITECT_EXCEPTION_REVIEW = ACCEPTED_WITH_IMPLEMENTATION_GATES
BASE_REVIEWED_MAIN_HEAD   = f324c1e157b71802acda14a797c0e0f6747b6276
LIVE_PROD_HEAD            = f324c1e157b71802acda14a797c0e0f6747b6276
LIVE_PROD_TREE            = cbe9ac1d3efed53a3d66b60915b9f1c21e7caa5c
TECHLEAD_IMPL_TASK        = PREPARED_FOR_OWNER_HANDOFF (separate file)
OPERATOR_RESET_RUNBOOK    = PREPARED_FOR_OWNER_REVIEW (separate file)
CODER_AUTHORIZATION       = HOLD
MERGE_AUTHORIZATION       = HOLD
DEPLOY_AUTHORIZATION      = HOLD
DESTRUCTIVE_RESET        = HOLD
```

**References:** Architecture Exception v1, Owner Request v2 (T01–T11), Attribution Recovery Architecture v1 §11/§16, `ZaurNavi/CaptivePortal@f324c1e`, live read-only git verification. The review supplements, rather than replaces, their existing frozen safety/privacy boundaries.
