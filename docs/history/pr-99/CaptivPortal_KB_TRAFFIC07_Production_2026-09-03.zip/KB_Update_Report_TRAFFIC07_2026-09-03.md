# KB Update Report — TASK-TRAFFIC-07

## Canonical implementation / production baseline

- HEAD: `6425988b5b4ec5ff38bf9c67c74846c3806f668f`
- tree: `b669f368b0062fcb100b24758cf05e2c4b500144`
- PR #98: TRAFFIC-07-READ merged
- PR #99: Online Guests Traffic merged
- `WEB_ADMIN_TRAFFIC_ONLINE_GUESTS_ENABLED=true`
- `captive-portal.service=active`

## Canonical status

- `TRAFFIC-07-READ — DONE / READ FOUNDATION IMPLEMENTED`
- `TRAFFIC-07 — COMPLETE / PRODUCTION ACTIVE`

## Updated current-state scope

- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/admin-web.md`
- `docs/modules/analytics.md`
- `docs/modules/traffic.md`
- `docs/project-inventory.md`
- `docs/testing.md`

## Current architecture

`Current State → CurrentStateReadService → CurrentGuestTrafficReadService → AdminQueryService → Admin API → Online Guests Traffic`

Endpoint:
`GET /admin/api/v1/sites/<site_id>/traffic/online-guests/current`

Capability:
`admin.read.devices`

Metric:
`network_traffic_online_guest_current_rate.v1`

Repository default:
`WEB_ADMIN_TRAFFIC_ONLINE_GUESTS_ENABLED=false`

Production:
`WEB_ADMIN_TRAFFIC_ONLINE_GUESTS_ENABLED=true`

## Drift removed

Current KB still listed TRAFFIC-07 as NEXT / NOT IMPLEMENTED and TRAFFIC-07-READ
as CONDITIONAL / NOT IMPLEMENTED. Current baseline still pointed to TRAFFIC-06.

No approved TRAFFIC-08 was found, so this update does not invent a next Traffic
task.
