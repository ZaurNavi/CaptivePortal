# TRAFFIC-07 KB Preservation Remediation V3

## Why V2 stopped

V2 restored the 12 KB files from exact main and then stopped during precheck
because it incorrectly asserted that this generated heading already existed:

`### Previous Traffic acceptance evidence — TRAFFIC-06`

That heading is intentionally created later by renaming:

`### Latest Traffic acceptance evidence`

So the V2 precheck ordering was impossible.

## V3 corrections

1. Removes the impossible generated-heading precheck.
2. Supports the exact dirty working-tree state left by failed V2.
3. Dirty-state recovery is allowed only when:
   - current branch is `docs/traffic07-production-kb-2026-09-03`;
   - local HEAD is `ebaa18621554b41dffe09ae5f12178cbf95d0b13`;
   - every dirty path belongs to the approved 12-file KB scope.
4. Any unrelated local modification causes STOP.
5. Hard-resets the PR branch to its exact remote head before rebuilding.
6. Restores the 12 docs from exact main and applies TRAFFIC-07 additively.
7. Preserves prior Traffic contracts and TRAFFIC-06/RANGE acceptance evidence.
8. Pushes a second remediation commit to existing Draft PR #100.
9. Does not merge.
