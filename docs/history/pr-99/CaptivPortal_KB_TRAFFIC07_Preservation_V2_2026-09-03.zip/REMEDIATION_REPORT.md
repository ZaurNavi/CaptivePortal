# TRAFFIC-07 KB Preservation Remediation V2

PR #100 first commit:
`ebaa18621554b41dffe09ae5f12178cbf95d0b13`

Problem found during live review:
the first documentation reconciliation removed substantial canonical detail from
`docs/modules/traffic.md` and replaced prior deployment/acceptance evidence in
`docs/deployment.md`.

V2 remediation:
1. verifies `main=6425988b5b4ec5ff38bf9c67c74846c3806f668f` / tree `b669f368b0062fcb100b24758cf05e2c4b500144`;
2. verifies PR branch head is exactly `ebaa18621554b41dffe09ae5f12178cbf95d0b13`;
3. restores all 12 KB files from exact main in the working tree;
4. reapplies TRAFFIC-07 changes additively;
5. asserts prior History/Statistics/Peak/Traffic-by-AP/AP-Share contracts remain;
6. asserts TRAFFIC-06/RANGE acceptance evidence remains;
7. adds a second commit to the same PR #100;
8. does not merge.

Expected final status:
TRAFFIC-07-READ = DONE / READ FOUNDATION IMPLEMENTED
TRAFFIC-07 = COMPLETE / PRODUCTION ACTIVE
next Traffic TASK = not assigned
