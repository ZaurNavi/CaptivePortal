﻿$ErrorActionPreference = "Stop"
$PublisherVersion = "TRAFFIC07-KB-FINAL-PRESERVATION-V4-2026-09-03"
Write-Host "Publisher: $PublisherVersion"

$Repo = "$env:USERPROFILE\Downloads\CaptivPortal-KB-Work"
$ExpectedMain = "6425988b5b4ec5ff38bf9c67c74846c3806f668f"
$ExpectedTree = "b669f368b0062fcb100b24758cf05e2c4b500144"
$ExpectedPrHead = "5318bcd7b1ba94b9cf767423f8dcdc64fa075899"
$Branch = "docs/traffic07-production-kb-2026-09-03"

$TestingRel = "docs/testing.md"
$ModuleRel = "docs/module-index.md"

function Decode-Utf8([string]$Value) {
  [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Value))
}
function Read-Lf([string]$Path) {
  [IO.File]::ReadAllText($Path).Replace("`r`n","`n")
}
function Write-Lf([string]$Path,[string]$Text) {
  [IO.File]::WriteAllText($Path,$Text.Replace("`r`n","`n"),(New-Object Text.UTF8Encoding($false)))
}
function Replace-Section([string]$Rel,[string]$Start,[string]$Next,[string]$New) {
  $Path=Join-Path $Repo $Rel
  $Text=Read-Lf $Path
  $Pattern="(?ms)^"+[regex]::Escape($Start.TrimEnd())+"\n.*?(?=^"+[regex]::Escape($Next.TrimEnd())+"\n)"
  $Matches=[regex]::Matches($Text,$Pattern)
  if($Matches.Count -ne 1){throw "STOP: section '$Start' in $Rel matched $($Matches.Count) times"}
  Write-Lf $Path ([regex]::Replace($Text,$Pattern,[System.Text.RegularExpressions.MatchEvaluator]{param($m) $New.TrimEnd()+"`n`n"},1))
}

$TestingOld64 = "IyMgVGVzdCBTZXQgTWFpbnRlbmFuY2UgUnVsZQoKRm9yIHRoZSBjdXJyZW50IFRSQUZGSUMtMDcgc3RhdGUsIHJlbGV2YW50IGNvdmVyYWdlIGluY2x1ZGVzIGF0IG1pbmltdW06CgotIGB0ZXN0cy9hbmFseXRpY3MvdGVzdF9jdXJyZW50X2d1ZXN0X3RyYWZmaWMucHlgOwotIGB0ZXN0cy9hZG1pbl93ZWIvdGVzdF90cmFmZmljX29ubGluZV9ndWVzdHMucHlgOwotIGB0ZXN0cy9hZG1pbl93ZWIvdGVzdF90cmFmZmljX29ubGluZV9ndWVzdHNfZnJvbnRlbmQucHlgOwotIGN1cnJlbnQgZ3Vlc3QgdHJhZmZpYyBjYXBhY2l0eS9QRVJGIGJlbmNobWFyayBjb3ZlcmFnZTsKLSBDdXJyZW50IFN0YXRlIHJlYWQtc2VydmljZSByZWdyZXNzaW9uczsKLSBBZG1pbiBjb25maWcvcm91dGVzL3F1ZXJ5L2NhcGFiaWxpdHkvcGFnaW5hdGlvbiByZWdyZXNzaW9uczsKLSBleGlzdGluZyBUcmFmZmljIHJlZ3Jlc3Npb25zIHByb3ZpbmcgaGlzdG9yaWNhbC9jdXJyZW50IHByb2R1Y3QgaXNvbGF0aW9uLgoKUGVybWFuZW50IGludmFyaWFudHM6Ci0gYEN1cnJlbnRHdWVzdFRyYWZmaWNSZWFkU2VydmljZWAgcmVtYWlucyBzZW1hbnRpYyBvd25lcjsKLSBwZXJzaXN0ZWQgQ3VycmVudCBTdGF0ZSByZW1haW5zIHRoZSBjYWxjdWxhdGlvbiBzb3VyY2U7Ci0gbnVtZXJpYyByYXRlcyByZXF1aXJlIHZhbGlkIGNvdW50ZXIvY29udGludWl0eSBldmlkZW5jZTsKLSBtaXNzaW5nL2Zyb3plbi9yZXNldCBldmlkZW5jZSBtdXN0IG5vdCBmYWJyaWNhdGUgbnVtZXJpYyB6ZXJvOwotIGN1cnNvciBjaGFpbnMgcmVtYWluIGRldGVybWluaXN0aWMgYW5kIGJvdW5kZWQ7Ci0gT25saW5lIEd1ZXN0cyBUcmFmZmljIHJlbWFpbnMgcmFuZ2UtaW5zZW5zaXRpdmU7Ci0gcXVlcnktdGltZSBPbWFkYSBpc29sYXRpb24gcmVtYWlucyBpbnRhY3QuCgpObyBuZXh0IFRyYWZmaWMgVEFTSyBpcyBjdXJyZW50bHkgYXNzaWduZWQuIFdoZW4gb25lIGlzIGFwcHJvdmVkLCBUZWNoIExlYWQKcmV2aWV3cyB0aGUgdGFyZ2V0ZWQgY29tbWFuZC90ZXN0IHNldCBmb3IgdGhhdCBleGFjdCBUQVNLLgo="
$TestingNew64 = "IyMgVGVzdCBTZXQgTWFpbnRlbmFuY2UgUnVsZQoKRXZlcnkgYWNjZXB0ZWQgVEFTSyAvIG1vZHVsZSAvIEFkbWluIHBhbmVsIC8gQVBJIC8gcmVhZC1zZXJ2aWNlIGNoYW5nZSByZXF1aXJlcyBhCmZyZXNoIHJldmlldyBvZiB0aGUgYWN0dWFsIHRlc3Qgc2V0LgoKQ29kZXIgaGFuZG9mZiBtdXN0IGV4cGxpY2l0bHkgbGlzdDoKLSBuZXcgdGVzdCBmaWxlczsKLSBleGlzdGluZyB0ZXN0IGZpbGVzIGNoYW5nZWQ7Ci0gZXhhY3QgZm9jdXNlZC9taW5pbWFsIGNvbW1hbmQ7Ci0gcmVzdWx0IG9mIHRoZSBhbGxvd2VkIGZvY3VzZWQgcnVuLgoKQWZ0ZXIgaW1wbGVtZW50YXRpb24gaGFuZG9mZiwgVGVjaCBMZWFkIC8gQXNzaXN0YW50IFRlY2ggTGVhZCBtdXN0IGRldGVybWluZToKMS4gd2hpY2ggbmV3IHRlc3RzIGJlbG9uZyB0byBUQVNLLWZvY3VzZWQgdmVyaWZpY2F0aW9uOwoyLiB3aGljaCBleGlzdGluZyBtb2R1bGVzIGJlbG9uZyB0byB0YXJnZXRlZCBDZW50cmFsIExhYiByZWdyZXNzaW9uOwozLiB3aGljaCBuZXcgY3Jvc3Mtc3VyZmFjZSBpbnZhcmlhbnRzIGV4aXN0Owo0LiB3aGljaCB0ZXN0IGZpbGVzIGJlbG9uZyBpbiB0aGUgY3VycmVudCB0YXJnZXRlZCByZWdyZXNzaW9uIGNvbW1hbmQ7CjUuIHdoZXRoZXIgdGhlIGZ1bGwgcmVwb3NpdG9yeSB0ZXN0IHNldCBjaGFuZ2VkOwo2LiB3aGV0aGVyIHRoZSBDZW50cmFsIExhYiBydW5uZXIgaXRzZWxmIGNoYW5nZWQsIG9yIG9ubHkgdGhlIHRhcmdldGVkIGNvbW1hbmQvdGVzdCBzZXQgY2hhbmdlZC4KClBlcm1hbmVudCBmbG93OgoKYGBgdGV4dApORVcgTU9EVUxFIC8gUEFORUwgLyBGRUFUVVJFCuKGkiBORVcgT1IgQ0hBTkdFRCBURVNUUwrihpIgVEVDSCBMRUFEIFRFU1QtU0VUIFJFVklFVwrihpIgVVBEQVRFRCBUQVJHRVRFRCBSRUdSRVNTSU9OIENPTU1BTkQK4oaSIENFTlRSQUwgTEFCIEFDQ0VQVEFOQ0UKYGBgCgpEbyBub3Qga2VlcCB1c2luZyBhbiBvbGQgdGFyZ2V0ZWQgY29tbWFuZCBtZXJlbHkgYmVjYXVzZSBpdCB3YXMgY29ycmVjdCBmb3IgdGhlCnByZXZpb3VzIFRBU0suCgpBZGRpbmcgYW4gb3JkaW5hcnkgcHl0ZXN0IGZpbGUgZG9lcyBub3QgYnkgaXRzZWxmIHJlcXVpcmUgZWRpdGluZyB0aGUgZnVsbCBydW5uZXIKd2hlbiBub3JtYWwgZnVsbCBkaXNjb3ZlcnkgYWxyZWFkeSBpbmNsdWRlcyB0aGF0IGZpbGUuCgpDaGFuZ2UgdGhlIENlbnRyYWwgTGFiIHJ1bm5lciBvbmx5IHdoZW4gaXRzIG93biBjb250cmFjdCBjaGFuZ2VzLCBmb3IgZXhhbXBsZToKLSByZXZpZXdlZCBjb21wYXRpYmlsaXR5IGNhc2UvY2xhc3NpZmljYXRpb24gY2hhbmdlczsKLSBhIG5ldyBtYW5kYXRvcnkgYWNjZXB0YW5jZSBwaGFzZTsKLSBjaGFuZ2VkIGlzb2xhdGlvbi9leGVjdXRpb24gbW9kZWw7Ci0gcmVwb3NpdG9yeS90ZXN0LWxheW91dCBhc3N1bXB0aW9ucyBjaGFuZ2U7Ci0gbmV3IG1hbmRhdG9yeSBnYXRlIGVudmlyb25tZW50L2RlcGVuZGVuY3kuCgpOZXZlciBhZGQgYSBuZXcgZmFpbHVyZSB0byBjb21wYXRpYmlsaXR5IG1lcmVseSB0byBvYnRhaW4gYSBncmVlbiBjYW5kaWRhdGUuCgojIyMgQ3VycmVudCBUUkFGRklDLTA3IHRhcmdldGVkIHNldAoKRm9yIHRoZSBjdXJyZW50IFRSQUZGSUMtMDcgc3RhdGUsIHJlbGV2YW50IGNvdmVyYWdlIGluY2x1ZGVzIGF0IG1pbmltdW06CgotIGB0ZXN0cy9hbmFseXRpY3MvdGVzdF9jdXJyZW50X2d1ZXN0X3RyYWZmaWMucHlgOwotIGB0ZXN0cy9hZG1pbl93ZWIvdGVzdF90cmFmZmljX29ubGluZV9ndWVzdHMucHlgOwotIGB0ZXN0cy9hZG1pbl93ZWIvdGVzdF90cmFmZmljX29ubGluZV9ndWVzdHNfZnJvbnRlbmQucHlgOwotIGN1cnJlbnQgZ3Vlc3QgdHJhZmZpYyBjYXBhY2l0eS9QRVJGIGJlbmNobWFyayBjb3ZlcmFnZTsKLSBDdXJyZW50IFN0YXRlIHJlYWQtc2VydmljZSByZWdyZXNzaW9uczsKLSBBZG1pbiBjb25maWcvcm91dGVzL3F1ZXJ5L2NhcGFiaWxpdHkvcGFnaW5hdGlvbiByZWdyZXNzaW9uczsKLSBleGlzdGluZyBUcmFmZmljIHJlZ3Jlc3Npb25zIHByb3ZpbmcgaGlzdG9yaWNhbC9jdXJyZW50IHByb2R1Y3QgaXNvbGF0aW9uLgoKUGVybWFuZW50IFRSQUZGSUMtMDcgaW52YXJpYW50czoKLSBgQ3VycmVudEd1ZXN0VHJhZmZpY1JlYWRTZXJ2aWNlYCByZW1haW5zIHNlbWFudGljIG93bmVyOwotIHBlcnNpc3RlZCBDdXJyZW50IFN0YXRlIHJlbWFpbnMgdGhlIGNhbGN1bGF0aW9uIHNvdXJjZTsKLSBudW1lcmljIHJhdGVzIHJlcXVpcmUgdmFsaWQgY291bnRlci9jb250aW51aXR5IGV2aWRlbmNlOwotIG1pc3NpbmcvZnJvemVuL3Jlc2V0IGV2aWRlbmNlIG11c3Qgbm90IGZhYnJpY2F0ZSBudW1lcmljIHplcm87Ci0gY3Vyc29yIGNoYWlucyByZW1haW4gZGV0ZXJtaW5pc3RpYyBhbmQgYm91bmRlZDsKLSBPbmxpbmUgR3Vlc3RzIFRyYWZmaWMgcmVtYWlucyByYW5nZS1pbnNlbnNpdGl2ZTsKLSBxdWVyeS10aW1lIE9tYWRhIGlzb2xhdGlvbiByZW1haW5zIGludGFjdC4KCk5vIG5leHQgVHJhZmZpYyBUQVNLIGlzIGN1cnJlbnRseSBhc3NpZ25lZC4gV2hlbiBvbmUgaXMgYXBwcm92ZWQsIFRlY2ggTGVhZApyZXZpZXdzIHRoZSB0YXJnZXRlZCBjb21tYW5kL3Rlc3Qgc2V0IGFnYWluIGZvciB0aGF0IGV4YWN0IFRBU0suCg=="
$ModuleNew64 = "IyMgQ3VycmVudCBwcm9kdWN0aW9uIGV2aWRlbmNlCgpPd25lci1wcm92aWRlZCBwcm9kdWN0aW9uIGNoZWNrcG9pbnQgMjAyNi0wOS0wMzoKCmBgYHRleHQKSEVBRDogNjQyNTk4OGI1YjRlYzVmZjM4YmY5YzY3Yzc0ODQ2YzM4MDZmNjY4Zgp0cmVlOiBiNjY5ZjM2OGIwMDYyZmNiMTAwYjI0NzU4Y2YwNWUyYzRiNTAwMTQ0CgpUUkFGRklDLTAwOiBET05FClRSQUZGSUMtMDEgQ3VycmVudDogcHJvZHVjdGlvbiBhY3RpdmUKVFJBRkZJQy0wMi1SRUFEOiBET05FClRSQUZGSUMtMDIgSGlzdG9yeTogcHJvZHVjdGlvbiBhY3RpdmUKVFJBRkZJQy0wMi1QRVJGLTAxOiBET05FClRSQUZGSUMtMDMgU3RhdGlzdGljczogcHJvZHVjdGlvbiBhY3RpdmUKVFJBRkZJQy0wNCBQZWFrOiBwcm9kdWN0aW9uIGFjdGl2ZQpUUkFGRklDLTA1IFRyYWZmaWMgYnkgQVA6IHByb2R1Y3Rpb24gYWN0aXZlClRSQUZGSUMtUkFOR0UtMDE6IHByb2R1Y3Rpb24gYWN0aXZlIC8gcHJvZHVjdGlvbiBhY2NlcHRhbmNlIFBBU1MKVFJBRkZJQy0wNiBBUCBUcmFmZmljIFNoYXJlOiBwcm9kdWN0aW9uIGFjdGl2ZSAvIHByb2R1Y3Rpb24gYWNjZXB0YW5jZSBQQVNTClRSQUZGSUMtMDctUkVBRDogRE9ORSAvIFJFQUQgRk9VTkRBVElPTiBJTVBMRU1FTlRFRApUUkFGRklDLTA3IE9ubGluZSBHdWVzdHMgVHJhZmZpYzogQ09NUExFVEUgLyBQUk9EVUNUSU9OIEFDVElWRQoKV0VCX0FETUlOX1RSQUZGSUNfRU5BQkxFRD10cnVlCldFQl9BRE1JTl9UUkFGRklDX0hJU1RPUllfRU5BQkxFRD10cnVlCldFQl9BRE1JTl9UUkFGRklDX1NUQVRJU1RJQ1NfRU5BQkxFRD10cnVlCldFQl9BRE1JTl9UUkFGRklDX1BFQUtfRU5BQkxFRD10cnVlCldFQl9BRE1JTl9UUkFGRklDX0JZX0FQX0VOQUJMRUQ9dHJ1ZQpXRUJfQURNSU5fVFJBRkZJQ19JTkRFUEVOREVOVF9SQU5HRVNfRU5BQkxFRD10cnVlCldFQl9BRE1JTl9UUkFGRklDX0FQX1NIQVJFX0VOQUJMRUQ9dHJ1ZQpXRUJfQURNSU5fVFJBRkZJQ19PTkxJTkVfR1VFU1RTX0VOQUJMRUQ9dHJ1ZQoKY2FwdGl2ZS1wb3J0YWwuc2VydmljZT1hY3RpdmUKYGBgCgojIyBOZXh0IFRyYWZmaWMgaXRlbQoKTm8gYXBwcm92ZWQgbmV4dCBUcmFmZmljIFRBU0sgaXMgY3VycmVudGx5IGFzc2lnbmVkLiBObyBgVFJBRkZJQy0wOGAgaXMKY2Fub25pY2FsIGNoYW5nZS1pbnRlbnQuCg=="

Write-Host "=== PRECHECK ==="
if(-not (Test-Path (Join-Path $Repo ".git"))){throw "STOP: repo missing"}
if(@(git -C $Repo status --porcelain).Count -ne 0){throw "STOP: working tree must be clean"}

git -C $Repo fetch origin main $Branch
if($LASTEXITCODE -ne 0){throw "STOP: fetch failed"}

$Main=(git -C $Repo rev-parse origin/main).Trim()
$MainTree=(git -C $Repo rev-parse "origin/main^{tree}").Trim()
$RemoteHead=(git -C $Repo rev-parse "origin/$Branch").Trim()

Write-Host "origin/main: $Main"
Write-Host "origin/main tree: $MainTree"
Write-Host "origin/${Branch}: $RemoteHead"

if($Main -ne $ExpectedMain){throw "STOP: main moved; re-review required"}
if($MainTree -ne $ExpectedTree){throw "STOP: main tree mismatch"}
if($RemoteHead -ne $ExpectedPrHead){throw "STOP: PR head moved; re-review required"}

git -C $Repo switch $Branch
if($LASTEXITCODE -ne 0){throw "STOP: switch branch failed"}
git -C $Repo reset --hard "origin/$Branch"
if($LASTEXITCODE -ne 0){throw "STOP: branch reset failed"}
if(@(git -C $Repo status --porcelain).Count -ne 0){throw "STOP: branch not clean after reset"}

Write-Host "=== ANCHOR PRECHECK ==="

$TestingPath=Join-Path $Repo $TestingRel
$TestingText=Read-Lf $TestingPath
$TestingOld=(Decode-Utf8 $TestingOld64).Replace("`r`n","`n")
$TestingCount=([regex]::Matches($TestingText,[regex]::Escape($TestingOld))).Count
if($TestingCount -ne 1){throw "STOP: current testing maintenance block matched $TestingCount times"}

$ModuleText=Read-Lf (Join-Path $Repo $ModuleRel)
$ModulePattern="(?ms)^"+[regex]::Escape("## Current production evidence")+"\n.*?(?=^"+[regex]::Escape("## Production evidence rule")+"\n)"
$ModuleCount=([regex]::Matches($ModuleText,$ModulePattern)).Count
if($ModuleCount -ne 1){throw "STOP: module-index production evidence section matched $ModuleCount times"}

Write-Host "PASS: exact two preservation anchors"

Write-Host "=== APPLY FINAL PRESERVATION ==="

$TestingNew=(Decode-Utf8 $TestingNew64).Replace("`r`n","`n")
Write-Lf $TestingPath ($TestingText.Replace($TestingOld,$TestingNew))

$ModuleNew=Decode-Utf8 $ModuleNew64
Replace-Section $ModuleRel "## Current production evidence" "## Production evidence rule" $ModuleNew

$Changed=@(git -C $Repo status --porcelain | ForEach-Object {$_.Substring(3).Trim()} | Sort-Object -Unique)
$ExpectedChanged=@($ModuleRel,$TestingRel | Sort-Object)
if(($Changed -join "`n") -ne ($ExpectedChanged -join "`n")){
  Write-Host "Changed paths:"
  $Changed | ForEach-Object {Write-Host "  $_"}
  throw "STOP: V4 scope must be exactly docs/module-index.md + docs/testing.md"
}

$TestingAfter=Read-Lf $TestingPath
foreach($Needle in @(
 "Every accepted TASK / module / Admin panel / API / read-service change requires a",
 "Coder handoff must explicitly list:",
 "TECH LEAD TEST-SET REVIEW",
 "Never add a new failure to compatibility merely to obtain a green candidate.",
 "### Current TRAFFIC-07 targeted set",
 "tests/analytics/test_current_guest_traffic.py",
 "### Previous Traffic acceptance evidence — TRAFFIC-06",
 "### Latest Traffic acceptance evidence — TRAFFIC-07",
 "CORE_PERF_GATE=PASS"
)){
  if($TestingAfter.IndexOf($Needle,[StringComparison]::Ordinal)-lt 0){
    throw "STOP: testing preservation assertion missing: $Needle"
  }
}

$ModuleAfter=Read-Lf (Join-Path $Repo $ModuleRel)
foreach($Needle in @(
 "TRAFFIC-06 AP Traffic Share: production active / production acceptance PASS",
 "TRAFFIC-07 Online Guests Traffic: COMPLETE / PRODUCTION ACTIVE",
 "WEB_ADMIN_TRAFFIC_ENABLED=true",
 "WEB_ADMIN_TRAFFIC_AP_SHARE_ENABLED=true",
 "WEB_ADMIN_TRAFFIC_ONLINE_GUESTS_ENABLED=true",
 "No approved next Traffic TASK is currently assigned"
)){
  if($ModuleAfter.IndexOf($Needle,[StringComparison]::Ordinal)-lt 0){
    throw "STOP: module-index preservation assertion missing: $Needle"
  }
}

git -C $Repo diff --check
if($LASTEXITCODE -ne 0){throw "STOP: git diff --check failed"}

$PatchOut=Join-Path $PSScriptRoot "CaptivPortal_KB_TRAFFIC07_Final_Preservation_V4.patch"
git -C $Repo diff --no-ext-diff --binary -- $ModuleRel $TestingRel | Out-File -FilePath $PatchOut -Encoding utf8

Write-Host "PASS: exact two-file V4 scope"
Write-Host "PASS: universal Test Set Maintenance governance restored"
Write-Host "PASS: TRAFFIC-07 targeted set retained"
Write-Host "PASS: TRAFFIC-06 and TRAFFIC-07 acceptance evidence retained"
Write-Host "PASS: full current Traffic production flag snapshot retained"
Write-Host "PASS: git diff --check"

Write-Host "=== COMMIT / PUSH ==="
git -C $Repo add -- $ModuleRel $TestingRel
if($LASTEXITCODE -ne 0){throw "STOP: git add failed"}
git -C $Repo diff --cached --check
if($LASTEXITCODE -ne 0){throw "STOP: staged diff check failed"}

git -C $Repo commit -m "docs: complete TRAFFIC-07 KB preservation" -m "Restore permanent test-set maintenance governance and retain the complete current Traffic production flag snapshot while preserving the TRAFFIC-07-specific additions."
if($LASTEXITCODE -ne 0){throw "STOP: commit failed"}
$Commit=(git -C $Repo rev-parse HEAD).Trim()

git -C $Repo push origin $Branch
if($LASTEXITCODE -ne 0){throw "STOP: push failed"}

Write-Host "=== FINAL ==="
Write-Host "Branch: $Branch"
Write-Host "V4 commit: $Commit"
Write-Host "Draft PR: https://github.com/ZaurNavi/CaptivePortal/pull/100"
Write-Host "Changed files in V4: docs/module-index.md, docs/testing.md"
Write-Host "Application code changed: NO"
Write-Host "Tests changed: NO"
Write-Host "Runtime config changed: NO"
Write-Host "Production changed: NO"
Write-Host "git diff --check: PASS"
Write-Host "Merge performed: NO"
Write-Host "Patch: $PatchOut"
