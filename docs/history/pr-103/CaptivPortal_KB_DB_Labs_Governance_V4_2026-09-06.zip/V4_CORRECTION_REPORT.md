# Publisher V4 correction report

## V3 STOP classification

`HARNESS / SCOPE-DETECTION ERROR`

V3 successfully:
- fetched and fast-forwarded local main to the exact baseline;
- created local branch `docs/db-baseline-labs-governance-kb-2026-09-06`;
- passed every mutation anchor/new-file precondition;
- applied the intended documentation changes.

It then stopped before staging/commit/push because ordinary:

`git status --porcelain`

collapsed the first untracked file under a newly created directory into:

`docs/deferred/`

while the exact allowlist expected:

`docs/deferred/TRAFFIC-PROJECTION-MAINTENANCE-REINDEX.md`

Remote GitHub verification after the STOP found no publication branch, so V3 did
not push and did not create a PR.

## V4 corrections

1. Recovery-safe from the exact failed-V3 state.
2. Dirty recovery is allowed only when:
   - current branch is the expected publication branch;
   - local HEAD is exact baseline `6fbc3736085be9d0538d893b6e9569ff490ef7f4`;
   - every dirty path, expanded with `--untracked-files=all`, belongs to the
     approved 14-file KB scope.
3. Any unrelated dirty path causes STOP.
4. Recovery uses `git reset --hard` only for tracked files at the exact baseline
   and removes only the four explicitly known new files. No broad `git clean`.
5. Scope collection now uses:
   `git status --porcelain --untracked-files=all`.
6. Unified patch is generated from the staged index so all four new files are
   included.
7. Exact baseline/tree, 14-file docs scope, assertions, Draft-PR-only behavior
   and Owner-controlled merge are unchanged.

Static validation before delivery:
- PowerShell delimiter balance: PASS
- variable-colon hazard scan: PASS
- unexpected backtick quoting scan: PASS
- no broad git clean: PASS
- no merge command: PASS
- approved scope = 14 files: PASS
- new canonical files = 4: PASS

SHA256:
`f3934cfba0673fff18781079178a601467712fce61def76e4a650cfba84c373b`
