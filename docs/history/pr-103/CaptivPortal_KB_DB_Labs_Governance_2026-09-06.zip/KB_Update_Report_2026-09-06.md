# CaptivPortal KB Update Report — DB Baseline / Lab Infrastructure / Lessons / Deferred Projection Maintenance

Date: 2026-09-06

## Exact base

- main: `6fbc3736085be9d0538d893b6e9569ff490ef7f4`
- tree: `fc3c1ed53df32d0074036a749ee028781ec1f1b5`
- source merge: PR #102 / TASK-ADMIN-PROD-BASELINE-01
- production HEAD: Owner-confirmed `6fbc3736085be9d0538d893b6e9569ff490ef7f4`
- production worktree: Owner-confirmed CLEAN

## Scope

- `AGENTS.md`
- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/agents/workflow.md`
- `docs/deferred/TRAFFIC-PROJECTION-MAINTENANCE-REINDEX.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/traffic.md`
- `docs/operations-command-lessons-learned.md`
- `docs/project-inventory.md`
- `docs/tasks/TASK-DB-BASELINE-SYNC-01.md`
- `docs/testing-environments.md`
- `docs/testing.md`

## Canonical changes

1. Adds `TASK-DB-BASELINE-SYNC-01` as the current production DB prerequisite before Traffic 0.8.
2. Canonicalizes Windows Central Lab, dedicated Owner WSL/Linux Lab and production separation.
3. Adds permanent invariant `PRODUCTION IS NOT AN ACCEPTANCE OR PERFORMANCE TEST HOST.`
4. Records Linux Lab identity `DESKTOP-7C8M3BS` / `zaur_navi` and known workdirs.
5. Adds practical command/harness lessons learned.
6. Adds deferred Projection Maintenance/Reindex request without promoting it to implementation.
7. Reconciles current documentation baseline from `6425988b5b4ec5ff38bf9c67c74846c3806f668f` to `6fbc3736085be9d0538d893b6e9569ff490ef7f4`.
8. Records Traffic 0.8 only as a planned stage after `FINAL_DB_BASELINE=PASS`.

## Non-actions

- no application code change
- no test change
- no runtime config change
- no production change
- no DB migration executed
- no Projection Maintenance implementation
- no merge
