# Publisher V2 correction report

## V1 failure classification

`HARNESS / PUBLISHER PARSER ERROR`

V1 failed during PowerShell parsing before any command in the publisher executed.
Therefore it did not:

- fetch/switch/create a branch;
- modify repository files;
- create a commit;
- push;
- create a PR;
- modify production.

Cause: Markdown backticks around two canonical SHA assertions were embedded in
PowerShell double-quoted strings and escaped the closing quote.

## V2 correction

- exact baseline unchanged:
  `6fbc3736085be9d0538d893b6e9569ff490ef7f4`
- exact tree unchanged:
  `fc3c1ed53df32d0074036a749ee028781ec1f1b5`
- exact intended 14-file docs scope unchanged
- all canonical assertion path/needle values now base64 encoded and decoded at runtime
- static variable-colon hazard scan: PASS
- static unexpected backtick-in-double-quote scan: PASS
- merge command: absent
- merge performed: NO

SHA256:
`3a0a922193dbbd7cdbb0368f813f4f498712340af09c47b6eaeb8c3e8adce87a`
