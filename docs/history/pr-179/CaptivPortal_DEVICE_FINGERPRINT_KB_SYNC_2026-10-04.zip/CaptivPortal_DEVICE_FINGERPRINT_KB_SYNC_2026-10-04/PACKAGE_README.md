# CaptivPortal Device Fingerprint KB Sync package

This package is a **documentation-only candidate** for exact baseline:

```text
main = 7c7c0919c3e546f499b5252ea9479d32c8f494d7
tree = dbf3e3804931d637ef1ec569128746ebce5c141a
```

Contents:

- `docs-modules-device-fingerprint-CANDIDATE.md` — full rewritten current Device Fingerprint module with 16 Mermaid diagrams.
- `DEVICE_FINGERPRINT_KB_RECONCILIATION_REPORT.md` — audit findings and scope.
- `publish_device_fingerprint_kb_sync.py` — exact-baseline guarded local materializer.
- `MANIFEST.json` / `SHA256.txt` — package integrity.

Recommended first run on a clean repository clone/worktree:

```powershell
python .\publish_device_fingerprint_kb_sync.py --repo "C:\path\to\CaptivePortal"
```

That run:
- fetches/verifies exact `origin/main`;
- refuses a moved baseline or dirty worktree;
- builds all edits in memory before writes;
- creates local branch `docs/device-fingerprint-production-knowledge-sync`;
- stages the exact documentation scope;
- runs `git diff --cached --check`;
- performs **no commit, push, PR, merge or deploy**.

Only after reviewing the staged diff may you optionally create a local commit with
`--commit`. The script still never pushes or opens a PR.

`AGENTS.md` drift is intentionally reported but not modified because agent-instruction
governance is outside this documentation-only sync.
