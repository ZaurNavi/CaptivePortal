#!/usr/bin/env python3
"""Materialize the Device Fingerprint production knowledge sync.

Documentation-only. Exact-baseline guarded. No push/PR/merge/deploy.
"""
from __future__ import annotations
import argparse, pathlib, re, subprocess, sys

BASE_COMMIT = "7c7c0919c3e546f499b5252ea9479d32c8f494d7"
BASE_TREE = "dbf3e3804931d637ef1ec569128746ebce5c141a"
BRANCH = "docs/device-fingerprint-production-knowledge-sync"
MARK_BEGIN = "<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->"
MARK_END = "<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->"

TARGETS = (
    "README.md",
    "README_RU.md",
    "docs/README.md",
    "docs/architecture.md",
    "docs/project-inventory.md",
    "docs/module-index.md",
    "docs/modules/device-fingerprint.md",
    "docs/modules/device-fingerprint-portal.md",
    "docs/modules/admin-web.md",
    "docs/testing.md",
    "docs/deployment.md",
    "docs/security.md",
    "docs/configuration.md",
)

MODULE = '# Device Fingerprint\n\nStatus: **current production capability**  \nUpdated: 2026-10-04  \nRepository / production checkpoint: `main@7c7c0919c3e546f499b5252ea9479d32c8f494d7`  \nRepository / production tree: `dbf3e3804931d637ef1ec569128746ebce5c141a`\n\nDevice Fingerprint is CaptivPortal\'s passive, deterministic, Site-scoped device\nclassification subsystem. It turns bounded normalized evidence into one\nstructured, persisted `ClassificationResult`, links production classification to\nthe post-authorization device/visit lifecycle where exact identity permits, and\nserves the latest authoritative **PRODUCTION** result to Admin Home and Device\nCard.\n\nThe system is advisory. Fingerprint data never authorizes a guest, never changes\nCAPPORT admission, never blocks a client, and never performs a destructive Omada\naction.\n\n> `TASK-DEVICE-FINGERPRINT-01` is the **Evidence Foundation layer**. Its historical\n> statement that the foundation itself does not classify devices or link identities\n> remains correct. It is not a description of the whole current Device Fingerprint\n> system.\n\n## 1. Current production status\n\n```text\nTASK-DEVICE-FINGERPRINT-04 = CLOSED / ACCEPTED / PRODUCTION ELIGIBLE\nTASK-DEVICE-FINGERPRINT-05 = CLOSED / INTEGRATED\nTASK-DEVICE-FINGERPRINT-05-PERF-01 = CLOSED\nTASK-DEVICE-FINGERPRINT-06 = PRODUCTION PASS / DEPLOYED\n\nproduction HEAD = 7c7c0919c3e546f499b5252ea9479d32c8f494d7\nproduction tree = dbf3e3804931d637ef1ec569128746ebce5c141a\n\ncaptive-portal.service = active\nfingerprint-classification.service = active\n```\n\nTask-06 production acceptance includes exact-code switch, production smoke, deploy\nPASS, and Owner visual confirmation that fingerprint Type is visible in Home and\nFingerprint Information is visible in Device Card.\n\nCurrent capability layers:\n\n```text\nDevice Fingerprint\n├── Evidence Foundation\n├── Evidence Producers\n│   ├── Network Sensor\n│   └── Portal Producer\n├── Foundation Contracts\n│   ├── bindings / clock\n│   ├── source health\n│   ├── schema admission\n│   └── snapshot policies\n├── Knowledge / Policy\n├── Classification Core\n├── Runtime Profiles / Admission\n├── Classification Persistence\n├── Auth / Device Integration\n├── Production Worker\n└── Product Presentation\n    ├── Home → Online Devices\n    └── Device Card → Fingerprint Information\n```\n\n## 2. Product dimensions and state semantics\n\nThe four product dimensions are:\n\n```text\ndevice_class\nplatform_family\nmanufacturer_family\nmodel_family\n```\n\nA dimension status is one of:\n\n```text\nresolved\nrecognized_out_of_scope\nunknown\ninsufficient_evidence\nconflicting_evidence\n```\n\nSupport is one of:\n\n```text\nnone\nlow\nmedium\nhigh\n```\n\nSupport is not a probability.\n\nProduct presentation keeps three different states distinct:\n\n| Product display | Meaning |\n|---|---|\n| `—` | no completed authoritative production result exists yet |\n| `Unknown` | classification completed, but the dimension was not resolved |\n| `Unavailable` | fingerprint persistence/read path is temporarily unavailable |\n\n`unknown != no result != unavailable`.\n\n## 3. DF-01 — Full end-to-end\n\n**Purpose:** show the whole production flow in one view.  \n**Inputs:** mirrored network traffic, Portal/CAPPORT request metadata, post-auth identity context.  \n**Outputs:** persisted authoritative classification and Admin presentation.  \n**Persistence boundary:** normalized evidence, control-plane artifacts, classifications, integration jobs. Raw frames are not durable.  \n**Failure behavior:** fingerprint degrades/fails independently; Auth/CAPPORT and core Admin continue.  \n**Authoritative owner/module:** `app/device_fingerprint*`, `app/admin_web/`.\n\n```mermaid\nflowchart TD\n    C[Client device] --> W[Wi-Fi / Omada]\n    W --> M[SPAN / mirrored traffic]\n    M --> NS[Network Sensor]\n    NS --> NE[Bounded normalized network evidence]\n\n    C --> P[Portal / CAPPORT request]\n    P --> PP[Portal evidence producer]\n    PP --> PE[Bounded normalized portal evidence]\n\n    NE --> EDB[(Evidence SQLite)]\n    PE --> EDB\n    EDB --> SNAP[Snapshot assembly]\n    SNAP --> SE[SourceEvaluability]\n    SE --> OA[OriginAssessments]\n    OA --> FUS[Cross-origin fusion]\n    FUS --> CR[ClassificationResult]\n    CR --> CDB[(Classification SQLite)]\n    CDB --> I[Task-05 integration / history]\n    I --> ID[Device / Visit relation]\n    CDB --> R[Task-06 production read]\n    R --> H[Home]\n    R --> D[Device Card]\n```\n\n## 4. DF-02 — Evidence sources / origins\n\n**Purpose:** distinguish independent origin families.  \n**Inputs:** normalized admitted evidence plus MAC-registry knowledge.  \n**Outputs:** per-origin assessments.  \n**Persistence boundary:** five physical/application evidence families persist through Task-01; MAC Registry is knowledge-derived, not packet evidence.  \n**Failure behavior:** unavailable/unsupported/disabled/unknown origin stays explicit and conservative.  \n**Authoritative owner/module:** evidence adapters + `origin_assessment.py`.\n\n```mermaid\nflowchart LR\n    subgraph Physical["Physical / network origins"]\n      DHCP[DHCP]\n      TCP[TCP]\n      TLS[TLS]\n      QUIC[QUIC]\n    end\n    subgraph Application["Application origin"]\n      PORTAL[Portal]\n    end\n    subgraph Knowledge["Knowledge-based origin"]\n      MAC[MAC Registry]\n    end\n\n    DHCP --> SNAP[Evidence Snapshot]\n    TCP --> SNAP\n    TLS --> SNAP\n    QUIC --> SNAP\n    PORTAL --> SNAP\n    MAC --> OA[OriginAssessments]\n    SNAP --> OA\n\n    AV[available] -.status.-> OA\n    UN[unavailable] -.status.-> OA\n    US[unsupported] -.status.-> OA\n    DI[disabled] -.status.-> OA\n    UK[unknown] -.status.-> OA\n```\n\nCurrent classifier origin order is exactly:\n\n```text\ndhcp, portal, tcp, tls, quic, mac_registry\n```\n\nRepeated rows from one origin do not become independent votes.\n\n## 5. Evidence Foundation and producers\n\n### Evidence Foundation\n\nTask-01 owns the normalized evidence/source-health persistence boundary and its\ninternal direct-TLS ingest/read service. The foundation remains separate from the\nclassification SQLite.\n\nNormalized durable evidence is P1/bounded. Raw packets, raw EVE, raw User-Agent,\nraw Client Hints, cookies, credentials and full request material are not durable\nclassification evidence.\n\n### Network producer\n\nConceptual flow:\n\n```text\nSPAN / mirrored traffic\n→ sensor-side capture/parsing\n→ bounded normalization\n→ durable normalized evidence\n→ Device Fingerprint Evidence SQLite\n```\n\nCurrent network evidence families include admitted DHCP, TCP SYN, TLS client and\nQUIC client schemas. The deployed sensor architecture keeps raw frames in memory;\nSuricata extraction is minimized and the product persistence boundary is the\nnormalized evidence envelope, not EVE/PCAP storage.\n\n### Portal producer\n\nConceptual flow:\n\n```text\nPortal / CAPPORT request\n→ bounded request metadata\n→ portal evidence producer\n→ normalized portal evidence\n→ existing Evidence SQLite\n```\n\nPortal evidence is another origin. It is not a second classifier.\n\nCurrent Portal source-health uses the accepted periodic replacement emitter with a\n60-second nominal same-state heartbeat. The historical EVENT_DRIVEN Portal emitter\nremains part of lineage but is not the current liveness contract.\n\n## 6. DF-03 — Evidence + source health + time\n\n**Purpose:** explain why absence of evidence is not automatically negative evidence.  \n**Inputs:** evidence rows, source-health timeline, binding timeline, clock policy.  \n**Outputs:** conservative source coverage/evaluability.  \n**Persistence boundary:** evidence and immutable source-health events persist; evaluability is derived classification input.  \n**Failure behavior:** stale/missing/incompatible health becomes unknown or another explicit non-covered state; no optimistic backfill.  \n**Authoritative owner/module:** `source_health_policy.py`, binding contracts, `source_evaluability.py`.\n\n```mermaid\nflowchart TD\n    E[Evidence rows] --> X[Time/binding evaluation]\n    H[Source Health timeline] --> X\n    B[Source binding timeline] --> X\n    C[Clock policy] --> X\n    X --> SE[SourceEvaluability]\n\n    A["absence of evidence"] --> Q{source coverage proven?}\n    Q -->|yes| COV[interpret within admitted semantics]\n    Q -->|no / unknown| N["NOT negative evidence"]\n```\n\nCurrent frozen source-health freshness includes:\n\n```text\nnetwork periodic emitter = 600 seconds\nhistorical Portal EVENT_DRIVEN emitter = 0 seconds\ncurrent Portal PERIODIC emitter = 180 seconds\ntimeout result = unknown\n```\n\nRecovery never retroactively upgrades a missed interval to complete.\n\n## 7. Binding and time model\n\nClassification is Site-scoped and time-windowed. Snapshot membership depends on:\n\n```text\nSite\nobserved MAC\nclassification window\nsource binding epoch\ncapture/source identity\nclock policy\nsource-health coverage\nTask-01 generation/watermark\n```\n\nA classifier cannot safely use “the latest row” without proving that row belongs\nto the requested Site, binding epoch and time window.\n\n## 8. DF-04 — Snapshot assembly\n\n**Purpose:** separate semantic snapshot contents from transient verified materialization and operational limits.  \n**Inputs:** retained Task-01 evidence/health plus foundation contracts.  \n**Outputs:** `EvidenceSnapshotContent`, verified `EvidenceSnapshotMaterialization`, `SourceEvaluability`.  \n**Persistence boundary:** `EvidenceSnapshotContent`/`SnapshotRecord` are retained audit lineage; materialization is transient.  \n**Failure behavior:** invalid integrity, incompatible binding, or exceeded resource policy fails closed for that classification request.  \n**Authoritative owner/module:** snapshot service/artifacts + foundation runtime profile.\n\n```mermaid\nflowchart TD\n    W[classification window] --> TX[One consistent Task-01 SQLite read snapshot]\n    TX --> EV[evidence selection]\n    TX --> HL[health selection]\n    B[bindings / clock] --> EV\n    CP[SnapshotContentPolicy] --> EV\n    XP[SnapshotExecutionPolicy] --> TX\n    EV --> ESC[EvidenceSnapshotContent]\n    HL --> ESC\n    ESC --> MAT[Verified transient materialization]\n    MAT --> SE[SourceEvaluability]\n```\n\nPermanent distinction:\n\n```text\nSnapshotContentPolicy != SnapshotExecutionPolicy\nsemantic content ceilings != operational execution guard\n```\n\nCurrent production-aligned memory guard:\n\n```text\nprocess_memory_guard_bytes = 1073741824\n                         = 1024 MiB\n                         = 1 GiB\n\nSnapshotExecutionPolicy:v1:sha256:\n36074993bb86daca8c43268c19ce0efab7e0e3ef5d644e07b9b6e65f5fff7f77\n```\n\nThis is a guard/threshold, not a 1-GiB memory reservation. Historical 96 MiB and\n512 MiB values are not current configuration.\n\n## 9. Knowledge and policy\n\nKnowledge is pinned, versioned and auditable. Production classification cannot\nsilently consult arbitrary current Internet/vendor knowledge.\n\nCurrent knowledge families include:\n\n| Family | Role |\n|---|---|\n| K1 | offline pinned Satori DHCP knowledge |\n| K2A | p0f parser/conformance foundation |\n| K2B | offline pinned legacy p0f TCP knowledge |\n| K3 | internal normalized Portal rule set |\n| K4 | offline admitted IEEE MAC-assignment knowledge |\n\nOther major artifacts include:\n\n```text\nClassificationTaxonomy\nAliasMapping\nKnowledgeFreshnessPolicy\nSourceGovernanceRecord\nKnowledgeProvenanceManifest\nCanonicalKnowledgeRecordSet\nKnowledgeBundle\nClassificationPolicy\nEvidenceAdapterContractSet\nClassifierArtifactManifest\n```\n\n## 10. DF-07 — Knowledge and policy\n\n**Purpose:** show how admitted knowledge becomes deterministic classifier input.  \n**Inputs:** taxonomy, aliases, versioned knowledge families, provenance/freshness.  \n**Outputs:** pinned `KnowledgeBundle` + policy/adapter contracts.  \n**Persistence boundary:** immutable artifact/control-plane content, not query-time cloud results.  \n**Failure behavior:** stale/unadmitted/incompatible knowledge blocks admission or produces conservative no-claim semantics; there is no silent fallback.  \n**Authoritative owner/module:** knowledge artifact builders, governance gates, runtime-profile artifacts.\n\n```mermaid\nflowchart TD\n    TAX[ClassificationTaxonomy] --> KB[KnowledgeBundle]\n    AL[AliasMapping] --> KB\n    K1[K1 Satori DHCP] --> KB\n    K2[K2A/K2B p0f] --> KB\n    K3[K3 Portal rules] --> KB\n    K4[K4 IEEE registry] --> KB\n    PROV[Provenance + freshness] --> KB\n    KB --> REQ[Classification request]\n    POL[ClassificationPolicy] --> REQ\n    AD[EvidenceAdapterContractSet] --> REQ\n```\n\n## 11. DF-05 — Pure deterministic classification core\n\n**Purpose:** show the I/O-free semantic core.  \n**Inputs:** exact snapshot/evaluability + admitted knowledge/policy/adapters/classifier identity.  \n**Outputs:** six `OriginAssessment`s, four `DimensionResult`s, global `ClassificationResult`.  \n**Persistence boundary:** none inside the pure core. Persistence happens outside it.  \n**Failure behavior:** malformed/incompatible inputs fail closed; no external fallback.  \n**Authoritative owner/module:** origin assessment + fusion/classification core.\n\n```mermaid\nflowchart TD\n    subgraph PURE["PURE DETERMINISTIC CORE — NO DB / NO NETWORK / NO CURRENT CLOCK / NO PERSISTENCE"]\n      ESC[EvidenceSnapshotContent]\n      MAT[EvidenceSnapshotMaterialization]\n      SE[SourceEvaluability]\n      KB[KnowledgeBundle]\n      CP[ClassificationPolicy]\n      EA[EvidenceAdapterContractSet]\n      CAM[ClassifierArtifactManifest]\n      KT[knowledge_evaluation_at_utc]\n\n      ESC --> OA[6 OriginAssessments]\n      MAT --> OA\n      SE --> OA\n      KB --> OA\n      EA --> OA\n      KT --> OA\n\n      OA --> F[Cross-Origin Fusion]\n      CP --> F\n      CAM --> F\n      F --> DR[4 DimensionResults]\n      DR --> GS[Global classification status]\n      GS --> CR[ClassificationResult]\n    end\n```\n\nThe pure core does not read DBs, network, filesystem discovery, current wall clock,\nmutable configuration or vendor schemas.\n\n## 12. OriginAssessment\n\nEvery origin is evaluated independently before fusion:\n\n```text\nDHCP\nPortal\nTCP\nTLS\nQUIC\nMAC Registry\n```\n\nAn origin can provide a candidate, no claim, ambiguity/conflict, or be\nunsupported/not evaluable. Documentation must not reduce this architecture to\n“User-Agent means Android” or “DHCP means Smartphone”.\n\n## 13. DF-06 — Per-dimension fusion\n\n**Purpose:** explain one dimension without pretending fusion is majority voting.  \n**Inputs:** one dimension\'s independently constructed origin assessments.  \n**Outputs:** status, canonical value when resolved, support and audit references.  \n**Persistence boundary:** result persists only after the pure decision is complete.  \n**Failure behavior:** ambiguity/conflict/insufficient evidence remains an explicit valid outcome.  \n**Authoritative owner/module:** `fusion.py` + `ClassificationPolicy`.\n\n```mermaid\nflowchart TD\n    D[DHCP claim] --> SO[same-origin assessment]\n    P[Portal claim] --> SO\n    T[TCP claim] --> SO\n    L[TLS claim] --> SO\n    Q[QUIC claim] --> SO\n    M[MAC Registry claim] --> SO\n    SO --> XO[cross-origin comparison]\n    XO --> R{Dimension result}\n    R --> RES[resolved]\n    R --> OOS[recognized_out_of_scope]\n    R --> UNK[unknown]\n    R --> INS[insufficient_evidence]\n    R --> CON[conflicting_evidence]\n    RES --> SUP[support: low / medium / high]\n    OOS --> SUP\n    UNK --> NONE[support: none]\n    INS --> NONE\n    CON --> NONE\n```\n\nIndependent-origin agreement and contradiction matter. Row counts are not votes.\n\n## 14. ClassificationResult\n\n`ClassificationResult` is the authoritative structured classifier product artifact.\n\nIt includes global classification status plus:\n\n```text\nplatform_result\ndevice_class_result\nmanufacturer_result\nmodel_result\n```\n\nEach dimension carries:\n\n```text\ncanonical value (when resolved)\nstatus\nsupport level\nsupporting origins\ncontradicting origins\nnot-evaluable origins\nout-of-scope references\nexplanation codes\nknowledge references\n```\n\nThe product UI consumes this artifact through typed read/presentation boundaries;\nit does not recompute its semantics.\n\n## 15. Reproducibility and audit\n\nA result is explainable relative to exact:\n\n```text\nevidence snapshot\nsource evaluability\nknowledge bundle\nclassification policy\nadapter contracts\nclassifier implementation identity\nruntime profile\nactivation/admission lineage\n```\n\nKey retained identities include:\n\n```text\nSnapshotRecord\nClassificationRequestManifest\nClassifierArtifactManifest\nClassificationResult\nFoundationRuntimeProfile\nClassificationRuntimeProfile\nRuntimeProfileAdmissionManifest\nRuntimeProfileActivationRecord\nRuntimeProfileValidityRecord\n```\n\n## 16. DF-09 — Artifact / audit lineage\n\n**Purpose:** show why a retained result can be reproduced and explained.  \n**Inputs:** exact request artifacts and activation lineage.  \n**Outputs:** retained result with immutable references.  \n**Persistence boundary:** control-plane + classification audit persistence.  \n**Failure behavior:** missing/inconsistent lineage fails closed; random “latest settings” are not substituted.  \n**Authoritative owner/module:** artifact/control-plane + classification persistence.\n\n```mermaid\nflowchart TD\n    SR[SnapshotRecord] --> CRM[ClassificationRequestManifest]\n    KB[KnowledgeBundle] --> CRM\n    POL[ClassificationPolicy] --> CRM\n    CAM[ClassifierArtifactManifest] --> CRM\n    RP[ClassificationRuntimeProfile] --> CRM\n    ACT[Admission / Activation lineage] --> RP\n    CRM --> CR[ClassificationResult]\n```\n\n## 17. Runtime profiles and admission\n\nThere are two compatibility levels:\n\n```text\nFoundationRuntimeProfile\nClassificationRuntimeProfile\n```\n\nThe classification profile pins the exact Foundation profile, KnowledgeBundle,\nClassificationPolicy, EvidenceAdapterContractSet and ClassifierArtifactManifest.\n\nA production request reads the active classification pointer once and pins one\nexact profile generation for the entire request. It does not repeatedly choose\n“current” artifacts.\n\n## 18. DF-08 — Runtime profile / admission lifecycle\n\n**Purpose:** make candidate/accepted/admitted/active states visibly different.  \n**Inputs:** immutable foundation/classifier artifacts and acceptance proofs.  \n**Outputs:** one active pinned runtime profile.  \n**Persistence boundary:** dedicated control-plane SQLite.  \n**Failure behavior:** compatibility/predecessor/validity failure blocks activation; no mixed generation.  \n**Authoritative owner/module:** runtime-profile/control-plane admission code.\n\n```mermaid\nflowchart TD\n    FA[Foundation artifacts] --> FRP[FoundationRuntimeProfile candidate]\n    FRP --> FACC[Foundation acceptance/admission]\n    FACC --> FACT[Foundation profile admitted/active]\n\n    FACT --> CRPC[ClassificationRuntimeProfile candidate]\n    K[Knowledge + Policy + Adapters + Classifier] --> CRPC\n    CRPC --> TAC[Task-04 acceptance]\n    TAC --> RPM[RuntimeProfileAdmissionManifest]\n    RPM --> ACT[Activation]\n    ACT --> PIN[Pinned PRODUCTION ClassificationRuntimeProfile]\n\n    C[candidate] -.not equal.-> A[accepted]\n    A -.not equal.-> AD[admitted]\n    AD -.not equal.-> AC[active]\n```\n\n### In-flight stability\n\n```text\nrequest starts\n→ exact ClassificationRuntimeProfile generation pinned once\n→ entire request uses the same semantic generation\n→ commit guard validates the pinned activation lineage\n```\n\nA safe profile activation during the request does not mix the new generation into\nthe already-running request.\n\n## 19. Persistence\n\nDevice Fingerprint uses separate stores by ownership:\n\n```text\n/opt/CaptivePortal/data/device_fingerprint_evidence.sqlite3\n/opt/CaptivePortal/data/device_fingerprint_classification.sqlite3\n/opt/CaptivePortal/data/device_fingerprint_control_plane.sqlite3\n/opt/CaptivePortal/data/device_fingerprint_integration.sqlite3\n```\n\nThe evidence, classification, control-plane and integration domains are not one\ndatabase and must not be aliased.\n\nClassification retention is a versioned policy; current accepted V1 retention is\n90 days. A classification result is historical product/audit evidence, not a field\nthat overwrites the Device row.\n\n## 20. DF-15 — Production components and stores\n\n**Purpose:** show runtime ownership.  \n**Inputs:** main Auth lifecycle plus passive evidence.  \n**Outputs:** classification and read-only Admin presentation.  \n**Persistence boundary:** four dedicated Device Fingerprint SQLite domains.  \n**Failure behavior:** independent components fail without changing Authorization semantics.  \n**Authoritative owner/module:** deployment templates + integration/classification services.\n\n```mermaid\nflowchart TD\n    CP[captive-portal.service]\n    FW[fingerprint-classification.service]\n    FE[fingerprint-evidence.service]\n    FS[fingerprint-sensor.service]\n    SU[fingerprint-suricata.service]\n\n    E[(Evidence SQLite)]\n    C[(Classification SQLite)]\n    P[(Control Plane SQLite)]\n    I[(Integration SQLite)]\n\n    FS --> E\n    SU --> FS\n    FE --> E\n    CP --> I\n    FW --> I\n    FW --> E\n    FW --> P\n    FW --> C\n    C --> CP\n    CP --> ADMIN[Admin read consumers]\n```\n\nThe production status explicitly confirmed for the final Task-06 checkpoint is\n`captive-portal.service=active` and `fingerprint-classification.service=active`.\nRepository component existence is not used to invent an unverified live service\nstate for other auxiliary units.\n\n## 21. Task-05 — post-Auth integration\n\nOne successful AuthRun creates one durable classification opportunity. Current\ncode constants define:\n\n```text\nlookback before Auth      = 300 s\npost-Auth evidence window = 120 s\ndue time                  = Auth + 150 s\nlease                     = 300 s\nmax attempts              = 5\nretry delays              = 30 / 120 / 300 / 600 s\nidentity retry interval   = 30 s\nidentity horizon          = 3600 s\n```\n\nCurrent job states:\n\n```text\nPENDING\nLEASED\nCLASSIFIED\nNO_RESULT_FINAL\n```\n\nIdentity states:\n\n```text\nUNRESOLVED\nDEVICE_RESOLVED\nDEVICE_AND_VISIT_RESOLVED\nCONFLICT\n```\n\n## 22. DF-10 — Post-Auth integration / worker\n\n**Purpose:** show the durable production classification trigger.  \n**Inputs:** confirmed authorization plus exact identity/session context.  \n**Outputs:** persisted production classification linked where exact identity permits.  \n**Persistence boundary:** integration SQLite + classification/control-plane stores.  \n**Failure behavior:** bounded retry, lease recovery and terminal no-result; Auth remains independent.  \n**Authoritative owner/module:** `app/device_fingerprint_integration/`, `fingerprint-classification.service`.\n\n```mermaid\nflowchart TD\n    A[Auth success] --> J[Create Integration Job]\n    J --> P[PENDING]\n    P --> DUE[due]\n    DUE --> L[LEASED]\n    L --> W[Single durable worker]\n    W --> ID[Exact identity/session resolution]\n    ID --> RP[Pin admitted ClassificationRuntimeProfile]\n    RP --> S[Assemble snapshot]\n    S --> C[Classify]\n    C --> PS[Persist ClassificationResult]\n    PS --> OK[CLASSIFIED]\n    OK --> LINK[Device / Visit linkage where proven]\n\n    ID -->|temporary unresolved| RETRY[bounded retry]\n    S -->|typed/retryable failure| RETRY\n    C -->|typed/retryable failure| RETRY\n    RETRY --> P\n    RETRY -->|attempt/horizon exhausted| NR[NO_RESULT_FINAL]\n```\n\nIdentity resolution does not guess. It uses exact Site/session/MAC Registry\nsnapshots and exact Visit/session/run relation where available.\n\n## 23. Device identity and later visits\n\nDevice identity and classification result are different records. Current relation\nuses Site, observed MAC, device/session anchors, integration job and\nclassification ID.\n\nFor the same Site + MAC, a later Visit can create another fingerprint opportunity:\n\n```text\nexisting Device identity\n+ new Visit/AuthRun\n+ new ClassificationResult\n```\n\nThere is no automatic cross-MAC identity merge. A randomized MAC can therefore be\na separate Device identity unless another separately proven linking mechanism\nexists.\n\n## 24. DF-11 — Device classification history\n\n**Purpose:** distinguish Device identity from repeated classification history.  \n**Inputs:** successive auth/visit opportunities for one Site+MAC.  \n**Outputs:** retained classification history and one current production selection.  \n**Persistence boundary:** classification SQLite retains multiple results.  \n**Failure behavior:** a failed/new opportunity does not rewrite older retained evidence.  \n**Authoritative owner/module:** classification persistence/read + Task-05 relation.\n\n```mermaid\nflowchart TD\n    DEV[Device — one Site + MAC]\n    DEV --> V1[Visit #1]\n    DEV --> V2[Visit #2]\n    DEV --> V3[Visit #3]\n    V1 --> R1[ClassificationResult #1]\n    V2 --> R2[ClassificationResult #2]\n    V3 --> R3[ClassificationResult #3]\n    R1 --> SEL[latest authoritative PRODUCTION result]\n    R2 --> SEL\n    R3 --> SEL\n    SEL --> UI[current Device Card / Home]\n```\n\n## 25. Task-05 performance and memory-pressure history\n\nThe first successful production-shaped assembly exposed a CPU-bound performance\nproblem: repeated validation/rematerialization of the same immutable knowledge\nclosure. `TASK-DEVICE-FINGERPRINT-05-PERF-01` introduced request-scoped validation\nproof reuse without changing classifier semantics or artifact identities.\n\nAccepted engineering history:\n\n```text\nbefore: wall ≈ 248.5 s, CPU ≈ 247.9 s\nafter:  wall ≈ 32.35 s\nspeedup ≈ 7.68x\nreduction ≈ 86.98%\n```\n\nA later live `snapshot_memory_pressure` exposed that the historical 96-MiB process\nRSS guard was operationally too small. This was not proof of host OOM, a semantic\nclassifier regression or a memory leak. The final current policy is 1 GiB.\n\nHistorical failed rows remain history; a later successful Owner-device job reached\n`CLASSIFIED` in one attempt with an empty last reason.\n\n## 26. Task-06 authoritative product read\n\nThe UI does not classify.\n\n```text\npersisted PRODUCTION ClassificationResult\n→ DeviceFingerprintClassificationReadService\n→ typed DeviceFingerprintPresentationService\n→ AdminQueryService/read model\n→ Home / Device Card\n```\n\nA newer `PRE_ACCEPTANCE_CANDIDATE` result cannot shadow the current production\nresult.\n\nHome batch reads are bounded to at most 250 input MACs. Inputs are canonicalized\nand deduplicated. The implementation uses one read-only SQLite connection /\ntransaction and bounded grouped SELECTs, not one connection/query per device row.\n\n## 27. DF-12 — Admin presentation read path\n\n**Purpose:** show the one authoritative read path shared by product surfaces.  \n**Inputs:** persisted PRODUCTION ClassificationResult.  \n**Outputs:** compact Home Type and detailed Device Card fingerprint information.  \n**Persistence boundary:** read-only; no UI writes/classification.  \n**Failure behavior:** fail-soft presentation on read failure.  \n**Authoritative owner/module:** classification read + Admin fingerprint presentation service.\n\n```mermaid\nflowchart TD\n    DB[(Classification SQLite)] --> PR[production-only read]\n    PR --> PA[typed presentation adapter]\n    PA --> AQ[AdminQueryService]\n    AQ --> H[Home → Online Devices]\n    AQ --> D[Device Card]\n\n    H --> HT["Type = Fingerprint device_class"]\n    H --> HP["Platform = controller device_type"]\n\n    D --> CP["Controller Platform"]\n    D --> FI["Fingerprint Information"]\n```\n\n## 28. Home → Online Devices current UI\n\nCurrent Home column semantics:\n\n```text\nDevice / MAC\nType       = fingerprint device_class\nPlatform   = existing controller / Omada device_type presentation\nAuth\nIP\nAP\nBand\nRSSI\nSNR\nUptime\nTraffic\n```\n\nThe old backend fields remain `device_type` / `device_type_key`; their current\nproduct meaning is **Controller Platform**. The existing Android icon and canonical\nlexical key still apply to that controller value.\n\nPermanent product rule:\n\n```text\nFingerprint Type != Controller Platform\nController Platform NEVER backfills Fingerprint Type\n```\n\n## 29. Device Card current UI\n\nDevice Card keeps controller evidence and fingerprint evidence separate:\n\n```text\nController information\n  Controller Platform = controller/source value\n\nFingerprint Information\n  Status\n  Classified at\n  Type\n  Fingerprint Platform\n  Manufacturer\n  Model Family\n  support\n```\n\nExpandable fingerprint details may show exact per-dimension status, support,\nsupporting/contradicting/not-evaluable origins, out-of-scope references,\nexplanation codes and knowledge references.\n\nController Platform and Fingerprint Platform can disagree. No reconciliation,\nauto-correction, hidden override or UI-side “best guess” is performed.\n\n## 30. DF-13 — UI state semantics\n\n**Purpose:** make no-result/Unknown/Unavailable unambiguous.  \n**Inputs:** production read state + dimension status.  \n**Outputs:** stable human-facing presentation.  \n**Persistence boundary:** none.  \n**Failure behavior:** read failure maps to Unavailable/— without breaking core page data.  \n**Authoritative owner/module:** Admin fingerprint presentation.\n\n```mermaid\nflowchart TD\n    Q{Fingerprint read available?}\n    Q -->|no| U[Unavailable]\n    Q -->|yes| R{PRODUCTION result exists?}\n    R -->|no| DASH[—]\n    R -->|yes| D{dimension resolved?}\n    D -->|yes| V[display resolved value]\n    D -->|no| K[Unknown]\n```\n\nA completed global classification status of `unknown` is still a completed\nclassification, not read-path Unavailable.\n\n## 31. DF-14 — Failure isolation\n\n**Purpose:** show that Device Fingerprint is advisory and fail-soft to the rest of CaptivPortal.  \n**Inputs:** possible sensor/store/classifier/worker/read failures.  \n**Outputs:** degraded/unavailable fingerprint only.  \n**Persistence boundary:** failures may be retained in domain history/telemetry; they do not mutate Auth decisions.  \n**Failure behavior:** core Auth/CAPPORT/Admin/Traffic continue according to their own contracts.  \n**Authoritative owner/module:** subsystem boundaries + Admin fail-soft adapter.\n\n```mermaid\nflowchart LR\n    SF[Sensor failure] --> FD[Fingerprint degraded / unavailable]\n    DBF[Fingerprint DB failure] --> FD\n    CF[Classifier unavailable] --> FD\n    WF[Worker retry/failure] --> FD\n\n    AUTH[Auth continues]\n    CAP[CAPPORT continues]\n    ADM[Admin core continues]\n    TR[Traffic/current-state continue]\n\n    FD -.does not control.-> AUTH\n    FD -.does not control.-> CAP\n    FD -.does not control.-> ADM\n    FD -.does not control.-> TR\n```\n\n## 32. Security and privacy boundaries\n\nPermanent invariants:\n\n```text\nclassification is advisory\nclassification never authorizes\nclassification never changes CAPPORT admission\nclassification is not a security credential\nno automatic client blocking\nno destructive Omada action\nno cross-MAC identity merge\nruntime classifier requires no Internet\nraw packets are non-durable\nraw User-Agent / Client Hints are non-durable\nAdmin presentation is Site-authorized and read-only\n```\n\nKnowledge acquisition/import may be an offline governed process; the production\nclassifier does not perform query-time external/cloud classification.\n\n## 33. Site boundary\n\nFingerprint reads/writes are Site-scoped. Do not model:\n\n```text\nMAC → one universal global identity\n```\n\nThe current product/read boundary is Site + observed MAC. This boundary must be\npreserved for future Multi-Site evolution.\n\n## 34. DF-16 — Current Device Fingerprint vs future Traffic Enrichment\n\n**Purpose:** prevent two initiatives from being conflated.  \n**Inputs:** current classification data vs future traffic/activity intelligence.  \n**Outputs:** richer future Device Card without changing what “fingerprint” means.  \n**Persistence boundary:** future initiative requires its own approved architecture.  \n**Failure behavior:** future work cannot silently expand current fingerprint semantics.  \n**Authoritative owner/module:** current Device Fingerprint docs; future Architect/roadmap for enrichment.\n\n```mermaid\nflowchart TD\n    DF["CURRENT — Device Fingerprint"] --> ID["identity / classification data"]\n    TE["FUTURE — Device Traffic Enrichment"] --> TI["traffic / activity / protocol / quality / behavior / anomaly data"]\n    ID --> CARD[Richer Device Card]\n    TI --> CARD\n```\n\nDevice Traffic Enrichment / Device Intelligence is future architecture work. It\nmust not be described as already implemented Device Fingerprint behavior.\n\n## 35. Historical architecture and provenance\n\nThe registered Device Fingerprint R14 architecture remains the normative detailed\nsemantic contract for frozen artifact/admission/classification semantics. It\ncontains historical lifecycle language (including periods when Task-04 was HOLD)\nthat is correct for that point in the project history.\n\nCurrent documentation must not rewrite that history. Current-state docs instead\nrecord the later accepted chain:\n\n```text\nFoundation accepted/admitted\n→ Task-04 implemented and T-ACCEPT PASS\n→ Task-05 identity/session integration\n→ Task-05 PERF repair\n→ Task-06 authoritative Admin presentation\n→ production deploy/acceptance\n```\n\n## 36. Current source-of-truth map\n\n| Topic | Current owner/reference |\n|---|---|\n| normalized evidence/store | `app/device_fingerprint/` Task-01 code |\n| network sensor | `app/device_fingerprint_sensor/`, `deploy/device-fingerprint/` |\n| Portal evidence | `app/device_fingerprint_portal/`, `docs/modules/device-fingerprint-portal.md` |\n| source health/bindings/snapshot | `app/device_fingerprint/` foundation contracts |\n| knowledge/policy | `app/device_fingerprint/` knowledge/policy artifacts |\n| pure classifier/fusion | `app/device_fingerprint/origin_assessment.py`, `fusion.py` |\n| runtime profiles/control plane | `app/device_fingerprint/` runtime-profile/control-plane modules |\n| classification persistence/read | `classification_persistence.py`, `classification_read.py` |\n| Task-05 integration | `app/device_fingerprint_integration/` |\n| production worker | `fingerprint-classification.service` deployment artifact |\n| Admin projection | `app/admin_web/device_fingerprint_presentation.py`, `docs/modules/admin-web.md` |\n| R14 normative semantics | registered FINAL R14 architecture decision |\n'
EN_BLOCK = '<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->\n## Device Fingerprint — current production\n\nDevice Fingerprint is now a production-active passive/advisory classification\ncapability, not only an evidence foundation.\n\n```text\nrepository / production HEAD = 7c7c0919c3e546f499b5252ea9479d32c8f494d7\nrepository / production tree = dbf3e3804931d637ef1ec569128746ebce5c141a\nPR #178 = MERGED\nTASK-DEVICE-FINGERPRINT-04 = CLOSED / ACCEPTED\nTASK-DEVICE-FINGERPRINT-05 = CLOSED / INTEGRATED\nTASK-DEVICE-FINGERPRINT-05-PERF-01 = CLOSED\nTASK-DEVICE-FINGERPRINT-06 = PRODUCTION PASS / DEPLOYED\ncaptive-portal.service = active\nfingerprint-classification.service = active\n```\n\nHigh-level flow:\n\n```mermaid\nflowchart LR\n    E[Passive normalized evidence] --> C[Deterministic Device Fingerprint]\n    C --> P[(Persisted PRODUCTION ClassificationResult)]\n    P --> A[Admin read model]\n    A --> H[Home]\n    A --> D[Device Card]\n```\n\nCurrent Home product terminology:\n\n```text\nType     = fingerprint device_class\nPlatform = controller / Omada device_type\n```\n\nController Platform never backfills fingerprint Type. Device Card keeps\n**Controller Platform** separate from **Fingerprint Information**. No-result is\n`—`, a completed unresolved dimension is `Unknown`, and a fingerprint read failure\nis `Unavailable`/`—` without failing core Admin data.\n\nDetailed architecture and all engineering diagrams:\n`docs/modules/device-fingerprint.md`.\n<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->\n'
RU_BLOCK = '<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->\n## Device Fingerprint — текущее production-состояние\n\nDevice Fingerprint теперь является production-active пассивной/advisory системой\nклассификации устройств, а не только foundation для хранения evidence.\n\n```text\nrepository / production HEAD = 7c7c0919c3e546f499b5252ea9479d32c8f494d7\nrepository / production tree = dbf3e3804931d637ef1ec569128746ebce5c141a\nPR #178 = MERGED\nTASK-DEVICE-FINGERPRINT-04 = CLOSED / ACCEPTED\nTASK-DEVICE-FINGERPRINT-05 = CLOSED / INTEGRATED\nTASK-DEVICE-FINGERPRINT-05-PERF-01 = CLOSED\nTASK-DEVICE-FINGERPRINT-06 = PRODUCTION PASS / DEPLOYED\ncaptive-portal.service = active\nfingerprint-classification.service = active\n```\n\n```mermaid\nflowchart LR\n    E[Passive normalized evidence] --> C[Deterministic Device Fingerprint]\n    C --> P[(Persisted PRODUCTION ClassificationResult)]\n    P --> A[Admin read model]\n    A --> H[Home]\n    A --> D[Device Card]\n```\n\nТекущая product-терминология Home:\n\n```text\nType     = fingerprint device_class\nPlatform = controller / Omada device_type\n```\n\nController Platform никогда не заполняет Fingerprint Type. Device Card отдельно\nпоказывает **Controller Platform** и **Fingerprint Information**. `—` означает,\nчто authoritative production-result ещё отсутствует; `Unknown` — завершённую,\nно не разрешённую dimension; `Unavailable` — недоступность read/persistence path.\n\nПодробный архитектурный контракт и схемы:\n`docs/modules/device-fingerprint.md`.\n<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->\n'

def run(repo, *args, capture=True):
    cp = subprocess.run(["git", *args], cwd=repo, text=True,
                        stdout=subprocess.PIPE if capture else None,
                        stderr=subprocess.PIPE if capture else None)
    if cp.returncode:
        raise RuntimeError(f"git {' '.join(args)} failed:\n{cp.stderr or ''}")
    return (cp.stdout or "").strip()

def replace_marker(text, block):
    if MARK_BEGIN in text:
        pattern = re.compile(re.escape(MARK_BEGIN) + r".*?" + re.escape(MARK_END), re.S)
        if not pattern.search(text):
            raise RuntimeError("broken Device Fingerprint marker block")
        return pattern.sub(block.rstrip(), text, count=1)
    # Place the current block before the first detailed legacy/current product section.
    anchors = (
        "## Admin Web local asset library",
        "## Current vs planned",
        "## 1. Mental model",
        "## 1. Composition roots",
        "## Current production evidence",
        "## Device Detail — Historical vs Current",
        "## Secrets",
        "## Core precondition",
    )
    for anchor in anchors:
        pos = text.find(anchor)
        if pos >= 0:
            return text[:pos] + block.rstrip() + "\n\n" + text[pos:]
    return text.rstrip() + "\n\n" + block.rstrip() + "\n"

def replace_section(text, heading, next_heading, replacement):
    start = text.find(heading)
    if start < 0:
        raise RuntimeError(f"missing section anchor: {heading}")
    end = text.find(next_heading, start + len(heading))
    if end < 0:
        raise RuntimeError(f"missing next section anchor: {next_heading}")
    return text[:start] + replacement.rstrip() + "\n\n" + text[end:]

def header_baseline(text, path):
    replacements = {
        "docs/README.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Current-state implementation baseline: `main@[0-9a-f]{40}`",
             "Current-state implementation baseline: `main@" + BASE_COMMIT + "`"),
            (r"Current implementation tree: `[0-9a-f]{40}`",
             "Current implementation tree: `" + BASE_TREE + "`"),
        ],
        "docs/architecture.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Runtime implementation baseline: `main@[0-9a-f]{40}`",
             "Runtime implementation baseline: `main@" + BASE_COMMIT + "`"),
            (r"Runtime tree: `[0-9a-f]{40}`", "Runtime tree: `" + BASE_TREE + "`"),
        ],
        "docs/project-inventory.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Runtime commit: `[0-9a-f]{40}`", "Runtime commit: `" + BASE_COMMIT + "`"),
            (r"Runtime tree: `[0-9a-f]{40}`", "Runtime tree: `" + BASE_TREE + "`"),
            (r"Commit source: .*", "Commit source: merge PR #178 / Task-06 Device Fingerprint presentation, 2026-10-04"),
        ],
        "docs/module-index.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Runtime implementation baseline: `main@[0-9a-f]{40}`",
             "Runtime implementation baseline: `main@" + BASE_COMMIT + "`"),
            (r"Runtime tree: `[0-9a-f]{40}`", "Runtime tree: `" + BASE_TREE + "`"),
        ],
        "docs/modules/admin-web.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Baseline: `main@[0-9a-f]{40}`", "Baseline: `main@" + BASE_COMMIT + "`"),
        ],
        "docs/testing.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Documentation/current-state implementation baseline: `main@[0-9a-f]{40}`",
             "Documentation/current-state implementation baseline: `main@" + BASE_COMMIT + "`"),
            (r"Production deployed HEAD: `[0-9a-f]{40}`", "Production deployed HEAD: `" + BASE_COMMIT + "`"),
            (r"Production tree: `[0-9a-f]{40}`", "Production tree: `" + BASE_TREE + "`"),
        ],
        "docs/deployment.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Current repository implementation baseline: `main@[0-9a-f]{40}`",
             "Current repository implementation baseline: `main@" + BASE_COMMIT + "`"),
            (r"Confirmed production deployed HEAD: `[0-9a-f]{40}`",
             "Confirmed production deployed HEAD: `" + BASE_COMMIT + "`"),
            (r"Confirmed production tree: `[0-9a-f]{40}`",
             "Confirmed production tree: `" + BASE_TREE + "`"),
        ],
        "docs/security.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Baseline: `main@[0-9a-f]{40}`", "Baseline: `main@" + BASE_COMMIT + "`"),
        ],
        "docs/configuration.md": [
            (r"Updated: \d{4}-\d{2}-\d{2}", "Updated: 2026-10-04"),
            (r"Baseline: `main@[0-9a-f]{40}`", "Baseline: `main@" + BASE_COMMIT + "`"),
        ],
    }
    for pattern, repl in replacements.get(path, []):
        text, count = re.subn(pattern, repl, text, count=1)
        if count != 1:
            raise RuntimeError(f"header pattern missing/ambiguous in {path}: {pattern}")
    return text

def update_readme_table(text):
    anchor = "| Current Device Context |"
    if "Device Fingerprint | **PRODUCTION ACTIVE" in text:
        return text
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith(anchor):
            lines.insert(i + 1, "| Device Fingerprint | **PRODUCTION ACTIVE / ADMIN VISIBLE** |")
            return "\n".join(lines) + ("\n" if text.endswith("\n") else "")
    raise RuntimeError("README project-at-a-glance anchor missing")

def fix_controller_sections(text):
    text = text.replace(
        "## Canonical Device Type contract — current production",
        "## Controller Platform lexical contract — current production compatibility",
    )
    text = text.replace(
        "## Device Card Device Type — current presentation",
        "## Device Card Controller Platform — current presentation",
    )
    # Preserve the old asset implementation as provenance, not a current whole-project checkpoint.
    text = text.replace(
        "## Admin Web local asset library — current production",
        "## Admin Web local asset library — historical production provenance",
    )
    return text

HOME_SECTION = """## Home Online Devices — current presentation

Current production columns:

```text
Device / MAC
Type
Platform
Auth
IP
AP
Band
RSSI
SNR
Uptime
Traffic
```

`Type` is the compact Device Fingerprint `device_class` presentation from the
latest authoritative PRODUCTION `ClassificationResult`.

`Platform` is the existing controller/Omada `device_type` presentation and keeps
the `device_type_key`/Android-icon compatibility contract.

```text
Type != Platform
Controller Platform NEVER backfills Fingerprint Type
```

Fingerprint no-result is `—`; a completed unresolved device class is `Unknown`.
A fingerprint read failure remains fail-soft and does not remove the rest of the
Home row.
"""

ADMIN_HOME_SECTION = HOME_SECTION

ARCH_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Device Fingerprint production architecture

Device Fingerprint is a Site-scoped advisory subsystem with independent
evidence, classification/control-plane, integration and presentation boundaries.

```mermaid
flowchart LR
    SPAN[SPAN sensor] --> EV[Normalized Evidence]
    PORTAL[Portal evidence] --> EV
    EV --> SNAP[Snapshot + SourceEvaluability]
    SNAP --> CLS[Pure deterministic classifier]
    CLS --> CDB[(Classification SQLite)]
    AUTH[Confirmed AuthRun] --> JOB[Task-05 integration job]
    JOB --> CLS
    CDB --> READ[production-only read]
    READ --> ADMIN[Home + Device Card]
```

The classifier has no Authorization/CAPPORT authority. Current product Type is
fingerprint `device_class`; the historical/controller `device_type` contract is
presented as Controller Platform.

Full subsystem architecture, runtime-profile/admission model and 16 focused
Mermaid diagrams: `modules/device-fingerprint.md`.
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

PROJECT_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Device Fingerprint — current production subsystem

Current state is broader than TASK-01 Evidence Foundation.

```text
Evidence Foundation
+ network / Portal producers
+ source-health/binding/snapshot foundation
+ versioned knowledge/policy
+ Task-04 classification core + persistence/read
+ Task-05 post-Auth integration + durable worker
+ Task-06 Admin presentation
= current Device Fingerprint system
```

Production checkpoint is the document header commit/tree. Task-06 is deployed and
Owner-accepted; `captive-portal.service` and `fingerprint-classification.service`
are active.

Current owned stores:

```text
device_fingerprint_evidence.sqlite3
device_fingerprint_classification.sqlite3
device_fingerprint_control_plane.sqlite3
device_fingerprint_integration.sqlite3
```

Current product read is Site-scoped and production-only. Home uses a bounded
batch (maximum 250 input MACs) and Device Card consumes the same authoritative
classification result.
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

MODULE_INDEX_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Device Fingerprint current routing

| Layer | Status | Owner | Persistence / output |
|---|---|---|---|
| Evidence Foundation | current production foundation | `app/device_fingerprint/` | Evidence SQLite |
| Network Evidence Producer | current implementation / deployed foundation | `app/device_fingerprint_sensor/` | normalized envelopes only |
| Portal Evidence Producer | current implementation / production foundation | `app/device_fingerprint_portal/` | normalized Portal evidence |
| Foundation contracts / admission | accepted/current | `app/device_fingerprint/` | control-plane artifacts |
| Classification Core | TASK-04 closed/accepted | `app/device_fingerprint/` | ClassificationResult |
| Classification persistence/read | current production | classification persistence/read services | Classification SQLite |
| Post-Auth integration worker | TASK-05 closed/current | `app/device_fingerprint_integration/` | Integration SQLite |
| Admin presentation | TASK-06 production pass | `app/admin_web/device_fingerprint_presentation.py` | read-only Home / Device Card |

Canonical detailed contract: `modules/device-fingerprint.md`.
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

PORTAL_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Current relationship to the production classifier

Portal evidence is one origin in the current Device Fingerprint system; it is not
a separate classifier. The normalized Portal evidence joins DHCP/TCP/TLS/QUIC
evidence in snapshot/origin assessment, while MAC Registry is a knowledge-based
sixth origin.

Current source-health liveness uses the admitted PERIODIC Portal emitter:

```text
nominal same-state heartbeat = 60 seconds
freshness timeout = 180 seconds
timeout disposition = unknown
```

The older EVENT_DRIVEN emitter remains historical lineage and has a frozen
freshness value of 0 seconds.

Raw request headers remain non-durable. The classifier consumes normalized
persisted evidence only.
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

TEST_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Device Fingerprint — latest acceptance evidence

Historical/current acceptance must be kept separate from production smoke.

```text
TASK-04 T-ACCEPT R6 = PASS / ACCEPTED / PRODUCTION_ELIGIBLE
Task-05 accepted integration full-repository evidence = 5171 passed, 30 skipped
Task-05 R1 full repository = 5184 passed, 28 skipped
Task-05 PERF-01 full repository = 5198 passed, 28 skipped
Task-06 focused candidate = 189 passed
Task-06 R1 = 22 passed
```

Task-06 publication and production deployment are separate stages. Production
verification used exact-code switch + bounded smoke/visual acceptance; the full
pytest suite was **not** run on production and must not be described as such.

Current documentation sync is docs-only and does not require a full pytest rerun.
Required checks are diff/Markdown/link/Mermaid sanity plus source-truth review.
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

DEPLOY_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Device Fingerprint production deployment

Current production checkpoint is the document header commit/tree.

Confirmed final Task-06 production state:

```text
captive-portal.service = active
fingerprint-classification.service = active
TASK-DEVICE-FINGERPRINT-06 = PRODUCTION PASS / DEPLOYED
```

Device Fingerprint domain stores:

```text
/opt/CaptivePortal/data/device_fingerprint_evidence.sqlite3
/opt/CaptivePortal/data/device_fingerprint_classification.sqlite3
/opt/CaptivePortal/data/device_fingerprint_control_plane.sqlite3
/opt/CaptivePortal/data/device_fingerprint_integration.sqlite3
```

Current canonical SnapshotExecutionPolicy memory guard is 1 GiB
(`process_memory_guard_bytes=1073741824`). This is a process-RSS guard, not a RAM
reservation.

`fingerprint-classification.service` is the durable Task-05 consumer. It uses
claim/lease/retry state and the active admitted ClassificationRuntimeProfile;
it does not open an Omada/controller listener.

Permanent production rules:

```text
exact code comes from verified Git SHA/tree
no local production source patch
no full pytest on production
activation is explicit and separate where applicable
historical failed integration/classification rows remain evidence
```
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

SEC_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Device Fingerprint security / privacy boundary

Current Device Fingerprint classification is passive and advisory.

```text
fingerprint result does NOT authorize users
fingerprint result does NOT change CAPPORT admission
fingerprint result does NOT block clients
fingerprint result does NOT trigger destructive Omada actions
fingerprint result is NOT a security credential
```

Production classification is Site-scoped and uses admitted normalized evidence.
Raw packets, raw full EVE, raw User-Agent/Client Hints, cookies and credentials
are not durable classifier evidence.

The runtime classifier requires no Internet/query-time cloud classification.
External knowledge enters through versioned/pinned/offline governance and
admission. Admin fingerprint presentation is read-only and Site-authorized.
Read/persistence failure is fail-soft to core Home/Device Card/Auth/CAPPORT.
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

CONFIG_BLOCK = """<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:BEGIN -->
## Device Fingerprint configuration map

Repository configuration exposes separate paths for the four ownership domains:

```text
DEVICE_FINGERPRINT_EVIDENCE_DB_PATH
  /opt/CaptivePortal/data/device_fingerprint_evidence.sqlite3

DEVICE_FINGERPRINT_CLASSIFICATION_DB_PATH
  /opt/CaptivePortal/data/device_fingerprint_classification.sqlite3

DEVICE_FINGERPRINT_CONTROL_PLANE_DB_PATH
  /opt/CaptivePortal/data/device_fingerprint_control_plane.sqlite3

DEVICE_FINGERPRINT_INTEGRATION_DB_PATH
  /opt/CaptivePortal/data/device_fingerprint_integration.sqlite3
```

`DEVICE_FINGERPRINT_INTEGRATION_ENABLED` remains repository-default false; a
repository default is not evidence of the live production flag.

The current 1-GiB `SnapshotExecutionPolicy.process_memory_guard_bytes` is a
versioned classifier/foundation policy artifact, not a replacement environment
variable and not a 1-GiB reservation.
<!-- DEVICE-FINGERPRINT-PRODUCTION-KB:END -->
"""

def transform(path, text):
    if path == "docs/modules/device-fingerprint.md":
        return MODULE.rstrip() + "\n"

    text = header_baseline(text, path)

    if path in ("README.md", "README_RU.md"):
        # Update only the top current checkpoint table values, not historical SHA mentions.
        for label, value in (
            ("Repository implementation checkpoint", "main@" + BASE_COMMIT),
            ("Repository tree", BASE_TREE),
            ("Production deployed HEAD", BASE_COMMIT),
            ("Production tree", BASE_TREE),
        ):
            pattern = re.compile(rf"(\|\s*{re.escape(label)}\s*\|\s*)`[^`]+`(\s*\|)")
            text, n = pattern.subn(rf"\1`{value}`\2", text, count=1)
            if n != 1:
                raise RuntimeError(f"README checkpoint row missing: {label}")
        text = update_readme_table(text)
        text = fix_controller_sections(text)
        block = RU_BLOCK if path == "README_RU.md" else EN_BLOCK
        text = replace_marker(text, block)
        if "## Home Online Devices — current presentation" in text:
            text = replace_section(
                text, "## Home Online Devices — current presentation",
                "## Device Card Controller Platform — current presentation", HOME_SECTION)
        return text

    if path == "docs/README.md":
        text = text.replace(
            "- [Device Fingerprint Evidence](modules/device-fingerprint.md) — current,\n  default disabled passive evidence foundation and isolated auxiliary service.",
            "- [Device Fingerprint](modules/device-fingerprint.md) — current production passive/advisory classification subsystem; TASK-01 remains its Evidence Foundation layer."
        )
        if "- `modules/device-fingerprint.md`" not in text:
            text = text.replace("- `modules/admin-web.md`",
                                "- `modules/device-fingerprint.md`\n- `modules/device-fingerprint-portal.md`\n- `modules/admin-web.md`")
        text = fix_controller_sections(text)
        text = replace_marker(text, EN_BLOCK)
        if "## Home Online Devices — current presentation" in text:
            text = replace_section(
                text, "## Home Online Devices — current presentation",
                "## Device Card Controller Platform — current presentation", HOME_SECTION)
        return text

    if path == "docs/architecture.md":
        old = """## Controlled auxiliary composition root

`run.py` remains the lifecycle/composition root for the main
`captive-portal.service`. TASK-DEVICE-FINGERPRINT-01 authorizes one isolated
exception: `python3 -m app.device_fingerprint.cli run` for
`fingerprint-evidence.service`. Its Flask app, SQLite writer, TLS listener and
maintenance lifecycle are not registered into the main runtime.

"""
        new = """## Controlled auxiliary composition roots

`run.py` remains the lifecycle/composition root for the main
`captive-portal.service`. Device Fingerprint also has explicitly authorized
auxiliary process roots: Task-01 evidence service, Task-02 sensor/Suricata
services, and the Task-05 `fingerprint-classification.service` durable consumer.
They are not folded into the main Flask process merely because their data is
consumed by Admin presentation.

"""
        if old not in text:
            raise RuntimeError("architecture auxiliary-root anchor drift")
        text = text.replace(old, new, 1)
        return replace_marker(text, ARCH_BLOCK)

    if path == "docs/project-inventory.md":
        if "## Device Fingerprint Evidence" in text:
            text = replace_section(text, "## Device Fingerprint Evidence", "## 1. Composition roots", PROJECT_BLOCK)
        else:
            text = replace_marker(text, PROJECT_BLOCK)
        # Add explicit worker root after Task-01 root if not already present.
        anchor = "- `python3 -m app.device_fingerprint.cli run` — независимо разрешённый `TASK-DEVICE-FINGERPRINT-01` auxiliary composition root; в main runtime не регистрируется.\n"
        if anchor in text and "fingerprint-classification.service` —" not in text:
            text = text.replace(anchor, anchor +
                "- `fingerprint-classification.service` — Task-05 durable classification consumer / auxiliary composition root.\n"
                "- `fingerprint-sensor.service` + `fingerprint-suricata.service` — isolated passive network evidence stack.\n", 1)
        # Persistence table additions before generic writer sentence.
        marker = "| `traffic_projection.sqlite3` |"
        if "device_fingerprint_classification.sqlite3` |" not in text and marker in text:
            line_end = text.find("\n", text.find(marker))
            additions = (
                "\n| `device_fingerprint_evidence.sqlite3` | Fingerprint Evidence Foundation | snapshot/classifier foundation | normalized evidence + source health |"
                "\n| `device_fingerprint_classification.sqlite3` | Task-04 classification persistence | classification read/Admin | ClassificationResult history |"
                "\n| `device_fingerprint_control_plane.sqlite3` | runtime-profile/control-plane owner | classifier runtime | admission/activation/validity lineage |"
                "\n| `device_fingerprint_integration.sqlite3` | Task-05 integration worker | Task-05 read/worker | durable post-Auth jobs + identity/classification links |"
            )
            text = text[:line_end] + additions + text[line_end:]
        return text

    if path == "docs/module-index.md":
        text = text.replace(
            "| Device Fingerprint Evidence | current; default disabled | `app/device_fingerprint/` | `modules/device-fingerprint.md` | isolated SQLite v1 | no |",
            "| Device Fingerprint Evidence Foundation | current foundation layer | `app/device_fingerprint/` | `modules/device-fingerprint.md` | Evidence SQLite | no |"
        )
        text = replace_marker(text, MODULE_INDEX_BLOCK)
        text = re.sub(r"Owner-provided production checkpoint \d{4}-\d{2}-\d{2}:",
                      "Owner-provided production checkpoint 2026-10-04:", text, count=1)
        text = re.sub(r"HEAD: [0-9a-f]{40}\ntree: [0-9a-f]{40}",
                      "HEAD: " + BASE_COMMIT + "\ntree: " + BASE_TREE, text, count=1)
        if "TASK-DEVICE-FINGERPRINT-06:" not in text:
            anchor = "Windows Central Lab current runner: V7 strict"
            insert = (
                "TASK-DEVICE-FINGERPRINT-04: CLOSED / ACCEPTED / PRODUCTION ELIGIBLE\n"
                "TASK-DEVICE-FINGERPRINT-05: CLOSED / INTEGRATED\n"
                "TASK-DEVICE-FINGERPRINT-05-PERF-01: CLOSED\n"
                "TASK-DEVICE-FINGERPRINT-06: PRODUCTION PASS / DEPLOYED / ADMIN VISIBLE\n"
                "fingerprint-classification.service=active\n"
            )
            if anchor not in text:
                raise RuntimeError("module-index production anchor drift")
            text = text.replace(anchor, insert + anchor, 1)
        return text

    if path == "docs/modules/device-fingerprint-portal.md":
        text = text.replace("Status: **implemented; repository default disabled**.",
                            "Status: **current production-foundation producer; repository default remains disabled**.", 1)
        return replace_marker(text, PORTAL_BLOCK)

    if path == "docs/modules/admin-web.md":
        text = fix_controller_sections(text)
        text = replace_marker(text, EN_BLOCK)
        if "## Home Online Devices — current presentation" in text:
            text = replace_section(text, "## Home Online Devices — current presentation", "## Home", ADMIN_HOME_SECTION)
        return text

    if path == "docs/testing.md":
        return replace_marker(text, TEST_BLOCK)
    if path == "docs/deployment.md":
        return replace_marker(text, DEPLOY_BLOCK)
    if path == "docs/security.md":
        return replace_marker(text, SEC_BLOCK)
    if path == "docs/configuration.md":
        return replace_marker(text, CONFIG_BLOCK)

    return text

def semantic_assertions(outputs):
    required = {
        "docs/modules/device-fingerprint.md": [
            "current production capability", "DF-01 — Full end-to-end",
            "DF-16 — Current Device Fingerprint vs future Traffic Enrichment",
            "Type       = fingerprint device_class",
            "process_memory_guard_bytes = 1073741824",
            "fingerprint-classification.service",
        ],
        "docs/modules/admin-web.md": [
            "Type     = fingerprint device_class",
            "Platform = controller / Omada device_type",
        ],
        "docs/README.md": ["production-active passive/advisory classification subsystem"],
        "docs/security.md": ["fingerprint result does NOT authorize users"],
        "docs/deployment.md": ["no full pytest on production"],
    }
    for path, needles in required.items():
        for needle in needles:
            if needle not in outputs[path]:
                raise RuntimeError(f"semantic assertion failed: {path} missing {needle!r}")
    if outputs["docs/modules/device-fingerprint.md"].count("```mermaid") != 16:
        raise RuntimeError("expected exactly 16 Mermaid diagrams")
    for path in TARGETS:
        if path == "docs/modules/device-fingerprint.md":
            continue
        if path.startswith("app/") or path.startswith("tests/"):
            raise RuntimeError("runtime/test path unexpectedly in target scope")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--commit", action="store_true",
                    help="create a local documentation commit after staging; never pushes")
    args = ap.parse_args()
    repo = pathlib.Path(args.repo).resolve()

    print("=== PRECHECK ===")
    if run(repo, "status", "--porcelain"):
        raise RuntimeError("worktree must be clean")
    run(repo, "fetch", "origin", "main")
    origin = run(repo, "rev-parse", "origin/main")
    if origin != BASE_COMMIT:
        raise RuntimeError(f"origin/main moved: {origin} != {BASE_COMMIT}")
    run(repo, "checkout", "main", capture=False)
    run(repo, "reset", "--hard", BASE_COMMIT, capture=False)
    head = run(repo, "rev-parse", "HEAD")
    tree = run(repo, "rev-parse", "HEAD^{tree}")
    if head != BASE_COMMIT or tree != BASE_TREE:
        raise RuntimeError(f"exact baseline mismatch: {head} / {tree}")
    if run(repo, "status", "--porcelain"):
        raise RuntimeError("baseline worktree not clean")

    print("=== TRANSACTIONAL BUILD ===")
    outputs = {}
    for path in TARGETS:
        source = (repo / path).read_text(encoding="utf-8")
        outputs[path] = transform(path, source)
    semantic_assertions(outputs)
    print(f"PASS: built {len(outputs)} docs in memory")

    # Write only after all transforms/assertions pass.
    try:
        run(repo, "checkout", "-b", BRANCH, capture=False)
    except RuntimeError:
        # Reuse only a local branch that still points at exact base.
        if run(repo, "rev-parse", BRANCH) != BASE_COMMIT:
            raise
        run(repo, "checkout", BRANCH, capture=False)

    for path, content in outputs.items():
        target = repo / path
        target.write_text(content, encoding="utf-8", newline="\n")

    run(repo, "add", "--", *TARGETS)
    changed = run(repo, "diff", "--cached", "--name-only").splitlines()
    if tuple(changed) != tuple(sorted(TARGETS)):
        if set(changed) != set(TARGETS):
            raise RuntimeError(f"changed scope mismatch: {changed}")
    run(repo, "diff", "--cached", "--check")
    print("PASS: exact documentation scope staged")
    print(run(repo, "diff", "--cached", "--stat"))

    # Stale current-truth checks in the edited current docs only.
    current = "\n".join(outputs.values())
    forbidden = [
        "Status: **current; default disabled**.\n\nTASK-DEVICE-FINGERPRINT-01 provides",
        "Home Type is the existing controller/source value",
    ]
    for needle in forbidden:
        if needle in current:
            raise RuntimeError(f"stale current truth remains: {needle}")

    if args.commit:
        run(repo, "commit", "-m",
            "docs: sync Device Fingerprint production knowledge", capture=False)
        print("LOCAL COMMIT:", run(repo, "rev-parse", "HEAD"))
        print("LOCAL TREE  :", run(repo, "rev-parse", "HEAD^{tree}"))
    else:
        print("NO-COMMIT: exact documentation diff is staged")
    print("NO PUSH / NO PR / NO MERGE / NO DEPLOY")

if __name__ == "__main__":
    main()
