#!/usr/bin/env python3
"""Verify the already-repaired Device Fingerprint KB staged candidate.

R3 already removed trailing whitespace and re-staged the module. This verifier
makes no repository content changes. It validates exact state, UTF-8 content,
scope, semantics, Mermaid count, diff cleanliness and emits a review patch.

No commit/push/PR/merge/deploy.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess

EXPECTED_BRANCH = "docs/device-fingerprint-production-knowledge-sync"
EXPECTED_HEAD = "7c7c0919c3e546f499b5252ea9479d32c8f494d7"
EXPECTED_FILES = tuple(sorted((
    "README.md",
    "README_RU.md",
    "docs/README.md",
    "docs/architecture.md",
    "docs/configuration.md",
    "docs/deployment.md",
    "docs/module-index.md",
    "docs/modules/admin-web.md",
    "docs/modules/device-fingerprint-portal.md",
    "docs/modules/device-fingerprint.md",
    "docs/project-inventory.md",
    "docs/security.md",
    "docs/testing.md",
)))

def git_bytes(repo: Path, *args: str, check: bool = True) -> bytes:
    cp = subprocess.run(
        ["git", *args],
        cwd=repo,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and cp.returncode:
        details = b"\n".join(
            part.rstrip() for part in (cp.stdout or b"", cp.stderr or b"")
            if part.strip()
        ).decode("utf-8", "replace")
        raise RuntimeError(
            f"git {' '.join(args)} failed"
            + (f":\n{details}" if details else "")
        )
    return cp.stdout or b""

def git_text(repo: Path, *args: str, check: bool = True) -> str:
    return git_bytes(repo, *args, check=check).decode("utf-8", "strict").strip()

def lines(value: str) -> tuple[str, ...]:
    return tuple(line.strip() for line in value.splitlines() if line.strip())

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--patch", required=True)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    patch = Path(args.patch).resolve()

    print("=== R4 VERIFY PRECHECK ===")

    branch = git_text(repo, "branch", "--show-current")
    head = git_text(repo, "rev-parse", "HEAD")

    print(f"BRANCH={branch}")
    print(f"HEAD={head}")

    if branch != EXPECTED_BRANCH:
        raise RuntimeError(f"wrong branch: {branch}")
    if head != EXPECTED_HEAD:
        raise RuntimeError(f"wrong HEAD: {head}")

    staged = tuple(sorted(lines(git_text(repo, "diff", "--cached", "--name-only"))))
    if staged != EXPECTED_FILES:
        raise RuntimeError(f"staged scope mismatch: {staged}")

    unstaged = lines(git_text(repo, "diff", "--name-only"))
    untracked = lines(git_text(repo, "ls-files", "--others", "--exclude-standard"))
    if unstaged:
        raise RuntimeError(f"unexpected unstaged paths: {unstaged}")
    if untracked:
        raise RuntimeError(f"unexpected untracked paths: {untracked}")

    print("PASS: exact 13-file staged state")

    check = subprocess.run(
        ["git", "diff", "--cached", "--check"],
        cwd=repo,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check.returncode:
        details = b"\n".join(
            part.rstrip() for part in (check.stdout or b"", check.stderr or b"")
            if part.strip()
        ).decode("utf-8", "replace")
        raise RuntimeError(
            "git diff --cached --check failed"
            + (f":\n{details}" if details else "")
        )

    print("PASS: git diff --cached --check")

    # Read index blobs as raw bytes, then decode explicitly as UTF-8.
    module = git_bytes(repo, "show", ":docs/modules/device-fingerprint.md").decode("utf-8", "strict")
    admin = git_bytes(repo, "show", ":docs/modules/admin-web.md").decode("utf-8", "strict")
    root_en = git_bytes(repo, "show", ":README.md").decode("utf-8", "strict")
    root_ru = git_bytes(repo, "show", ":README_RU.md").decode("utf-8", "strict")
    docs_readme = git_bytes(repo, "show", ":docs/README.md").decode("utf-8", "strict")
    portal = git_bytes(repo, "show", ":docs/modules/device-fingerprint-portal.md").decode("utf-8", "strict")
    deployment = git_bytes(repo, "show", ":docs/deployment.md").decode("utf-8", "strict")
    security = git_bytes(repo, "show", ":docs/security.md").decode("utf-8", "strict")

    required_module = (
        "DF-01",
        "Full end-to-end",
        "DF-16",
        "Current Device Fingerprint vs future Traffic Enrichment",
        "process_memory_guard_bytes = 1073741824",
        "fingerprint-classification.service",
        "Type       = fingerprint device_class",
        "Controller Platform NEVER backfills Fingerprint Type",
    )
    for needle in required_module:
        if needle not in module:
            raise RuntimeError(f"module semantic assertion missing: {needle}")

    mermaid = module.count("```mermaid")
    if mermaid != 16:
        raise RuntimeError(f"expected 16 Mermaid diagrams, got {mermaid}")

    if "Type     = fingerprint device_class" not in admin:
        raise RuntimeError("Admin fingerprint Type contract missing")
    if "Platform = controller / Omada device_type" not in admin:
        raise RuntimeError("Admin Platform contract missing")

    if "production-active passive/advisory Device Fingerprint" not in root_en:
        raise RuntimeError("EN README current Fingerprint opening missing")
    if "The repository also contains a default-disabled passive Device Fingerprint" in root_en:
        raise RuntimeError("stale EN README Fingerprint opening remains")

    if "production-active пассивная/advisory подсистема" not in root_ru:
        raise RuntimeError("RU README current Fingerprint opening missing")
    if "В репозитории также находится по умолчанию выключенная основа пассивного сбора" in root_ru:
        raise RuntimeError("stale RU README Fingerprint opening remains")

    if "current production passive/advisory classification subsystem" not in docs_readme:
        raise RuntimeError("docs/README current Fingerprint routing missing")

    if "current production-foundation producer" not in portal:
        raise RuntimeError("Portal current production-foundation wording missing")
    if "Current relationship to the production classifier" not in portal:
        raise RuntimeError("Portal/classifier relationship section missing")

    if "fingerprint result does NOT authorize users" not in security:
        raise RuntimeError("security advisory boundary missing")
    if "no full pytest on production" not in deployment:
        raise RuntimeError("deployment production-test boundary missing")

    # Guard the rewritten module itself against trailing whitespace.
    bad_ws = [
        i for i, line in enumerate(module.splitlines(), 1)
        if line.endswith((" ", "\t"))
    ]
    if bad_ws:
        raise RuntimeError(f"module trailing whitespace remains: {bad_ws[:20]}")

    print("PASS: UTF-8 content decode")
    print("PASS: semantic gates")
    print("PASS: 16 Mermaid diagrams")
    print("PASS: rewritten module has no trailing whitespace")

    if patch.exists():
        raise RuntimeError(f"patch already exists: {patch}")

    with patch.open("wb") as fh:
        cp = subprocess.run(
            ["git", "diff", "--cached", "--binary"],
            cwd=repo,
            stdout=fh,
            stderr=subprocess.PIPE,
        )
    if cp.returncode:
        raise RuntimeError(
            "patch generation failed: "
            + (cp.stderr.decode("utf-8", "replace") if cp.stderr else "")
        )
    if patch.stat().st_size <= 0:
        raise RuntimeError("generated patch is empty")

    stat = git_text(repo, "diff", "--cached", "--stat")
    print("=== STAGED DIFF STAT ===")
    print(stat)

    print("=== R4 VERIFY PASS ===")
    print(f"BRANCH={branch}")
    print(f"HEAD={head}")
    print(f"STAGED_FILES={len(staged)}")
    print(f"MERMAID={mermaid}")
    print(f"PATCH={patch}")
    print(f"PATCH_BYTES={patch.stat().st_size}")
    print("COMMIT=NO")
    print("PUSH=NO")
    print("PR=NO")
    print("MERGE=NO")
    print("DEPLOY=NO")

if __name__ == "__main__":
    main()
