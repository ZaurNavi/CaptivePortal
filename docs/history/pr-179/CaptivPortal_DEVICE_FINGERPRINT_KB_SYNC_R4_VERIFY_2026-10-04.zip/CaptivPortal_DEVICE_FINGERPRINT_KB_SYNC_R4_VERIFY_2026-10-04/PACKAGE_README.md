# CaptivPortal Device Fingerprint KB Sync — R4 verifier

Verification-only package for the already-repaired R3 staged candidate.

R3 successfully:
- repaired 83 trailing-whitespace lines;
- re-staged the module;
- passed `git diff --cached --check`.

R3 then failed only because Python on Windows decoded UTF-8 `git show` output
through the system cp1251 codec.

R4:
- makes no repository content changes;
- reads Git stdout as bytes and decodes explicitly as UTF-8;
- validates the exact 13-file staged scope;
- reruns `git diff --cached --check`;
- validates Device Fingerprint semantics and 16 Mermaid diagrams;
- generates a non-empty review patch;
- performs no commit/push/PR/merge/deploy.
