# CaptivPortal Device Fingerprint — Knowledge Reconciliation Report

Status: prepared / repository writes not performed in this session  
Date: 2026-10-04

## Exact audited baseline

```text
repository = ZaurNavi/CaptivePortal
main = 7c7c0919c3e546f499b5252ea9479d32c8f494d7
tree = dbf3e3804931d637ef1ec569128746ebce5c141a
merge source = PR #178
```

The GitHub repository was inspected at the exact baseline above. The local container
cannot resolve `github.com`, so a clean clone could not be materialized here. No
claim is made that the publisher was executed against a local clone in this session.

## Primary findings

1. `docs/modules/device-fingerprint.md` still opens as if TASK-01 Evidence Foundation
   describes the whole Device Fingerprint subsystem. Its Task-01 statements are
   historically correct, but the document structure is stale for current production.
2. PR #178 updated only `docs/modules/device-fingerprint.md` and
   `docs/modules/admin-web.md`; the wider current knowledge layer was not reconciled.
3. `README.md`, `README_RU.md`, `docs/README.md`, `docs/architecture.md`,
   `docs/project-inventory.md`, `docs/module-index.md`, `docs/testing.md`,
   `docs/deployment.md`, `docs/security.md` and `docs/configuration.md` still contain
   older current-checkpoint/Device-Fingerprint framing that predates the final chain.
4. `docs/modules/admin-web.md` has a correct Task-06 section at the top but later
   inherited sections still describe the controller `device_type` column as product
   **Type**. Current product truth is fingerprint **Type** plus controller **Platform**.
5. `AGENTS.md` still enumerates Task-01/Task-02 auxiliary roots and an older Lab
   baseline. Because changing agent instructions is a separate governance scope, this
   package reports that drift but does not modify `AGENTS.md`.
6. The current source confirms:
   - six classifier origins: DHCP, Portal, TCP, TLS, QUIC, MAC Registry;
   - four dimensions: platform, device class, manufacturer, model;
   - production-only grouped read, max 250 MAC inputs;
   - `—` / `Unknown` / `Unavailable` are distinct;
   - current SnapshotExecutionPolicy memory guard = 1 GiB;
   - four separate fingerprint SQLite domains;
   - Task-05 exact post-Auth timing/retry constants.

## Proposed documentation scope

Changed by the publisher:

```text
README.md
README_RU.md
docs/README.md
docs/architecture.md
docs/project-inventory.md
docs/module-index.md
docs/modules/device-fingerprint.md
docs/modules/device-fingerprint-portal.md
docs/modules/admin-web.md
docs/testing.md
docs/deployment.md
docs/security.md
docs/configuration.md
```

Explicitly NOT changed:

```text
runtime Python/JS/CSS
tests
SQLite schemas/data
.env.example / runtime configuration
AGENTS.md
.github/*
historical FINAL/R14/task acceptance documents
production host
```

## Historical/current boundary

Historical R14, earlier Foundation checklists, PR acceptance bodies and task records
remain evidence for their time. The sync must not rewrite them to pretend Task-04
was never HOLD or production was always active.

The new current module document instead explains the later state transition and
links back to normative historical contracts.

## Diagrams

The candidate `docs/modules/device-fingerprint.md` contains 16 Mermaid diagrams:

1. DF-01 End-to-End
2. DF-02 Evidence Origins
3. DF-03 Source Health & Time
4. DF-04 Snapshot Assembly
5. DF-05 Pure Classification Core
6. DF-06 Per-Dimension Fusion
7. DF-07 Knowledge & Policy
8. DF-08 Runtime Profiles & Admission
9. DF-09 Artifact / Audit Lineage
10. DF-10 Post-Auth Integration
11. DF-11 Device History
12. DF-12 Admin Presentation
13. DF-13 UI State Semantics
14. DF-14 Failure Isolation
15. DF-15 Production Components & Stores
16. DF-16 Current vs Future Enrichment

Every diagram includes Purpose, Inputs, Outputs, Persistence boundary, Failure
behavior and authoritative owner/module.

## Known separate-scope drift

`AGENTS.md` is current-governance content and still describes only the Task-01 and
Task-02 auxiliary process exceptions; it also contains older Lab-environment wording.
This package intentionally does not change agent instructions. Tech Lead should
issue a separate bounded instruction-governance task if those lines are to be
updated.

## Publication boundary

Proposed branch:

```text
docs/device-fingerprint-production-knowledge-sync
```

This package does not push, open a PR, merge or deploy. The publisher defaults to
local materialization/staging only and refuses any baseline other than the exact
audited commit/tree.

## R2 materialization correction

The first local materialization attempt stopped transactionally before repository
writes because one `docs/README.md` assertion expected wording different from the
generated current text. R2 corrects that assertion and also upgrades both root
README opening paragraphs so they no longer describe the whole current subsystem
as only a default-disabled Evidence Foundation.

## R3 materialization correction

R2 successfully built and staged the exact 13-document candidate, then stopped at
`git diff --cached --check`. Root cause: the rewritten module used Markdown
hard-break syntax (two trailing spaces) on 83 lines. Git treats those added
trailing spaces as whitespace errors. R3 normalizes those lines without changing
their semantic content and improves failed-command diagnostics.
