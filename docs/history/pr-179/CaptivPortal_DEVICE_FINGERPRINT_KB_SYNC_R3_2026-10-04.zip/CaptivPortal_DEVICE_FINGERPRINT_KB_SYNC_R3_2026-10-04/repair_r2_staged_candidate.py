#!/usr/bin/env python3
"""Repair the already-materialized R2 staged candidate.

Exact-state guarded. Changes only docs/modules/device-fingerprint.md by removing
trailing spaces/tabs from the fully rewritten module, then re-stages it and runs
the documentation gates. No commit/push/PR/merge/deploy.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess

EXPECTED_BRANCH = "docs/device-fingerprint-production-knowledge-sync"
EXPECTED_HEAD = "7c7c0919c3e546f499b5252ea9479d32c8f494d7"
MODULE = "docs/modules/device-fingerprint.md"
EXPECTED_FILES = tuple(sorted((
    "README.md",
    "README_RU.md",
    "docs/README.md",
    "docs/architecture.md",
    "docs/configuration.md",
    "docs/deployment.md",
    "docs/module-index.md",
    "docs/modules/admin-web.md",
    "docs/modules/device-fingerprint-portal.md",
    "docs/modules/device-fingerprint.md",
    "docs/project-inventory.md",
    "docs/security.md",
    "docs/testing.md",
)))

def git(repo: Path, *args: str, check: bool = True) -> str:
    cp = subprocess.run(
        ["git", *args],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and cp.returncode:
        details = "\n".join(
            part.rstrip() for part in (cp.stdout or "", cp.stderr or "") if part.strip()
        )
        raise RuntimeError(
            f"git {' '.join(args)} failed"
            + (f":\n{details}" if details else "")
        )
    return (cp.stdout or "").strip()

def lines(value: str) -> tuple[str, ...]:
    return tuple(line.strip() for line in value.splitlines() if line.strip())

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True)
    ap.add_argument("--patch", required=True)
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    patch = Path(args.patch).resolve()

    print("=== R3 REPAIR PRECHECK ===")
    branch = git(repo, "branch", "--show-current")
    head = git(repo, "rev-parse", "HEAD")
    if branch != EXPECTED_BRANCH:
        raise RuntimeError(f"wrong branch: {branch}")
    if head != EXPECTED_HEAD:
        raise RuntimeError(f"wrong HEAD: {head}")

    staged = tuple(sorted(lines(git(repo, "diff", "--cached", "--name-only"))))
    if staged != EXPECTED_FILES:
        raise RuntimeError(f"staged scope mismatch: {staged}")

    unstaged = lines(git(repo, "diff", "--name-only"))
    untracked = lines(git(repo, "ls-files", "--others", "--exclude-standard"))
    if unstaged:
        raise RuntimeError(f"unexpected unstaged paths before repair: {unstaged}")
    if untracked:
        raise RuntimeError(f"unexpected untracked paths before repair: {untracked}")

    print("PASS: exact R2 staged state")

    target = repo / MODULE
    original = target.read_text(encoding="utf-8")
    bad_before = [
        i for i, line in enumerate(original.splitlines(), 1)
        if line.endswith((" ", "\t"))
    ]
    if not bad_before:
        raise RuntimeError("expected module trailing whitespace is not present")

    repaired = "\n".join(
        line.rstrip(" \t") for line in original.splitlines()
    ).rstrip() + "\n"
    target.write_text(repaired, encoding="utf-8", newline="\n")

    changed_unstaged = lines(git(repo, "diff", "--name-only"))
    if changed_unstaged != (MODULE,):
        raise RuntimeError(
            f"repair touched unexpected unstaged paths: {changed_unstaged}"
        )

    git(repo, "add", "--", MODULE)

    print(f"REPAIRED TRAILING-WHITESPACE LINES: {len(bad_before)}")
    check = subprocess.run(
        ["git", "diff", "--cached", "--check"],
        cwd=repo,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check.returncode:
        details = "\n".join(
            part.rstrip() for part in (check.stdout or "", check.stderr or "")
            if part.strip()
        )
        raise RuntimeError(
            "git diff --cached --check still fails"
            + (f":\n{details}" if details else "")
        )
    print("PASS: git diff --cached --check")

    staged = tuple(sorted(lines(git(repo, "diff", "--cached", "--name-only"))))
    if staged != EXPECTED_FILES:
        raise RuntimeError("final staged scope changed")
    if lines(git(repo, "diff", "--name-only")):
        raise RuntimeError("unexpected final unstaged changes")
    if lines(git(repo, "ls-files", "--others", "--exclude-standard")):
        raise RuntimeError("unexpected final untracked files")

    module = git(repo, "show", f":{MODULE}")
    admin = git(repo, "show", ":docs/modules/admin-web.md")
    root_en = git(repo, "show", ":README.md")
    root_ru = git(repo, "show", ":README_RU.md")
    docs_readme = git(repo, "show", ":docs/README.md")

    required_module = (
        "DF-01",
        "Full end-to-end",
        "DF-16",
        "Current Device Fingerprint vs future Traffic Enrichment",
        "process_memory_guard_bytes = 1073741824",
        "fingerprint-classification.service",
        "Type       = fingerprint device_class",
        "Controller Platform NEVER backfills Fingerprint Type",
    )
    for needle in required_module:
        if needle not in module:
            raise RuntimeError(f"module semantic assertion missing: {needle}")
    if module.count("```mermaid") != 16:
        raise RuntimeError("expected exactly 16 Mermaid diagrams")
    if "Type     = fingerprint device_class" not in admin:
        raise RuntimeError("Admin fingerprint Type contract missing")
    if "Platform = controller / Omada device_type" not in admin:
        raise RuntimeError("Admin Platform contract missing")
    if "production-active passive/advisory Device Fingerprint" not in root_en:
        raise RuntimeError("EN README current Fingerprint opening missing")
    if "The repository also contains a default-disabled passive Device Fingerprint" in root_en:
        raise RuntimeError("stale EN README Fingerprint opening remains")
    if "production-active пассивная/advisory подсистема" not in root_ru:
        raise RuntimeError("RU README current Fingerprint opening missing")
    if "В репозитории также находится по умолчанию выключенная основа пассивного сбора" in root_ru:
        raise RuntimeError("stale RU README Fingerprint opening remains")
    if "current production passive/advisory classification subsystem" not in docs_readme:
        raise RuntimeError("docs/README current Fingerprint routing missing")

    print("PASS: semantic gates")
    print("PASS: 16 Mermaid diagrams")

    if patch.exists():
        raise RuntimeError(f"patch already exists: {patch}")
    with patch.open("wb") as fh:
        cp = subprocess.run(
            ["git", "diff", "--cached", "--binary"],
            cwd=repo,
            stdout=fh,
            stderr=subprocess.PIPE,
        )
    if cp.returncode:
        raise RuntimeError(
            "patch generation failed: "
            + (cp.stderr.decode("utf-8", "replace") if cp.stderr else "")
        )
    if patch.stat().st_size <= 0:
        raise RuntimeError("generated patch is empty")

    print("=== R3 REPAIR PASS ===")
    print(f"BRANCH={branch}")
    print(f"HEAD={head}")
    print(f"STAGED_FILES={len(staged)}")
    print("MERMAID=16")
    print(f"PATCH={patch}")
    print(f"PATCH_BYTES={patch.stat().st_size}")
    print("COMMIT=NO")
    print("PUSH=NO")
    print("PR=NO")
    print("MERGE=NO")
    print("DEPLOY=NO")

if __name__ == "__main__":
    main()
