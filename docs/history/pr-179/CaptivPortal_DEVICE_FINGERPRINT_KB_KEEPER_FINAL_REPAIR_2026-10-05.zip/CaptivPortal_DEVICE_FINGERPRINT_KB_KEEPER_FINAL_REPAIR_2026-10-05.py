from __future__ import annotations

import argparse
import hashlib
import subprocess
from pathlib import Path

EXPECTED_BRANCH = "docs/device-fingerprint-production-knowledge-sync"
EXPECTED_HEAD = "7c7c0919c3e546f499b5252ea9479d32c8f494d7"
OLD_HEAD = "3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5"
OLD_TREE = "8312658be3ba272998f46212d9bad76950e3867e"

EXPECTED_STAGED = {
    "README.md",
    "README_RU.md",
    "docs/README.md",
    "docs/architecture.md",
    "docs/configuration.md",
    "docs/deployment.md",
    "docs/module-index.md",
    "docs/modules/admin-web.md",
    "docs/modules/device-fingerprint-portal.md",
    "docs/modules/device-fingerprint.md",
    "docs/project-inventory.md",
    "docs/security.md",
    "docs/testing.md",
}

TARGETS = (
    "README.md",
    "README_RU.md",
    "docs/README.md",
    "docs/modules/admin-web.md",
    "docs/modules/device-fingerprint.md",
    "docs/testing.md",
)


def run(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run(
        ["git", *args], cwd=repo, text=True, encoding="utf-8", errors="strict",
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    )
    if check and cp.returncode != 0:
        raise RuntimeError(f"git {' '.join(args)} failed:\n{cp.stderr}")
    return cp


def read_preserving_newline(path: Path) -> tuple[str, str]:
    raw = path.read_bytes()
    text = raw.decode("utf-8")
    newline = "\r\n" if raw.count(b"\r\n") > raw.count(b"\n") / 2 else "\n"
    return text.replace("\r\n", "\n"), newline


def write_preserving_newline(path: Path, text: str, newline: str) -> None:
    if newline == "\r\n":
        data = text.replace("\n", "\r\n").encode("utf-8")
    else:
        data = text.encode("utf-8")
    path.write_bytes(data)


def replace_exact(text: str, old: str, new: str, label: str, count: int = 1) -> str:
    actual = text.count(old)
    if actual != count:
        raise RuntimeError(f"{label}: expected {count} exact match(es), found {actual}")
    return text.replace(old, new, count)


def section_bounds(text: str, heading: str) -> tuple[int, int]:
    marker = heading + "\n"
    start = text.find(marker)
    if start < 0:
        raise RuntimeError(f"missing section heading: {heading}")
    body_start = start + len(marker)
    next_h2 = text.find("\n## ", body_start)
    end = len(text) if next_h2 < 0 else next_h2 + 1
    return start, end


def transform_checkpoint_sections(text: str, path: str) -> str:
    headings = (
        "## Admin Web local asset library — historical production provenance",
        "## Controller Platform lexical contract — current production compatibility",
    )
    for heading in headings:
        start, end = section_bounds(text, heading)
        section = text[start:end]
        old_h = f"current production HEAD={OLD_HEAD}"
        old_t = f"current production tree={OLD_TREE}"
        if old_h not in section or old_t not in section:
            raise RuntimeError(f"{path}: expected historical checkpoint lines missing in {heading}")
        section = section.replace(old_h, f"historical production checkpoint HEAD={OLD_HEAD}", 1)
        section = section.replace(old_t, f"historical production checkpoint tree={OLD_TREE}", 1)
        text = text[:start] + section + text[end:]
    return text


SNR_BLOCK = '''\

SNR is presentation-only:

```text
>=25      good    #10b956
15..24    warning #f2c20d
<15       danger  #ed3038
null      neutral / —
```

RSSI and SNR are independent. No combined score or backend quality
classification exists.

Home-specific geometry and tones are scoped to:

```css
.live-section[aria-labelledby="devices-now-title"]
```

and do not redefine unrelated `.live-table` surfaces.
'''

DIAGRAM_INDEX = '''\
## Architecture diagrams

The detailed module uses sixteen focused GitHub-renderable diagrams. This index
is the stable navigation map for the current Device Fingerprint architecture:

```text
DF-01 — Full end-to-end
DF-02 — Evidence sources / origins
DF-03 — Evidence + source health + time
DF-04 — Snapshot assembly
DF-05 — Pure deterministic classification core
DF-06 — Per-dimension fusion
DF-07 — Knowledge and policy
DF-08 — Runtime profile / admission lifecycle
DF-09 — Artifact / audit lineage
DF-10 — Post-Auth integration / worker
DF-11 — Device classification history
DF-12 — Admin presentation read path
DF-13 — UI state semantics
DF-14 — Failure isolation
DF-15 — Production components and stores
DF-16 — Current Device Fingerprint vs future Traffic Enrichment
```

'''

REACCEPTANCE_BLOCK = '''\

`ClassifierArtifactManifest` pins the exact executable classifier implementation
identity used by the admitted runtime profile. A semantic classifier
implementation-byte change is therefore not merely an Admin/UI revision: it can
require a new candidate lineage and the applicable acceptance/admission path
before that implementation becomes production-active.

Reacceptance boundary:

```text
classifier semantic implementation / admitted classifier artifacts changed
→ new candidate identity + applicable acceptance/admission required

Admin presentation-only change with unchanged classifier semantics/artifacts
→ does not by itself require classifier reacceptance
```
'''

ROADMAP_OLD_EN = '''\
```mermaid
flowchart LR
    T0[Traffic Foundation]:::done --> T1[Current]:::done --> T2[History]:::done --> T3[Statistics]:::done --> T4[Peak]:::done --> T5[Traffic by AP]:::done --> R[Independent ranges]:::done --> T6[AP Traffic Share]:::done --> T7[Online Guests Traffic]:::done --> DB[DB Baseline Sync]:::next --> T8[Traffic 0.8]:::next
    classDef done fill:#d9f2d9,stroke:#2e7d32,color:#000;
    classDef next fill:#fff3cd,stroke:#b8860b,color:#000;
```
'''

ROADMAP_NEW_EN = '''\
```mermaid
flowchart LR
    T0[Traffic Foundation]:::done --> T1[Current]:::done --> T2[History]:::done --> T3[Statistics]:::done --> T4[Peak]:::done --> T5[Traffic by AP]:::done --> R[Independent ranges]:::done --> T6[AP Traffic Share]:::done --> T7[Online Guests Traffic]:::done --> DB[DB Baseline Sync]:::done --> T8[Traffic-08]:::done --> T9[Traffic-09]:::done
    classDef done fill:#d9f2d9,stroke:#2e7d32,color:#000;
```
'''

DF_ROADMAP_EN = '''\

Device Fingerprint current roadmap/status:

```text
TASK-DEVICE-FINGERPRINT-04         CLOSED / ACCEPTED
TASK-DEVICE-FINGERPRINT-05         CLOSED / INTEGRATED
TASK-DEVICE-FINGERPRINT-05-PERF-01 CLOSED
TASK-DEVICE-FINGERPRINT-06         PRODUCTION PASS / ADMIN VISIBLE
```

`Device Traffic Enrichment / Device Intelligence (DTI)` is a separate future
architecture/roadmap initiative under Owner + Tech Lead review. It is not part
of TASK-DEVICE-FINGERPRINT-06 and this documentation sync does not present DTI
as implemented or production-active.
'''

DF_ROADMAP_RU = '''\

Текущий roadmap/status Device Fingerprint:

```text
TASK-DEVICE-FINGERPRINT-04         CLOSED / ACCEPTED
TASK-DEVICE-FINGERPRINT-05         CLOSED / INTEGRATED
TASK-DEVICE-FINGERPRINT-05-PERF-01 CLOSED
TASK-DEVICE-FINGERPRINT-06         PRODUCTION PASS / ADMIN VISIBLE
```

`Device Traffic Enrichment / Device Intelligence (DTI)` — отдельная будущая
architecture/roadmap initiative, находящаяся на Owner + Tech Lead review. Она не
является частью TASK-DEVICE-FINGERPRINT-06, и этот knowledge sync не выдаёт DTI
за реализованную или production-active функцию.
'''

TEST_OLD = '''\
Task-05 PERF-01 full repository = 5198 passed, 28 skipped
Task-06 focused candidate = 189 passed
Task-06 R1 = 22 passed
'''

TEST_NEW = '''\
Task-05 PERF-01 full repository (2026-10-04; artifact SHA=0507a1fd66e84d00f105a53e6c36dec74ea14520; tree=439ab64697f2fcdcd5e822527f287ca5404e45ba) = 5198 passed, 28 skipped
Task-06 focused candidate (2026-10-04; commit=bf4eba5973c6f23b8939396249fac987ae88bdf1; tree=53f8d463eab6dff413e8bbdcc6e181bd2bc25d7f) = 189 passed
Task-06 R1 (2026-10-04; commit=596f7480c9878d95ac9056a3e9694c5942a48ef4; parent=bf4eba5973c6f23b8939396249fac987ae88bdf1; tree=dbf3e3804931d637ef1ec569128746ebce5c141a) = 22 passed
'''


def transform(path: str, text: str) -> str:
    if path in {"README.md", "README_RU.md", "docs/README.md", "docs/modules/admin-web.md"}:
        text = transform_checkpoint_sections(text, path)

    if path == "docs/modules/admin-web.md":
        start, end = section_bounds(text, "## Home Online Devices — current presentation")
        section = text[start:end]
        if "SNR is presentation-only:" in section:
            raise RuntimeError("admin-web: SNR block already present; refusing duplicate repair")
        anchor = (
            "Fingerprint no-result is `—`; a completed unresolved device class is `Unknown`.\n"
            "A fingerprint read failure remains fail-soft and does not remove the rest of the\n"
            "Home row.\n"
        )
        if anchor not in section:
            raise RuntimeError("admin-web: Home fail-soft anchor missing")
        section = section.replace(anchor, anchor + SNR_BLOCK, 1)
        text = text[:start] + section + text[end:]

    if path == "docs/modules/device-fingerprint.md":
        if "## Architecture diagrams\n" in text:
            raise RuntimeError("device-fingerprint: Architecture diagrams index already present")
        anchor = "## 3. DF-01 — Full end-to-end\n"
        if anchor not in text:
            raise RuntimeError("device-fingerprint: DF-01 anchor missing")
        text = text.replace(anchor, DIAGRAM_INDEX + anchor, 1)

        audit_anchor = '''\
Key retained identities include:

```text
SnapshotRecord
ClassificationRequestManifest
ClassifierArtifactManifest
ClassificationResult
FoundationRuntimeProfile
ClassificationRuntimeProfile
RuntimeProfileAdmissionManifest
RuntimeProfileActivationRecord
RuntimeProfileValidityRecord
```
'''
        if audit_anchor not in text:
            raise RuntimeError("device-fingerprint: audit identity anchor missing")
        text = text.replace(audit_anchor, audit_anchor + REACCEPTANCE_BLOCK, 1)

    if path == "README.md":
        text = replace_exact(text, ROADMAP_OLD_EN, ROADMAP_NEW_EN, "README roadmap mermaid")
        anchor = (
            "TASK-TRAFFIC-09 is completed and production-active. No successor Traffic TASK is canonical until separately approved by Owner / Tech Lead.\n"
        )
        if anchor not in text:
            raise RuntimeError("README: roadmap prose anchor missing")
        text = text.replace(anchor, anchor + DF_ROADMAP_EN, 1)

    if path == "README_RU.md":
        text = replace_exact(text, ROADMAP_OLD_EN, ROADMAP_NEW_EN, "README_RU roadmap mermaid")
        anchor = (
            "TASK-TRAFFIC-09 завершён и production-active. Следующий Traffic TASK не считается каноническим до отдельного утверждения Owner / Tech Lead.\n"
        )
        if anchor not in text:
            raise RuntimeError("README_RU: roadmap prose anchor missing")
        text = text.replace(anchor, anchor + DF_ROADMAP_RU, 1)

    if path == "docs/testing.md":
        text = replace_exact(text, TEST_OLD, TEST_NEW, "testing acceptance identities")

    return text


def semantic_verify(outputs: dict[str, str]) -> None:
    admin = outputs["docs/modules/admin-web.md"]
    module = outputs["docs/modules/device-fingerprint.md"]
    testing = outputs["docs/testing.md"]
    readme = outputs["README.md"]
    readme_ru = outputs["README_RU.md"]

    required_admin = (
        "SNR is presentation-only:",
        ">=25      good    #10b956",
        "RSSI and SNR are independent.",
        '.live-section[aria-labelledby="devices-now-title"]',
    )
    for needle in required_admin:
        if needle not in admin:
            raise RuntimeError(f"semantic verify: admin-web missing {needle!r}")

    for n in range(1, 17):
        needle = f"DF-{n:02d}"
        if needle not in module:
            raise RuntimeError(f"semantic verify: diagram index/module missing {needle}")
    for needle in (
        "## Architecture diagrams",
        "implementation-byte change",
        "does not by itself require classifier reacceptance",
    ):
        if needle not in module:
            raise RuntimeError(f"semantic verify: module missing {needle!r}")

    for needle in (
        "TASK-DEVICE-FINGERPRINT-04         CLOSED / ACCEPTED",
        "TASK-DEVICE-FINGERPRINT-06         PRODUCTION PASS / ADMIN VISIBLE",
        "Device Traffic Enrichment / Device Intelligence (DTI)",
    ):
        if needle not in readme or needle not in readme_ru:
            raise RuntimeError(f"semantic verify: README pair missing {needle!r}")

    if "DB[DB Baseline Sync]:::next" in readme or "T8[Traffic 0.8]:::next" in readme:
        raise RuntimeError("semantic verify: stale README roadmap next markers remain")
    if "DB[DB Baseline Sync]:::next" in readme_ru or "T8[Traffic 0.8]:::next" in readme_ru:
        raise RuntimeError("semantic verify: stale README_RU roadmap next markers remain")

    for needle in (
        "artifact SHA=0507a1fd66e84d00f105a53e6c36dec74ea14520",
        "commit=bf4eba5973c6f23b8939396249fac987ae88bdf1",
        "commit=596f7480c9878d95ac9056a3e9694c5942a48ef4",
    ):
        if needle not in testing:
            raise RuntimeError(f"semantic verify: testing missing {needle}")

    for path in ("README.md", "README_RU.md", "docs/README.md", "docs/modules/admin-web.md"):
        text = outputs[path]
        # Historical SHA values remain valid provenance, but must no longer be labelled current.
        if f"current production HEAD={OLD_HEAD}" in text:
            raise RuntimeError(f"semantic verify: {path} still labels old HEAD as current production")
        if f"current production tree={OLD_TREE}" in text:
            raise RuntimeError(f"semantic verify: {path} still labels old tree as current production")
        if f"historical production checkpoint HEAD={OLD_HEAD}" not in text:
            raise RuntimeError(f"semantic verify: {path} missing historical HEAD label")
        if f"historical production checkpoint tree={OLD_TREE}" not in text:
            raise RuntimeError(f"semantic verify: {path} missing historical tree label")


def main() -> None:
    ap = argparse.ArgumentParser(description="Repair final Keeper findings in the verified R4 staged docs candidate.")
    ap.add_argument("--repo", default=".", help="Path to the CaptivPortal repository")
    ap.add_argument(
        "--patch-output",
        default="CaptivPortal_DEVICE_FINGERPRINT_KB_KEEPER_FINAL_REPAIRED_2026-10-05.patch",
        help="Output path for the full staged candidate patch after repair",
    )
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    if not (repo / ".git").exists():
        raise RuntimeError(f"not a Git repository: {repo}")

    print("=== KEEPER FINAL REPAIR PRECHECK ===")
    branch = run(repo, "branch", "--show-current").stdout.strip()
    head = run(repo, "rev-parse", "HEAD").stdout.strip()
    if branch != EXPECTED_BRANCH:
        raise RuntimeError(f"unexpected branch: {branch}")
    if head != EXPECTED_HEAD:
        raise RuntimeError(f"unexpected HEAD: {head}")

    staged = {line.strip() for line in run(repo, "diff", "--cached", "--name-only").stdout.splitlines() if line.strip()}
    if staged != EXPECTED_STAGED:
        extra = sorted(staged - EXPECTED_STAGED)
        missing = sorted(EXPECTED_STAGED - staged)
        raise RuntimeError(f"unexpected staged scope; extra={extra}; missing={missing}")

    unstaged = [line for line in run(repo, "diff", "--name-only").stdout.splitlines() if line.strip()]
    if unstaged:
        raise RuntimeError(f"unstaged changes present before repair: {unstaged}")

    run(repo, "diff", "--cached", "--check")
    print("PASS: exact R4 staged baseline")

    outputs: dict[str, str] = {}
    newlines: dict[str, str] = {}
    for rel in TARGETS:
        text, newline = read_preserving_newline(repo / rel)
        outputs[rel] = transform(rel, text)
        newlines[rel] = newline

    semantic_verify(outputs)
    print("PASS: all Keeper repair transforms built and verified in memory")

    # Write only after every transform and semantic assertion passed.
    for rel in TARGETS:
        write_preserving_newline(repo / rel, outputs[rel], newlines[rel])

    run(repo, "add", "--", *TARGETS)
    run(repo, "diff", "--cached", "--check")

    staged_after = {line.strip() for line in run(repo, "diff", "--cached", "--name-only").stdout.splitlines() if line.strip()}
    if staged_after != EXPECTED_STAGED:
        raise RuntimeError("staged scope changed unexpectedly after repair")

    # Re-read staged content through working files; there must be no unstaged drift now.
    unstaged_after = [line for line in run(repo, "diff", "--name-only").stdout.splitlines() if line.strip()]
    if unstaged_after:
        raise RuntimeError(f"unexpected unstaged drift after repair: {unstaged_after}")

    patch_path = Path(args.patch_output)
    if not patch_path.is_absolute():
        patch_path = repo / patch_path
    patch = run(repo, "diff", "--cached", "--binary").stdout
    patch_path.write_text(patch, encoding="utf-8", newline="\n")
    patch_bytes = patch_path.read_bytes()
    digest = hashlib.sha256(patch_bytes).hexdigest().upper()

    print("=== KEEPER FINAL REPAIR PASS ===")
    print(f"BRANCH={branch}")
    print(f"HEAD={head}")
    print(f"STAGED_FILES={len(staged_after)}")
    print(f"PATCH={patch_path}")
    print(f"PATCH_BYTES={len(patch_bytes)}")
    print(f"PATCH_SHA256={digest}")
    print("COMMIT=NO")
    print("PUSH=NO")
    print("PR=NO")
    print("MERGE=NO")
    print("DEPLOY=NO")


if __name__ == "__main__":
    main()
