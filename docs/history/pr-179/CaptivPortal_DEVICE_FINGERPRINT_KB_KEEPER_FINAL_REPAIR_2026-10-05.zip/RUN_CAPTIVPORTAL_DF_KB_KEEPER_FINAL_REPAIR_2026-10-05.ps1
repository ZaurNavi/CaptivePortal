$ErrorActionPreference = 'Stop'

$Repo = 'C:\Users\Zaur Navi\Downloads\CaptivPortal-KB-DF-Sync-R2-2026-10-04'
$Script = Join-Path $PSScriptRoot 'CaptivPortal_DEVICE_FINGERPRINT_KB_KEEPER_FINAL_REPAIR_2026-10-05.py'
$Patch = 'C:\Users\Zaur Navi\Downloads\CaptivPortal_DEVICE_FINGERPRINT_KB_KEEPER_FINAL_REPAIRED_2026-10-05.patch'

if (-not (Test-Path -LiteralPath $Script)) {
    throw "Repair script not found: $Script"
}
if (-not (Test-Path -LiteralPath (Join-Path $Repo '.git'))) {
    throw "Repository not found: $Repo"
}

python $Script --repo $Repo --patch-output $Patch
if ($LASTEXITCODE -ne 0) {
    throw "KEEPER FINAL REPAIR FAILED"
}

Write-Host ''
Write-Host '=== FINAL LOCAL STATE ==='
git -C $Repo status --short
git -C $Repo diff --cached --stat
git -C $Repo diff --cached --check
if ($LASTEXITCODE -ne 0) {
    throw 'git diff --cached --check failed after repair'
}

Write-Host ''
Write-Host 'NO COMMIT / NO PUSH / NO PR / NO MERGE / NO DEPLOY'
