# Read first — NI-04 unified55 Coder handoff

This archive contains **ONE** implementation TASK, the 55-unique-service research registry, and exact frozen Lane A reference files, plus Architect/Tech Lead reviews and supporting research. **It does not contain an admitted 55-rule runtime bundle.**

## Start order
1. Read `OWNER-DECISION-AND-SCOPE-RECONCILIATION.md`.
2. Read `TASK-DTI-NI-04-UNIFIED55-CODER-IMPLEMENTATION-CONTRACT-v1.md`.
3. Read `NI04-UNIFIED55-REGISTER.md` and exact `NI04-UNIFIED55-RESEARCH-REGISTRY-v1.json` (research metadata, not runtime).
4. Read `ARCHITECT-AND-RESEARCH-SOURCES/NI04-ARCHITECTURE-v1-R1.md` (normative addendum), full original `TASK-DTI-NI-04-ARCHITECTURE-CONTRACT-v1.md` from CaptivPortal Project Library and the existing repository `AGENTS.md`/workflow/handoff. The **full parent v1 is only in the Project Library**, not this ZIP, because the Library did not authorize raw-byte export. This requirement must not be silently replaced by a generic interpretation.
5. Read the Architect R2/R3 decision and TOP-50 evidence report, then inspect frozen Lane A JSON and their exact semantic digests.

## Authority
User/Owner authorized ONE unified Coder TASK and waived an additional independent admission reviewer. This is **not** authorization for production deployment, GitHub merge, activation, invented source rules or weakening NI-04 v1/R1 security guarantees.

## Fundamental limit
55 researched identities != 55 admitted positive SNI rules. The 9 Architect HOLD, one repair, and 5 new candidates remain gated until real first-party/controlled evidence and exact immutable reviewable per-rule artifacts exist. Coder cannot invent them. A functional single PR may implement the data-driven engine and protected Device Card without assuming full app recognition coverage.
