$ErrorActionPreference = "Stop"

$RepoPath = "$env:USERPROFILE\Downloads\CaptivPortal-KB-Work"
$PackageDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExpectedBase = "b55dcabeea22cbb802b044c263a0887123771c7d"
$RuntimeBaseline = "dfc62b43712301b05baf9f6e5dd843e13eaa9fc7"
$Branch = "docs/readme-human-facing-2026-08-25"
$Repo = "ZaurNavi/CaptivePortal"

Write-Host "`n=== PRECHECK ==="

if (-not (Test-Path (Join-Path $RepoPath ".git"))) {
    throw "Repository not found: $RepoPath"
}

if (-not (Test-Path (Join-Path $PackageDir "README.md"))) {
    throw "Package README.md not found"
}

if (-not (Test-Path (Join-Path $PackageDir "README_RU.md"))) {
    throw "Package README_RU.md not found"
}

git -C "$RepoPath" fetch origin
if ($LASTEXITCODE -ne 0) { throw "git fetch failed" }

$OriginMain = git -C "$RepoPath" rev-parse origin/main
Write-Host "origin/main: $OriginMain"

if ($OriginMain -ne $ExpectedBase) {
    throw "STOP: origin/main moved from expected README baseline $ExpectedBase. README must be rechecked against the new main before publishing."
}

if (git -C "$RepoPath" status --porcelain) {
    throw "STOP: working tree is not clean"
}

git -C "$RepoPath" switch main
if ($LASTEXITCODE -ne 0) { throw "switch main failed" }

git -C "$RepoPath" pull --ff-only origin main
if ($LASTEXITCODE -ne 0) { throw "pull main failed" }

if ((git -C "$RepoPath" rev-parse HEAD) -ne $ExpectedBase) {
    throw "STOP: local main does not match expected base"
}

$Existing = git -C "$RepoPath" branch --list $Branch
if ($Existing) {
    throw "STOP: local branch already exists: $Branch"
}

git -C "$RepoPath" switch -c $Branch
if ($LASTEXITCODE -ne 0) { throw "create branch failed" }

Copy-Item (Join-Path $PackageDir "README.md") (Join-Path $RepoPath "README.md") -Force
Copy-Item (Join-Path $PackageDir "README_RU.md") (Join-Path $RepoPath "README_RU.md") -Force

Write-Host "`n=== SCOPE CHECK ==="
$Changed = @(git -C "$RepoPath" status --porcelain)
$Changed | ForEach-Object { Write-Host $_ }

if ($Changed.Count -ne 2) {
    throw "STOP: expected exactly 2 changed files, found $($Changed.Count)"
}

$Names = @(git -C "$RepoPath" diff --name-only)
$BadNames = @($Names | Where-Object { $_ -notin @("README.md", "README_RU.md") })

if (($Names -notcontains "README.md") -or ($Names -notcontains "README_RU.md")) {
    throw "STOP: expected README.md and README_RU.md only"
}

if ($BadNames.Count -gt 0) {
    throw "STOP: non-README file changed: $($BadNames -join ', ')"
}

git -C "$RepoPath" --no-pager diff --check
if ($LASTEXITCODE -ne 0) { throw "STOP: diff check failed" }

Write-Host "PASS: README-only scope and diff check"

git -C "$RepoPath" add -- README.md README_RU.md
if ($LASTEXITCODE -ne 0) { throw "git add failed" }

git -C "$RepoPath" --no-pager diff --cached --check
if ($LASTEXITCODE -ne 0) { throw "STOP: staged diff check failed" }

Write-Host "PASS: staged diff check"

Write-Host "`n=== COMMIT ==="
git -C "$RepoPath" commit `
    -m "docs: restore human-facing project README" `
    -m "Expand README.md and README_RU.md with current architecture, diagrams, project stage, roadmap, next increment, subsystem status, and human-readable operating context." `
    -m "Documentation-only change. No runtime code, tests, schemas, feature flags, configuration, deployment, or production state changed."

if ($LASTEXITCODE -ne 0) { throw "commit failed" }

$Commit = git -C "$RepoPath" rev-parse HEAD

Write-Host "`n=== PUSH ==="
git -C "$RepoPath" push -u origin $Branch
if ($LASTEXITCODE -ne 0) { throw "push failed" }

Write-Host "`n=== GITHUB AUTH ==="
gh auth status
if ($LASTEXITCODE -ne 0) { throw "GitHub CLI is not authenticated" }

$Body = @"
## Purpose

Restore the root README files as a **human-facing project map**, while keeping the factual accuracy introduced by the current Knowledge Base refresh.

The previous README refresh made the files precise but too compressed. This PR deliberately restores the human-readable project narrative: what CaptivPortal is, how it works, where the project stands, and what comes next.

## Scope

**DOCUMENTATION-ONLY**

Changed files:

- `README.md`
- `README_RU.md`

No other repository files are changed.

## What this PR adds

- human-readable project overview;
- current project checkpoint and explicit runtime-vs-doc SHA distinction;
- multiple Mermaid architecture diagrams;
- guest authorization flow;
- process-composition diagram;
- Pending Session Cleaner flow;
- acquisition → persistence → analytics → Admin data flow;
- Snapshot vs Registry vs Observation vs Current State vs Visit explanation;
- Visit Lifecycle flow;
- Analytics architecture;
- Current Traffic / Home Traffic semantics;
- Admin Web security/query boundary;
- current Home architecture;
- **Home Activity** clearly marked as the next approved change-intent, not current runtime;
- engineering-observability vs product-UI boundary;
- persistence map;
- current subsystem status matrix;
- curated Omada Open API research summary;
- completed roadmap staircase;
- near-term direction;
- Multi-Site → Tenant → RBAC → Entitlements → managed-service evolution;
- technical debts and architectural invariants;
- project philosophy and knowledge-base navigation.

## Accuracy boundary

Repository / documentation baseline checked before this PR:

`$ExpectedBase`

The README explicitly preserves the distinction that PR #63 was documentation-only and the runtime code checkpoint described by the current KB remains:

`$RuntimeBaseline`

Home Activity is described only as **approved change-intent / next increment** and is not presented as current implementation.

## Explicit non-scope

**No runtime code changed.**
**No tests changed.**
**No database schema changed.**
**No feature flags changed.**
**No production configuration changed.**
**No deployment or production activation is part of this PR.**

## Validation

- exactly 2 files changed;
- paths limited to `README.md` and `README_RU.md`;
- `git diff --check` — PASS;
- staged diff check — PASS.

## Commit

`$Commit`

## Merge

Created as **Draft**. Final review and merge remain with the repository owner.
"@

Write-Host "`n=== CREATE DRAFT PR ==="
$PrUrl = gh pr create `
    --repo $Repo `
    --base main `
    --head $Branch `
    --title "Docs: restore human-facing CaptivPortal README" `
    --body $Body `
    --draft

if ($LASTEXITCODE -ne 0) { throw "Draft PR creation failed" }

Write-Host "`n=== FINAL ==="
Write-Host "PR: $PrUrl"
Write-Host "Commit: $Commit"
Write-Host "Changed files: README.md, README_RU.md only"
Write-Host "Runtime code changed: NO"
Write-Host "Tests changed: NO"
Write-Host "Merge performed: NO"
