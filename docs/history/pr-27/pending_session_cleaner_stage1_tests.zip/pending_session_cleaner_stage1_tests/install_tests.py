#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import sys

EXPECTED_BRANCH = "feature/pending-session-cleaner"
EXPECTED_HEAD = "38906a70c4e792987c0247596e2f6c85b9db947f"


def run(*args, capture=False):
    print("+", " ".join(args))
    return subprocess.run(
        args,
        check=True,
        text=True,
        capture_output=capture,
    )


def output(*args):
    return run(*args, capture=True).stdout.strip()


def main():
    repo = Path.cwd()
    if not (repo / ".git").exists():
        raise SystemExit("Run from /opt/CaptivePortal repository root")

    branch = output("git", "branch", "--show-current")
    head = output("git", "rev-parse", "HEAD")
    status = output("git", "status", "--porcelain")

    if branch != EXPECTED_BRANCH:
        raise SystemExit(f"Wrong branch: {branch!r}; expected {EXPECTED_BRANCH!r}")
    if head != EXPECTED_HEAD:
        raise SystemExit(f"Wrong HEAD: {head}; expected {EXPECTED_HEAD}")
    if status:
        raise SystemExit("Working tree is not clean")

    source = Path(__file__).resolve().parent / "files" / "tests"
    destination = repo / "tests"

    for path in sorted(source.rglob("*.py")):
        relative = path.relative_to(source)
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        print(f"installed {target}")

    test_files = [
        str(path)
        for path in sorted((repo / "tests" / "pending_sessions").glob("test_*.py"))
    ]
    run(sys.executable, "-m", "py_compile", *test_files)
    run("git", "diff", "--check")

    print()
    print("Stage 1 test files installed successfully.")
    print("No commit or push was performed.")


if __name__ == "__main__":
    raise SystemExit(main())
