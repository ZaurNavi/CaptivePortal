# Pending Session Cleaner — Stage 1 tests

Adds focused tests under `tests/pending_sessions/` for:

- disabled-by-default and strict config parsing;
- classifier filtering, counts, sorting and duplicate protection;
- pagination completeness, defensive copies and hard caps;
- journal durability/error handling and telemetry fail-open behavior;
- Omada GET contracts, strict response validation, token expiration and token secrecy.

The installer requires:

- branch `feature/pending-session-cleaner`;
- exact HEAD `38906a70c4e792987c0247596e2f6c85b9db947f`;
- clean working tree.

It copies and syntax-checks tests only. It does not commit or push.
