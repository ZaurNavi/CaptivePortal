# Pending Client Session Cleaner completion package

Expected state:

- branch: `feature/pending-session-cleaner`
- HEAD: `33c9a69`
- clean working tree

Adds the remaining runtime layer:

- thread-safe shared Omada token cache;
- `reconnect_client`;
- immutable AuthSessionManager protection snapshot;
- local protection adapter;
- action guard;
- scan/preflight/reconnect/verification engine;
- fixed-delay worker;
- fail-open factory;
- `run.py` startup/shutdown integration;
- targeted tests.

The installer does not commit or push.
`PENDING_SESSION_CLEANER_ENABLED` remains `false` by default.
