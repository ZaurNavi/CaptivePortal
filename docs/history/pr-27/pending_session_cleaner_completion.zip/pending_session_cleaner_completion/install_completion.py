#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import sys

EXPECTED_BRANCH = "feature/pending-session-cleaner"
EXPECTED_HEAD = "33c9a69"


def run(*args, capture=False):
    print("+", " ".join(args))
    return subprocess.run(
        args,
        check=True,
        text=True,
        capture_output=capture,
    )


def output(*args):
    return run(*args, capture=True).stdout.strip()


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise SystemExit(
            f"Expected one anchor in {path}, found {count}"
        )
    path.write_text(
        text.replace(old, new, 1),
        encoding="utf-8",
    )
    print("patched", path)


def patch_omada_provider(repo: Path) -> None:
    path = repo / "app/controllers/omada.py"
    replace_once(
        path,
        'import math\nimport requests\n',
        'import math\nimport threading\nimport time\nimport requests\n',
    )
    replace_once(
        path,
        '''        self._verify_ssl = settings["verify_ssl"]

    def _get_token(self) -> Result:
''',
        '''        self._verify_ssl = settings["verify_ssl"]
        self._token_condition = threading.Condition(
            threading.RLock()
        )
        self._cached_token = None
        self._cached_token_expires_at = 0.0
        self._token_refreshing = False

    def _request_token_uncached(self) -> Result:
''',
    )
    replace_once(
        path,
        '''    def connect(self) -> None:
        logger.info("Omada provider ready (dynamic token per request)")
''',
        '''    def _get_token(self, *, force_refresh: bool = False) -> Result:
        # One atomic cache shared by AuthWorker and Cleaner threads.
        while True:
            with self._token_condition:
                now = time.monotonic()
                if (
                    not force_refresh
                    and isinstance(self._cached_token, str)
                    and self._cached_token
                    and now + 30.0 < self._cached_token_expires_at
                ):
                    return Result.ok(
                        message="Success",
                        data={
                            "token": self._cached_token,
                            "http_status": 200,
                            "error_code": 0,
                        },
                    )
                if self._token_refreshing:
                    self._token_condition.wait()
                    force_refresh = False
                    continue
                self._token_refreshing = True
                break

        result = None
        try:
            result = self._request_token_uncached()
            return result
        finally:
            with self._token_condition:
                if result is not None and result.success:
                    token = result.data.get("token")
                    if isinstance(token, str) and token:
                        self._cached_token = token
                        # Token lifetime is two hours; refresh early.
                        self._cached_token_expires_at = (
                            time.monotonic() + 6600.0
                        )
                self._token_refreshing = False
                self._token_condition.notify_all()

    def _invalidate_cached_token(self, token=None) -> None:
        with self._token_condition:
            if token is None or token == self._cached_token:
                self._cached_token = None
                self._cached_token_expires_at = 0.0
            self._token_condition.notify_all()

    def connect(self) -> None:
        logger.info("Omada provider ready (shared token cache)")
''',
    )


def patch_pending_provider(repo: Path) -> None:
    path = repo / "app/controllers/omada_pending_sessions.py"
    text = path.read_text(encoding="utf-8")
    marker = "\n\ndef install_pending_session_methods(provider_class) -> None:\n"
    if text.count(marker) != 1:
        raise SystemExit("Pending provider installer anchor missing")

    reconnect = r'''

def reconnect_client(
    self,
    *,
    site_id: str,
    client_mac: str,
    timeout_seconds: float,
) -> Result:
    if not isinstance(site_id, str) or not site_id.strip():
        return _failure(
            error="INVALID_SITE_ID",
            message="site_id is required",
            category="invalid_argument",
            retryable=False,
        )
    try:
        endpoint_mac = format_mac_hyphen(client_mac)
    except (TypeError, ValueError):
        return _failure(
            error="INVALID_CLIENT_MAC",
            message="client_mac is invalid",
            category="invalid_argument",
            retryable=False,
        )
    timeout = _validated_timeout(timeout_seconds)
    if timeout is None:
        return _failure(
            error="INVALID_TIMEOUT",
            message="timeout_seconds must be finite and positive",
            category="invalid_argument",
            retryable=False,
        )

    token, token_failure = _token_or_failure(self)
    if token_failure is not None:
        return token_failure
    url = (
        f"{self._omada_url}/openapi/v1/{self._omada_id}"
        f"/sites/{site_id.strip()}/clients/{endpoint_mac}/reconnect"
    )
    try:
        response = requests.post(
            url,
            headers={"Authorization": f"AccessToken={token}"},
            verify=self._verify_ssl,
            timeout=(timeout, timeout),
        )
    except requests.exceptions.Timeout as exc:
        return _failure(
            error="HTTP_ERROR",
            message=str(exc),
            category="timeout",
            retryable=True,
        )
    except requests.exceptions.RequestException as exc:
        return _failure(
            error="HTTP_ERROR",
            message=str(exc),
            category="network_error",
            retryable=True,
        )

    payload, failure = _parse_response(response)
    if failure is not None:
        if failure.error == "TOKEN_EXPIRED":
            invalidate = getattr(
                self,
                "_invalidate_cached_token",
                None,
            )
            if callable(invalidate):
                invalidate(token)
        return failure
    return Result.ok(
        message=str(payload.get("msg") or "Success."),
        data={
            "http_status": response.status_code,
            "error_code": 0,
            "message": str(payload.get("msg") or "Success."),
            "command_accepted": True,
        },
    )
'''
    text = text.replace(marker, reconnect + marker, 1)
    assign = (
        "    provider_class.get_pending_client_state = "
        "get_pending_client_state"
    )
    if text.count(assign) != 1:
        raise SystemExit("Pending provider assignment anchor missing")
    text = text.replace(
        assign,
        assign
        + "\n    provider_class.reconnect_client = reconnect_client",
        1,
    )
    path.write_text(text, encoding="utf-8")
    print("patched", path)


def patch_auth_manager(repo: Path) -> None:
    path = repo / "app/auth/manager.py"
    replace_once(
        path,
        'import threading\nimport time\nimport uuid\n',
        'import threading\nimport time\nimport types\nimport uuid\n',
    )
    anchor = '''    def snapshot(self, session_or_id) -> Optional[dict]:
'''
    method = '''    def pending_session_protection_snapshot(
        self,
        site_id: str,
        client_mac: str,
    ):
        # Immutable read-only data for Cleaner local protection.
        session_key = self.get_session_key(site_id, client_mac)
        with self._lock:
            self._cleanup_locked()
            session = self._sessions_by_key.get(session_key)
            if session is None:
                return None
            run = session.current_run()
            snapshot = {
                "site_id": session.site_id,
                "client_mac": session.client_mac,
                "status": session.status.value,
                "updated_at": session.updated_at,
                "activity_age_seconds": max(
                    0.0,
                    time.monotonic()
                    - session._last_activity_monotonic,
                ),
                "session_active": session.is_active(),
                "retryable": bool(session.retryable),
                "run_active": bool(run is not None and run.active),
                "worker_active": bool(
                    run is not None
                    and run.worker_started
                    and not run.worker_finished
                ),
            }
            return types.MappingProxyType(snapshot)

'''
    replace_once(path, anchor, method + anchor)


def patch_run(repo: Path) -> None:
    path = repo / "run.py"
    replace_once(
        path,
        'from app.web.web import create_app, auth_executor\n',
        (
            'from app.pending_sessions import '
            'create_pending_session_cleaner\n'
            'from app.web.web import '
            'create_app, auth_executor, auth_manager\n'
        ),
    )
    replace_once(
        path,
        '_visitor_registry = None\n',
        '_visitor_registry = None\n_pending_session_cleaner = None\n',
    )
    replace_once(
        path,
        '''    logger.info("Shutting down authentication worker executor...")

    if _public_traffic_worker is not None:
''',
        '''    logger.info("Shutting down authentication worker executor...")

    if _pending_session_cleaner is not None:
        try:
            config = getattr(
                _pending_session_cleaner,
                "config",
                None,
            )
            timeout_seconds = getattr(
                config,
                "shutdown_timeout_seconds",
                20.0,
            )
            _pending_session_cleaner.stop(timeout_seconds)
        except Exception:
            logger.exception("pending_session_cleaner_stop_failed")

    if _public_traffic_worker is not None:
''',
    )
    replace_once(
        path,
        '    global _visitor_snapshot_collector, _visitor_registry\n',
        (
            '    global _visitor_snapshot_collector, _visitor_registry\n'
            '    global _pending_session_cleaner\n'
        ),
    )
    replace_once(
        path,
        '''    logger.info("Web application created")
    try:
        _visitor_snapshot_collector.start()
''',
        '''    logger.info("Web application created")
    _pending_session_cleaner = create_pending_session_cleaner(
        settings=settings,
        provider=controller,
        auth_manager=auth_manager,
        telemetry=app.extensions["auth_telemetry"],
    )
    try:
        _pending_session_cleaner.start()
    except Exception:
        logger.exception("pending_session_cleaner_start_failed")
    try:
        _visitor_snapshot_collector.start()
''',
    )


def patch_exports(repo: Path) -> None:
    path = repo / "app/pending_sessions/__init__.py"
    text = path.read_text(encoding="utf-8")
    anchor = "from .telemetry import CleanerTelemetryAdapter\n"
    imports = '''from .action_guard import ActionGuard, ActionGuardDecision
from .protection import AuthManagerPendingSessionProtection
from .cleaner import PendingClientSessionCleaner
from .worker import PendingSessionWorker
from .factory import (
    DisabledPendingSessionCleaner,
    UnavailablePendingSessionCleaner,
    create_pending_session_cleaner,
)
'''
    if imports not in text:
        if text.count(anchor) != 1:
            raise SystemExit("Export import anchor missing")
        text = text.replace(anchor, anchor + imports, 1)

    old = '''    "CleanerTelemetryAdapter",
]'''
    new = '''    "CleanerTelemetryAdapter",
    "ActionGuard",
    "ActionGuardDecision",
    "AuthManagerPendingSessionProtection",
    "PendingClientSessionCleaner",
    "PendingSessionWorker",
    "DisabledPendingSessionCleaner",
    "UnavailablePendingSessionCleaner",
    "create_pending_session_cleaner",
]'''
    if new not in text:
        if text.count(old) != 1:
            raise SystemExit("Export __all__ anchor missing")
        text = text.replace(old, new, 1)
    path.write_text(text, encoding="utf-8")
    print("patched", path)


def main():
    repo = Path.cwd()
    if not (repo / ".git").exists():
        raise SystemExit("Run from repository root")

    branch = output("git", "branch", "--show-current")
    head = output("git", "rev-parse", "--short", "HEAD")
    status = output("git", "status", "--porcelain")
    if branch != EXPECTED_BRANCH:
        raise SystemExit(f"Wrong branch: {branch}")
    if head != EXPECTED_HEAD:
        raise SystemExit(
            f"Wrong HEAD: {head}; expected {EXPECTED_HEAD}"
        )
    if status:
        raise SystemExit("Working tree must be clean")

    source = Path(__file__).resolve().parent / "files"
    for src in sorted(source.rglob("*.py")):
        rel = src.relative_to(source)
        dst = repo / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        print("installed", dst)

    patch_omada_provider(repo)
    patch_pending_provider(repo)
    patch_auth_manager(repo)
    patch_run(repo)
    patch_exports(repo)

    run(sys.executable, "-m", "compileall", "-q", "app")
    run("git", "diff", "--check")
    print()
    print("Cleaner completion package installed.")
    print("Feature remains disabled by default.")
    print("No commit and no push were performed.")


if __name__ == "__main__":
    raise SystemExit(main())
