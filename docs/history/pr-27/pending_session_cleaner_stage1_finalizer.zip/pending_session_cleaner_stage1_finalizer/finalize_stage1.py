#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

EXPECTED_BRANCH = "feature/pending-session-cleaner"
EXPECTED_HEAD = "9d1c50b24eb4bb308429bfe339d2889c6f2a041e"
BASE_BRANCH = "main"
COMMIT_MESSAGE = "feat(pending-sessions): complete stage 1 foundation"


def run(*args: str, check: bool = True) -> subprocess.CompletedProcess:
    print("+", " ".join(args))
    return subprocess.run(args, text=True, check=check)


def output(*args: str) -> str:
    return subprocess.check_output(args, text=True).strip()


def append_once(path: Path, marker: str, block_path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    if marker in text:
        print(f"= {path}: block already present")
        return
    block = block_path.read_text(encoding="utf-8")
    path.write_text(text.rstrip() + block + "\n", encoding="utf-8")


def main() -> int:
    bundle = Path(__file__).resolve().parent
    repo = Path.cwd()

    if not (repo / ".git").exists():
        print("ERROR: run this script from the CaptivePortal repository root")
        return 2

    branch = output("git", "branch", "--show-current")
    head = output("git", "rev-parse", "HEAD")
    if branch != EXPECTED_BRANCH:
        print(f"ERROR: expected branch {EXPECTED_BRANCH}, got {branch}")
        return 2
    if head != EXPECTED_HEAD:
        print(f"ERROR: expected HEAD {EXPECTED_HEAD}, got {head}")
        print("The branch changed; review before rewriting history.")
        return 2
    if output("git", "status", "--porcelain"):
        print("ERROR: working tree is not clean")
        return 2

    run("git", "fetch", "origin")
    base_sha = output("git", "rev-parse", f"origin/{BASE_BRANCH}")

    # Install corrected/new files.
    files_root = bundle / "files"
    for source in files_root.rglob("*"):
        if not source.is_file():
            continue
        relative = source.relative_to(files_root)
        destination = repo / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        print(f"installed {relative}")

    append_once(
        repo / "app/config.py",
        "PENDING_SESSION_CLEANER_ENABLED",
        bundle / "config_block.txt",
    )
    append_once(
        repo / ".env.example",
        "PENDING_SESSION_CLEANER_ENABLED",
        bundle / "env_block.txt",
    )

    # Static checks before history rewrite.
    run(sys.executable, "-m", "py_compile",
        "app/pending_sessions/config.py",
        "app/pending_sessions/models.py",
        "app/pending_sessions/protocols.py",
        "app/pending_sessions/classifier.py",
        "app/pending_sessions/pagination.py",
        "app/pending_sessions/journal.py",
        "app/pending_sessions/telemetry.py",
        "app/controllers/omada_pending_sessions.py",
        "app/controllers/__init__.py",
        "app/config.py",
        "app/settings.py",
    )
    run(sys.executable, "-m", "compileall", "-q", "app")
    run("git", "diff", "--check")

    # Collapse the five intermediate commits and the final changes into one commit.
    run("git", "reset", "--soft", base_sha)
    run("git", "add",
        "app/pending_sessions",
        "app/controllers/omada_pending_sessions.py",
        "app/controllers/__init__.py",
        "app/config.py",
        "app/settings.py",
        ".env.example",
    )
    run("git", "diff", "--cached", "--check")
    run("git", "commit", "-m", COMMIT_MESSAGE)

    new_head = output("git", "rev-parse", "HEAD")
    print(f"NEW_HEAD={new_head}")
    run("git", "push", "--force-with-lease", "origin", f"{EXPECTED_BRANCH}:{EXPECTED_BRANCH}")

    print("DONE")
    print(f"branch={EXPECTED_BRANCH}")
    print(f"head={new_head}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
