# Pending Session Cleaner Stage 1 finalizer

Run from the CaptivePortal repository root while checked out at:

- branch: `feature/pending-session-cleaner`
- HEAD: `9d1c50b24eb4bb308429bfe339d2889c6f2a041e`

Commands:

```bash
unzip pending_session_cleaner_stage1_finalizer.zip -d /tmp/psc-finalizer
cd /opt/CaptivePortal
git switch feature/pending-session-cleaner
git status
python3 /tmp/psc-finalizer/pending_session_cleaner_stage1_finalizer/finalize_stage1.py
```

The script:
1. Refuses to run on another branch, another HEAD, or a dirty worktree.
2. Installs the corrected Stage 1 files.
3. Keeps `PENDING_SESSION_CLEANER_ENABLED=false`.
4. Runs `py_compile`, `compileall`, and `git diff --check`.
5. Squashes the five intermediate commits into one clean commit based on `origin/main`.
6. Pushes with `--force-with-lease`.
