# CaptivPortal KB Controlled Update — TRAFFIC-03 / Production / Governance

Prepared: 2026-08-30
Exact repository baseline: `b92efbfabb38f912550526bc5a3d1f2f1a8ae4d6`
Exact tree: `1d8b94590848f9505e45e653384dd8a7c18d4339`

## Verified repository facts

GitHub main is merge PR #89:
`TASK-TRAFFIC-03 — Period Statistics`.

Merged commit:
`b92efbfabb38f912550526bc5a3d1f2f1a8ae4d6`

Tree:
`1d8b94590848f9505e45e653384dd8a7c18d4339`

PR #89 records:
- initial candidate `d96ddbc6f8685be175ee9a48da9b8e15621f2161` / `5e6a28950c8079d805450dc2a7ecf652a8285820` — functional/V6 PASS, production-size PERF FAIL, superseded;
- final remediation candidate `79875aca61297c8de4c30b7119b15118079f26d0` / `1d8b94590848f9505e45e653384dd8a7c18d4339` — all mandatory gates PASS.

## Current production truth supplied by Owner

```text
TASK-TRAFFIC-03:
PRODUCTION ACCEPTANCE PASS / CLOSED

WEB_ADMIN_TRAFFIC_ENABLED=true
WEB_ADMIN_TRAFFIC_HISTORY_ENABLED=true
WEB_ADMIN_TRAFFIC_STATISTICS_ENABLED=true

Browser acceptance:
PASS

History + Statistics:
24h ↔ 7d synchronized switching PASS
```

## Current Traffic roadmap after reconciliation

```text
TRAFFIC-00         DONE
TRAFFIC-01         DONE
TRAFFIC-02-READ    DONE
TRAFFIC-02 History DONE
TRAFFIC-02-PERF-01 DONE
TRAFFIC-03         DONE / PRODUCTION ACTIVE
TRAFFIC-04 Peak    NEXT / NOT IMPLEMENTED
```

## Permanent governance canonicalized

```text
Patch → Lab.
All mandatory gates → PASS.
Accepted candidate → Git.
Git → Production.
Activation → separate step.
```

Mandatory PERF/Linux/security/browser/etc. gates are pre-publication candidate
acceptance.

`Central Lab V6 PASS` alone is insufficient if another mandatory gate is
required.

Git is the normal production application-code delivery boundary.

## Documentation scope

- `AGENTS.md`
- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/agents/handoff.md`
- `docs/agents/repository-actions.md`
- `docs/agents/task-contract.md`
- `docs/agents/workflow.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/admin-web.md`
- `docs/modules/analytics.md`
- `docs/modules/traffic.md`
- `docs/project-inventory.md`
- `docs/tasks/TASK-template.md`
- `docs/testing.md`

Total: 18 files.

No runtime code.
No automated test code.
No production action.
No merge.

## Known drift addressed

- README / README_RU still named TRAFFIC-02-READ as NEXT.
- `docs/modules/traffic.md` still stopped at TRAFFIC-01.
- module index / inventory lacked Historical Traffic and Period Statistics.
- configuration lacked History/Statistics current documentation.
- deployment checkpoint was still TRAFFIC-00/01.
- testing latest Traffic evidence was still TRAFFIC-00/01.
- workflow did not require every TASK-specific mandatory gate before publication.
- Linux/production-compatible gate wording could be read as post-publication release testing.
- repository actions did not prohibit normal publication of a not-yet-accepted candidate.
- current Traffic UI position had no explicit "functional-current, design-not-final" rule.

## Historical documents

Historical FINAL TASKs, PR history and superseded candidate evidence are not
rewritten. Current governance supersedes weaker historical process wording for
future execution.

## Publisher V2 correction

V1 did not execute because PowerShell parser rejected ambiguous variable
interpolation in the Draft PR here-string (`$Variable:`).

V2 fixes those interpolation points with `${Variable}` syntax and also defines
the three candidate-history variables used in the PR body.

No repository operation could have occurred from the failed V1 because the
failure was a PowerShell parse-time error.
