CaptivPortal KB TRAFFIC-03 Production/Governance Publisher V3

Version:
TRAFFIC03-KB-GOV-V3-2026-08-30

Fixes:
- README_RU roadmap anchor corrected to:
  ## Уже пройденная лестница
- full mutation ANCHOR PRECHECK added before the first file write;
- V2 PowerShell interpolation fixes retained;
- failed V2 local branch recovery retained.

Exact base:
b92efbfabb38f912550526bc5a3d1f2f1a8ae4d6

Exact tree:
1d8b94590848f9505e45e653384dd8a7c18d4339

Expected failed-V2 repository state:
local docs/traffic03-production-governance-2026-08-30 branch,
HEAD still at exact base,
only allowed docs files dirty,
no commit/push/PR.

V3 will verify that state, reset it to origin/main, run all anchor checks,
then apply the controlled KB update.

SHA256:
92c0fc34d40335ef23668d45974448cfcb54676434a2346d60cd58f1ea27bc7b
