# CaptivPortal KB Controlled Update — TRAFFIC-06

Prepared: 2026-09-01
Exact repository/production baseline: `c5f9dc39bbf399847f147526c9c7ae15769a198c`
Exact tree: `0831ecf598b5760e8ede2e9e94a25b926480c2dd`

## Reconciliation scope

12 current/canonical docs:
- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/admin-web.md`
- `docs/modules/analytics.md`
- `docs/modules/traffic.md`
- `docs/project-inventory.md`
- `docs/testing.md`

## Current truth after update

- TASK-TRAFFIC-06 — AP Traffic Share: DONE / PRODUCTION ACTIVE.
- AP Traffic Share added to production Traffic surface.
- `WEB_ADMIN_TRAFFIC_AP_SHARE_ENABLED=true` in production; repository default remains false.
- canonical `products=` order: `history,statistics,peak,aps,apshare`.
- AP Share metric: `network_traffic_ap_share.v1`.
- share method: `accepted_site_interval_integrated_ap_contribution_ratio.v1`.
- NEXT product task: `TRAFFIC-07 — Online Guests Traffic`.
- `TRAFFIC-07-READ` remains CONDITIONAL / NOT IMPLEMENTED.

## Publication

Publisher is fail-closed on exact SHA/tree, exact anchors, exact 12-file scope and `git diff --check`. It creates a docs-only branch/commit/Draft PR and does not merge.
