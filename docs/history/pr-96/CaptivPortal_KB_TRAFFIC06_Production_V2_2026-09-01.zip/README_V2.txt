CaptivPortal KB TRAFFIC-06 Production Publisher V2

Version:
TRAFFIC06-KB-V2-2026-09-01

V1 stopped during ANCHOR PRECHECK because it used a stale deployment heading:

  ## Traffic production checkpoint — 2026-08-31

Actual canonical heading on exact main:

  ## Traffic production checkpoint — 2026-09-01

Since V1 failed before === APPLY KB UPDATE ===:
- documentation files were not written;
- no commit was created;
- nothing was pushed;
- no PR was opened.

V1 only:
- fetched/fast-forwarded local main to the exact baseline;
- created the clean local branch docs/traffic06-production-kb-2026-09-01.

V2 keeps the same exact baseline/tree guards and safely recreates that clean,
unpushed local branch from verified main before applying the documentation update.

Exact base:
c5f9dc39bbf399847f147526c9c7ae15769a198c

Exact tree:
0831ecf598b5760e8ede2e9e94a25b926480c2dd

The full anchor precheck still runs before the first documentation write.
The 12-file documentation allowlist, git diff --check, staged diff check,
Draft PR creation, and no-merge boundary are unchanged.

SHA256:
8637005f03d3a27ae1a8a7b6d7555944f7b7cca5f94a2f23fa92461d5ae87c50
