# Projection lifecycle P0 KB — V4 Header Fix

PR #112 review found one real documentation blocker after V3 publication.

The semantic closure content is correct. Six current-state headers retained old
tree/production identities because the previous publisher's SHA regex did not
match those fields.

V4 changes only:

- `docs/README.md`
- `docs/architecture.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/traffic.md`
- `docs/testing.md`

Target current identity:

```text
main / production=7472d67274ea5aaea2a20df6b613b78d5bb70f42
tree=3950df6d400049ed16a823032c6740396cd61137
```

Expected starting PR head:

```text
29e76b1da816c6415349382b21b9550b4fdf8969
```

V4 creates one small commit on the same branch and pushes it to PR #112.
It does not create another PR and does not merge.

SHA256:
`f52b70ed52868b6ecdb7714cee444ff7b7bf874b679820a339a665fb112a033b`
