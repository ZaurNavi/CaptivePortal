from __future__ import annotations
import os, subprocess
from pathlib import Path

BASE_MAIN='7472d67274ea5aaea2a20df6b613b78d5bb70f42'
TREE='3950df6d400049ed16a823032c6740396cd61137'
PR_HEAD='29e76b1da816c6415349382b21b9550b4fdf8969'
BRANCH='docs/projection-lifecycle-p0-closure-kb-2026-09-11'
FIXES={'docs/README.md': [('Current implementation tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Current implementation tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/architecture.md': [('Runtime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Runtime tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/deployment.md': [('Confirmed production deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`', 'Confirmed production deployed HEAD: `7472d67274ea5aaea2a20df6b613b78d5bb70f42`'), ('Confirmed production tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Confirmed production tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/module-index.md': [('Runtime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Runtime tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/modules/traffic.md': [('Repository tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`', 'Repository tree: `3950df6d400049ed16a823032c6740396cd61137`'), ('Production deployed HEAD: `e32ade378bdbfc9f8458db9c18221958f4552718`', 'Production deployed HEAD: `7472d67274ea5aaea2a20df6b613b78d5bb70f42`'), ('Production tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`', 'Production tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/testing.md': [('Production deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`', 'Production deployed HEAD: `7472d67274ea5aaea2a20df6b613b78d5bb70f42`'), ('Production tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Production tree: `3950df6d400049ed16a823032c6740396cd61137`')]}

def run_text(args,cwd,check=True):
    p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                     encoding="utf-8",errors="replace")
    if check and p.returncode != 0:
        if p.stdout: print(p.stdout,end="")
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")
    return p.stdout or ""

def run_pass(args,cwd):
    p=subprocess.run(args,cwd=cwd)
    if p.returncode != 0:
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")

def norm(s):
    return s.replace("\r\n","\n").replace("\r","\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def write(path,text):
    Path(path).write_text(norm(text),encoding="utf-8",newline="\n")

def status(repo):
    return run_text(["git","status","--short","--untracked-files=all"],repo).strip()

def changed(repo,cached=False):
    args=["git","diff"]
    if cached: args.append("--cached")
    args += ["--name-only","--"]
    out=run_text(args,repo)
    return sorted(x.strip() for x in out.splitlines() if x.strip())

def main():
    repo=Path(os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) /
            "Downloads" / "CaptivPortal-KB-Work")
    ))
    print("Publisher: PROJECTION-LIFECYCLE-P0-KB-V4-HEADER-FIX-2026-09-12")
    print("=== PRECHECK ===")

    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if status(repo):
        print(status(repo))
        raise SystemExit("STOP: worktree must be clean")
    if run_text(["git","branch","--show-current"],repo).strip()!=BRANCH:
        raise SystemExit("STOP: not on PR #112 publication branch")
    if run_text(["git","rev-parse","HEAD"],repo).strip()!=PR_HEAD:
        raise SystemExit("STOP: local PR head moved")

    run_pass(["git","fetch","origin","main",BRANCH],repo)
    main_sha=run_text(["git","rev-parse","origin/main"],repo).strip()
    main_tree=run_text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    remote_head=run_text(["git","rev-parse",f"origin/{BRANCH}"],repo).strip()

    print("origin/main:",main_sha)
    print("origin main tree:",main_tree)
    print("origin branch head:",remote_head)

    if main_sha!=BASE_MAIN or main_tree!=TREE:
        raise SystemExit("STOP: main moved; re-review PR before header repair")
    if remote_head!=PR_HEAD:
        raise SystemExit("STOP: remote PR head moved")

    print("=== VERIFY EXACT STALE HEADER SET ===")
    for path,repls in FIXES.items():
        text=read(repo/path)
        for old,new in repls:
            c=text.count(old)
            if c!=1:
                raise SystemExit(f"STOP: {path} expected stale header matched {c} times: {old}")
            if new in text:
                # For fields where the same new SHA appears elsewhere, this is fine.
                pass
    print("PASS: exact expected stale header fields confirmed")

    print("=== APPLY HEADER-ONLY FIX ===")
    for path,repls in FIXES.items():
        text=read(repo/path)
        for old,new in repls:
            text=text.replace(old,new,1)
        write(repo/path,text)

    expected=sorted(FIXES)
    actual=changed(repo)
    print("Changed files:")
    for p in actual: print(" ",p)
    if actual!=expected:
        raise SystemExit("STOP: header-fix scope mismatch")

    print("=== CURRENT IDENTITY ASSERTIONS ===")
    checks={
        "docs/README.md":[
            f"Current-state implementation baseline: `main@{BASE_MAIN}`",
            f"Current implementation tree: `{TREE}`",
        ],
        "docs/architecture.md":[
            f"Runtime implementation baseline: `main@{BASE_MAIN}`",
            f"Runtime tree: `{TREE}`",
        ],
        "docs/deployment.md":[
            f"Current repository implementation baseline: `main@{BASE_MAIN}`",
            f"Confirmed production deployed HEAD: `{BASE_MAIN}`",
            f"Confirmed production tree: `{TREE}`",
        ],
        "docs/module-index.md":[
            f"Runtime implementation baseline: `main@{BASE_MAIN}`",
            f"Runtime tree: `{TREE}`",
        ],
        "docs/modules/traffic.md":[
            f"Repository implementation baseline: `main@{BASE_MAIN}`",
            f"Repository tree: `{TREE}`",
            f"Production deployed HEAD: `{BASE_MAIN}`",
            f"Production tree: `{TREE}`",
            "health=healthy",
            "P0 incident=closed",
        ],
        "docs/testing.md":[
            f"Documentation/current-state implementation baseline: `main@{BASE_MAIN}`",
            f"Production deployed HEAD: `{BASE_MAIN}`",
            f"Production tree: `{TREE}`",
            "P0 INCIDENT=CLOSED",
        ],
    }
    for path,needles in checks.items():
        text=read(repo/path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: missing post-fix assertion in {path}: {needle}")

    stale_headers=[
        "Current implementation tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`",
        "Runtime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`",
        "Confirmed production deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`",
        "Confirmed production tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`",
        "Repository tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`",
        "Production deployed HEAD: `e32ade378bdbfc9f8458db9c18221958f4552718`",
        "Production tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`",
        "Production deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`",
        "Production tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`",
    ]
    for path in expected:
        text=read(repo/path)
        for stale in stale_headers:
            if stale in text:
                raise SystemExit(f"STOP: stale current-state header remains in {path}: {stale}")

    run_pass(["git","diff","--check"],repo)
    print("PASS: six-file header-only scope")
    print("PASS: current main/tree/prod identity canonicalized")
    print("PASS: P0 semantic closure unchanged")
    print("PASS: git diff --check")

    run_pass(["git","add","--"]+expected,repo)
    if changed(repo,True)!=expected:
        raise SystemExit("STOP: staged header-fix scope mismatch")
    run_pass(["git","diff","--cached","--check"],repo)

    print("=== COMMIT ===")
    run_pass([
        "git","commit",
        "-m","docs: fix Projection P0 current-state identities",
        "-m","Correct stale tree and production identity headers left by the KB reconciliation harness. No semantic P0/recovery content changes."
    ],repo)
    commit=run_text(["git","rev-parse","HEAD"],repo).strip()

    if status(repo):
        raise SystemExit("STOP: worktree not clean after header-fix commit")

    print("=== PUSH SAME PR BRANCH ===")
    run_pass(["git","push","origin",BRANCH],repo)

    print("=== FINAL ===")
    print("Branch:",BRANCH)
    print("Header-fix commit:",commit)
    print("PR: https://github.com/ZaurNavi/CaptivePortal/pull/112")
    print("Files changed by V4: 6")
    print("New PR created: NO")
    print("Merge performed: NO")

if __name__=="__main__":
    main()
