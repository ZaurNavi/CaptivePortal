from __future__ import annotations
import os
import subprocess
from pathlib import Path

BASE_MAIN='7472d67274ea5aaea2a20df6b613b78d5bb70f42'
TREE='3950df6d400049ed16a823032c6740396cd61137'
PR_HEAD='29e76b1da816c6415349382b21b9550b4fdf8969'
BRANCH='docs/projection-lifecycle-p0-closure-kb-2026-09-11'
EXPECTED={'docs/README.md': [('Current implementation tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Current implementation tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/architecture.md': [('Runtime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Runtime tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/deployment.md': [('Confirmed production deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`', 'Confirmed production deployed HEAD: `7472d67274ea5aaea2a20df6b613b78d5bb70f42`'), ('Confirmed production tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Confirmed production tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/module-index.md': [('Runtime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Runtime tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/modules/traffic.md': [('Repository tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`', 'Repository tree: `3950df6d400049ed16a823032c6740396cd61137`'), ('Production deployed HEAD: `e32ade378bdbfc9f8458db9c18221958f4552718`', 'Production deployed HEAD: `7472d67274ea5aaea2a20df6b613b78d5bb70f42`'), ('Production tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`', 'Production tree: `3950df6d400049ed16a823032c6740396cd61137`')], 'docs/testing.md': [('Production deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`', 'Production deployed HEAD: `7472d67274ea5aaea2a20df6b613b78d5bb70f42`'), ('Production tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`', 'Production tree: `3950df6d400049ed16a823032c6740396cd61137`')]}
EXPECTED_FILES=['docs/README.md', 'docs/architecture.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/traffic.md', 'docs/testing.md']

def run_capture(args,cwd,check=True):
    p=subprocess.run(
        args,cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and p.returncode != 0:
        if p.stdout: print(p.stdout,end="")
        if p.stderr: print(p.stderr,end="")
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")
    return p.stdout or "", p.stderr or ""

def run_text(args,cwd,check=True):
    return run_capture(args,cwd,check)[0]

def run_pass(args,cwd):
    p=subprocess.run(args,cwd=cwd)
    if p.returncode != 0:
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")

def norm(s):
    return s.replace("\r\n","\n").replace("\r","\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def diff_names(repo,cached=False):
    args=["git","diff"]
    if cached:
        args.append("--cached")
    args += ["--name-only","--"]
    out,err=run_capture(args,repo)
    # Git may emit CRLF advice to stderr; it is intentionally never parsed as filenames.
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def untracked(repo):
    out,_=run_capture(["git","ls-files","--others","--exclude-standard"],repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def status_short(repo):
    out,_=run_capture(["git","status","--short","--untracked-files=all"],repo)
    return out.strip()

def numstat(repo,path):
    out,_=run_capture(["git","diff","--numstat","--",path],repo)
    rows=[x for x in out.splitlines() if x.strip()]
    if len(rows)!=1:
        raise SystemExit(f"STOP: unexpected numstat row count for {path}: {rows}")
    a,d,p=rows[0].split("\t",2)
    return int(a),int(d),p

def main():
    repo=Path(os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) /
            "Downloads" / "CaptivPortal-KB-Work")
    ))
    print("Publisher: PROJECTION-LIFECYCLE-P0-KB-V5-RESUME-HEADER-FIX-2026-09-12")
    print("=== RECOVERY PRECHECK ===")

    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if run_text(["git","branch","--show-current"],repo).strip()!=BRANCH:
        raise SystemExit("STOP: not on PR #112 publication branch")
    if run_text(["git","rev-parse","HEAD"],repo).strip()!=PR_HEAD:
        raise SystemExit("STOP: local PR head moved")

    run_pass(["git","fetch","origin","main",BRANCH],repo)
    main_sha=run_text(["git","rev-parse","origin/main"],repo).strip()
    main_tree=run_text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    remote_head=run_text(["git","rev-parse",f"origin/{BRANCH}"],repo).strip()

    print("origin/main:",main_sha)
    print("origin main tree:",main_tree)
    print("origin PR branch:",remote_head)

    if main_sha!=BASE_MAIN or main_tree!=TREE:
        raise SystemExit("STOP: main moved; re-review required")
    if remote_head!=PR_HEAD:
        raise SystemExit("STOP: remote PR head moved")

    unstaged=diff_names(repo,False)
    staged=diff_names(repo,True)
    extras=untracked(repo)

    print("Unstaged files:")
    for p in unstaged: print(" ",p)

    if unstaged!=EXPECTED_FILES:
        raise SystemExit(f"STOP: expected exactly six V4-modified files, got {unstaged}")
    if staged:
        raise SystemExit(f"STOP: unexpected staged changes: {staged}")
    if extras:
        raise SystemExit(f"STOP: unexpected untracked files: {extras}")

    print("PASS: exact failed-V4 state (6 unstaged, 0 staged, 0 untracked)")

    print("=== VERIFY V4 HEADER FIX CONTENT ===")
    expected_line_counts={
        "docs/README.md":(1,1),
        "docs/architecture.md":(1,1),
        "docs/deployment.md":(2,2),
        "docs/module-index.md":(1,1),
        "docs/modules/traffic.md":(3,3),
        "docs/testing.md":(2,2),
    }

    for path,repls in EXPECTED.items():
        text=read(repo/path)
        for old,new in repls:
            if old in text:
                raise SystemExit(f"STOP: stale header still present in {path}: {old}")
            if new not in text:
                raise SystemExit(f"STOP: corrected header missing in {path}: {new}")
        a,d,p=numstat(repo,path)
        ea,ed=expected_line_counts[path]
        if (a,d)!=(ea,ed):
            raise SystemExit(
                f"STOP: {path} is not header-only as expected; numstat={a}/{d}, expected={ea}/{ed}"
            )

    print("PASS: V4 changed only expected identity-header lines")

    print("=== SEMANTIC CLOSURE ASSERTIONS ===")
    semantic={
        "docs/modules/traffic.md":[
            "RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE",
            "health=healthy",
            "worker=active + enabled",
            "P0 incident=closed",
        ],
        "docs/deployment.md":[
            "projection_revision=123634",
            "traffic-projection.service=active + enabled",
            "P0 incident=closed",
        ],
        "docs/testing.md":[
            "P0 INCIDENT=CLOSED",
            "PRODUCTION ACCEPTANCE=PASS",
        ],
    }
    for path,needles in semantic.items():
        text=read(repo/path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: semantic closure drift in {path}: {needle}")
    print("PASS: P0 semantic closure unchanged")

    run_pass(["git","diff","--check"],repo)
    print("PASS: git diff --check")

    print("=== STAGE HEADER FIX ===")
    run_pass(["git","add","--"]+EXPECTED_FILES,repo)

    if diff_names(repo,False):
        raise SystemExit("STOP: unstaged changes remain after staging")
    if diff_names(repo,True)!=EXPECTED_FILES:
        raise SystemExit("STOP: staged scope mismatch")
    run_pass(["git","diff","--cached","--check"],repo)

    print("PASS: exact six-file staged scope")
    print("PASS: git diff --cached --check")

    print("=== COMMIT ===")
    run_pass([
        "git","commit",
        "-m","docs: fix Projection P0 current-state identities",
        "-m","Correct six stale tree/production identity headers left by the KB reconciliation harness. Semantic P0/recovery content is unchanged."
    ],repo)
    commit=run_text(["git","rev-parse","HEAD"],repo).strip()

    if status_short(repo):
        raise SystemExit("STOP: worktree not clean after commit")

    print("=== PUSH SAME PR BRANCH ===")
    run_pass(["git","push","origin",BRANCH],repo)

    print("=== FINAL ===")
    print("Branch:",BRANCH)
    print("Header-fix commit:",commit)
    print("PR: https://github.com/ZaurNavi/CaptivePortal/pull/112")
    print("Files changed by V5: 6")
    print("New PR created: NO")
    print("Merge performed: NO")

if __name__=="__main__":
    main()
