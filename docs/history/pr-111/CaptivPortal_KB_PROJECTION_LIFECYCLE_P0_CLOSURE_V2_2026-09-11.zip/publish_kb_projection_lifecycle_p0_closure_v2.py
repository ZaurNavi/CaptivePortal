from __future__ import annotations
import argparse
import os
import re
import subprocess
from pathlib import Path

BASE = '7472d67274ea5aaea2a20df6b613b78d5bb70f42'
TREE = '3950df6d400049ed16a823032c6740396cd61137'
BRANCH = 'docs/projection-lifecycle-p0-closure-kb-2026-09-11'
SCOPE = ['README.md', 'README_RU.md', 'docs/README.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/traffic.md', 'docs/operations-command-lessons-learned.md', 'docs/project-inventory.md', 'docs/tasks/TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01-IMPLEMENTATION-READY-FINAL-R5.md', 'docs/testing.md']
CLOSURE_RECORD = '# IMPLEMENTATION-READY FINAL-R5 — TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01 — PRODUCTION CLOSURE\n\n**Project:** CaptivPortal  \n**Priority:** `P0 / PRODUCTION INCIDENT`  \n**Architecture authority:** `ARCHITECTURE FINAL-R1 — PASS`  \n**Historical implementation milestone:** `IMPLEMENTATION-READY FINAL-R5`  \n**Accepted implementation:** `FINAL-R5 + FIX-1`  \n**Current status:** `PRODUCTION ACCEPTED / P0 INCIDENT CLOSED`  \n**Production repair/rebuild:** `COMPLETED / PASS`  \n**Production Projection worker:** `ACTIVE + ENABLED`  \n**Prepared / closure updated:** 2026-09-11\n\n> Historical HOLD / containment statements below are retained as dated lifecycle\n> evidence. They are not current production status.\n\n---\n\n# 0. Current authoritative status\n\n```text\nTASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01\n= CLOSED / PRODUCTION ACCEPTANCE PASS\n\nPR #111 / FIX-1\n= MERGED + DEPLOYED + VERIFIED\n\nPRODUCTION ARTIFACT\n= 7472d67274ea5aaea2a20df6b613b78d5bb70f42\n\nPRODUCTION TREE\n= 3950df6d400049ed16a823032c6740396cd61137\n\nPROJECTION HEALTH\n= HEALTHY\n\nHISTORICAL TRAFFIC READ SURFACE\n= RESTORED\n\ntraffic-projection.service\n= ACTIVE + ENABLED\n\nP0 INCIDENT\n= CLOSED\n```\n\nThe current state supersedes the earlier **current-status** wording:\n\n```text\nproduction repair/rebuild = HOLD\ntraffic-projection.service = STOPPED + DISABLED / CONTAINED\n```\n\nThose statements remain valid only for the historical containment stage before\ncandidate acceptance and production recovery.\n\n---\n\n# 1. Incident classification — unchanged\n\nCanonical root-cause classification remains:\n\n```text\nRETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE\n```\n\nPermanent authority:\n\n```text\nObservation = authoritative source.\nTraffic Projection = derived / rebuildable read model.\n```\n\nThe P0 failure mechanism was:\n\n```text\nfrozen reconcile sweep fixes proof window\n        ↓\nwall clock / normal retention cutoff advances\n        ↓\ncleanup deletes Projection rows still inside frozen proof window\n        ↓\nsource/projection identity diverges\n        ↓\nSite status=diverged\nlast_error_category=source_identity\n        ↓\nHistorical Projection reads fail closed\n```\n\nThe fix protects the proof window. It does **not** weaken identity proof.\n\nDivergence remains fail-closed. An untrusted Projection must not be served as\nhealthy.\n\nProduction repair remains constrained to the accepted repair model. Arbitrary\nSQL mutation, manual health reset or Observation mutation is forbidden.\n\n---\n\n# 2. Historical incident / containment stage\n\nProduction Site:\n\n```text\nsite_id=6a64f17630da7c70d232187a\nprojection_version=historical_traffic_projection.v1\n```\n\nBefore repair:\n\n```text\nstatus=diverged\nlast_error_category=source_identity\nprojection_revision=88955\n\ntraffic-projection.service=inactive\ntraffic-projection.service=disabled\nwriter lock=free\n```\n\nObservation continued authoritative acquisition and `captive-portal.service`\nremained active.\n\nProjection DB:\n\n```text\n/opt/CaptivePortal/data/traffic_projection.sqlite3\n```\n\nObservation DB:\n\n```text\n/opt/CaptivePortal/data/observations.sqlite3\n```\n\nContainment purpose:\n\n```text\nstop the known-vulnerable Projection writer\npreserve incident evidence\nprevent unaccepted repair/rebuild\nkeep Observation untouched\nkeep Captive Portal operational\n```\n\nHistorical milestone at this stage:\n\n```text\nIMPLEMENTATION-READY FINAL-R5\nproduction repair/rebuild=HOLD\nProjection writer=STOPPED + DISABLED / CONTAINED\n```\n\nThis stage is retained as chronology, not current status.\n\n---\n\n# 3. FINAL-R5 + FIX-1 accepted implementation\n\nAccepted implementation adds / hardens:\n\n```text\ndurable cleanup fence\ndurable repair continuation\nhealth observer / structured telemetry\nimmutable loaded artifact identity\nbounded shutdown\nrestart/interruption-safe persisted repair continuation\n```\n\nCritical durable repair rule:\n\n```text\nversion active\n+\nstatus=rebuilding\n+\nlast_error_category=repair_delete\n→ active durable repair phase\n```\n\nThe normal Projection worker recognizes active persisted repair lineage and\ncontinues `repair_site()` instead of falling into the ordinary incremental path.\n\nThe same lifecycle also covers an active durable reconcile sweep within\n`rebuilding`.\n\nNo Projection schema migration was required for the retention fence.\n\n---\n\n# 4. Git / acceptance identity\n\nImplementation baseline before PR:\n\n```text\nff39fe888c53361a7c65a034eaddb0ce92cc4a12\n```\n\nAccepted PR head:\n\n```text\na0dc02d5ae0ff16c250cf46a7e7a610c24e6f433\n```\n\nAccepted tree:\n\n```text\n3950df6d400049ed16a823032c6740396cd61137\n```\n\nPR:\n\n```text\n#111\n```\n\nFIX-1 patch SHA256:\n\n```text\n53f76302494edb4ab135cb416b957a392beb55b2469c5bd29cc1823ae9be52a5\n```\n\nOwner merged PR #111.\n\nProduction merge artifact:\n\n```text\n7472d67274ea5aaea2a20df6b613b78d5bb70f42\n```\n\nProduction merge tree:\n\n```text\n3950df6d400049ed16a823032c6740396cd61137\n```\n\nTherefore:\n\n```text\naccepted tree == production merge tree\n```\n\nThe exact artifact that passed acceptance is the artifact deployed to\nproduction.\n\nPR acceptance evidence:\n\n```text\nSource Review=PASS\nWindows Central Full V6=PASS\nstrict regressions=0\nLinux targeted=132 PASS\nLinux full=3154 PASS, 1 SKIP\n3 baseline/environment failures reproduced identically on clean base\ncandidate-specific regressions=0\n```\n\n---\n\n# 5. Forensic preflight before mutation\n\nBefore any production repair mutation, the writer was contained and a forensic\nbackup was created outside the repository:\n\n```text\n/home/admin/captivportal-recovery/projection-incident-20260911-112820\n```\n\nThe recovery evidence preserved:\n\n```text\nSQLite-consistent Projection backup\nraw DB/WAL/SHM\nwriter-lock snapshot\nmanifest\nSite-state snapshot\nSHA256 evidence\n```\n\nThis is an accepted recovery-workflow requirement for this real incident:\n\n```text\ncontain writer\n→ prove lock state\n→ preserve forensic evidence / consistent backup\n→ only then mutate derived Projection through canonical repair\n```\n\nObservation was not mutated.\n\n---\n\n# 6. Production fixed-artifact deployment\n\nProduction checkout:\n\n```text\n/opt/CaptivePortal\n```\n\nExact deployed artifact:\n\n```text\nHEAD=7472d67274ea5aaea2a20df6b613b78d5bb70f42\ntree=3950df6d400049ed16a823032c6740396cd61137\n```\n\nPost-deploy proof:\n\n```text\nrepository clean=PASS\nexact HEAD/tree=PASS\ncompileall=PASS\nimport smoke=PASS\nloaded artifact identity=PASS\ncaptive-portal.service=active\n```\n\nDuring this validation:\n\n```text\ntraffic-projection.service=inactive\ntraffic-projection.service=disabled\n```\n\nThe Projection worker intentionally remained contained until repair entry.\n\n---\n\n# 7. Repair CLI environment lesson\n\nThe first `repair-site` attempt from an ordinary interactive shell was rejected:\n\n```text\nTRAFFIC_PROJECTION_ENABLED must be true\n```\n\nRequired classification:\n\n```text\nfail-closed configuration behavior=CORRECT\nrepair mutation started=NO\nProjection DB changed=NO\n```\n\nProduction Projection runtime environment is defined by systemd:\n\n```text\nunit=/etc/systemd/system/traffic-projection.service\nEnvironmentFile=/etc/default/captive-portal\nUser=admin\nGroup=admin\nWorkingDirectory=/opt/CaptivePortal\nExecStart=/usr/bin/python3 -m app.traffic_projection.cli run\n```\n\nOperational invariant learned from the recovery:\n\n```text\nProduction Projection CLI/repair must not be executed from an arbitrary shell\nenvironment when the canonical worker environment is supplied by systemd\nEnvironmentFile.\n```\n\nControlled repair must reproduce the canonical User/Group/WorkingDirectory and\nEnvironmentFile context without exposing secrets.\n\n---\n\n# 8. First controlled durable repair quantum\n\nThe first real production repair quantum ran through a transient systemd unit\nusing the canonical Projection environment.\n\nResult:\n\n```text\nREPAIR_RC=0\n\nprojection_revision:\n88955 → 88956\n\nstatus=rebuilding\nlast_error_category=repair_delete\n```\n\nThe repair model cleared obsolete proof/checkpoint state as intended:\n\n```text\nold fast_checkpoint cleared\nold reconcile sweep/cursor cleared\nold projection head cleared\nold proof fields cleared\n```\n\nAfter the quantum:\n\n```text\nPRAGMA quick_check=ok\nwriter lock=FREE\n```\n\nThis was not yet full recovery. It was the accepted durable repair entry.\n\n---\n\n# 9. Durable continuation through the normal worker\n\nAfter the first quantum, the permanent Projection worker was started but not yet\nenabled:\n\n```text\ntraffic-projection.service=active\ntraffic-projection.service=disabled\n```\n\nLoaded artifact telemetry proved:\n\n```text\nartifact_sha=7472d67274ea5aaea2a20df6b613b78d5bb70f42\nartifact_tree=3950df6d400049ed16a823032c6740396cd61137\nservice_name=traffic-projection.service\n```\n\nThe worker discovered the persisted:\n\n```text\nstatus=rebuilding\nlast_error_category=repair_delete\n```\n\nand automatically continued the durable repair through the normal worker\nlifecycle.\n\nProduction therefore proved:\n\n```text\nrepair continuation after restart/persisted rebuilding state=PASS\n```\n\nNo repeated manual repair-site loop was required.\n\n---\n\n# 10. Delete phase proof\n\nInitial Projection-cycle count:\n\n```text\n34342\n```\n\nObserved bounded progress included:\n\n```text\n34342\n→ 32642\n→ 30942\n→ 27742\n→ ...\n```\n\nDelete work occurred in bounded chunks of 100 cycles and continued rather than\nstalling.\n\nResult:\n\n```text\ndurable delete phase=PASS\nbounded repair continuation=PASS\n```\n\n---\n\n# 11. Automatic rebuild / reconcile / deep audit\n\nAfter delete completion, the same worker automatically progressed to rebuild and\nreconcile from authoritative Observation.\n\nRecovery path proved:\n\n```text\nObservation authoritative data\n→ Projection rebuild\n→ full reconcile\n→ source/projection identity proof\n→ deep audit\n→ healthy\n```\n\nNo arbitrary Projection-row insert and no Observation mutation were used.\n\n---\n\n# 12. Final production acceptance state\n\nFinal Site state:\n\n```text\nprojection_revision=123634\nstatus=healthy\nlast_error_category=NULL\n\nprojection_head_utc=2026-09-11T13:18:00.739Z\nsource_head_utc=2026-09-11T13:18:00.739Z\n\nlast_incremental_progress_at=2026-09-11T13:18:01.515Z\nlast_full_reconcile_completed_at=2026-09-11T13:17:46.393Z\nlast_full_reconcile_source_head_utc=2026-09-11T13:16:11.360Z\nlast_deep_audit_at=2026-09-11T13:17:46.393Z\n\nbacklog_cycle_count=0\n\navailable_from_utc=2026-08-13T17:37:01.104Z\navailable_through_utc=2026-09-11T13:17:30.622Z\n```\n\nHead coherence:\n\n```text\nprojection_head_utc == source_head_utc\nPASS\n```\n\nProjection version:\n\n```text\nhistorical_traffic_projection.v1\nstatus=active\n```\n\nDB integrity:\n\n```text\nPRAGMA user_version=1\nPRAGMA quick_check=ok\n```\n\nFinal product health:\n\n```text\nhealthy\n```\n\n---\n\n# 13. Service / autostart final state\n\nFinal services:\n\n```text\ncaptive-portal.service=active\ntraffic-projection.service=active\n```\n\nAfter acceptance:\n\n```text\nsystemctl enable traffic-projection.service\n```\n\nFinal worker state:\n\n```text\ntraffic-projection.service=active + enabled\n```\n\nThe Projection worker is therefore restored to normal production operation and\nwill start after reboot.\n\n---\n\n# 14. End-to-end Historical Traffic proof\n\nAfter recovery, Owner manually opened the production Admin Web and verified the\npreviously unavailable Historical Traffic panels rendered normally again.\n\nThis is production proof of the full path:\n\n```text\nObservation\n→ Traffic Projection\n→ HistoricalTrafficReadService\n→ Admin Traffic read surface\n→ Web UI panels\n```\n\nHistorical Traffic read surface:\n\n```text\nRESTORED / PASS\n```\n\nThis acceptance does not alter Historical Traffic business formulas.\n\n---\n\n# 15. Final incident verdict\n\n```text\nPR #111 / FIX-1=DEPLOYED\nProduction artifact=VERIFIED\n\nDurable repair=PASS\nPersisted repair continuation=PASS\nDelete phase=PASS\nRebuild=PASS\nFull reconcile=PASS\nDeep audit=PASS\n\nProjection health=HEALTHY\nSource/projection head coherence=PASS\nBacklog=0\nDB integrity=PASS\n\nHistorical Web panels=PASS\nCaptive Portal=ACTIVE\n\nProjection worker=ACTIVE\nProjection autostart=ENABLED\n\nP0 INCIDENT=CLOSED\nPRODUCTION ACCEPTANCE=PASS\n```\n\nCurrent-status wording is therefore:\n\n```text\nFIX-1 accepted, merged and deployed to production.\nProduction recovery completed.\nProjection healthy.\nHistorical Traffic read surface restored.\nWorker active + enabled.\nP0 incident closed.\n```\n\n---\n\n# 16. Non-blocking post-recovery observation\n\nAfter recovery, normal telemetry showed a short transition:\n\n```text\nhealthy → stale → healthy\n```\n\nduring an active reconcile sweep.\n\nObserved context:\n\n```text\nerror_category=NULL\nworker remained running\nProjection continued processing\nreconcile completed\nfresh last_full_reconcile_completed_at was written afterward\nfinal state=healthy\n```\n\nCurrent classification:\n\n```text\nOBSERVATION — transient healthy/stale/healthy during active reconcile sweep\n```\n\nIt is **not** currently classified as:\n\n```text\nnew incident\nTASK regression\nproduction blocker\n```\n\nMonitor this behavior. If transient `stale` becomes frequent or user-visible\nthrough the Historical read gate/Web UI, analyze health-observer/read-gate\nsemantics as a separate future issue.\n\nNo new architecture decision is made by recording this observation.\n\n---\n\n# 17. Permanent recovery invariants retained\n\n```text\nObservation remains authoritative.\nProjection remains derived/rebuildable.\nDivergence remains fail-closed.\nDo not weaken source/projection proof to restore availability.\nDo not mutate Observation to repair Projection.\nDo not manually mark diverged Projection healthy.\nDo not perform arbitrary SQL repair outside the canonical repair lifecycle.\nForensic capture/consistent backup precedes production repair mutation.\nExact loaded artifact identity is part of production proof.\n```\n\n---\n\n# 18. Chronology summary\n\n```text\nP0 detected\n→ root cause classified:\n  RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE\n\n→ containment:\n  writer STOPPED + DISABLED\n  repair/rebuild HOLD\n  Observation continues\n\n→ Architecture FINAL-R1\n→ IMPLEMENTATION-READY FINAL-R5\n\n→ FINAL-R5 + FIX-1 implemented\n→ Owner + Tech Lead acceptance PASS\n→ PR #111 merged\n\n→ forensic preflight + consistent backup\n→ exact fixed artifact deployed\n\n→ arbitrary-shell repair rejected fail-closed\n→ repair re-run under canonical systemd runtime context\n\n→ first durable repair quantum:\n  rebuilding + repair_delete\n\n→ normal worker resumed persisted repair\n→ bounded delete\n→ rebuild\n→ full reconcile\n→ deep audit\n→ healthy / backlog 0\n\n→ Historical Web panels restored\n→ worker enabled for autostart\n\n→ P0 incident CLOSED\n```\n'
BLOCKS = {'README.md': '## Traffic Projection lifecycle P0 — closed\n\n`TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01` is now production-accepted.\n\n```text\nroot cause=RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE\naccepted implementation=FINAL-R5 + FIX-1\nPR #111=merged\nproduction artifact=7472d67274ea5aaea2a20df6b613b78d5bb70f42\nproduction tree=3950df6d400049ed16a823032c6740396cd61137\nProjection health=healthy\nHistorical Traffic=restored\ntraffic-projection.service=active + enabled\nP0 incident=closed\n```\n\nPermanent authority is unchanged:\n\n```text\nObservation = authoritative source\nTraffic Projection = derived/rebuildable read model\ndivergence = fail-closed\n```\n\nThe earlier `repair/rebuild HOLD` and `STOPPED + DISABLED / CONTAINED` state is\nhistorical containment evidence only, not current production status.\n', 'README_RU.md': '## Traffic Projection lifecycle P0 — закрыт\n\n`TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01` полностью принят в production.\n\n```text\nroot cause=RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE\naccepted implementation=FINAL-R5 + FIX-1\nPR #111=merged\nproduction artifact=7472d67274ea5aaea2a20df6b613b78d5bb70f42\nproduction tree=3950df6d400049ed16a823032c6740396cd61137\nProjection health=healthy\nHistorical Traffic=restored\ntraffic-projection.service=active + enabled\nP0 incident=closed\n```\n\nАрхитектурный принцип не изменился:\n\n```text\nObservation = authoritative source\nTraffic Projection = derived/rebuildable read model\ndivergence = fail-closed\n```\n\nСтарые `repair/rebuild HOLD` и `STOPPED + DISABLED / CONTAINED` сохраняются\nтолько как историческое состояние containment, а не current production status.\n', 'docs/README.md': '## Traffic Projection lifecycle P0 closure\n\nCanonical task / incident record:\n\n`tasks/TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01-IMPLEMENTATION-READY-FINAL-R5.md`\n\nCurrent truth:\n\n```text\nFINAL-R5 + FIX-1=accepted\nPR #111=merged\nproduction=7472d67274ea5aaea2a20df6b613b78d5bb70f42\ntree=3950df6d400049ed16a823032c6740396cd61137\nrecovery=PASS\nProjection health=healthy\nHistorical Traffic=restored\nworker=active + enabled\nP0 incident=closed\n```\n\nThe task record preserves the earlier HOLD/containment state as chronology and\ndoes not treat it as current status.\n', 'docs/architecture.md': '### Traffic Projection lifecycle consistency — accepted production architecture\n\nThe P0 lifecycle incident is closed.\n\nCanonical root-cause class remains:\n\n```text\nRETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE\n```\n\nPermanent architecture:\n\n```text\nObservation\n→ authoritative Historical Traffic evidence\n\nTraffic Projection\n→ derived / rebuildable read model\n```\n\nA frozen reconcile proof window must be protected from moving retention cleanup.\nDivergence remains fail-closed; inconsistent Projection is not served merely to\nrestore availability.\n\nAccepted `FINAL-R5 + FIX-1` adds/hardens:\n\n```text\ndurable cleanup fence\ndurable repair continuation\nhealth observer / telemetry\nimmutable loaded artifact identity\nbounded shutdown\n```\n\nPersisted `rebuilding + repair_delete` is active durable repair lineage. After a\nrestart/interruption, the normal Projection worker continues the accepted\n`repair_site()` lifecycle rather than losing the repair and returning to normal\nincremental maintenance.\n\nProduction repair must use the canonical repair lifecycle. Manual Projection\nrow insertion, manual healthy reset and authoritative Observation mutation\nremain forbidden.\n\nProduction acceptance proved:\n\n```text\nfixed artifact=7472d67274ea5aaea2a20df6b613b78d5bb70f42\ntree=3950df6d400049ed16a823032c6740396cd61137\ndurable repair continuation=PASS\nfull reconcile=PASS\ndeep audit=PASS\nhealth=healthy\nbacklog=0\nHistorical Traffic Web path=PASS\nworker=active + enabled\n```\n', 'docs/configuration.md': '### Historical Traffic projection — production lifecycle state\n\nRepository defaults remain safe/off unless separately configured:\n\n```text\nTRAFFIC_PROJECTION_ENABLED=false\nWEB_ADMIN_TRAFFIC_PROJECTION_READ_ENABLED=false\n```\n\nRepository default values do not describe current production runtime.\n\nOwner-confirmed production recovery on 2026-09-11 ended with:\n\n```text\ntraffic-projection.service=active + enabled\nprojection_version=historical_traffic_projection.v1\nversion_status=active\nSite health=healthy\n```\n\nCanonical worker runtime environment is supplied by:\n\n```text\n/etc/systemd/system/traffic-projection.service\nEnvironmentFile=/etc/default/captive-portal\nUser=admin\nGroup=admin\nWorkingDirectory=/opt/CaptivePortal\nExecStart=/usr/bin/python3 -m app.traffic_projection.cli run\n```\n\nProduction CLI/repair must use the canonical worker environment rather than an\narbitrary interactive shell environment. Secret values are never recorded in KB.\n', 'docs/deployment.md': '## Projection lifecycle P0 production recovery — 2026-09-11\n\nArtifact:\n\n```text\nTASK=TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01\naccepted implementation=FINAL-R5 + FIX-1\nPR=#111\naccepted head=a0dc02d5ae0ff16c250cf46a7e7a610c24e6f433\naccepted tree=3950df6d400049ed16a823032c6740396cd61137\nmerge / production=7472d67274ea5aaea2a20df6b613b78d5bb70f42\n```\n\nBefore mutation:\n\n```text\nSite=6a64f17630da7c70d232187a\nstatus=diverged\nlast_error_category=source_identity\nprojection_revision=88955\ntraffic-projection.service=inactive + disabled\nwriter lock=free\nObservation=continuing\ncaptive-portal.service=active\n```\n\nForensic backup created before repair:\n\n```text\n/home/admin/captivportal-recovery/projection-incident-20260911-112820\n```\n\nIt preserved SQLite-consistent Projection backup, raw DB/WAL/SHM, writer-lock\nsnapshot, manifest, Site-state snapshot and SHA256 evidence.\n\nFixed deploy proof:\n\n```text\nclean repository=PASS\nHEAD=7472d67274ea5aaea2a20df6b613b78d5bb70f42\ntree=3950df6d400049ed16a823032c6740396cd61137\ncompileall=PASS\nimport smoke=PASS\nloaded artifact identity=PASS\ncaptive-portal.service=active\nProjection worker intentionally remained inactive + disabled\n```\n\nAn interactive-shell `repair-site` attempt failed closed with:\n\n```text\nTRAFFIC_PROJECTION_ENABLED must be true\n```\n\nNo mutation began. Recovery then used a transient systemd unit reproducing the\ncanonical EnvironmentFile/User/Group/WorkingDirectory.\n\nFirst durable repair quantum:\n\n```text\nREPAIR_RC=0\nprojection_revision 88955 → 88956\nstatus=rebuilding\nlast_error_category=repair_delete\nPRAGMA quick_check=ok\nwriter lock=FREE\n```\n\nThe permanent worker was started while still disabled and loaded exact artifact\n`7472d67274ea5aaea2a20df6b613b78d5bb70f42` / `3950df6d400049ed16a823032c6740396cd61137`. It automatically continued persisted repair.\n\nDelete progress included:\n\n```text\n34342 → 32642 → 30942 → 27742 → ...\n```\n\nthen automatically transitioned to rebuild/reconcile/deep-audit.\n\nFinal acceptance:\n\n```text\nprojection_revision=123634\nstatus=healthy\nlast_error_category=NULL\nprojection_head_utc=2026-09-11T13:18:00.739Z\nsource_head_utc=2026-09-11T13:18:00.739Z\nbacklog_cycle_count=0\nPRAGMA user_version=1\nPRAGMA quick_check=ok\nHistorical Web panels=PASS\n```\n\nAfter final proof:\n\n```text\nsystemctl enable traffic-projection.service\ntraffic-projection.service=active + enabled\nrollback=not required\nP0 incident=closed\n```\n', 'docs/module-index.md': '## Traffic Projection lifecycle P0 closure\n\n```text\nTASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01\nCLOSED / PRODUCTION ACCEPTANCE PASS\n\nFINAL-R5 + FIX-1\nPR #111 merged\n\nproduction=7472d67274ea5aaea2a20df6b613b78d5bb70f42\ntree=3950df6d400049ed16a823032c6740396cd61137\n```\n\nProjection remains derived/rebuildable from authoritative Observation. The\naccepted lifecycle fix protects frozen reconcile proof windows, resumes durable\nrepair after restart, and adds operational health/artifact lifecycle evidence.\n\nCurrent production:\n\n```text\nProjection health=healthy\nHistorical Traffic=restored\ntraffic-projection.service=active + enabled\n```\n', 'docs/modules/traffic.md': '## Traffic Projection lifecycle P0 closure\n\nHistorical Traffic Projection remains a derived/rebuildable read model over\nauthoritative Observation.\n\nP0 root cause:\n\n```text\nRETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE\n```\n\nThe incident caused a fail-closed Site `diverged/source_identity` state because\nmoving retention cleanup could remove Projection rows still required by an\nactive frozen reconcile proof window.\n\nAccepted permanent fix:\n\n```text\nFINAL-R5 + FIX-1\nPR #111\nproduction=7472d67274ea5aaea2a20df6b613b78d5bb70f42\ntree=3950df6d400049ed16a823032c6740396cd61137\n```\n\nKey lifecycle guarantees:\n\n```text\ndurable per-Site/per-version cleanup fence\ndiverged cleanup blocked\nactive repair cleanup blocked\npersisted repair continuation\nrebuilding + repair_delete = active durable repair phase\nnormal worker resumes repair_site() lifecycle\nhealth observer / structured telemetry\nimmutable startup artifact identity\nbounded shutdown\n```\n\nProduction recovery proved:\n\n```text\ndurable repair=PASS\ndelete phase=PASS\nrebuild=PASS\nfull reconcile=PASS\ndeep audit=PASS\nhealth=healthy\nsource/projection head coherent\nbacklog=0\nDB integrity=PASS\nHistorical read/UI=PASS\nworker=active + enabled\nP0 incident=closed\n```\n\nPermanent repair boundaries remain:\n\n```text\nObservation mutation=FORBIDDEN\nmanual missing-row insertion=FORBIDDEN\nmanual healthy reset=FORBIDDEN\nserve divergent Projection=FORBIDDEN\n```\n\n### Post-recovery observation\n\nNormal production telemetry later showed a short:\n\n```text\nhealthy → stale → healthy\n```\n\nduring an active reconcile sweep, with `error_category=NULL`, no worker failure,\nsuccessful reconcile completion and final `healthy`.\n\nCurrent classification:\n\n```text\nOBSERVATION — transient healthy/stale/healthy during active reconcile sweep\n```\n\nThis is not currently a new incident or TASK regression. Monitor for repetition\nor user-visible read-gate/UI impact before opening separate analysis.\n', 'docs/operations-command-lessons-learned.md': '## 8A. Use the canonical systemd environment for Projection repair CLI\n\nProduction Projection worker configuration is supplied by systemd\n`EnvironmentFile=/etc/default/captive-portal`.\n\nDuring the 2026-09-11 Projection P0 recovery, running `repair-site` from an\nordinary interactive shell correctly failed closed with:\n\n```text\nTRAFFIC_PROJECTION_ENABLED must be true\n```\n\nNo DB mutation began.\n\nThe controlled repair was then run with the same effective runtime context as\n`traffic-projection.service`:\n\n```text\nUser=admin\nGroup=admin\nWorkingDirectory=/opt/CaptivePortal\nEnvironmentFile=/etc/default/captive-portal\n```\n\nPermanent operational rule:\n\n```text\nDo not assume an interactive shell has the production service environment.\nFor production CLI/repair that depends on service configuration, reproduce the\ncanonical systemd EnvironmentFile/User/Group/WorkingDirectory context.\n```\n\nNever print secret EnvironmentFile values while proving the context.\n', 'docs/project-inventory.md': '## Projection lifecycle P0 production state\n\n```text\nTASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01\n= CLOSED / PRODUCTION ACCEPTANCE PASS\n\nPR #111=MERGED\nproduction HEAD=7472d67274ea5aaea2a20df6b613b78d5bb70f42\nproduction tree=3950df6d400049ed16a823032c6740396cd61137\n\nprojection_version=historical_traffic_projection.v1\nversion_status=active\nSite health=healthy\nbacklog_cycle_count=0\n\ntraffic-projection.service=active + enabled\ncaptive-portal.service=active\nHistorical Traffic read surface=restored\n```\n\nSource authority remains:\n\n```text\nobservations.sqlite3 = authoritative\ntraffic_projection.sqlite3 = derived / rebuildable\n```\n\nThe prior `repair/rebuild HOLD` and Projection `STOPPED + DISABLED / CONTAINED`\nstate is retained only in incident chronology.\n\nForensic recovery evidence is outside the repository at:\n\n```text\n/home/admin/captivportal-recovery/projection-incident-20260911-112820\n```\n', 'docs/testing.md': '### Latest Projection lifecycle P0 acceptance — TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01\n\nArtifact identity:\n\n```text\nbaseline=ff39fe888c53361a7c65a034eaddb0ce92cc4a12\naccepted PR head=a0dc02d5ae0ff16c250cf46a7e7a610c24e6f433\naccepted tree=3950df6d400049ed16a823032c6740396cd61137\nPR #111=MERGED\nmerge / production=7472d67274ea5aaea2a20df6b613b78d5bb70f42\n```\n\nPre-publication acceptance:\n\n```text\nSource Review=PASS\nWindows Central Full V6=PASS\nstrict regressions=0\nLinux targeted=132 PASS\nLinux full=3154 PASS, 1 SKIP\n3 known baseline/environment failures reproduced on clean base\ncandidate-specific regressions=0\n```\n\nProduction recovery acceptance:\n\n```text\nforensic preflight/backup=PASS\nexact deployed artifact identity=PASS\nfirst durable repair quantum=PASS\npersisted repair continuation=PASS\nbounded delete phase=PASS\nrebuild=PASS\nfull reconcile=PASS\ndeep audit=PASS\nsource/projection head coherence=PASS\nbacklog=0\nDB quick_check=ok\nProjection health=healthy\nHistorical Web panels=PASS\nworker active=PASS\nworker enabled/autostart=PASS\n```\n\nFinal Site sample:\n\n```text\nprojection_revision=123634\nstatus=healthy\nlast_error_category=NULL\nprojection_head_utc=2026-09-11T13:18:00.739Z\nsource_head_utc=2026-09-11T13:18:00.739Z\nlast_full_reconcile_completed_at=2026-09-11T13:17:46.393Z\nlast_deep_audit_at=2026-09-11T13:17:46.393Z\nbacklog_cycle_count=0\n```\n\nOwner manual Web verification proved the restored path:\n\n```text\nObservation\n→ Traffic Projection\n→ Historical read service\n→ Web UI panels\n```\n\nFinal verdict:\n\n```text\nP0 INCIDENT=CLOSED\nPRODUCTION ACCEPTANCE=PASS\n```\n\nNon-blocking telemetry observation:\n\n```text\nhealthy → stale → healthy\nduring active reconcile sweep\n```\n\nWith no error category, no worker failure and final healthy state, this remains\nan observation only, not a regression/incident.\n'}

def run_text(args, cwd, check=True):
    p = subprocess.run(
        args, cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        encoding="utf-8",
        errors="replace",
    )
    if check and p.returncode != 0:
        if p.stdout:
            print(p.stdout, end="")
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")
    return p.stdout or ""

def run_pass(args, cwd):
    p = subprocess.run(args, cwd=cwd)
    if p.returncode != 0:
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")

def norm(s):
    return s.replace("\r\n", "\n").replace("\r", "\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(norm(text), encoding="utf-8", newline="\n")

def status_paths(repo):
    out = run_text(["git","status","--porcelain","--untracked-files=all"], repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def replace_regex_once(text, pattern, replacement, *, flags=0, label="regex"):
    rx = re.compile(pattern, flags)
    matches = list(rx.finditer(text))
    if len(matches) != 1:
        raise SystemExit(f"STOP: {label} matched {len(matches)} times")
    return rx.sub(replacement, text, count=1)

def insert_before_once(text, anchor, block, *, label):
    if text.count(anchor) != 1:
        raise SystemExit(f"STOP: {label} anchor matched {text.count(anchor)} times")
    marker = block.splitlines()[0].strip()
    if marker and marker in text:
        raise SystemExit(f"STOP: {label} already appears applied")
    return text.replace(anchor, block.rstrip() + "\n\n" + anchor, 1)

def update_common_header(path, text):
    # Date
    if re.search(r"(?m)^Updated: \d{4}-\d{2}-\d{2}$", text):
        text = replace_regex_once(
            text, r"(?m)^Updated: \d{4}-\d{2}-\d{2}$",
            "Updated: 2026-09-11", label=f"{path}: Updated"
        )

    header_rules = [
        (r"(?m)^Current-state implementation baseline: `main@[0-9a-f]{40}`$",
         f"Current-state implementation baseline: `main@{BASE}`"),
        (r"(?m)^Current implementation tree: `[0-9a-f]{{40}}`$",
         f"Current implementation tree: `{TREE}`"),
        (r"(?m)^Runtime implementation baseline: `main@[0-9a-f]{40}`$",
         f"Runtime implementation baseline: `main@{BASE}`"),
        (r"(?m)^Runtime tree: `[0-9a-f]{{40}}`$",
         f"Runtime tree: `{TREE}`"),
        (r"(?m)^Baseline: `main@[0-9a-f]{40}`$",
         f"Baseline: `main@{BASE}`"),
        (r"(?m)^Current repository implementation baseline: `main@[0-9a-f]{40}`$",
         f"Current repository implementation baseline: `main@{BASE}`"),
        (r"(?m)^Confirmed production deployed HEAD: `[0-9a-f]{{40}}`$",
         f"Confirmed production deployed HEAD: `{BASE}`"),
        (r"(?m)^Confirmed production tree: `[0-9a-f]{{40}}`$",
         f"Confirmed production tree: `{TREE}`"),
        (r"(?m)^Repository implementation baseline: `main@[0-9a-f]{40}`$",
         f"Repository implementation baseline: `main@{BASE}`"),
        (r"(?m)^Repository tree: `[0-9a-f]{{40}}`$",
         f"Repository tree: `{TREE}`"),
        (r"(?m)^Production deployed HEAD: `[0-9a-f]{{40}}`$",
         f"Production deployed HEAD: `{BASE}`"),
        (r"(?m)^Production tree: `[0-9a-f]{{40}}`$",
         f"Production tree: `{TREE}`"),
        (r"(?m)^Documentation/current-state implementation baseline: `main@[0-9a-f]{40}`$",
         f"Documentation/current-state implementation baseline: `main@{BASE}`"),
    ]
    for pattern, replacement in header_rules:
        if re.search(pattern, text):
            text = replace_regex_once(
                text, pattern, replacement, label=f"{path}: header field"
            )
    return text

def update_readme_table(text):
    labels = {
        "Repository implementation checkpoint": f"`main@{BASE}`",
        "Repository tree": f"`{TREE}`",
        "Production deployed HEAD": f"`{BASE}`",
        "Production tree": f"`{TREE}`",
    }
    for label, value in labels.items():
        pattern = rf"(?m)^\| {re.escape(label)} \| .* \|$"
        text = replace_regex_once(
            text, pattern, f"| {label} | {value} |",
            label=f"README table {label}",
        )
    return text

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE", str(Path.home())))
            / "Downloads" / "CaptivPortal-KB-Work")
    ))
    ap.add_argument("--no-push", action="store_true")
    ns = ap.parse_args()
    repo = Path(ns.repo)

    print("Publisher: PROJECTION-LIFECYCLE-P0-KB-V2-2026-09-11")
    print("=== PRECHECK ===")

    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if status_paths(repo):
        print("Dirty paths:")
        for p in status_paths(repo):
            print(" ", p)
        raise SystemExit("STOP: worktree must be clean")

    run_pass(["git","fetch","origin","main"], repo)
    remote = run_text(["git","rev-parse","origin/main"],repo).strip()
    tree = run_text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:", remote)
    print("origin tree:", tree)
    if remote != BASE:
        raise SystemExit("STOP: origin/main moved; KB package must be rebound")
    if tree != TREE:
        raise SystemExit("STOP: origin/main tree mismatch")

    run_pass(["git","switch","main"],repo)
    run_pass(["git","merge","--ff-only","origin/main"],repo)
    if status_paths(repo):
        raise SystemExit("STOP: main not clean after fast-forward")

    remote_branch = run_text(
        ["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo
    ).strip()
    if remote_branch:
        raise SystemExit("STOP: remote publication branch already exists")

    local = run_text(["git","branch","--list",BRANCH],repo).strip()
    if local:
        local_sha = run_text(["git","rev-parse",BRANCH],repo).strip()
        if local_sha != BASE:
            raise SystemExit("STOP: existing local publication branch advanced")
        run_pass(["git","branch","-D",BRANCH],repo)

    run_pass(["git","switch","-c",BRANCH],repo)

    final_path = "docs/tasks/TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01-IMPLEMENTATION-READY-FINAL-R5.md"
    if (repo/final_path).exists():
        raise SystemExit("STOP: canonical FINAL-R5 record already exists; rebind instead of duplicating")

    print("=== APPLY PREPARED FROZEN RECONCILIATION ===")

    # README
    p = repo/"README.md"
    t = update_readme_table(read(p))
    if "| Traffic Projection lifecycle P0 |" in t:
        raise SystemExit("STOP: README Projection status already exists")
    anchor = "| Traffic Evidence | **TASK-TRAFFIC-09 — COMPLETED / PRODUCTION ACTIVE** |"
    if t.count(anchor) != 1:
        raise SystemExit("STOP: README Traffic Evidence row anchor mismatch")
    t = t.replace(
        anchor,
        anchor + "\n| Traffic Projection lifecycle P0 | **CLOSED / PRODUCTION ACCEPTANCE PASS** |",
        1,
    )
    t = insert_before_once(t, "# Architecture\n", BLOCKS["README.md"], label="README Projection closure")
    write(p,t)

    # README_RU
    p = repo/"README_RU.md"
    t = update_readme_table(read(p))
    if "| Traffic Projection lifecycle P0 |" in t:
        raise SystemExit("STOP: README_RU Projection status already exists")
    anchor = "| Traffic Evidence | **TASK-TRAFFIC-09 — COMPLETED / PRODUCTION ACTIVE** |"
    if t.count(anchor) != 1:
        raise SystemExit("STOP: README_RU Traffic Evidence row anchor mismatch")
    t = t.replace(
        anchor,
        anchor + "\n| Traffic Projection lifecycle P0 | **CLOSED / PRODUCTION ACCEPTANCE PASS** |",
        1,
    )
    t = insert_before_once(t, "# Архитектура\n", BLOCKS["README_RU.md"], label="README_RU Projection closure")
    write(p,t)

    # docs/README
    p = repo/"docs/README.md"
    t = update_common_header(str(p), read(p))
    t = replace_regex_once(
        t,
        r"(?m)^Current Traffic state at implementation baseline `main@[0-9a-f]{40}`:$",
        f"Current Traffic state at implementation baseline `main@{BASE}`:",
        label="docs/README Traffic baseline",
    )
    row = "| DEVICE-CARD-01 final production closure | `tasks/TASK-DEVICE-CARD-01-FINAL.md` |"
    newrow = "| Projection lifecycle P0 closure | `tasks/TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01-IMPLEMENTATION-READY-FINAL-R5.md` |"
    if newrow in t:
        raise SystemExit("STOP: docs/README Projection map row already exists")
    if t.count(row) != 1:
        raise SystemExit("STOP: docs/README map row anchor mismatch")
    t = t.replace(row, row + "\n" + newrow, 1)
    t = insert_before_once(t, "## Permanent promotion boundary\n", BLOCKS["docs/README.md"], label="docs/README Projection closure")
    write(p,t)

    # architecture
    p = repo/"docs/architecture.md"
    t = update_common_header(str(p), read(p))
    t = insert_before_once(t, "## 8. Admin Web\n", BLOCKS["docs/architecture.md"], label="architecture Projection closure")
    write(p,t)

    # configuration
    p = repo/"docs/configuration.md"
    t = update_common_header(str(p), read(p))
    t = insert_before_once(t, "### Pending Session Cleaner\n", BLOCKS["docs/configuration.md"], label="configuration Projection closure")
    write(p,t)

    # deployment
    p = repo/"docs/deployment.md"
    t = update_common_header(str(p), read(p))
    t = insert_before_once(t, "## Feature activation\n", BLOCKS["docs/deployment.md"], label="deployment Projection recovery")
    write(p,t)

    # module-index
    p = repo/"docs/module-index.md"
    t = update_common_header(str(p), read(p))
    t = insert_before_once(t, "## Next Traffic item\n", BLOCKS["docs/module-index.md"], label="module-index Projection closure")
    write(p,t)

    # traffic module
    p = repo/"docs/modules/traffic.md"
    t = update_common_header(str(p), read(p))
    t = insert_before_once(t, "## Historical request broker / admission\n", BLOCKS["docs/modules/traffic.md"], label="traffic Projection closure")
    write(p,t)

    # ops lessons
    p = repo/"docs/operations-command-lessons-learned.md"
    t = update_common_header(str(p), read(p))
    t = insert_before_once(t, "## 9. Permanent pre-action sequence\n", BLOCKS["docs/operations-command-lessons-learned.md"], label="ops Projection CLI lesson")
    write(p,t)

    # project inventory
    p = repo/"docs/project-inventory.md"
    t = update_common_header(str(p), read(p))
    # Runtime commit/tree if present.
    if re.search(r"(?m)^Runtime commit: `[0-9a-f]{40}`$", t):
        t = replace_regex_once(
            t, r"(?m)^Runtime commit: `[0-9a-f]{40}`$",
            f"Runtime commit: `{BASE}`", label="project-inventory runtime commit"
        )
    if re.search(r"(?m)^Runtime tree: `[0-9a-f]{40}`$", t):
        t = replace_regex_once(
            t, r"(?m)^Runtime tree: `[0-9a-f]{40}`$",
            f"Runtime tree: `{TREE}`", label="project-inventory runtime tree"
        )
    if re.search(r"(?m)^Commit source: .*$", t):
        t = replace_regex_once(
            t, r"(?m)^Commit source: .*$",
            "Commit source: merge PR #111 / Projection lifecycle P0 fix, 2026-09-11",
            label="project-inventory commit source"
        )
    t = insert_before_once(t, "## 13. Admin security facts\n", BLOCKS["docs/project-inventory.md"], label="inventory Projection closure")
    write(p,t)

    # testing
    p = repo/"docs/testing.md"
    t = update_common_header(str(p), read(p))
    t = insert_before_once(
        t,
        "### Latest Device acceptance evidence — TASK-DEVICE-CARD-01\n",
        BLOCKS["docs/testing.md"],
        label="testing Projection acceptance",
    )
    write(p,t)

    # canonical task record: same frozen-update record, now closed with full chronology
    write(repo/final_path, CLOSURE_RECORD.rstrip() + "\n")

    actual = status_paths(repo)
    expected = sorted(SCOPE)
    print("Changed files:")
    for pth in actual:
        print(" ",pth)
    if actual != expected:
        print("Expected:")
        for pth in expected:
            print(" ",pth)
        raise SystemExit("STOP: exact 12-file frozen-reconciliation scope mismatch")

    print("=== CANONICAL ASSERTIONS ===")
    checks = {
        final_path: [
            "RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE",
            "Historical milestone at this stage:",
            "production repair/rebuild=HOLD",
            "FINAL-R5 + FIX-1 accepted implementation",
            "projection_revision=123634",
            "traffic-projection.service=active + enabled",
            "OBSERVATION — transient healthy/stale/healthy during active reconcile sweep",
            "P0 INCIDENT=CLOSED",
        ],
        "docs/modules/traffic.md": [
            "FINAL-R5 + FIX-1",
            "Projection health=healthy",
            "OBSERVATION — transient healthy/stale/healthy during active reconcile sweep",
        ],
        "docs/deployment.md": [
            "/home/admin/captivportal-recovery/projection-incident-20260911-112820",
            "TRAFFIC_PROJECTION_ENABLED must be true",
            "traffic-projection.service=active + enabled",
        ],
        "docs/configuration.md": [
            "EnvironmentFile=/etc/default/captive-portal",
            "traffic-projection.service=active + enabled",
        ],
        "docs/operations-command-lessons-learned.md": [
            "Use the canonical systemd environment for Projection repair CLI",
            "TRAFFIC_PROJECTION_ENABLED must be true",
        ],
        "docs/testing.md": [
            "Linux targeted=132 PASS",
            "Linux full=3154 PASS, 1 SKIP",
            "P0 INCIDENT=CLOSED",
        ],
    }
    for path, needles in checks.items():
        text = read(repo/path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: missing canonical assertion in {path}: {needle}")

    # Old current-status wording may exist only inside the canonical historical chronology.
    for path in expected:
        if path == final_path:
            continue
        text = read(repo/path)
        bad = [
            "production repair/rebuild = HOLD",
            "Production Projection writer:** `STOPPED + DISABLED / CONTAINED`",
        ]
        for phrase in bad:
            if phrase in text:
                raise SystemExit(f"STOP: stale current containment wording remains in {path}: {phrase}")

    # Docs only.
    for pth in actual:
        if pth.startswith("app/") or pth.startswith("tests/") or pth == ".env.example":
            raise SystemExit(f"STOP: runtime/test scope detected: {pth}")

    run_pass(["git","diff","--check"],repo)

    print("PASS: exact 12-file frozen KB reconciliation scope")
    print("PASS: existing frozen update reused; no independent incident note")
    print("PASS: root-cause classification preserved")
    print("PASS: HOLD/contained state preserved as history only")
    print("PASS: FINAL-R5 + FIX-1 production closure current")
    print("PASS: forensic backup + canonical repair workflow")
    print("PASS: durable repair continuation / delete / rebuild / reconcile / audit")
    print("PASS: final healthy/head-coherent/backlog-zero state")
    print("PASS: worker active + enabled")
    print("PASS: Historical Web read path restored")
    print("PASS: transient stale recorded as observation, not regression")
    print("PASS: git diff --check")

    run_pass(["git","add","--"] + expected,repo)
    run_pass(["git","diff","--cached","--check"],repo)

    patch = Path(__file__).resolve().parent / "CaptivPortal_KB_PROJECTION_LIFECYCLE_P0_CLOSURE_2026-09-11.patch"
    with patch.open("wb") as fh:
        p = subprocess.run(
            ["git","diff","--cached","--binary","--"] + expected,
            cwd=repo, stdout=fh, stderr=subprocess.PIPE
        )
    if p.returncode != 0 or patch.stat().st_size <= 0:
        err = p.stderr.decode("utf-8", errors="replace")
        raise SystemExit(f"STOP: patch generation failed: {err}")

    if ns.no_push:
        print("NO-PUSH: staged only")
        print("Unified diff:",patch)
        return

    run_pass([
        "git","commit",
        "-m","docs: close Projection lifecycle P0 incident",
        "-m","Complete the previously frozen TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01 KB reconciliation: preserve containment history, record FINAL-R5 + FIX-1 acceptance, PR111 deploy, forensic recovery, durable repair continuation, final healthy proof, restored Historical Traffic, active+enabled worker, and transient stale observation."
    ],repo)
    commit = run_text(["git","rev-parse","HEAD"],repo).strip()

    if run_text(["git","status","--short","--untracked-files=all"],repo).strip():
        raise SystemExit("STOP: worktree not clean after docs commit")

    run_pass(["git","push","-u","origin",BRANCH],repo)

    body = f"""## Purpose

Publish the previously prepared/frozen Knowledge Base reconciliation for
TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01 after complete production
recovery and acceptance.

This is not a second independent incident note. The canonical FINAL-R5 record is
the same lifecycle record and preserves the former HOLD/containment stage as
history.

## Current truth

- root cause: RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE
- accepted implementation: FINAL-R5 + FIX-1
- PR #111: merged
- runtime / production artifact: {BASE}
- tree: {TREE}
- durable repair: PASS
- repair continuation: PASS
- rebuild/reconcile/deep audit: PASS
- Projection health: healthy
- backlog: 0
- Historical Traffic Web path: restored / PASS
- traffic-projection.service: active + enabled
- P0 incident: CLOSED
- production acceptance: PASS

## Preserved chronology

The prior states:
- production repair/rebuild = HOLD
- writer STOPPED + DISABLED / CONTAINED

remain only as historical containment evidence.

## Non-blocking observation

A transient healthy → stale → healthy transition during active reconcile sweep
is documented as observation only, not a regression/incident.

## Scope

- exactly 12 canonical docs
- app code changed: NO
- tests changed: NO
- runtime config changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""
    pr = run_text([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main",
        "--head",BRANCH,
        "--title","Docs: close Projection lifecycle P0 incident",
        "--body",body,
        "--draft",
    ],repo).strip()

    print("=== FINAL ===")
    print("Branch:",BRANCH)
    print("Commit:",commit)
    print("Draft PR:",pr)
    print("Changed files: 12")
    print("Application code changed: NO")
    print("Tests changed: NO")
    print("Runtime config changed: NO")
    print("Production changed: NO")
    print("Merge performed: NO")
    print("Unified diff:",patch)

if __name__ == "__main__":
    main()
