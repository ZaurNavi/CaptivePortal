# Projection lifecycle P0 KB — V3 Resume

V2 stopped after applying the exact 12-file reconciliation.

Root cause of publisher stop:

```text
docs/modules/traffic.md contains canonical:
health=healthy

V2 self-check incorrectly expected:
Projection health=healthy
```

No commit, push or PR was performed.

V3:
- requires exact failed-V2 branch/HEAD/main/tree;
- requires exact 12-file working-tree scope and no staged changes;
- confirms the self-check mismatch;
- removes the expected trailing whitespace from FINAL metadata lines 3-10;
- reruns canonical assertions;
- runs `git diff --check` and `git diff --cached --check`;
- commits, pushes and creates Draft PR.

Publisher SHA256:
`849b7e417a4ed48cab2421a6dbdea47d2632146fdf3dcbc98c5208a8aae4c6b7`
