from __future__ import annotations
import os, subprocess
from pathlib import Path

BASE='7472d67274ea5aaea2a20df6b613b78d5bb70f42'
TREE='3950df6d400049ed16a823032c6740396cd61137'
BRANCH='docs/projection-lifecycle-p0-closure-kb-2026-09-11'
SCOPE=['README.md', 'README_RU.md', 'docs/README.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/traffic.md', 'docs/operations-command-lessons-learned.md', 'docs/project-inventory.md', 'docs/tasks/TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01-IMPLEMENTATION-READY-FINAL-R5.md', 'docs/testing.md']
FINAL='docs/tasks/TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01-IMPLEMENTATION-READY-FINAL-R5.md'
CHECKS={'docs/tasks/TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01-IMPLEMENTATION-READY-FINAL-R5.md': ['RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE', 'Historical milestone at this stage:', 'production repair/rebuild=HOLD', 'FINAL-R5 + FIX-1 accepted implementation', 'projection_revision=123634', 'traffic-projection.service=active + enabled', 'OBSERVATION — transient healthy/stale/healthy during active reconcile sweep', 'P0 INCIDENT=CLOSED'], 'docs/modules/traffic.md': ['FINAL-R5 + FIX-1', 'health=healthy', 'OBSERVATION — transient healthy/stale/healthy during active reconcile sweep'], 'docs/deployment.md': ['/home/admin/captivportal-recovery/projection-incident-20260911-112820', 'TRAFFIC_PROJECTION_ENABLED must be true', 'traffic-projection.service=active + enabled'], 'docs/configuration.md': ['EnvironmentFile=/etc/default/captive-portal', 'traffic-projection.service=active + enabled'], 'docs/operations-command-lessons-learned.md': ['Use the canonical systemd environment for Projection repair CLI', 'TRAFFIC_PROJECTION_ENABLED must be true'], 'docs/testing.md': ['Linux targeted=132 PASS', 'Linux full=3154 PASS, 1 SKIP', 'P0 INCIDENT=CLOSED']}

def run_text(args,cwd,check=True):
    p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                     encoding="utf-8",errors="replace")
    if check and p.returncode != 0:
        if p.stdout: print(p.stdout,end="")
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")
    return p.stdout or ""

def run_pass(args,cwd):
    p=subprocess.run(args,cwd=cwd)
    if p.returncode != 0:
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")

def status_paths(repo):
    out=run_text(["git","status","--porcelain","--untracked-files=all"],repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def staged_paths(repo):
    out=run_text(["git","diff","--cached","--name-only","--"],repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def norm(s):
    return s.replace("\r\n","\n").replace("\r","\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def write(path,text):
    Path(path).write_text(norm(text),encoding="utf-8",newline="\n")

def main():
    repo=Path(os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) /
            "Downloads" / "CaptivPortal-KB-Work")
    ))
    print("Publisher: PROJECTION-LIFECYCLE-P0-KB-V3-RESUME-2026-09-11")
    print("=== RECOVERY PRECHECK ===")

    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if run_text(["git","branch","--show-current"],repo).strip()!=BRANCH:
        raise SystemExit("STOP: expected failed-V2 publication branch")
    if run_text(["git","rev-parse","HEAD"],repo).strip()!=BASE:
        raise SystemExit("STOP: failed-V2 branch HEAD moved")

    run_pass(["git","fetch","origin","main"],repo)
    remote=run_text(["git","rev-parse","origin/main"],repo).strip()
    tree=run_text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:",remote)
    print("origin tree:",tree)
    if remote!=BASE or tree!=TREE:
        raise SystemExit("STOP: origin/main moved or tree mismatch")

    rb=run_text(["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo).strip()
    if rb:
        raise SystemExit("STOP: remote publication branch already exists")

    actual=status_paths(repo)
    print("Working-tree files:")
    for p in actual: print(" ",p)
    if actual!=sorted(SCOPE):
        print("Expected:")
        for p in sorted(SCOPE): print(" ",p)
        raise SystemExit("STOP: failed-V2 scope is not exact 12-file reconciliation")
    if staged_paths(repo):
        raise SystemExit("STOP: V2 unexpectedly left staged changes")

    print("PASS: exact failed-V2 worktree state")
    print("=== VERIFY SELF-CHECK DEFECT ===")

    traffic=read(repo/"docs/modules/traffic.md")
    if "health=healthy" not in traffic:
        raise SystemExit("STOP: expected accepted health wording is missing")
    if "Projection health=healthy" in traffic:
        raise SystemExit("STOP: V2 state differs from the known self-check defect")
    print("PASS: V2 self-check defect confirmed (health=healthy is canonical text)")

    print("=== VERIFY + REPAIR TRAILING WHITESPACE ===")
    final=read(repo/FINAL)
    trailing=[i for i,line in enumerate(final.splitlines(),1)
              if line.endswith(" ") or line.endswith("\t")]
    if trailing != [3,4,5,6,7,8,9,10]:
        raise SystemExit(f"STOP: unexpected FINAL trailing-whitespace lines: {trailing}")
    fixed="\n".join(line.rstrip(" \t") for line in final.split("\n"))
    write(repo/FINAL,fixed)
    print("PASS: removed only expected FINAL metadata trailing whitespace")

    print("=== CANONICAL ASSERTIONS ===")
    for path,needles in CHECKS.items():
        text=read(repo/path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: missing canonical assertion in {path}: {needle}")

    # HOLD / containment wording is allowed only inside the canonical chronology record.
    for path in SCOPE:
        if path==FINAL:
            continue
        text=read(repo/path)
        for bad in [
            "production repair/rebuild = HOLD",
            "Production Projection writer:** `STOPPED + DISABLED / CONTAINED`",
        ]:
            if bad in text:
                raise SystemExit(f"STOP: stale current containment wording remains in {path}: {bad}")

    print("PASS: canonical content")
    print("PASS: HOLD/containment preserved as history only")

    run_pass(["git","diff","--check"],repo)
    print("PASS: git diff --check")

    run_pass(["git","add","--"]+sorted(SCOPE),repo)
    if staged_paths(repo)!=sorted(SCOPE):
        raise SystemExit("STOP: staged scope mismatch")
    run_pass(["git","diff","--cached","--check"],repo)
    print("PASS: exact staged 12-file scope")
    print("PASS: git diff --cached --check")

    patch=Path(__file__).resolve().parent/"CaptivPortal_KB_PROJECTION_LIFECYCLE_P0_CLOSURE_2026-09-11.patch"
    with patch.open("wb") as fh:
        p=subprocess.run(["git","diff","--cached","--binary","--"]+sorted(SCOPE),
                         cwd=repo,stdout=fh,stderr=subprocess.PIPE)
    if p.returncode!=0 or patch.stat().st_size<=0:
        err=p.stderr.decode("utf-8",errors="replace")
        raise SystemExit(f"STOP: patch generation failed: {err}")
    print("PASS: binary-safe patch written")

    print("=== COMMIT ===")
    run_pass([
        "git","commit",
        "-m","docs: close Projection lifecycle P0 incident",
        "-m","Complete the previously frozen TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01 KB reconciliation: preserve containment history, record FINAL-R5 + FIX-1 acceptance, PR111 deploy, forensic recovery, durable repair continuation, final healthy proof, restored Historical Traffic, active+enabled worker, and transient stale observation."
    ],repo)
    commit=run_text(["git","rev-parse","HEAD"],repo).strip()

    if run_text(["git","status","--short","--untracked-files=all"],repo).strip():
        raise SystemExit("STOP: worktree not clean after docs commit")

    print("=== PUSH ===")
    run_pass(["git","push","-u","origin",BRANCH],repo)

    print("=== CREATE DRAFT PR ===")
    body=f"""## Purpose

Publish the previously prepared/frozen Knowledge Base reconciliation for
TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01 after complete production
recovery and acceptance.

This is not a second independent incident note. The canonical FINAL-R5 record
preserves the former HOLD/containment stage as history.

## Current truth

- root cause: RETENTION CLEANUP / FROZEN RECONCILE WINDOW RACE
- accepted implementation: FINAL-R5 + FIX-1
- PR #111: merged/deployed
- production artifact: {BASE}
- tree: {TREE}
- durable repair/rebuild/reconcile/deep audit: PASS
- Projection health: healthy
- backlog: 0
- Historical Traffic: restored
- traffic-projection.service: active + enabled
- P0 incident: CLOSED
- production acceptance: PASS

## Scope

- exactly 12 canonical docs
- app code changed: NO
- tests changed: NO
- runtime config changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""
    pr=run_text([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main","--head",BRANCH,
        "--title","Docs: close Projection lifecycle P0 incident",
        "--body",body,"--draft"
    ],repo).strip()

    print("=== FINAL ===")
    print("Branch:",BRANCH)
    print("Commit:",commit)
    print("Draft PR:",pr)
    print("Changed files: 12")
    print("Application code changed: NO")
    print("Tests changed: NO")
    print("Runtime config changed: NO")
    print("Production changed: NO")
    print("Merge performed: NO")
    print("Unified diff:",patch)

if __name__=="__main__":
    main()
