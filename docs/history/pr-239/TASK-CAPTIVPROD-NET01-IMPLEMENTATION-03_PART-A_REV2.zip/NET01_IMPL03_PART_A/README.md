# TASK-CAPTIVPROD-NET01-IMPLEMENTATION-03 — Part A revision 2

**Architect review response:** ACCEPTED_WITH_CORRECTIONS → REV2 FOR INDEPENDENT REVIEW. **Part B HOLD / no Owner GO.**

All executable scripts here are offline *proposals*. They have **NOT** been installed or executed on production. Do not run firewall scripts or systemd units outside a separately approved maintenance window. The only activity involving `captiv-prod` while preparing REV2 was **read-only** Docker/image inspection. No Docker pull, up/down/recreate, network edit, iptables/nft edit, NPM config edit, Omada edit or Flask start occurred.

## Grounded network snapshot

- Host: `captiv-prod`, Ubuntu 22.04.5; Docker Engine 29.1.3, Compose 2.40.3.
- Docker network: `nginx-proxy-manager_default`, ID `627e7c1ca6d557e7522ed3a041f3f6173541fcf18570edd8c33da5ce82432697`.
- Bridge `br-627e7c1ca6d5`; subnet `172.18.0.0/16`, gateway `172.18.0.1`, IPv6 disabled in Docker network.
- NPM container `npm`: `172.18.0.2`, MAC `b2:fa:fc:bf:d5:bc`; sole Docker container attached to this network.
- Public NPM ports `192.168.0.99:80,81,443`; three existing Proxy Hosts remain unchanged; separate new Let's Encrypt certificate not assigned to a Proxy Host.
- Omada `jsvc` occupies TCP `*:8088`; TCP 18089 absent from current listeners. Proposed Flask `172.18.0.1:18089` remains unimplemented.
- Host IPv4 `INPUT ACCEPT`, IPv6 `INPUT ACCEPT`; Docker `DOCKER-USER` is under `FORWARD`, not the locally delivered `INPUT` path.

## Contents and change index

- `compose.current.yaml`, `compose.proposed.yaml`, `compose.diff` — unchanged relative to Rev1; proposed `external: true`, pinned IP/MAC only, **requires NPM recreate** to apply, maintenance window and backup/rollback.
- `firewall/net01-verify.py` — **P1 FIX**: exact canonical option/value MULTISET match for first IPv4 INPUT hook, first IPv6 deny, full dedicated two-rule chain. Only one optional `-m tcp` module pair is normalized away. Unknown/inverted/duplicated/narrowing matches fail; no blanket `attr()` substring matching. Sticky root-owned HOLD directory is required.
- `tests/test_guard_offline.py` — **P1 FIX**: 1 baseline PASS, 15 adversarial firewall fixtures HOLD; tests include extra IPv4 `-i`, `-s`, `-d`, IPv6 `-s ::1/128`, inversions, reorder, missing terminal REJECT, extra ACCEPT.
- `evidence/docker-image-identity.txt` — **P1** distinct observed fields and exact inspector methods; see below.
- `tests/test_identity_offline.py` — separate image manifest digest, local Docker image ID and container `.Image` checks; verifies simulated unequal OCI digest vs image ID is acceptable when attested identities agree.
- `firewall/net01-runtime-watchdog.py` — **P1** proposed root-only periodic guard; 2-second interval, 15-second per-check deadline; on drift/engine unavailability calls sticky-HOLD emergency stop.
- `firewall/net01-hold-and-stop.py` — root-only durable HOLD marker then `systemctl stop captive-portal.service` (narrow SIGKILL fallback only for this new unit).
- `firewall/net01-clear-hold-review-only.sh` — explicit manual clearance requires full verified identity+firewall, Flask stopped; NO automatic restart.
- `systemd/captiv-net01-watchdog.service`, `systemd/captiv-net01-failsafe.service` — proposed systemd runtime drift handling and last-resort failure response.
- `systemd/captiv-net01-firewall.service` — now provisions root-owned `/var/lib/captiv-net01` mode 0700; no ExecStop, no silent rule deletion.
- `systemd/captive-portal-net01.drop-in.conf` — proposed startup guard, firewall ordering, watchdog coupling; `Restart=no` to avoid unsafe retry loop on cold boot.
- `tests/test_runtime_offline.py` — pure mocked watchdog decisions, NO Docker/systemctl activity.
- `TEST_AND_ROLLBACK_PLAN.md` — P2 test sequence avoiding membership==1 conflict; startup/cold boot, HOLD clearance and rollback.
- `ARCHITECT_REPORT.txt` — formal revision 2 report; `MANIFEST.sha256` — deterministic content checksums, NOT an authenticity signature.

## P1 image identity: **three separately checked observations**

Current Compose uses the OCI `image@sha256:` reference. Read-only production commands observed:

1. `docker inspect npm` **Config.Image** = `jc21/nginx-proxy-manager:2.16.0@sha256:4393...f9594` (configured registry reference).
2. `docker inspect npm` **Image** = `sha256:4393...f9594` (image ID used by the running container).
3. `docker image inspect jc21/nginx-proxy-manager:2.16.0` **Id** = `sha256:4393...f9594`; **Descriptor.mediaType** = `application/vnd.oci.image.index.v1+json`, **Descriptor.digest** = `sha256:4393...f9594`, **RepoDigests** includes `jc21/nginx-proxy-manager@sha256:4393...f9594`.

These values **coincide for this Docker 29 image store**; they are NOT semantically assumed to be equal. The revised guard has separate `NPM_IMAGE_REF`, `NPM_MANIFEST_DIGEST`, `NPM_IMAGE_CONFIG_ID` and independently compares configured ref, container image ID, locally inspected image ID, RepoDigests and OCI Descriptor.digest. Future engines and image updates require re-attestation. `docker image inspect` is local/read-only; no pull.

## Runtime drift (P1) and limitations

1. Only after a distinct Owner GO: stage scripts root-owned and read-only to the app; enable separate firewall oneshot, watchdog and app dependencies; create root-owned 0700 state directory **before** guard runs.
2. `ExecStartPre` refuses activation when Docker or NPM unavailable, Docker identity mismatched, exact firewall state differs, or `/var/lib/captiv-net01/HOLD` is present.
3. The watchdog checks immediately after starting, and every 2 seconds thereafter. A guard run has a maximum process deadline of 15 seconds. Any mismatch, Docker command error/unavailability or timeout latches HOLD to durable storage, then stops **only** `captive-portal.service` with bounded escalation. Unexpected watchdog failure triggers the independent fail-safe via `OnFailure` once systemd start limits are exhausted.
4. Future app drop-in explicitly sets `Restart=no`; no automated reactivation during an incident. Operator restores Docker/firewall, confirms old NPM unaffected, stops Flask, manually runs reviewed `net01-clear-hold-review-only.sh` (guard `--all --ignore-hold` must PASS), then starts only the new Flask unit under separate approved procedure.
5. **Residual risk:** first listener-to-watchdog-start race, at least 2s detection interval, up to 15s guard timeout plus stop latency, and privileged root/Docker admin tampering. A periodic monitor is not an instantaneous proof of firewall enforcement. No promise of protection against hostile privileged local administrators. Backend also binds only `172.18.0.1`, NOT `0.0.0.0`.
6. Watchdog manual stop/service suppression is an operational bypass possibility; must be protected with unit ownership/operator policy and verified in Part B. Before publicly exposing new route, independent reviewer must accept residual risks or mandate a stronger prevention mechanism. A failed watchdog/latched HOLD stops ONLY the new Flask, not NPM, Omada or the old Portal.

## P2 startup/cold boot and negative tests

- Docker daemon active **does not** imply NPM is running. If NPM startup lags, identity validation fails and Flask stays **STOPPED**. With `Restart=no`, operator retries only after NPM and firewall identity pass. Never relax membership/address checks to recover from a boot race.
- Do **not** attach a temporary Docker container to the production NPM network: the guard deliberately enforces exactly one member and the watchdog would stop Flask. Instead, same-bridge unapproved-source filtering may be tested in an explicitly authorized test window with a carefully isolated **temporary Linux network namespace/veth** attached to the bridge (no new Docker network membership). This is privileged and changes a live bridge temporarily: requires separate approval and cleanup. A disposable container in a **different** Docker network tests cross-network denial.
- If the architect requires an actual second container ON the NPM bridge for acceptance, this cannot be safely tested while enforcing membership==1. Use an isolated clone/test host or approve a separate maintenance test contract; do not disable the production guard or claim same-bridge-container PASS.

## Testing status

`python tests/test_guard_offline.py`, `python tests/test_identity_offline.py`, `python tests/test_runtime_offline.py` PASS. `bash -n` and Python compile checks PASS. Proposed Compose syntax PASS from Rev1; Compose text is unchanged. No runtime firewall installation, NPM recreate, startup, negative traffic, watchdog-driven stop or rollback was conducted. All Part B criteria remain `NOT_TESTED`.
