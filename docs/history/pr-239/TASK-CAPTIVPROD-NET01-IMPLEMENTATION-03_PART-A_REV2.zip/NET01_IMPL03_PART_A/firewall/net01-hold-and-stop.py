#!/usr/bin/env python3
"""REV2 PROPOSAL; intended root-only operation after explicit GO. NOT EXECUTED."""
import os
from pathlib import Path
import subprocess
import sys
import time

HOLD = Path('/var/lib/captiv-net01/HOLD')
UNIT = 'captive-portal.service'


def hold_and_stop(reason):
    """Sticky latch first, then stop ONLY the new Flask service.

    No global iptables flush, Docker/NPM restart, or old Portal mutation.
    The backend unit's ExecStartPre must always reject an existing HOLD.
    """
    marker_error = None
    try:
        HOLD.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        os.chmod(HOLD.parent, 0o700)
        fd = os.open(str(HOLD), os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600)
        with os.fdopen(fd, 'a') as f:
            f.write(f'{time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())} NET01={reason}\n')
            f.flush()
            os.fsync(f.fileno())
    except (OSError, PermissionError) as exc:
        # Even a marker failure MUST NOT prevent attempting to stop Flask.
        marker_error = exc
    try:
        subprocess.run(['systemctl', 'stop', UNIT], check=True, timeout=20)
    except (OSError, subprocess.TimeoutExpired, subprocess.CalledProcessError):
        # Narrow escalation: only the approved new Flask unit, not system-wide.
        subprocess.run(['systemctl', 'kill', '--signal=SIGKILL', UNIT],
                       check=True, timeout=10)
        subprocess.run(['systemctl', 'stop', UNIT], check=True, timeout=10)
    if subprocess.run(['systemctl', 'is-active', '--quiet', UNIT], timeout=5).returncode == 0:
        raise RuntimeError('HOLD: Flask still active after stop request')
    if marker_error is not None:
        raise RuntimeError('Flask stop requested but durable HOLD marker could not be recorded')
    print('NET01_STICKY_HOLD=SET BACKEND=STOPPED')


if __name__ == '__main__':
    try:
        hold_and_stop(sys.argv[1] if len(sys.argv) > 1 else 'UNSPECIFIED')
    except BaseException as exc:
        print(f'NET01_EMERGENCY_STOP_FAILED: {type(exc).__name__}', file=sys.stderr)
        sys.exit(1)
