#!/usr/bin/env bash
# REVIEW ONLY. Dedicated NET01 rollback, AFTER backend stopped.
set -euo pipefail
CHAIN=CAPTIV_FLASK_18089
# Refuse rule removal while any process still listens on TCP 18089.
if ss -H -lnt | awk '{print $4}' | grep -Eq '(^|:)18089$'; then
  echo 'STOP Flask/listener before firewall rollback' >&2
  exit 1
fi
if systemctl is-active --quiet captive-portal.service; then
  echo 'STOP captive-portal.service before firewall rollback' >&2
  exit 1
fi
# Exact matches only: leave other services, global policies and SSH intact.
iptables -w -D INPUT -p tcp --dport 18089 -j "$CHAIN"
iptables -w -F "$CHAIN"
iptables -w -X "$CHAIN"
ip6tables -w -D INPUT -p tcp --dport 18089 -j REJECT --reject-with tcp-reset
# Unit disablement/restore of original Compose is separate reviewed procedure.
