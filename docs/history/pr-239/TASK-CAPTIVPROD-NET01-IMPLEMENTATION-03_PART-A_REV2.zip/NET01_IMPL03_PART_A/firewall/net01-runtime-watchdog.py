#!/usr/bin/env python3
"""REV2 proposed runtime watchdog; no runtime exposure tests done in Part A.

A detection interval is unavoidable. Privileged firewall replacement may expose
backend between checks; this does not replace network isolation.
"""
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/usr/local/libexec/captiv-net01')
GUARD = ROOT / 'net01-verify.py'
EMERGENCY = ROOT / 'net01-hold-and-stop.py'
HOLD = Path('/var/lib/captiv-net01/HOLD')
INTERVAL_SEC = 2
GUARD_TIMEOUT_SEC = 15


def iteration(run=subprocess.run):
    if HOLD.exists():
        return 'sticky-hold-present'
    try:
        result = run(['/usr/bin/python3', str(GUARD), '--all'],
                     check=False, capture_output=True, text=True,
                     timeout=GUARD_TIMEOUT_SEC)
    except (OSError, subprocess.TimeoutExpired):
        return 'guard-unavailable-or-timeout'
    return None if result.returncode == 0 else 'guard-reported-drift'


def main():
    # First check immediately; do not wait for first interval.
    while True:
        why = iteration()
        if why is not None:
            # Use a single fail-safe code path for guard/identity/Docker failure.
            try:
                subprocess.run(['/usr/bin/python3', str(EMERGENCY), why],
                               check=True, timeout=40)
            except (OSError, subprocess.TimeoutExpired, subprocess.CalledProcessError):
                print('NET01_WATCHDOG_FAILSAFE_ERROR', file=sys.stderr)
                return 1  # systemd OnFailure invokes independent failsafe
            return 0       # Sticky HOLD; do not auto-restart watchdog or Flask
        time.sleep(INTERVAL_SEC)


if __name__ == '__main__':
    sys.exit(main())
