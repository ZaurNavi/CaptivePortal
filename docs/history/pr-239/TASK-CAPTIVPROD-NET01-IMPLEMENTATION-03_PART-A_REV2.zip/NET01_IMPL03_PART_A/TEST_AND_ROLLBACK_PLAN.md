# NET01 Implementation-03 Part A REV2 — TEST / BOOT / HOLD / ROLLBACK

**REVIEW ONLY.** All production modifications remain prohibited under this revision. No commands below were run on production except documented read-only observations.

## Gate dependencies

1. Architect independently accepts Rev2 guard image, systemd and watchdog design.
2. Owner issues a separate explicit **Part B GO**, including NPM maintenance window and rollback authorization.
3. Accepted Git release enables HOST/PORT deployment config, correct CAPPORT FQDN `captivprod-navi.duckdns.org` and verified new Omada Site ID/CIDRs; exact SHA/tree, unit, permissions and credential-handling approved.
4. Current Docker network ID/bridge/gateway, NPM IP/MAC, container image ID, local OCI descriptor and current NPM backups rechecked. No automatic Docker network rebuild.
5. Establish new root-owned NET01 HOLD directory, immutable reviewed scripts and firewall service; Flask remains STOPPED.

## Boot and activation sequence (future only)

1. Docker daemon reaches active state; NPM container must actually be **running** and match approved network/image endpoints. `After=docker.service` alone is insufficient.
2. `captiv-net01-firewall.service` creates `/var/lib/captiv-net01` (StateDirectory, root-owned 0700), runs the identity guard, installs catch-all DENY before inserting narrow ALLOW, inserts IPv4/IPv6 INPUT hooks, then runs `net01-verify.py --all` (strict canonical check). Existing `INPUT ACCEPT`, old Omada guard and `DOCKER-USER` unaffected.
3. Only if firewall and identity PASS, the new Flask service passes `ExecStartPre net01-verify.py --all`; bind only `172.18.0.1:18089`, single process. Set `Restart=no` through reviewed drop-in while staged.
4. App unit pulls in `captiv-net01-watchdog.service`; monitor checks immediately and then every 2 seconds. Confirm watchdog service is actually active; otherwise STOP Flask and HOLD. The watchdog's `OnFailure` independently invokes `captiv-net01-failsafe.service` for repeated unexpected failures.
5. No new public Proxy Host until acceptance of all mandatory tests and **separate activation GO**.

### Cold boot scenario: Docker daemon started but NPM missing/delayed

`docker.service=active` does not satisfy Docker identity. If `docker inspect npm` fails, reports stopped container, wrong network or bridge, guard exits HOLD (75). Firewall service fails or remains unverified; Flask fails `Requires/After` or `ExecStartPre`. App `Restart=no` prevents restart loops. Operator must first repair/await NPM **without changing firewall identity assumptions**, check identity and firewall, resolve sticky HOLD if set, then explicitly start new Flask. No automatic fallback bind, no loosening membership==1. Cold-boot and restart sequencing are NOT_TESTED in Part A.

## Runtime drift design and response

- `net01-runtime-watchdog.py`: root-only child with 2-second poll interval, first probe immediately; verifies Docker network ID, IPAM, Linux bridge, sole NPM endpoint IP/MAC, full distinct image identities, and exact IPv4/IPv6 firewall. Guard subprocess timeout 15 seconds; Docker Engine outage/error is HOLD, not tolerated.
- Any drift or timeout invokes `net01-hold-and-stop.py`: append durable root-owned `/var/lib/captiv-net01/HOLD` with timestamp/reason (no secrets), `systemctl stop captive-portal.service`; if graceful stop fails, scope SIGKILL to **that unit only**. Guard checks HOLD marker in `ExecStartPre`, so even if app is started again inadvertently, it fails. Systemd override `Restart=no` prevents runtime restart loops.
- If watchdog itself repeatedly crashes, systemd `OnFailure=captiv-net01-failsafe.service` initiates the same STOP+HOLD. Manually stopping/disabling the watchdog is an operational bypass to control in review/permissions; not equivalent to cryptographic prevention.
- Recovery: independent admin approval; new Flask STOPPED, NPM and firewall identity restored, `net01-verify.py --all --ignore-hold` PASS; reviewed manual clear script removes the latch; operator then explicitly starts app and verifies watchdog is active before any public route may be enabled.
- Residual risk: detection may take approximately a 2-second interval + up to 15-second subprocess deadline + stop latency, plus possible startup-to-watchdog gap. Privileged host admin can bypass both firewall and watchdog. Do NOT claim instantaneous fail-closed enforcement against root adversary. For stronger guarantee Architect can request non-root architectural isolation or continuous kernel enforcement and revised threat model.

## Proposed positive and negative acceptance (Part B only)

- NPM container `172.18.0.2` → `172.18.0.1:18089`: permitted, identify **Flask**, not Omada `*:8088`. Synthetic, non-sensitive URL; controlled 4xx without Omada context is acceptable. Verify `ss` bind exactly `172.18.0.1:18089`.
- LAN `192.168.0.0/24` via management interface → backend: denied; Guest VLAN20 → backend: denied (Owner-controlled client only); external WAN → backend: denied; unrelated Docker bridge/container → backend: denied; IPv6 18089 → denied.
- **Same Docker bridge, unauthorized source:** DO NOT attach another Docker container to NPM network while guard checks `membership==1`. Instead, if separately authorized, use a temporary named Linux network namespace and veth connected to NPM bridge, with a different test IP/MAC. This tests Linux INPUT source filtering without Docker membership changes. Explicitly approve namespace/veth lifecycle; avoid conflicting addresses; clean up in `finally`/controlled rollback, do not leave unauthorized interfaces. A namespace is NOT proof of a real second Docker container; that scenario remains NOT_TESTED unless separately tested on an isolated clone.
- Test `iptables -vnL` counters for accepted NPM and denied non-NPM. Re-run `net01-verify.py --all` after each negative test, ensure watchdog remains active and Flask stable. No deliberate firewall fault injection during public serving.
- Test unexpected drift **only in isolated staging** or a separately authorized non-public maintenance window; simulate guard fixture failures locally as in Part A. Do not remove live first INPUT hook to test watchdog while public app is enabled.
- Test `Host`, `X-Forwarded-For`, `X-Forwarded-Host`, `X-Forwarded-Proto`, `X-Forwarded-Port`, trusted single hop and original client IP; verify NPM overwrites spoofable headers and prevents sensitive query data in logs. Separate TLS/SNI and cert verification.
- Verify old Portal (`captivportal-navi.duckdns.org`), Nextcloud, VPN, old Omada, NPM Admin :81 isolation and SSH unchanged.
- Reboot and controlled Compose recreate **only** in approved downtime, verify stable network object ID and firewall persistence prior to Flask restart. Unexpected object recreation/new IP/MAC/image refuses start.

## Precise rollback hierarchy (after separate GO)

1. STOP **new** `captive-portal.service` only, verify TCP 18089 no listener; do not change old Portal/Omada or global firewall policy. Disable newly created public Proxy Host only if it was separately authorized and created later.
2. Stop/disable NET01 watchdog + NET01 firewall oneshot for next boot **after** Flask is stopped. Guard marker remains latched until operator-approved restoration. Stopping the firewall unit does NOT remove INPUT hooks by default.
3. Run `net01-fw-rollback.sh` only if its exact expected rules match (non-matching state => HOLD/manual security review); remove new IPv4 hook, dedicated chain and new IPv6 hook, never flush INPUT or Docker chains. Recheck SSH/NPM/Omada.
4. If NPM Compose network endpoint change caused breakage, restore `compose.current.yaml`, and perform separately approved controlled NPM recreate only if needed. Never `docker compose down` or `docker network rm`. Confirm original network object ID persists. Validate old Proxy Hosts and cert fingerprints.
5. Record NPM backup location, observed Docker and firewall state, owner decision, and post-rollback HTTP/TLS checks. Source SQLite backup must be online/application-consistent.

## Static evidence completed in Part A Revision 2

- Strict firewall grammar fixtures: 1 positive PASS, 15 negative HOLD.
- Docker identity and image digest separation fixtures: 2 positive PASS (including unequal-digest simulation), 8 negative HOLD.
- Runtime watchdog decision tests: 1 positive PASS, 4 negative/timeout/HOLD.
- Syntax: Python compile PASS, Bash `-n` PASS.
- Compose syntax: unchanged from Rev1, validated on host with Compose v2.40.3 `config --quiet` exit 0. **No runtime recreate trial**.
- Observed `docker image inspect` and `docker inspect npm`: independent identities detailed in `evidence/docker-image-identity.txt`.
- Production firewall installed/removed: NOT_TESTED. Watchdog service started/failed-over: NOT_TESTED. Cold boot: NOT_TESTED. Complete real positive/negative connectivity: NOT_TESTED. Rollback: NOT_TESTED.
