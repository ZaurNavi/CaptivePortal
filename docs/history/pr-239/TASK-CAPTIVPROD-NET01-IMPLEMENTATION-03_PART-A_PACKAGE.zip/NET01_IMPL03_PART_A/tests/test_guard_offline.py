"""Local pure-fixture tests; never reach Docker or mutate firewall."""
import importlib.util
import json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('net01_guard',root/'firewall'/'net01-verify.py')
g=importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)

ip4in='''-P INPUT ACCEPT
-A INPUT -p tcp -m tcp --dport 18089 -j CAPTIV_FLASK_18089
-A INPUT -d 192.168.0.99/32 -i enp2s0 -j CAPTIV_OMADA_GUARD
'''
chain='''-N CAPTIV_FLASK_18089
-A CAPTIV_FLASK_18089 -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
-A CAPTIV_FLASK_18089 -j REJECT --reject-with tcp-reset
'''
ip6='''-P INPUT ACCEPT
-A INPUT -p tcp -m tcp --dport 18089 -j REJECT --reject-with tcp-reset
'''

def fake(*args):
    if args[0] == 'iptables':
        return {'INPUT':ip4in, 'CAPTIV_FLASK_18089':chain}[args[-1]]
    if args[0] == 'ip6tables':
        return ip6
    raise AssertionError(args)

g.command=fake
g.check_firewall()

for label, bad in [
    ('unprotected_first_rule', ip4in.replace('-A INPUT -p tcp -m tcp --dport 18089 -j CAPTIV_FLASK_18089\n','')),
    ('reordered_input',ip4in.replace('-A INPUT -d 192.168.0.99/32 -i enp2s0 -j CAPTIV_OMADA_GUARD\n','-A INPUT -j ACCEPT\n')),
]:
    original=ip4in
    if label == 'reordered_input':
        bad='-P INPUT ACCEPT\n-A INPUT -j ACCEPT\n-A INPUT -p tcp -m tcp --dport 18089 -j CAPTIV_FLASK_18089\n'
    g.command=lambda *args, bad=bad: bad if args[0]=='iptables' and args[-1]=='INPUT' else fake(*args)
    try:
        g.check_firewall()
        raise AssertionError('Expected HOLD for '+label)
    except RuntimeError:
        pass

g.command=fake
bad_chain=chain.replace('b2:fa:fc:bf:d5:bc','11:22:33:44:55:66')
g.command=lambda *args: bad_chain if args[0]=='iptables' and args[-1]=='CAPTIV_FLASK_18089' else fake(*args)
try:
    g.check_firewall()
    raise AssertionError('Expected MAC mismatch HOLD')
except RuntimeError:
    pass
print('OFFLINE_GUARD_TESTS=PASS (positive fixture and 3 fail-closed negatives)')
