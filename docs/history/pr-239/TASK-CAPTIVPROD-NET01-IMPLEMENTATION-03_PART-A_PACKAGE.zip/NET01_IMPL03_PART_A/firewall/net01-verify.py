#!/usr/bin/env python3
"""Read-only fail-closed guard; Part A proposal, NOT deployed."""
import argparse
import json
import shlex
import subprocess
import sys

BRIDGE = 'br-627e7c1ca6d5'
NETWORK = 'nginx-proxy-manager_default'
NETWORK_ID = '627e7c1ca6d557e7522ed3a041f3f6173541fcf18570edd8c33da5ce82432697'
GATEWAY = '172.18.0.1'
NETWORK_CIDR = '172.18.0.0/16'
NPM_IP = '172.18.0.2'
NPM_MAC = 'b2:fa:fc:bf:d5:bc'
NPM_IMAGE_ID = 'sha256:4393e642e233e5efd5adeb7f10918d4aaea71c9ed875b94190273fc8e87f9594'
CHAIN = 'CAPTIV_FLASK_18089'
PORT = '18089'


def command(*argv):
    p = subprocess.run(argv, text=True, capture_output=True, timeout=12)
    if p.returncode:
        raise RuntimeError(f'failed: {argv[0]} (rc={p.returncode})')
    return p.stdout


def must(test, message):
    if not test:
        raise RuntimeError(message)


def attr(tokens, key, value):
    return any(tokens[i] == key and tokens[i + 1] == value
               for i in range(len(tokens) - 1))


def rules(chain, program='iptables'):
    return [shlex.split(s) for s in command(program, '-w', '-S', chain).splitlines()
            if s.startswith('-A ')]


def check_identity():
    net = json.loads(command('docker', 'network', 'inspect', NETWORK))[0]
    must(net['Id'] == NETWORK_ID, 'Docker network ID changed; refuse start')
    must(net['Driver'] == 'bridge' and not net['EnableIPv6'], 'Docker network driver / IPv6 mismatch')
    must(len(net['IPAM']['Config']) == 1, 'Unexpected Docker IPAM layout')
    ipam = net['IPAM']['Config'][0]
    must(ipam['Subnet'] == NETWORK_CIDR and ipam['Gateway'] == GATEWAY,
         'Docker subnet/gateway changed')
    members = list(net['Containers'].values())
    must(len(members) == 1 and members[0]['Name'] == 'npm',
         'Unexpected member of NPM network')
    must(members[0]['IPv4Address'] == NPM_IP + '/16', 'NPM IPv4 in network changed')
    must(members[0]['MacAddress'].lower() == NPM_MAC, 'NPM MAC in network changed')
    npm = json.loads(command('docker', 'inspect', 'npm'))[0]
    must(npm['State']['Running'], 'NPM not running')
    must(npm['Image'] == NPM_IMAGE_ID, 'NPM image changed')
    must(npm['Name'] == '/npm', 'Wrong container name')
    must(npm['Id'] in net['Containers'], 'NPM endpoint mismatch')
    endpoints = npm['NetworkSettings']['Networks']
    must(list(endpoints) == [NETWORK], 'NPM attached to unexpected networks')
    ep = endpoints[NETWORK]
    must(ep['NetworkID'] == NETWORK_ID and ep['Gateway'] == GATEWAY,
         'NPM endpoint network/gateway changed')
    must(ep['IPAddress'] == NPM_IP and ep['MacAddress'].lower() == NPM_MAC,
         'NPM endpoint identity changed')
    links = json.loads(command('ip', '-j', '-4', 'addr', 'show', 'dev', BRIDGE))
    must(len(links) == 1 and links[0].get('operstate') == 'UP',
         'Bridge absent or not UP')
    must(any(a.get('local') == GATEWAY and a.get('prefixlen') == 16
             for a in links[0]['addr_info']), 'Linux bridge address changed')
    print('DOCKER_IDENTITY=PASS')


def check_firewall():
    inp = rules('INPUT')
    must(len(inp) > 0, 'INPUT jump absent')
    first = inp[0]
    must(first[:2] == ['-A', 'INPUT'] and attr(first, '--dport', PORT)
         and attr(first, '-j', CHAIN) and attr(first, '-p', 'tcp'),
         'TCP 18089 hook not first in INPUT')
    must(sum(attr(r, '-j', CHAIN) for r in inp) == 1, 'Duplicate backend INPUT hooks')
    chain = rules(CHAIN)
    must(len(chain) == 2, 'Backend chain must contain exactly ALLOW and REJECT')
    a, deny = chain
    checks = [('-i', BRIDGE), ('-s', NPM_IP + '/32'), ('-d', GATEWAY + '/32'),
              ('-p', 'tcp'), ('--dport', PORT), ('--mac-source', NPM_MAC),
              ('--ctstate', 'NEW,ESTABLISHED'), ('-j', 'ACCEPT')]
    must(all(attr(a, k, v) for k, v in checks), 'NPM allow rule mismatch')
    must(deny[:2] == ['-A', CHAIN] and attr(deny, '-j', 'REJECT') and
         attr(deny, '--reject-with', 'tcp-reset') and len(deny) == 6,
         'Nonterminal or noncatchall IPv4 deny')
    ipv6 = rules('INPUT', 'ip6tables')
    must(len(ipv6) > 0 and ipv6[0][:2] == ['-A', 'INPUT']
         and attr(ipv6[0], '-p', 'tcp') and attr(ipv6[0], '--dport', PORT)
         and attr(ipv6[0], '-j', 'REJECT'), 'IPv6 TCP 18089 deny is not first')
    print('FIREWALL_FAIL_CLOSED=PASS')


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--identity', action='store_true')
    p.add_argument('--all', action='store_true')
    args = p.parse_args()
    try:
        if not (args.identity or args.all):
            p.error('specify --identity or --all')
        check_identity()
        if args.all:
            check_firewall()
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.TimeoutExpired) as e:
        print('NET01_GUARD=HOLD: ' + str(e), file=sys.stderr)
        sys.exit(1)
