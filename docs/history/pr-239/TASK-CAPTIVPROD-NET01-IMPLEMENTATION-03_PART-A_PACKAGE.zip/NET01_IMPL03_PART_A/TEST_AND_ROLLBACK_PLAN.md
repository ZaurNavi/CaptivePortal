# NET-01: PART B execution and test model (NOT AUTHORIZED)

## Before implementation

1. Explicit Owner GO, Architect-approved reviewed Part A package and accepted Git SHA+tree for Flask `HOST/PORT`, CAPPORT FQDN, new Omada Site, guest CIDR; obtain independent review of firewall/rule persistence.
2. Maintenance window for possible NPM container recreate; snapshot and test backup of `/opt/nginx-proxy-manager/compose.yaml`, complete `/opt/nginx-proxy-manager/data`, `/opt/nginx-proxy-manager/letsencrypt`, existing firewall rules (`iptables-save`, `ip6tables-save`), network inspect, Omada state. Use approved online NPM backup, not a raw copy of live SQLite.
3. Pre-check HTTP status and certificate chains for `captivportal-navi.duckdns.org`, `navi-cloud.duckdns.org`, `vpn-navi.duckdns.org`, NPM :81 management restrictions, Docker/NPM uptime, SSH, new Omada 8043/8088. Do not change old services.
4. Stage all reviewed files as root-owned, non-writable by app, with appropriate permissions. Record SHA256 checksums, verify installation paths, and require a locked systemd activation sequence. NPM image digest in `net01-verify.py` must match approved running image; no unreviewed upgrades.

## Proposed order, only after GO

1. Verify preexisting Docker network ID **exactly** matches `627e...32697`; do not remove or rebuild network. Preflight live attach viability and maintenance rollback before applying Compose diff. Stage rollback Compose beside new one (not within NPM data).
2. Change only service networking in Compose; `docker compose -p nginx-proxy-manager -f /opt/nginx-proxy-manager/compose.yaml config --quiet` then authorized `up -d --no-deps npm` (likely causes NPM recreate), NEVER `down`. Verify same network ID, bridge, gateway, NPM IP, MAC, image, published ports, SSL certs, all old Proxy Hosts. If fails, restore original Compose with same existing network and re-run approved NPM recreate/rollback, not network removal.
3. Ensure Flask 18089 absent. Install `net01-verify.py`, firewall script, and systemd firewall unit, retaining previous NPM/Omada rule snapshot. Start `captiv-net01-firewall.service`: network identity must pass, INPUT first hook and IPv6 deny must be installed and `--all` PASS. If partial install fails, DO NOT start Flask; inspect safely while backend closed.
4. Deploy only approved Git SHA/tree; app unit `Requires/After/BindsTo=captiv-net01-firewall.service`; `ExecStartPre` checks `--all`; runtime env `HOST=172.18.0.1`, `PORT=18089` only if accepted code supports those vars. Bind strictly to bridge host address, single Flask process, not `0.0.0.0` or Docker container `127.0.0.1`. Verify `ss -lntp` listener exactly `172.18.0.1:18089`, and no 8088 conflict.
5. Positive test FROM NPM container: `docker exec npm curl --noproxy '*' -sS -D - -o /dev/null --max-time 5 http://172.18.0.1:18089/` (application may return controlled 4xx without Omada query). Check that HTTP response identifies new Flask, not Omada. No user MAC or tokens in test.
6. Negative TCP tests: dedicated authorized disposable test container on same bridge with different IP/MAC (only in separate window, account for current non-attachable setting); container on other Docker bridge; LAN host to both `172.18.0.1:18089` and `192.168.0.99:18089`; owner-controlled guest client VLAN20; independent WAN test. Require all denied. If test container cannot safely be attached, HOLD the negative test; don't claim PASS. Verify `iptables -vnL` counter increments for allowed and denied packets. Verify IPv6 denied. SSH, Omada and existing proxy routes must remain PASS.
7. Spoofed `X-Forwarded-For`, `X-Forwarded-Host`, `X-Forwarded-Proto`, `X-Forwarded-Port` probes with synthetic canary IP and HTTP path; proxy must overwrite untrusted incoming values at trusted NPM hop, Flask `ProxyFix` must trust exactly the approved hop. Validate scheme `https`, forwarded host `captivprod-navi.duckdns.org`, port 443, URI/path/query handling, original client IP (not NPM IP), log privacy, no synthetic canary leaks in persistent access logs.
8. Only after all gates PASS may Architect/Owner separately authorize the new NPM Proxy Host with existing isolated certificate. Before that, `NEW_PROXY_HOST=NOT_CREATED` and public TLS for new SNI can remain unserved.
9. Reboot/recreate simulation is **separate explicitly scheduled window**: include Docker restart, NPM reattachment, firewall persistence, fail-closed when Docker identity is deliberately mismatched under isolated nonproduction conditions, and positive/negative recheck. Do not alter live NPM IP/MAC to force a test.

## Persistence strategy

- The independent `captiv-net01-firewall.service` is `Type=oneshot`, `RemainAfterExit=yes`, `Requires/After=docker.service`; only the pre-approved firewall rules are installed. It has NO `ExecStop`, so stopping a unit does not silently remove rules. It does not replace firewall administration for the existing NPM/Omada services.
- Future `captive-portal.service` depends on this service. A failing `net01-verify.py --all` in `ExecStartPre` prevents Flask from starting. If Docker's restart policy has not yet brought NPM up when guard runs, backend stays stopped. Require documented retry when NPM ready, NOT a permissive bypass.
- A privileged operator could remove the INPUT hook after Flask starts. To meet stronger runtime invariants, separately approve a monitoring mechanism that stops Flask on observed firewall/identity drift; monitoring alone has a detection interval and is not an instantaneous enforcement guarantee. No such agent is installed during Part A.

## Rollback (future authorized change only)

1. Stop new Flask unit; prove TCP 18089 no longer listening; remove/disable new public Proxy Host **only if later separately created and approved** (not present today). Preserve old Proxy Hosts and old Omada.
2. Run dedicated `net01-fw-rollback.sh` to remove ONLY new INPUT hook, new custom chain and IPv6 reject. Existing INPUT policy, CAPTIV_OMADA_GUARD, DOCKER-USER, SSH rules, NPM Admin firewall are untouched. If any rule mismatch, HOLD and use reviewed manual rollback; do not flush entire firewall.
3. If Compose networking change caused trouble, restore `compose.current.yaml` and use controlled `docker compose -p nginx-proxy-manager -f ... up -d --no-deps npm`; inspect and preserve same **existing** network object. Do not use `docker compose down` or `docker network rm`.
4. Verify old portal HTTPS, cert fingerprints, Hestia, Nextcloud, VPN, NPM :81 restrictions, Omada, SSH and backup consistency. Record test evidence and report to Owner/Architect.

## Verification status at Part A

- Compose proposed syntax: **PASS**, `docker compose -p nginx-proxy-manager -f - config --quiet` exit 0 (stdin stream on actual host).
- Proposed Docker attach/recreate/rollback: **NOT_TESTED**.
- Firewall applied/packet behavior: **NOT_TESTED**.
- Startup gates/live Flask: **NOT_TESTED**.
- Old production has not been modified by this Part A; no new Proxy Host.
