# TASK-CAPTIVPROD-NET01-IMPLEMENTATION-03 / Part A only

**Status:** REVIEW-ONLY / UNAPPLIED. Owner GO for Part B not issued. Contains no tokens, API keys or environment secrets. DO NOT run the `firewall/` scripts against production until independent review and release approval.

## Factual live snapshot, 2026-10-14

- `captiv-prod` Ubuntu 22.04.5; NPM `jc21/nginx-proxy-manager:2.16.0` image locked by sha256.
- Docker Engine 29.1.3, Compose `2.40.3+ds1-0ubuntu1~22.04.1`.
- Existing Docker network ID `627e7c1ca6d557e7522ed3a041f3f6173541fcf18570edd8c33da5ce82432697`, name `nginx-proxy-manager_default`, bridge `br-627e7c1ca6d5`, subnet `172.18.0.0/16`, gateway `172.18.0.1`, no IPv6, only `npm` attached at IP `172.18.0.2`, MAC `b2:fa:fc:bf:d5:bc`.
- NPM published ports remain `192.168.0.99:80/81/443` and old proxy hosts untouched.
- `*:8088` owned by Omada `jsvc`. TCP 18089 not listening, no associated socket or published port when checked.
- Existing host IPv4 INPUT policy ACCEPT, custom `CAPTIV_OMADA_GUARD`; Docker `DOCKER-USER` is called from FORWARD, not host-local INPUT. Host IPv6 INPUT policy ACCEPT. Existing `captiv-npm-admin-firewall.service` and `captiv-omada-guard.service` untouched.
- NPM certificate `captivprod-navi.duckdns.org` created independently and NOT USED; new Proxy Host NOT CREATED.

## Package contents

- `compose.current.yaml`: observed production Compose, sanitized (no secrets present).
- `compose.proposed.yaml`: exact minimal proposed replacement, **NOT deployed**.
- `compose.diff`: exact unified diff against observed production Compose.
- `firewall/net01-verify.py`: read-only strict Docker identity and firewall guard; expected network ID, image ID, bridge, endpoint, IP and MAC are pinned.
- `firewall/net01-fw-install.sh`: candidate ordered, fail-closed rules. This script **mutates firewall if executed**. Not executed.
- `firewall/net01-fw-rollback.sh`: candidate narrow rollback, requires Flask stopped. This script **mutates firewall if executed**. Not executed.
- `systemd/captiv-net01-firewall.service`: proposed independent oneshot unit; intentionally no ExecStop.
- `systemd/captive-portal-net01.drop-in.conf`: *template* for future accepted app unit, not a live unit.
- `firewall/commands-review-only.txt`: exact firewall commands for reviewer inspection.
- `TEST_AND_ROLLBACK_PLAN.md`: detailed future positive/negative tests, safe sequencing and rollback.
- `ARCHITECT_REPORT.txt`: formal handoff/status.
- `tests/test_guard_offline.py`: synthetic firewall parsing tests (read-only, no host mutation).
- `MANIFEST.sha256`: integrity hashes of package files; not a signature.

## Docker strategy (review proposal)

1. Keep **existing Docker network object**. Mark the service's `default` network as `external: true` with its existing name, rather than asking Compose to remove/create it.
2. Pin NPM's IP `172.18.0.2` and MAC `b2:fa:fc:bf:d5:bc` on that existing network. Leave published ports, image, volumes, logs, restart policy and secrets handling unchanged.
3. Proposed Compose was validated remotely by streaming YAML through SSH into `docker compose -p nginx-proxy-manager -f - config --quiet` — **exit code 0**, with no file or production changes. This is **syntax/config acceptance only**, NOT live attach compatibility or recreate acceptance.
4. **A container recreate is likely required** to apply network endpoint settings; an NPM interruption is possible. No `docker compose down`, `docker compose up` or Docker network create/rm ran in Part A.
5. A changed network **ID**, subnet/gateway, bridge, image, NPM endpoint IP/MAC or extra container causes the guard to reject the backend (fail closed). The same named network recreated with a new ID **does not** pass.
6. Static IP/MAC and membership checks are layered protection against accidental address reuse; not authentication against Docker administrators or privileged workloads capable of IP/MAC spoofing. An NPM image upgrade triggers a guard review.

## Evidence and test limits

- Live `docker compose -p nginx-proxy-manager -f - config --quiet` on this Compose: **exit 0**.
- Bash scripts: `bash -n` **PASS**; Python guard: bytecode syntax **PASS**; fixture test positive/negative firewall matching **PASS**.
- Actual iptables rule installation, Docker network attachment after recreate, systemd start ordering, packet filtering and rollback are **NOT TESTED** (Part B not authorized).

## Security and operational limitations

- Backend still requires a **reviewed Git release** with HOST/PORT as deployment-configurable and exact proposed values `172.18.0.1:18089`.
- Checked current GitHub default-branch `app/config.py`: still `HOST = "127.0.0.1"`, `PORT = 8088`, and `CAPPORT_PUBLIC_BASE_URL = "https://captivportal-navi.duckdns.org"` with old fixed Site ID. This is **NOT** an accepted new Portal release. Actual new Omada Site ID and CAPPORT allowed CIDRs need separate confirmation.
- The backend must not start until firewall rules and identity have been verified. Its future systemd unit must require `captiv-net01-firewall.service` and have an independent `ExecStartPre` check. If Docker/NPM is not yet ready on boot, fail closed and retry only after investigation; no unsafe fallback.
- If an administrator flushes iptables while Flask is running, ANY software firewall on that host can cease protecting the socket. Future acceptance requires preventing such external changes operationally and an active detection/stop mechanism if this risk must be covered. A startup-only guard cannot guarantee protection against privileged post-start deletion. A narrowly scoped host bind alone does not secure Docker-bridge traffic against every locally attached container.
- The INPUT rule blocks all non-NPM IPv4 sources to TCP 18089; the IPv6 rule blocks all IPv6 TCP 18089. A host-process with root or CAP_NET_ADMIN can bypass; this threat is out of the IP/MAC-boundary contract.
- Do not treat `NET01_DESIGN` or runtime acceptance as PASS from this package. Review is not deployment.
