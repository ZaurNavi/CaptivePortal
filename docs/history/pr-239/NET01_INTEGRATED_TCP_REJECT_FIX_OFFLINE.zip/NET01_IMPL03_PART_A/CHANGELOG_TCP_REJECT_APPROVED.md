# NET-01 integrated TCP REJECT correction — Architect-approved offline patch

- Upstream integration ZIP SHA-256: `e2c109695216c59944e48ce71391a287f3feb5b031bce976ffc4e558219a6d60`.
- Approved scope: add `-p tcp` to **two** terminal IPv4 REJECT rules, in `CAPTIV_FLASK_18089` and `CAPTIV_SENSOR_OUT_18089`.
- Synchronized `net01-fw-install.sh`, `net01-fw-rollback.sh`, the exact-match `net01-verify.py`, review commands, and fixture baselines.
- No change to first INPUT/OUTPUT hooks, source IP/MAC/bridge, Sensor UID owner match, IPv6 policy, Docker identity, systemd units, or service activation.
- Exact verifier rejects missing `-p tcp`, wrong protocol and inverted/extra conditions.
- Tested in isolated WSL2 Linux with `iptables v1.8.7 (nf_tables)` and `unshare -n`. Real bridge, veth endpoint/MAC and UID-restricted loopback were exercised.
- Negative/positive results, idempotent repeat installation, drift HOLD and normal rollback: PASS in test namespace; **actual production scripts with real systemd/Docker are NOT live-tested**.
- Original integrated source ZIP kept unchanged. Package excludes cache/__pycache__ files and builds a regenerated SHA-256 manifest.
- `PRODUCTION_CHANGES=NONE`. Part B and Portal installation **not authorized**.
