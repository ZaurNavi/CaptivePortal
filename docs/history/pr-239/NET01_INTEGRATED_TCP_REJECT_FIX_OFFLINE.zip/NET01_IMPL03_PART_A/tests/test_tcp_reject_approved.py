"""Architect-approved narrow fix: TCP protocol mandatory on two IPv4 REJECTs."""
from pathlib import Path
import pytest
from rev4_fixture import isolated
from test_net01_integrated_two_paths import proof, REJECT_IN, REJECT_OUT

ROOT=Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('chain,reject',[
    ('inchain',REJECT_IN),('outchain',REJECT_OUT),
])
@pytest.mark.parametrize('mutated',[
    lambda line:line.replace('-p tcp -j REJECT','-j REJECT'),
    lambda line:line.replace('-p tcp -j REJECT','-p udp -j REJECT'),
    lambda line:line.replace('-p tcp -j REJECT','! -p udp -j REJECT'),
])
def test_terminal_reject_protocol_drift_is_hold(monkeypatch,chain,reject,mutated):
    from test_net01_integrated_two_paths import NPM_ALLOW, SENSOR_IN, SENSOR_OUT
    base = ('-N CAPTIV_FLASK_18089\n'+NPM_ALLOW+SENSOR_IN+REJECT_IN if chain=='inchain' else
            '-N CAPTIV_SENSOR_OUT_18089\n'+SENSOR_OUT+REJECT_OUT)
    with pytest.raises(RuntimeError):
        proof(monkeypatch, **{chain:base.replace(reject,mutated(reject))})


def test_installer_and_rollback_have_exact_two_tcp_rejects():
    for name,action in [('net01-fw-install.sh','-A'),('net01-fw-rollback.sh','-D')]:
        script=(ROOT/'firewall'/name).read_text()
        assert f'iptables -w {action} "$CHAIN" -p tcp -j REJECT --reject-with tcp-reset' in script
        assert f'iptables -w {action} "$OUTCHAIN" -p tcp -j REJECT --reject-with tcp-reset' in script
        assert f'iptables -w {action} "$CHAIN" -j REJECT --reject-with tcp-reset' not in script
        assert f'iptables -w {action} "$OUTCHAIN" -j REJECT --reject-with tcp-reset' not in script
    assert 'ip6tables -w -I INPUT 1 -p tcp --dport 18089 -j REJECT --reject-with tcp-reset' in (ROOT/'firewall/net01-fw-install.sh').read_text()
    assert 'ip6tables -w -D INPUT -p tcp --dport 18089 -j REJECT --reject-with tcp-reset' in (ROOT/'firewall/net01-fw-rollback.sh').read_text()


def test_installer_and_rollback_mock_commands_reject_tcp_only():
    with isolated() as (_root,_env,run,_hold,_maint,_log):
        result,mut=run('net01-fw-install.sh')
        assert result.returncode==0,result.stderr
        assert len(mut)==10
        assert len([x for x in mut if ' -p tcp -j REJECT --reject-with tcp-reset' in x and 'ip6tables' not in x])==2
        assert ' -I INPUT ' in '\n'.join(mut) and ' -I OUTPUT ' in '\n'.join(mut)
    with isolated() as (_root,_env,run,hold,maint,_log):
        result,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
        assert result.returncode==0,result.stderr
        assert len(mut)==10
        assert len([x for x in mut if ' -p tcp -j REJECT --reject-with tcp-reset' in x and 'ip6tables' not in x])==2
        assert ' -D INPUT ' in '\n'.join(mut) and ' -D OUTPUT ' in '\n'.join(mut)
        assert hold.exists() and maint.exists()
