# NET-01 integrated NPM+Sensor offline package — TCP REJECT fix

**Status:** `READY_FOR_INDEPENDENT_REVIEW`; `PRODUCTION_CHANGES=NONE`; **DO NOT APPLY without scoped Owner GO**.

Approved two routes: `NPM 172.18.0.2 → bridge 172.18.0.1:18089`; `fingerprint-sensor dedicated UID → lo → 172.18.0.1:18089`.

## Single change

Two dedicated IPv4 terminal rules are now `-p tcp -j REJECT --reject-with tcp-reset` rather than `-j REJECT --reject-with tcp-reset`. This avoids netfilter-nft `Invalid argument` for TCP-reset on an unrestricted-protocol rule. Both hooks already only match TCP `--dport 18089` and continue unchanged. IPv6 INPUT remains TCP deny.

## Exact files

See `TCP_REJECT_FIX_APPROVED.diff`. Installer, rollback, strict verifier, review command list and fixture tests are updated together. No other runtime configuration edits.

## Acceptance

Offline pytest `149 passed`. Isolated Linux netns `RC=0`: positive NPM/source-MAC and Sensor UID traffic; negative alternate container IP, MAC, root and another UID; original/rollback rule shape; reinstall; deliberate drift HOLD. See `TEST_RESULTS_TCP_REJECT.txt`.

## Remaining gates

Actual production identity, application service, full systemd PID1 integration, production firewall enforcement, Docker NPM recreate, Proxy Host, headers, Omada integration: `NOT_TESTED` under this offline directive. All remain HOLD pending specific approvals.
