# NET01 — REV3 acceptance and rollback runbook (PROPOSED / NOT EXECUTED)

## Operator prerequisites (future Owner GO only)

1. Independent Architect approval of REV3, accepted Git release with configurable HOST/PORT and exact new Omada Site/CAPPORT FQDN; isolated staging lifecycle PASS.
2. Approved maintenance window/backup of NPM and existing proxy routes, old certificate fingerprint and process/network/firewall baseline; documented fallback.
3. Install scripts and root-only systemd units from reviewed artifact with root owner and non-app-writable permissions; new Flask `User=captivportal`, no supplementary Docker group, no Docker socket permission.
4. Do **not** auto-run `docker compose up/down`, remove Docker network, alter Omada, or enable public Proxy Host during setup. NPM container recreate requires separate consent.
5. Check pinned network ID/bridge/gateway/IP/MAC and local OCI/image ID with independent read-only commands.

## Correct cold boot / startup ordering

1. Docker daemon and NPM appear; if daemon is up but NPM absent/not ready, watchdog guard FAIL and no listener. `Restart=no`; operator fixes NPM and manually retries after approved HOLD review.
2. Root firewall oneshot installs known rules after Docker identity validation and before any Flask bind.
3. `captive-portal.service` transaction pulls watchdog via `BindsTo`; watchdog `Type=notify` must emit READY after initial guard PASS; Flask is ordered `After` it.
4. Flask root-only `ExecStartPre=+... --all` rechecks policy; process itself runs under `User=captivportal`, listens ONLY `172.18.0.1:18089`.
5. If watchdog deliberately stops, crashes, fails to start, or receives SIGKILL, systemd `BindsTo` must stop Flask and `ExecStopPost` must set HOLD. OnFailure independent failsafe confirms and escalates if needed. Do not rely on OnFailure for manual stop.
6. `Restart=no` for app/watchdog, plus sticky HOLD: no automatic restart. Operator must correct, reset failed state as needed, clear marker via reviewed script and manually restart.

## Isolated Ubuntu staging (mandatory before Part B)

- Build disposable systemd PID1 VM or container with **dummy** non-production Flask listener and mock Docker/firewall guard; never use real NPM or guest traffic.
- Verify `systemctl cat`, `systemctl show -p User -p Group -p ExecStartPre -p ExecStart -p After -p BindsTo -p Restart` and actual `/proc/$PID/status` Uid/Gid, `id` and Docker socket denial from Flask user.
- Test valid initial Docker+firewall guard, READY ordering, and listener opens only after watchdog READY.
- Test Docker Engine unavailable at cold boot, Docker active but NPM container delayed, firewall guard reject; **no** bound TCP 18089, no restart loop.
- Test `systemctl stop captiv-net01-watchdog`, unexpected exit (`kill` watchdog main PID), systemctl kill --signal=SIGKILL, timeout of verification; Flask must stop, 18089 must unbind, HOLD latched, no restart.
- Test watchdog unit `OnFailure` actually starts independent failsafe; ensure no job cycles/deadlocks. Explicit stop is verified via BindsTo (OnFailure may not fire).
- Test failsafe marker creation failure while stop still occurs; graceful `systemctl stop` timeout, SIGKILL fallback scoped only to dummy app; listener and service stopped or FAIL with critical alarm.
- Test startup after HOLD: Flask must reject; after explicit admin recovery and `systemctl reset-failed`, only operator can start.
- Privileged stop or administrator tampering is outside the root threat boundary; document maximum observed detection+stop latency.

## Future real Part B positive/negative network tests (NOT EXECUTED)

- NPM container to `172.18.0.1:18089` permitted, responds actual Flask; other containers and network namespaces denied; LAN/Guest/WAN denied; IPv6 denied.
- Do not attach a second Docker container to NPM network while membership guard==1. Authorized temporary Linux network namespace/veth can test a distinct source IP/MAC without Docker membership mutation; clean up fully.
- Verify `Host`, `Proto`, `Port`, trusted client IP, `X-Forwarded-*` spoof rejection, safe HTTP logs and no Admin exposed.
- Check post-install/POST-restart NPM and old Portal/Nextcloud/VPN/Omada unchanged.
- Docker recreate and full reboot acceptance require separate window and rollback plan.

## Firewall rollback: exact-state ownership gate

1. Authorized operator stops **new** Flask; verify inactive and `ss` no listener on 18089; stops watchdog, confirms HOLD latched.
2. `net01-fw-rollback.sh` acquires exclusive NET01 lock and runs `net01-verify.py --firewall-only`, which ignores sticky HOLD but does not need Docker, and checks the entire approved owned ruleset.
3. If a rule is modified, missing, reordered, duplicated, stale, or unexpected: **HOLD with zero rule deletion**. Preserve exact `iptables -S`, `ip6tables -S` evidence and request manual security review; do not flush.
4. If exact posture verified, remove only named first INPUT jump, chain allow, terminal reject, empty chain, then first IPv6 reject. Error at any step: HOLD/manual review, never blanket cleanup.
5. Retain HOLD until reviewed recovery; rollback Compose only in approved maintenance window. Recheck SSH and old NPM proxies.
6. Recovery of HOLD is NOT automatic: owner reviews root-only state, identity, firewall and active unit, runs reviewed clear script after all PASS, resets failed states, manually starts Flask and rechecks watchdog.

## Unavoidable residual security risks

- A periodically sampled watchdog cannot atomically guarantee reaction to privileged firewall tampering. The interval is 2 sec + guard deadline 15 sec + service-stop latency; stalled kernel/systemd and root adversary can bypass.
- BindsTo lifecycle depends on functioning systemd and exact installed unit configuration; isolated stage is REQUIRED before trusting it.
- `flock` coordinates NET01 scripts, not arbitrary root modifications. Firewall deletion steps cannot be atomic against other root actors.
- Docker IP+MAC is not cryptographic container authentication. No public routing until all acceptance gates PASS.
