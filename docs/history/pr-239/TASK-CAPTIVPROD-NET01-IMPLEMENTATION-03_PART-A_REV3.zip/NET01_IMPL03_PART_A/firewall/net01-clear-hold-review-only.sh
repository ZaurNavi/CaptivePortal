#!/usr/bin/env bash
# MANUAL OPERATOR REVIEW ONLY after approved remediation. NEVER automatically invoked.
set -euo pipefail
HOLD=/var/lib/captiv-net01/HOLD
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
if systemctl is-active --quiet captive-portal.service; then
  echo 'HOLD: backend must be stopped before clearing latch' >&2
  exit 1
fi
if ss -H -lnt | awk '{print $4}' | grep -Eq '(^|:)18089$'; then
  echo 'HOLD: listener remains on TCP 18089' >&2
  exit 1
fi
# No unconditional bypass: require full current posture PASS.
/usr/bin/python3 "$GUARD" --all --ignore-hold
rm -f -- "$HOLD"
# OPERATOR starts backend manually AFTER external review; this script does not start it.
echo 'HOLD marker cleared after guard PASS; backend still STOPPED'
