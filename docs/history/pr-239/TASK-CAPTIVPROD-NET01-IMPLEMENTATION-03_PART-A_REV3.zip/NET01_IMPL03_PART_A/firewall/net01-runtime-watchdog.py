#!/usr/bin/env python3
"""REV3 strict root-only Type=notify supervisor; never manages systemctl jobs.

Flask BindsTo + After watchdog ensures watchdog ACTIVE (READY) before bind,
and Flask stops when watchdog becomes inactive, failed or is intentionally stopped.
ExecStopPost latches HOLD on *all* watchdog terminations; OnFailure triggers an
independent emergency service for redundant termination verification.
"""
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

ROOT = Path('/usr/local/libexec/captiv-net01')
GUARD = ROOT / 'net01-verify.py'
HOLD = Path('/var/lib/captiv-net01/HOLD')
INTERVAL_SEC = 2
GUARD_TIMEOUT_SEC = 15


def iteration(run=subprocess.run):
    try:
        if HOLD.exists():
            return 'sticky-hold-present'
        result = run(['/usr/bin/python3', str(GUARD), '--all'],
                     check=False, capture_output=True, text=True,
                     timeout=GUARD_TIMEOUT_SEC)
    except (OSError, subprocess.TimeoutExpired):
        return 'guard-unavailable-or-timeout'
    return None if result.returncode == 0 else 'guard-reported-drift'


def sd_notify(message, env=os.environ, make_socket=socket.socket):
    addr = env.get('NOTIFY_SOCKET')
    if not addr:
        raise RuntimeError('NOTIFY_SOCKET absent: cannot prove supervisor readiness')
    if addr.startswith('@'):
        addr = '\0' + addr[1:]
    s = make_socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    try:
        s.sendto(message.encode('utf-8'), addr)
    finally:
        s.close()


def main(probe=iteration, notify=sd_notify, pause=time.sleep):
    if os.geteuid() != 0:
        return 1
    first = probe()  # NO systemd READY until all checks pass.
    if first is not None:
        print('NET01_WATCHDOG_INITIAL_HOLD=' + first, file=sys.stderr)
        return 75
    try:
        notify('READY=1\nSTATUS=NET01 supervisor READY, guard passed')
    except (OSError, RuntimeError):
        print('NET01_WATCHDOG_NOTIFY_FAILURE', file=sys.stderr)
        return 75
    while True:
        pause(INTERVAL_SEC)
        why = probe()
        if why is not None:
            # Do not call systemctl stop from this service. Exit nonzero and
            # let systemd BindsTo stop Flask + ExecStopPost latch HOLD.
            print('NET01_RUNTIME_DRIFT=' + why, file=sys.stderr)
            return 75


if __name__ == '__main__':
    sys.exit(main())
