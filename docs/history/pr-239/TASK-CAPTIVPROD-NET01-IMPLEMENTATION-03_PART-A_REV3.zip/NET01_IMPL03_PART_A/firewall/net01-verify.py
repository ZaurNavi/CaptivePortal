#!/usr/bin/env python3
"""NET-01 proposed strict, read-only identity and firewall guard. NOT DEPLOYED."""
import argparse
import json
import pathlib
import shlex
import stat
import subprocess
import sys

BRIDGE = 'br-627e7c1ca6d5'
NETWORK = 'nginx-proxy-manager_default'
NETWORK_ID = '627e7c1ca6d557e7522ed3a041f3f6173541fcf18570edd8c33da5ce82432697'
GATEWAY = '172.18.0.1'
NETWORK_CIDR = '172.18.0.0/16'
NPM_IP = '172.18.0.2'
NPM_MAC = 'b2:fa:fc:bf:d5:bc'
# Separate concepts. Values happen to match in the OBSERVED Docker 29 image store.
NPM_IMAGE_REF = 'jc21/nginx-proxy-manager:2.16.0@sha256:4393e642e233e5efd5adeb7f10918d4aaea71c9ed875b94190273fc8e87f9594'
NPM_MANIFEST_DIGEST = 'sha256:4393e642e233e5efd5adeb7f10918d4aaea71c9ed875b94190273fc8e87f9594'
NPM_IMAGE_CONFIG_ID = 'sha256:4393e642e233e5efd5adeb7f10918d4aaea71c9ed875b94190273fc8e87f9594'
CHAIN = 'CAPTIV_FLASK_18089'
PORT = '18089'
HOLD_FILE = pathlib.Path('/var/lib/captiv-net01/HOLD')


def command(*argv):
    p = subprocess.run(argv, text=True, capture_output=True, timeout=6)
    if p.returncode:
        raise RuntimeError(f'command failed: {argv[0]} rc={p.returncode}')
    return p.stdout


def must(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def rules(chain, program='iptables'):
    output = command(program, '-w', '-S', chain)
    # Fail closed if iptables format is unfamiliar; only -A rules are returned.
    return [shlex.split(line) for line in output.splitlines() if line.startswith('-A ')]


def normalize(tokens):
    """Canonical multiset of exact option/value pairs.

    iptables -S reorders -s/-d/-i independently of input command order.
    Reordering exact pairs is safe, adding ANY extra match/inversion is NOT.
    Remove only ONE renderer-generated '-m tcp' pair. Every other pair,
    including -m mac and -m conntrack, is preserved; duplicates fail.
    """
    must(len(tokens) % 2 == 0, 'Malformed firewall option/value structure')
    pairs = []
    removed_tcp_module = False
    for i in range(0, len(tokens), 2):
        key, val = tokens[i:i + 2]
        must(key.startswith('-') and key != '!', 'Unrecognized/inverted firewall option')
        if (key, val) == ('-m', 'tcp'):
            must(not removed_tcp_module, 'Repeated tcp module in firewall rule')
            removed_tcp_module = True
        else:
            pairs.append((key, val))
    return sorted(pairs)


def exact(actual, expected, label):
    must(normalize(actual) == normalize(expected),
         f'{label}: exact normalized firewall match differs (unexpected, missing, duplicated or inverted clause)')


def check_identity():
    net = json.loads(command('docker', 'network', 'inspect', NETWORK))[0]
    must(net['Id'] == NETWORK_ID, 'Docker network ID changed')
    must(net['Name'] == NETWORK and net['Driver'] == 'bridge' and not net['EnableIPv6'],
         'Docker network name, driver or IPv6 changed')
    must(len(net['IPAM']['Config']) == 1, 'Unexpected Docker IPAM layout')
    ipam = net['IPAM']['Config'][0]
    must(ipam['Subnet'] == NETWORK_CIDR and ipam['Gateway'] == GATEWAY,
         'Docker subnet/gateway changed')
    members = net['Containers']
    must(len(members) == 1, 'Unauthorized NPM bridge membership')
    npm = json.loads(command('docker', 'inspect', 'npm'))[0]
    must(npm['Name'] == '/npm' and npm['State']['Running'], 'NPM name/state invalid')
    must(npm['Id'] in members and members[npm['Id']]['Name'] == 'npm',
         'NPM identity does not own the sole network endpoint')
    member = members[npm['Id']]
    must(member['IPv4Address'] == NPM_IP + '/16' and member['MacAddress'].lower() == NPM_MAC,
         'NPM network IP/MAC changed')
    must(npm['Config']['Image'] == NPM_IMAGE_REF, 'NPM configured registry image reference changed')
    # Read-only local image inspect by approved image ID (no network/pull).
    # The container's configured registry reference is checked separately above.
    imgs = json.loads(command('docker', 'image', 'inspect', NPM_IMAGE_CONFIG_ID))
    must(len(imgs) == 1, 'Approved image absent locally')
    img = imgs[0]
    must(img['Id'] == NPM_IMAGE_CONFIG_ID, 'Local image ID changed')
    must(npm['Image'] == NPM_IMAGE_CONFIG_ID and npm['Image'] == img['Id'],
         'Container image config ID differs from approved local image')
    must(NPM_IMAGE_REF in img.get('RepoDigests', []) or
         ('jc21/nginx-proxy-manager@' + NPM_MANIFEST_DIGEST) in img.get('RepoDigests', []),
         'Local image RepoDigests does not include approved manifest digest')
    descriptor = img.get('Descriptor')
    must(isinstance(descriptor, dict) and descriptor.get('digest') == NPM_MANIFEST_DIGEST,
         'Local OCI descriptor digest differs from approved manifest digest')
    endpoints = npm['NetworkSettings']['Networks']
    must(set(endpoints) == {NETWORK}, 'NPM attached to unapproved networks')
    ep = endpoints[NETWORK]
    must(ep['NetworkID'] == NETWORK_ID and ep['Gateway'] == GATEWAY,
         'NPM endpoint network ID/gateway changed')
    must(ep['IPAddress'] == NPM_IP and ep['MacAddress'].lower() == NPM_MAC,
         'NPM endpoint IP/MAC changed')
    links = json.loads(command('ip', '-j', '-4', 'addr', 'show', 'dev', BRIDGE))
    must(len(links) == 1 and links[0].get('operstate') == 'UP',
         'Approved Linux bridge absent/down')
    must(any(a.get('local') == GATEWAY and a.get('prefixlen') == 16
             for a in links[0]['addr_info']), 'Linux bridge gateway changed')
    print('DOCKER_IDENTITY=PASS')


def check_firewall():
    # An unconditional TCP-wide hook must be FIRST in INPUT, not a narrowed subset.
    inp = rules('INPUT')
    must(bool(inp), 'IPv4 INPUT has no rules')
    exact(inp[0], ['-A', 'INPUT', '-p', 'tcp', '--dport', PORT, '-j', CHAIN],
          'IPv4 FIRST INPUT hook')
    must(sum(rule.count(CHAIN) for rule in inp) == 1,
         'Duplicate reference to protected chain in INPUT')
    chain = rules(CHAIN)
    must(len(chain) == 2, 'Dedicated chain must contain EXACTLY allow + terminal REJECT')
    exact(chain[0], ['-A', CHAIN,
                     '-i', BRIDGE, '-s', NPM_IP + '/32', '-d', GATEWAY + '/32',
                     '-p', 'tcp', '--dport', PORT,
                     '-m', 'mac', '--mac-source', NPM_MAC,
                     '-m', 'conntrack', '--ctstate', 'NEW,ESTABLISHED',
                     '-j', 'ACCEPT'], 'NPM-only allow')
    exact(chain[1], ['-A', CHAIN, '-j', 'REJECT', '--reject-with', 'tcp-reset'],
          'terminal catch-all IPv4 REJECT')
    ipv6 = rules('INPUT', 'ip6tables')
    must(bool(ipv6), 'IPv6 INPUT has no rules')
    exact(ipv6[0], ['-A', 'INPUT', '-p', 'tcp', '--dport', PORT,
                    '-j', 'REJECT', '--reject-with', 'tcp-reset'],
          'IPv6 FIRST INPUT deny')
    must(sum(1 for rule in ipv6 if '--dport' in rule and PORT in rule) == 1,
         'Unexpected additional IPv6 rule mentioning backend port')
    # No hidden additional hook to this dedicated chain in any other IPv4 chain.
    full = command('iptables', '-w', '-S')
    refs = [shlex.split(line) for line in full.splitlines()
            if line.startswith('-A ') and '-j ' + CHAIN in line]
    must(len(refs) == 1, 'Unexpected extra IPv4 jump to dedicated chain')
    exact(refs[0], ['-A', 'INPUT', '-p', 'tcp', '--dport', PORT, '-j', CHAIN],
          'global protected-chain reference')
    print('FIREWALL_FAIL_CLOSED=PASS')


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--identity', action='store_true')
    p.add_argument('--firewall-only', action='store_true', help='Root-only exact rollback posture: no Docker required; HOLD marker ignored')
    p.add_argument('--all', action='store_true')
    p.add_argument('--ignore-hold', action='store_true',
                   help='OPERATORS ONLY: check posture before clearing sticky HOLD; not for app start')
    args = p.parse_args()
    if sum((args.identity, args.all, args.firewall_only)) != 1:
        p.error('specify exactly one of --identity, --all, --firewall-only')
    try:
        if args.ignore_hold and not args.all:
            raise RuntimeError('--ignore-hold requires --all')
        must(HOLD_FILE.parent.is_dir(), 'Sticky HOLD state directory missing')
        st = HOLD_FILE.parent.stat()
        must(st.st_uid == 0 and stat.S_IMODE(st.st_mode) == 0o700,
             'Sticky HOLD state directory must be root-owned 0700')
        if HOLD_FILE.exists() and not (args.ignore_hold or args.firewall_only):
            raise RuntimeError('NET01 sticky HOLD marker present; operator action required')
        if not args.firewall_only:
            check_identity()
        if args.all or args.firewall_only:
            check_firewall()
    except (OSError, ValueError, KeyError, IndexError, RuntimeError,
            subprocess.TimeoutExpired, json.JSONDecodeError) as e:
        print('NET01_GUARD=HOLD: ' + str(e), file=sys.stderr)
        return 75
    return 0


if __name__ == '__main__':
    sys.exit(main())
