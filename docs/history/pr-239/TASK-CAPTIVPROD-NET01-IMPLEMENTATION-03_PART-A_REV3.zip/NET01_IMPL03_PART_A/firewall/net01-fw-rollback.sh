#!/usr/bin/env bash
# REV3 REVIEW ONLY; STRICT OWNERSHIP PRECHECK before ANY mutation.
# Explicit approval and maintenance required; never uninstall firewall while Flask active.
set -euo pipefail
umask 077
if (( EUID != 0 )); then echo 'HOLD: root required' >&2; exit 75; fi
CHAIN=CAPTIV_FLASK_18089
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
exec 9>/run/lock/captiv-net01-firewall.lock
flock -n 9 || { echo 'HOLD: NET01 firewall lock busy' >&2; exit 75; }
# Never stop other production units, change INPUT policy or flush global rules.
if systemctl is-active --quiet captive-portal.service; then
  echo 'HOLD: new Flask still running' >&2; exit 75
fi
if ss -H -lnt | awk '{print $4}' | grep -Eq '(^|:)18089$'; then
  echo 'HOLD: listener on 18089' >&2; exit 75
fi
# Watchdog must be stopped: it would otherwise flag intentional rule removal.
if systemctl is-active --quiet captiv-net01-watchdog.service; then
  echo 'HOLD: watchdog must be stopped, sticky HOLD already latched' >&2; exit 75
fi
# Independent, exact firewall-only check. Deliberately ignores sticky HOLD;
# does NOT require Docker/NPM up and never repairs unexpected/partial rules.
/usr/bin/python3 "$GUARD" --firewall-only || {
  echo 'HOLD: unrecognized/partial/changed NET01 rules; NO rules removed' >&2
  exit 75
}
# Remove exactly the four reviewed objects; no -F, no blanket cleanup.
# Failure midway => HOLD/manual review; never retry with a broad flush.
iptables -w -D INPUT -p tcp --dport 18089 -j "$CHAIN"
iptables -w -D "$CHAIN" -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc \
  -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
iptables -w -D "$CHAIN" -j REJECT --reject-with tcp-reset
iptables -w -X "$CHAIN"
ip6tables -w -D INPUT -p tcp --dport 18089 -j REJECT --reject-with tcp-reset
printf '%s\n' 'NET01_ROLLBACK=COMPLETED_FOR_EXACT_REVIEWED_RULESET'
