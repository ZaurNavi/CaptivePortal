#!/usr/bin/env bash
# REVIEW ONLY. Not executed in Part A. Root and Owner GO required for Part B.
set -euo pipefail
umask 077
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
CHAIN=CAPTIV_FLASK_18089

# Fail closed if network object, image or endpoint identity changed.
/usr/bin/python3 "$GUARD" --identity

# Existing chain can only be reused after exact verification: no silent repairs.
# Check existing policy BEFORE listener state (e.g., an already protected runtime).
if iptables -w -S "$CHAIN" >/dev/null 2>&1; then
  /usr/bin/python3 "$GUARD" --all
  exit 0
fi

# Fresh installation requires backend STOPPED. Existing listeners => manual HOLD.
if ss -H -lnt | awk '{print $4}' | grep -Eq '(^|:)18089$'; then
  echo 'HOLD: port 18089 has a listener but no firewall policy' >&2
  exit 1
fi

# Catchall first; then hook; allow only after hook in place. No backend listener.
iptables -w -N "$CHAIN"
iptables -w -A "$CHAIN" -j REJECT --reject-with tcp-reset
iptables -w -I INPUT 1 -p tcp --dport 18089 -j "$CHAIN"
iptables -w -I "$CHAIN" 1 \
  -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 \
  -p tcp --dport 18089 \
  -m mac --mac-source b2:fa:fc:bf:d5:bc \
  -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
ip6tables -w -I INPUT 1 -p tcp --dport 18089 -j REJECT --reject-with tcp-reset

# If incomplete, service fails and Flask unit cannot start. Manual review needed.
/usr/bin/python3 "$GUARD" --all
