# NET01-IMPLEMENTATION-03 / Part A REV3 — OFFLINE REVIEW PACKAGE

**Status:** `PART_A_REV3=READY_FOR_INDEPENDENT_REVIEW`; `PART_B=NOT_AUTHORIZED`; `NET01=HOLD`; `OWNER_GO=REQUIRED`.
**Reviewed source:** Architect's `CAPTIVPROD_NET01_REV2_INDEPENDENT_ARCH_REVIEW_2026-10-14(1).md`, SHA-256 review references the exact REV2 archive `35a5b499a7df2b68e38e73d6a80abc309631a77855a6df5bfcf42d227e4214d3`.

## Absolute boundary

No files in this package have been installed on `captiv-prod`. No Docker network, NPM, iptables, nftables, Omada, Cisco, running Flask, old Portal, proxies, certificates, or production systemd units have been modified. This is a **design and local offline test artifact**, NOT authorization to install, enable, restart, stop, or execute included privileged scripts in production. All live acceptance statuses remain **NOT_TESTED**.

## Preserved infrastructure contract

- NPM 2.16.0: Docker network `nginx-proxy-manager_default`, network ID `627e7c1ca6d557e7522ed3a041f3f6173541fcf18570edd8c33da5ce82432697`, Linux bridge `br-627e7c1ca6d5`, NPM `172.18.0.2` MAC `b2:fa:fc:bf:d5:bc`.
- Host gateway `172.18.0.1`, candidate new Flask bind `172.18.0.1:18089`. Omada owns existing `*:8088`. Existing NPM public ports `192.168.0.99:80/81/443` unchanged.
- `compose.proposed.yaml` retains approved network object as external and pins NPM IP/MAC; requires an approved NPM recreate (maintenance). Nothing in this package executes a recreate.
- App source must provide reviewed configurable HOST/PORT, CAPPORT base URL `https://captivprod-navi.duckdns.org`, and the actual new Omada Site ID. Existing Git app release **not approved**: no Flask activation.

## P1-01 — Root prestart with unprivileged Flask

`systemd/captive-portal-net01.drop-in.conf` uses `ExecStartPre=+/usr/bin/python3 ... net01-verify.py --all` to run **only** privileged prestart verification as root. The base Flask unit must independently specify `User=captivportal`, `Group=captivportal`, and an unprivileged `ExecStart`. `+` must **never** prefix ExecStart. No membership of Docker group, Docker socket mount/pass-through, sudoers blanket grant, or permission escalation for the Flask user. Watchdog and firewall helper units are root-owned; root access to the Docker socket is confined to those system services and their limited validation task. Full privilege semantics require live staging `systemctl show`, `systemctl cat`, process /proc credential, file permission, and negative Docker socket access tests. Local systemd-analyze verified only parsed/merged unit syntax using a **synthetic fixture root**, not real User credential switching.

## P1-02 — Flask tightly bound to the supervisor

`captive-portal-net01.drop-in.conf` uses `BindsTo=captiv-net01-watchdog.service` and `After=captiv-net01-watchdog.service`. Watchdog has **no reverse After/BindsTo** to Flask, hence no ordering cycle. `watchdog.service` is `Type=notify`, `NotifyAccess=main`; its Python loop first validates the full guard and **only then** emits `READY=1` using systemd's native notify socket. Thus a Flask startup will not proceed while Docker/NPM/firewall identity is unknown. Missing Docker or NPM => watchdog start FAIL, Flask remains stopped. `Restart=no` on both; no hidden retry if supervisor fails.

After startup, watchdog checks every 2 seconds with 15-second guard subprocess deadline. Drift => watchdog exits nonzero. For watchdog crash/kill/manual `systemctl stop`, the `BindsTo` dependency stops Flask as the primary control, independent of `OnFailure`. Watchdog `ExecStopPost` writes root-only sticky HOLD on **every exit**; `OnFailure=captiv-net01-failsafe.service` invokes a **separate root-only unit** to verify STOP and escalate to SIGKILL on failure. The watchdog process itself never invokes `systemctl stop`, eliminating self-cancellation/deadlock. This intentionally conservative design also latches HOLD when operator stops watchdog (including maintenance). Manual recovery requires guard PASS, marker clearance, `systemctl reset-failed` if required, then deliberate Flask start. Watchdog may remain active while Flask is intentionally stopped; do not stop watchdog casually. This is not an availability guarantee.

**Residual risk:** interval + guard timeout + systemd stop latency; privilege-bearing admin can tamper between checks; systemd failure/host stall could prevent timely stop. `BindsTo` provides systemd-mediated lifecycle, not kernel-enforced constant-time isolation. Must validate actual stop propagation and listener disappearance on isolated staging before Part B.

## P1-03 — Exact-state rollback, HOLD on surprises

`firewall/net01-fw-rollback.sh` refuses if Flask/any listener on TCP 18089/watchdog is active. It takes a dedicated lock and runs `net01-verify.py --firewall-only` **before any iptables deletion**. This mode checks exact first INPUT hook, exact two rules of dedicated IPv4 chain, exact first IPv6 deny, and sole jump reference from all IPv4 chains; it intentionally accepts a sticky HOLD marker and does not require Docker Engine or NPM during rollback. Any extra, missing, modified or partially installed rule => HOLD and **zero mutations**. On exact posture it deletes only named owned rules using explicit `iptables -D`, removes the now empty chain `-X`, and deletes the owned IPv6 rule. There is NO `-F`/global flush. A concurrent privileged mutation remains possible; lock coordinates *only* NET01 scripts, not arbitrary root commands. Mid-rollback command failure remains HOLD/manual intervention, never automatic broad cleanup.

## P2-01 — Emergency and lifecycle verification

Tests include watchdog initial guard failure, readyness notification sequence, actual local Unix-datagram notify, drift exit, timeout, marker durability/failure, graceful stop, stop timeout and SIGKILL fallback, unit still active, listener still bound, independent OnFailure dispatcher mock, negative restart-policy and dependency-order assertions, rollback guard HOLD/pre-mutation tests, plus original firewall/image regressions. Unit syntax checked with `systemd-analyze --root` against synthetic mock units (does NOT execute real systemd PID 1).

**Real systemd integration remains NOT_TESTED**, because test environment is not running a systemd manager as PID 1. Architect may demand a disposable Ubuntu VM/systemd-nspawn with a dummy Flask socket before approving Part B. Required tests are in `TEST_AND_ROLLBACK_PLAN.md`.

## Package layout

- `compose.*`: unchanged REV2 Compose/current/proposed/unified diff.
- `firewall/net01-verify.py`: strict guard, `--firewall-only` rollback read path; never bypass startup HOLD.
- `firewall/net01-mark-hold.py`: persistent root-only marker, no systemctl interaction.
- `firewall/net01-runtime-watchdog.py`: systemd notify supervisor, no stop call.
- `firewall/net01-hold-and-stop.py`: independent bounded emergency stop + SIGKILL fallback + listener proof.
- `firewall/net01-fw-rollback.sh`: preverified deletion only; installed state not tested.
- `systemd/*`: approved-direction unit overlays; NOT deployed.
- `tests/*`: local fixture/mocks and synthetic unit parser.
- `REV2_TO_REV3.diff`, `CHANGELOG_REV3.md`, `TEST_RESULTS_REV3.txt`, `ARCHITECT_REPORT.txt`, `MANIFEST.sha256`.

## Go/no-go

`PART_A_REV3=READY_FOR_INDEPENDENT_REVIEW` is **not** `NET01=PASS`. Part B stays prohibited until independent code review, accepted Git release/Site/FQDN, Owner GO, approved maintenance window, real non-NPM denial, listener/credentials/watchdog lifecycle staging tests and rollback validation.
