"""OFFLINE ONLY: lifecycle/mocks, no real systemd or production network mutations."""
import importlib.util
from pathlib import Path
import socket
import subprocess
from tempfile import TemporaryDirectory
from unittest.mock import patch

import pytest

BASE = Path(__file__).resolve().parents[1]

def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, BASE / rel)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

w = load('watchdog_rev3', 'firewall/net01-runtime-watchdog.py')
e = load('emergency_rev3', 'firewall/net01-hold-and-stop.py')
m = load('marker_rev3', 'firewall/net01-mark-hold.py')


def run_response(code=0, out=''):
    return subprocess.CompletedProcess([], code, stdout=out, stderr='')


def test_watchdog_readiness_only_after_initial_pass():
    sent=[]
    with patch.object(w.os, 'geteuid', return_value=0):
        assert w.main(probe=lambda: 'initial-docker-unavailable', notify=sent.append) == 75
        assert sent == []  # NEVER READY when guard fails


def test_watchdog_drift_returns_failure_without_systemctl():
    checks=iter([None, 'guard-reported-drift'])
    sent=[]
    with patch.object(w.os, 'geteuid', return_value=0):
        assert w.main(probe=lambda: next(checks), notify=sent.append, pause=lambda _: None) == 75
    assert sent == ['READY=1\nSTATUS=NET01 supervisor READY, guard passed']


def test_watchdog_notify_missing_socket_holds():
    with patch.object(w.os, 'geteuid', return_value=0):
        assert w.main(probe=lambda: None, notify=lambda _: (_ for _ in ()).throw(RuntimeError('no socket'))) == 75


def test_watchdog_notify_datagram_actual_unix_socket():
    with TemporaryDirectory() as td:
        path=str(Path(td)/'notify.sock')
        recv=socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        try:
            recv.bind(path)
            w.sd_notify('READY=1', env={'NOTIFY_SOCKET':path})
            recv.settimeout(1)
            assert recv.recv(100) == b'READY=1'
        finally:
            recv.close()


def test_watchdog_runtime_timeout():
    with patch.object(w, 'HOLD', type('Marker', (), {'exists':staticmethod(lambda:False)})):
        assert w.iteration(run=lambda *a,**k: (_ for _ in ()).throw(subprocess.TimeoutExpired('guard',15))) == 'guard-unavailable-or-timeout'


def test_hold_marker_durable_and_root_only():
    with TemporaryDirectory() as td:
        parent=Path(td)/'state';parent.mkdir(mode=0o700)
        path=parent/'HOLD'
        m.mark('test-drift', path=path)
        assert 'test-drift' in path.read_text()
        assert (path.stat().st_mode & 0o777) == 0o600


def test_hold_marker_failure_does_not_claim_success():
    with TemporaryDirectory() as td:
        parent=Path(td)/'state';parent.mkdir(mode=0o755)
        with pytest.raises(RuntimeError, match='not root-owned 0700'):
            m.mark('test', path=parent/'HOLD')


def fake_systemctl(cmd, timeout, *_, **kw):
    if cmd[1] == 'stop': return run_response()
    if cmd[1] == 'is-active': return run_response(3)
    if cmd[0] == 'ss': return run_response(0, 'LISTEN 0 128 127.0.0.1:8043 0.0.0.0:*\n')
    raise AssertionError(cmd)


def test_emergency_normal_stop_and_port_check():
    commands=[]
    def run(cmd, **kw):
        commands.append(cmd)
        return fake_systemctl(cmd, kw['timeout'])
    assert e.hold_and_stop('unit-failed', run=run, latch=lambda x:None)
    assert ['systemctl','stop','captive-portal.service'] in commands
    assert not any(c[:2] == ['systemctl','kill'] for c in commands)


def test_emergency_marker_failure_still_stops():
    commands=[]
    def run(cmd, **kw):
        commands.append(cmd)
        return fake_systemctl(cmd, kw['timeout'])
    with pytest.raises(RuntimeError, match='marker-failed'):
        e.hold_and_stop('marker-failed', run=run, latch=lambda x:(_ for _ in ()).throw(OSError('readonly')))
    assert ['systemctl','stop','captive-portal.service'] in commands


def test_emergency_sigkill_fallback_after_stop_timeout():
    commands=[]
    count={'active':0}
    def run(cmd, **kw):
        commands.append(cmd)
        if cmd[0] == 'ss':return run_response()
        if cmd[1] == 'stop' and commands.count(cmd)==1:
            raise subprocess.TimeoutExpired(cmd,kw['timeout'])
        if cmd[1] == 'is-active':
            count['active']+=1
            return run_response(0 if count['active']==1 else 3)
        return run_response()
    with pytest.raises(RuntimeError, match='graceful-stop-timeout'):
        e.hold_and_stop('stop-timeout',run=run,latch=lambda x:None)
    assert any(c[:2]==['systemctl','kill'] and '--signal=SIGKILL' in c for c in commands)
    assert commands.count(['systemctl','stop','captive-portal.service'])==2


def test_emergency_listener_remains_hold():
    def run(cmd, **kw):
        if cmd[0]=='ss':return run_response(0,'LISTEN 0 128 172.18.0.1:18089 0.0.0.0:*\n')
        return fake_systemctl(cmd, kw['timeout'])
    with pytest.raises(RuntimeError, match='listener-still-present'):
        e.hold_and_stop('listener',run=run,latch=lambda x:None)


def test_emergency_stop_failure_stays_fail():
    def run(cmd, **kw):
        if cmd[0]=='ss':return run_response()
        if cmd[1]=='is-active':return run_response(0)
        if cmd[1]=='kill':return run_response(1)
        return run_response(1)
    with pytest.raises(RuntimeError, match='unit-active'):
        e.hold_and_stop('stuck',run=run,latch=lambda x:None)


def test_systemd_dependency_static_contract_no_cycle():
    wd=(BASE/'systemd/captiv-net01-watchdog.service').read_text()
    app=(BASE/'systemd/captive-portal-net01.drop-in.conf').read_text()
    assert 'Type=notify' in wd and 'NotifyAccess=main' in wd
    assert 'BindsTo=captiv-net01-watchdog.service' in app
    assert 'After=docker.service captiv-net01-firewall.service captiv-net01-watchdog.service' in app
    assert 'ExecStartPre=+/usr/bin/python3' in app
    assert 'Restart=no' in app and 'Restart=no' in wd
    assert 'OnFailure=captiv-net01-failsafe.service' in wd
    assert 'ExecStopPost=+' in wd
    assert 'BindsTo=captive-portal.service' not in wd
    assert 'After=docker.service captive-portal.service' not in wd


def test_permissions_static_contract():
    app=(BASE/'systemd/captive-portal-net01.drop-in.conf').read_text()
    assert 'User=root' not in app
    assert 'ExecStartPre=+' in app
    assert 'ExecStart=+' not in app
    assert 'docker.sock' not in app


def test_watchdog_onfailure_dispatch_is_independent_and_stop_target_scoped():
    watchdog=(BASE/'systemd/captiv-net01-watchdog.service').read_text()
    failsafe=(BASE/'systemd/captiv-net01-failsafe.service').read_text()
    assert 'OnFailure=captiv-net01-failsafe.service' in watchdog
    assert 'ExecStart=/usr/bin/python3 /usr/local/libexec/captiv-net01/net01-hold-and-stop.py watchdog-failed' in failsafe
    assert 'BindsTo=captive-portal.service' not in failsafe
    with patch.object(e,'hold_and_stop') as emergency:
        with patch.object(e.sys,'argv',['net01-hold-and-stop.py','watchdog-failed']):
            assert e.main()==0
        emergency.assert_called_once_with('watchdog-failed')


def test_sticky_hold_bypass_is_not_in_application_prestart():
    app=(BASE/'systemd/captive-portal-net01.drop-in.conf').read_text()
    assert '--ignore-hold' not in app and '--firewall-only' not in app
    assert 'net01-verify.py --all' in app
    assert 'Restart=no' in app
