"""Run rollback in a sandbox with mock executables; NEVER call host iptables/systemctl.

The copied rollback script has its absolute GUARD and lock paths rewritten to
isolated temporary files, while all executable firewall/systemctl/ss commands
are shadowed by test fixtures. Only logic is validated, not real system impact.
"""
from pathlib import Path
from tempfile import TemporaryDirectory
import os
import subprocess

SCRIPT = Path(__file__).resolve().parents[1] / 'firewall/net01-fw-rollback.sh'


def write_exec(path, content):
    path.write_text('#!/bin/sh\n' + content)
    path.chmod(0o755)


def scenario(name, guard_ok, expected_mutation, service_active=False, listener=False,
             watchdog_active=False):
    with TemporaryDirectory(prefix='net01-rollback-fixture-') as folder:
        p=Path(folder);b=p/'bin';b.mkdir()
        log=p/'mutations.log'
        write_exec(b/'iptables', f'printf "iptables %s\\n" "$*" >> "{log}"\nexit 0\n')
        write_exec(b/'ip6tables', f'printf "ip6tables %s\\n" "$*" >> "{log}"\nexit 0\n')
        write_exec(b/'systemctl',
                   f'if [ "$1" = "is-active" ]; then\n'
                   f'  if [ "$3" = "captive-portal.service" ]; then exit {0 if service_active else 3}; fi\n'
                   f'  if [ "$3" = "captiv-net01-watchdog.service" ]; then exit {0 if watchdog_active else 3}; fi\n'
                   'fi\nexit 3\n')
        write_exec(b/'ss', 'printf "%s\\n" "LISTEN 0 128 172.18.0.1:18089 0.0.0.0:*"\n' if listener else 'exit 0\n')
        guard=p/'guard.py'
        guard.write_text('import sys\n'
                         f'sys.exit({0 if guard_ok else 75})\n')
        script=(SCRIPT.read_text()
                .replace('GUARD=/usr/local/libexec/captiv-net01/net01-verify.py',f'GUARD={guard}')
                .replace('exec 9>/run/lock/captiv-net01-firewall.lock',f'exec 9>{p}/lock'))
        dest=p/'rollback.sh';dest.write_text(script);dest.chmod(0o755)
        env={**os.environ,'PATH':f'{b}:/usr/bin:/bin'}
        result=subprocess.run(['/bin/bash',str(dest)],capture_output=True,text=True,env=env,timeout=8)
        mutations=log.read_text().splitlines() if log.exists() else []
        assert (result.returncode==0)==expected_mutation, (name,result.stderr,result.stdout)
        if not expected_mutation:
            assert not mutations, (name,mutations)
        else:
            assert len(mutations)==5, (name,mutations)
            assert all('-D ' in s or '-X ' in s for s in mutations)
            assert not any(' -F ' in s for s in mutations)
        return result.returncode, mutations


def test_clean_exact_policy_can_rollback_in_mock():
    scenario('baseline',guard_ok=True,expected_mutation=True)


def test_drifted_chain_holds_before_mutation():
    scenario('modified-chain',guard_ok=False,expected_mutation=False)


def test_modified_hook_holds_before_mutation():
    scenario('modified-input-hook',guard_ok=False,expected_mutation=False)


def test_partial_install_holds_before_mutation():
    scenario('partial-install',guard_ok=False,expected_mutation=False)


def test_stale_rules_holds_before_mutation():
    scenario('stale-rules',guard_ok=False,expected_mutation=False)


def test_backend_active_holds():
    scenario('service-active',guard_ok=True,expected_mutation=False,service_active=True)


def test_watchdog_active_holds():
    scenario('watchdog-active',guard_ok=True,expected_mutation=False,watchdog_active=True)


def test_stray_listener_holds():
    scenario('stray-listener',guard_ok=True,expected_mutation=False,listener=True)
