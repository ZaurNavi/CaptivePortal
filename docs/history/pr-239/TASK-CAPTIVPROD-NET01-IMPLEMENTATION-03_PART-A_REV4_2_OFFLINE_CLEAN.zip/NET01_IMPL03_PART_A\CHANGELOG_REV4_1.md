# NET01 REV4.1 — focused maintenance reinstall P1 correction
Date: 2026-10-15. Revision of REV4 offline package. NO captiv-prod mutation.

- Verified error: real net01-verify.py rejected --identity --ignore-maintenance --ignore-hold sent by maintenance-reinstall script (REV4).
- Permits those flags on --identity only if root and MAINTENANCE marker is a root-owned regular 0600 file under root-owned 0700 directory.
- --all operator bypass is similarly confined to verified maintenance. Ordinary startup/ExecStartPre (without flags) still fail closed on HOLD/MAINTENANCE.
- Revised two existing offline marker fixture assertions to model required 0600 permissions.
- Added tests/test_rev4_1_real_verifier_cli.py, exercising actual verifier.main with exact shell flag contract, negative latch/root/mode scenarios.
- Linux test suite on isolated WSL Ubuntu-22.04 scratch copy: 104 passed in 11.48s (2026-10-15); NO real iptables/Docker/systemd PID1 acceptance.
- This revision deliberately does NOT implement host-local Sensor -> Core allowance, which needs an extended exact firewall contract and independent security review.
STATUS=REV4_1_OFFLINE_CANDIDATE; NET01_PART_B=HOLD.
