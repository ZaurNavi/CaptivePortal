# REV4.2 Sensor local-origin extension (offline candidate)
Chain: NPM-only allow, exact lo host-local allow src=dst=172.18.0.1/32 TCP 18089, terminal REJECT.
IPv6: unconditional deny. Watchdog: real verifier --all checks exact ordered 3-rule chain.
Local-origin is not Sensor-UID-only: any local host process can connect; strict Sensor identity requires a separate accepted boundary.
Update installer, rollback, verifier, watchdog, fixtures and six-command mutation count together.
DO NOT INSTALL on captiv-prod until independent review and real isolated PID1 and packet-filter tests.
