# NET01 focused recovery addendum (REV4.1)

This archive supersedes REV4 only as a **review candidate**. No production changes are authorized merely by this package. The old recovery sequence is intact: root operator enters MAINTENANCE, verifies quiescence, rolls back only exact owned rules, reinstalls with `net01-fw-install.sh --maintenance-reinstall`, verifies exact state, clears HOLD, verifies exact state, clears MAINTENANCE and manually starts app when separately permitted. The real verifier now accepts installer flags in root + verified MAINTENANCE context, and never in normal startup.

This does **not** resolve Sensor-origin local TCP to bridge gateway. Do not add a permissive broad 172.18/16 rule or install REV4.1 as the final firewall. A next extension must update ordered chain policy, exact verifier, tests, rollback and watchdog together.

Systemd PID1, Docker identity drift/recreate, privileged/other-container denial, IPv6 denial, sensor local-origin policy, logging privacy and NPM synthetic HTTP remain HOLD.
