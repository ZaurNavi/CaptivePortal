"""Pure fixture regression for NET-01 strict firewall grammar; NO host commands."""
import importlib.util
from pathlib import Path

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('net01_guard', root / 'firewall' / 'net01-verify.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)

IPV4 = '''-P INPUT ACCEPT
-A INPUT -p tcp -m tcp --dport 18089 -j CAPTIV_FLASK_18089
-A INPUT -d 192.168.0.99/32 -i enp2s0 -j CAPTIV_OMADA_GUARD
'''
CHAIN = '''-N CAPTIV_FLASK_18089
-A CAPTIV_FLASK_18089 -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
-A CAPTIV_FLASK_18089 -i lo -s 172.18.0.1/32 -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
-A CAPTIV_FLASK_18089 -j REJECT --reject-with tcp-reset
'''
IPV6 = '''-P INPUT ACCEPT
-A INPUT -p tcp -m tcp --dport 18089 -j REJECT --reject-with tcp-reset
'''


def check_fixtures(ipv4=IPV4, chain=CHAIN, ipv6=IPV6, expected_pass=True, name='positive', extra_jump=''):
    def command(program, *args):
        if program == 'iptables':
            if args[-1] == '-S':
                return ipv4 + chain + extra_jump
            return {'INPUT': ipv4, g.CHAIN: chain}[args[-1]]
        if program == 'ip6tables':
            return ipv6
        raise AssertionError(program)
    g.command = command
    try:
        g.check_firewall()
        if not expected_pass:
            raise AssertionError(f'{name} unexpectedly PASS')
    except RuntimeError as ex:
        if expected_pass:
            raise AssertionError(f'{name} unexpectedly FAIL: {ex}')
    print(('PASS' if expected_pass else 'HOLD_AS_EXPECTED') + ' ' + name)


check_fixtures(name='baseline')
basehook = '-A INPUT -p tcp -m tcp --dport 18089 -j CAPTIV_FLASK_18089'
base6 = '-A INPUT -p tcp -m tcp --dport 18089 -j REJECT --reject-with tcp-reset'
baseallow = '-A CAPTIV_FLASK_18089 -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT'

sensorallow = '-A CAPTIV_FLASK_18089 -i lo -s 172.18.0.1/32 -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT'
assert CHAIN.index(baseallow) < CHAIN.index(sensorallow) < CHAIN.index('-A CAPTIV_FLASK_18089 -j REJECT')
cases = [
    dict(name='missing_sensor', chain=CHAIN.replace(sensorallow + '\n', '')),
    dict(name='wide_source', chain=CHAIN.replace(sensorallow, sensorallow.replace(' -s 172.18.0.1/32', ' -s 172.18.0.0/16'))),
    dict(name='wrong_interface', chain=CHAIN.replace(sensorallow, sensorallow.replace(' -i lo', ' -i br-627e7c1ca6d5'))),
    dict(name='wrong_destination', chain=CHAIN.replace(sensorallow, sensorallow.replace(' -d 172.18.0.1/32', ' -d 0.0.0.0/0'))),
    dict(name='missing_conntrack', chain=CHAIN.replace(sensorallow, sensorallow.replace(' -m conntrack --ctstate NEW,ESTABLISHED', ''))),
    dict(name='duplicate_sensor', chain=CHAIN.replace(sensorallow, sensorallow + '\n' + sensorallow)),
    dict(name='reordered_after_reject', chain=CHAIN.replace(sensorallow + '\n', '').replace('-A CAPTIV_FLASK_18089 -j REJECT --reject-with tcp-reset', '-A CAPTIV_FLASK_18089 -j REJECT --reject-with tcp-reset\n' + sensorallow)),
    dict(name='ipv4_extra_i', ipv4=IPV4.replace(basehook, basehook.replace(' -p tcp', ' -i br-627e7c1ca6d5 -p tcp'))),
    dict(name='ipv4_extra_s', ipv4=IPV4.replace(basehook, basehook.replace(' -p tcp', ' -s 172.18.0.2/32 -p tcp'))),
    dict(name='ipv4_extra_d', ipv4=IPV4.replace(basehook, basehook.replace(' -p tcp', ' -d 172.18.0.1/32 -p tcp'))),
    dict(name='ipv4_inverted_match', ipv4=IPV4.replace(basehook, basehook.replace(' -p tcp', ' ! -s 192.168.0.0/24 -p tcp'))),
    dict(name='ipv6_extra_loopback_source', ipv6=IPV6.replace(base6, base6.replace(' -p tcp', ' -s ::1/128 -p tcp'))),
    dict(name='ipv6_extra_interface', ipv6=IPV6.replace(base6, base6.replace(' -p tcp', ' -i lo -p tcp'))),
    dict(name='ipv6_inverted_match', ipv6=IPV6.replace(base6, base6.replace(' -p tcp', ' ! -i eth0 -p tcp'))),
    dict(name='ipv4_reordered_input', ipv4=IPV4.replace(basehook + '\n', '').replace('-P INPUT ACCEPT\n', '-P INPUT ACCEPT\n-A INPUT -j ACCEPT\n' + basehook + '\n')),
    dict(name='ipv6_reordered_input', ipv6=IPV6.replace(base6 + '\n', '').replace('-P INPUT ACCEPT\n', '-P INPUT ACCEPT\n-A INPUT -j ACCEPT\n' + base6 + '\n')),
    dict(name='missing_terminal_reject', chain=CHAIN.replace('-A CAPTIV_FLASK_18089 -j REJECT --reject-with tcp-reset\n', '')),
    dict(name='extra_allow', chain=CHAIN + '-A CAPTIV_FLASK_18089 -j ACCEPT\n'),
    dict(name='extra_chain_allow_match', chain=CHAIN.replace(baseallow, baseallow.replace(' -j ACCEPT',' -s 10.0.0.0/8 -j ACCEPT'))),
    dict(name='extra_ipv4_hook', ipv4=IPV4 + basehook + '\n'),
    dict(name='extra_tcp_module_ipv4', ipv4=IPV4.replace(basehook, basehook.replace('--dport', '-m tcp --dport'))),
    dict(name='unknown_extra_condition', ipv4=IPV4.replace(basehook, basehook.replace(' -j ', ' -m comment --comment something -j '))),
    dict(name='extra_external_jump', extra_jump='-A FORWARD -p tcp --dport 18089 -j CAPTIV_FLASK_18089\n'),
]

for case in cases:
    label = case.pop('name')
    check_fixtures(**case, expected_pass=False, name=label)

print(f'OFFLINE_FIREWALL_GUARD_FIXTURES=PASS positive=1 negative={len(cases)}')
