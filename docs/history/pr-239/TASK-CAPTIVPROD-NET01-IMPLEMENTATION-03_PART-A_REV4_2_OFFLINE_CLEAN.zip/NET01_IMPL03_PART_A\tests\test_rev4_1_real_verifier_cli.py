"""REV4.1: real verifier parser used by --maintenance-reinstall shell mode."""
import importlib.util
from pathlib import Path
import sys
import pytest

ROOT = Path(__file__).resolve().parents[1]
script = ROOT / "firewall/net01-verify.py"
spec = importlib.util.spec_from_file_location("real_rev41_verifier", script)
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)

def run_real_parser(monkeypatch, tmp_path, flags, maintenance=True, root=True, mode=0o600):
    base = tmp_path / "state"
    base.mkdir(mode=0o700)
    base.chmod(0o700)
    mark = base / "MAINTENANCE"
    hold = base / "HOLD"
    if maintenance:
        mark.write_text("maintenance")
        mark.chmod(mode)
    hold.write_text("hold")
    hold.chmod(0o600)
    calls = []
    monkeypatch.setattr(verifier, "MAINTENANCE_FILE", mark)
    monkeypatch.setattr(verifier, "HOLD_FILE", hold)
    monkeypatch.setattr(verifier.os, "geteuid", lambda: 0 if root else 1000)
    monkeypatch.setattr(verifier, "check_identity", lambda: calls.append("identity"))
    monkeypatch.setattr(verifier, "check_firewall", lambda: calls.append("firewall"))
    monkeypatch.setattr(sys, "argv", ["net01-verify.py", *flags])
    return verifier.main(), calls

def test_real_verifier_accepts_installer_reinstall_flag_contract(monkeypatch, tmp_path):
    installer = (ROOT / "firewall/net01-fw-install.sh").read_text()
    assert "EXTRA=(--ignore-maintenance --ignore-hold)" in installer
    assert '"$GUARD" --identity "${EXTRA[@]}"' in installer
    rc, calls = run_real_parser(monkeypatch, tmp_path, ["--identity", "--ignore-maintenance", "--ignore-hold"])
    assert rc == 0 and calls == ["identity"]

def test_real_verifier_accepts_post_install_firewall_check(monkeypatch, tmp_path):
    rc, calls = run_real_parser(monkeypatch, tmp_path, ["--all", "--ignore-maintenance", "--ignore-hold"])
    assert rc == 0 and calls == ["identity", "firewall"]

@pytest.mark.parametrize("flags,maintenance,root,mode", [
    (["--identity", "--ignore-maintenance", "--ignore-hold"], False, True, 0o600),
    (["--identity", "--ignore-maintenance", "--ignore-hold"], True, False, 0o600),
    (["--identity", "--ignore-maintenance", "--ignore-hold"], True, True, 0o644),
    (["--identity", "--ignore-hold"], True, True, 0o600),
    (["--identity", "--ignore-maintenance"], False, True, 0o600),
    (["--all", "--ignore-maintenance", "--ignore-hold"], False, True, 0o600),
    (["--all", "--ignore-maintenance", "--ignore-hold"], True, False, 0o600),
])
def test_real_verifier_rejects_unsafe_recovery(monkeypatch, tmp_path, flags, maintenance, root, mode):
    rc, calls = run_real_parser(monkeypatch, tmp_path, flags, maintenance, root, mode)
    assert rc == 75 and calls == []

@pytest.mark.parametrize("flags", [["--identity"], ["--all"]])
def test_normal_start_must_fail_closed_with_latches(monkeypatch, tmp_path, flags):
    rc, calls = run_real_parser(monkeypatch, tmp_path, flags)
    assert rc == 75 and calls == []
