## REV4 strict maintenance/rollback and race closure (review-only)

**No NET01 firewall changes without Owner GO and independent acceptance.** Do not execute commands from this package on `captiv-prod` now.

1. `net01-maintenance-enter.sh` (root) obtains NET01 flock, **creates and fsyncs root-owned 0600 MAINTENANCE marker first**, stops only new `captive-portal.service` and `captiv-net01-watchdog.service`, then obtains strict `net01-quiescent.py --mode quiescent` proof. A failed stop, systemctl/ss error, status other than `inactive/dead`, any pending `start/stop` job, or 18089 listener => HOLD, marker remains. If the stop attempt encounters a non-responding systemd, do not manually remove firewall.
2. `net01-fw-rollback.sh` independently locks, requires the marker, obtains strict quiescence, verifies exact IPv4+IPv6 owned firewall state with `net01-verify.py --firewall-only`, repeats quiescence, and removes only the known six exact commands. Unknown rules/partial install => ZERO deletions. Ordinary startup cannot pass root-owned MAINTENANCE; lock blocks concurrent prestart. If deletion fails partway, never retry blindly; preserve marker and exact diagnostic evidence for security review.
3. In an approved recovery window, with MAINTENANCE still latched and app stopped, `net01-fw-install.sh --maintenance-reinstall` can reinstall; normal systemd firewall service invocation uses **no flags** and refuses MAINTENANCE. Only after exact guard PASS and strict quiescence may an operator run `net01-clear-hold-review-only.sh` and `net01-clear-maintenance-review-only.sh` in that order. Marker deletion is root-only, no symlink, exact regular file 0600. Both commands leave app stopped. Manual start after recovery; never reset failed state or start new Flask automatically.
4. `net01-start-admit.sh` is root ExecStartPre for **both** watchdog and Flask; obtains same lock and checks MAINTENANCE absent and complete `--all` guard. Watchdog's runtime guard detects MAINTENANCE drift and exits (systemd BindsTo must stop Flask). No unauthorized direct start is permitted. An arbitrarily privileged operator overriding systemd/markers/firewall is outside the trust boundary; a small race with concurrent privileged mutation or systemd failure cannot be disproved with mocks.
5. `net01-quiescent.py --mode install` differs intentionally from rollback quiescence: it accepts only a **verified, matching `start` job for Flask/watchdog** queued behind the firewall unit (required during cold boot), while `LoadState=loaded`, `ActiveState=inactive`, `SubState=dead` and TCP 18089 unbound remain mandatory. Any unexpected/unknown systemd job, current activation, TCP listener, or failed command yields HOLD. Validate this ordering with real systemd PID1 before GO.

### Required isolated systemd PID1 acceptance after REV4 independent review

- With dummy `captive-portal.service` and watchdog, confirm all effective dependencies and privilege separation. Instrument listener; do not use live Portal or NPM.
- Deliberately fail `systemctl show` and `ss` availability; verify admission, rollback and HOLD-clear fail, markers preserved, **zero firewall deletion**, and no dummy listener.
- Inject `activating`, `deactivating`, `failed`, pending `start`/`stop` job, stop latency, and simultaneous `systemctl start` vs maintenance/rollback; ensure new-start cannot open listener after maintenance admission and firewall removal.
- Simulate Docker Engine up but NPM not yet ready; watchdog `READY` withheld and app bind absent. Later manual remediation, no unsafe auto-restart.
- Test watchdog deliberate stop, crash, SIGKILL, OnFailure, timeout, sticky HOLD, no restart and listener disappearance; verify stop works on the actual manager, not just mocks.
- Perform rollback positive with exact ownership; introduce stale/modified hook and partial chain => HOLD with zero deletion; test unexpected command error during deletion => still MAINTENANCE and no automatic cleanup.
- Measure observation-to-stop latency, post-stop `ss`, journal and `systemctl list-jobs`. Include root-owned file tests and make sure forbidden Docker socket is inaccessible to Flask user.

### Test boundary

REV4 mock/unit tests are not a live systemd PID1 test, not an iptables enforcement test and not a proof of cross-container isolation. Hold `PART_B=NOT_AUTHORIZED` until independent review and actual staging lifecycle passes.

# NET01 вЂ” REV4 acceptance and rollback runbook (PROPOSED / NOT EXECUTED)

## Operator prerequisites (future Owner GO only)

1. Independent Architect approval of REV3, accepted Git release with configurable HOST/PORT and exact new Omada Site/CAPPORT FQDN; isolated staging lifecycle PASS.
2. Approved maintenance window/backup of NPM and existing proxy routes, old certificate fingerprint and process/network/firewall baseline; documented fallback.
3. Install scripts and root-only systemd units from reviewed artifact with root owner and non-app-writable permissions; new Flask `User=captivportal`, no supplementary Docker group, no Docker socket permission.
4. Do **not** auto-run `docker compose up/down`, remove Docker network, alter Omada, or enable public Proxy Host during setup. NPM container recreate requires separate consent.
5. Check pinned network ID/bridge/gateway/IP/MAC and local OCI/image ID with independent read-only commands.

## Correct cold boot / startup ordering

1. Docker daemon and NPM appear; if daemon is up but NPM absent/not ready, watchdog guard FAIL and no listener. `Restart=no`; operator fixes NPM and manually retries after approved HOLD review.
2. Root firewall oneshot installs known rules after Docker identity validation and before any Flask bind.
3. `captive-portal.service` transaction pulls watchdog via `BindsTo`; watchdog `Type=notify` must emit READY after initial guard PASS; Flask is ordered `After` it.
4. Flask root-only `ExecStartPre=+... --all` rechecks policy; process itself runs under `User=captivportal`, listens ONLY `172.18.0.1:18089`.
5. If watchdog deliberately stops, crashes, fails to start, or receives SIGKILL, systemd `BindsTo` must stop Flask and `ExecStopPost` must set HOLD. OnFailure independent failsafe confirms and escalates if needed. Do not rely on OnFailure for manual stop.
6. `Restart=no` for app/watchdog, plus sticky HOLD: no automatic restart. Operator must correct, reset failed state as needed, clear marker via reviewed script and manually restart.

## Isolated Ubuntu staging (mandatory before Part B)

- Build disposable systemd PID1 VM or container with **dummy** non-production Flask listener and mock Docker/firewall guard; never use real NPM or guest traffic.
- Verify `systemctl cat`, `systemctl show -p User -p Group -p ExecStartPre -p ExecStart -p After -p BindsTo -p Restart` and actual `/proc/$PID/status` Uid/Gid, `id` and Docker socket denial from Flask user.
- Test valid initial Docker+firewall guard, READY ordering, and listener opens only after watchdog READY.
- Test Docker Engine unavailable at cold boot, Docker active but NPM container delayed, firewall guard reject; **no** bound TCP 18089, no restart loop.
- Test `systemctl stop captiv-net01-watchdog`, unexpected exit (`kill` watchdog main PID), systemctl kill --signal=SIGKILL, timeout of verification; Flask must stop, 18089 must unbind, HOLD latched, no restart.
- Test watchdog unit `OnFailure` actually starts independent failsafe; ensure no job cycles/deadlocks. Explicit stop is verified via BindsTo (OnFailure may not fire).
- Test failsafe marker creation failure while stop still occurs; graceful `systemctl stop` timeout, SIGKILL fallback scoped only to dummy app; listener and service stopped or FAIL with critical alarm.
- Test startup after HOLD: Flask must reject; after explicit admin recovery and `systemctl reset-failed`, only operator can start.
- Privileged stop or administrator tampering is outside the root threat boundary; document maximum observed detection+stop latency.

## Future real Part B positive/negative network tests (NOT EXECUTED)

- NPM container to `172.18.0.1:18089` permitted, responds actual Flask; other containers and network namespaces denied; LAN/Guest/WAN denied; IPv6 denied.
- Do not attach a second Docker container to NPM network while membership guard==1. Authorized temporary Linux network namespace/veth can test a distinct source IP/MAC without Docker membership mutation; clean up fully.
- Verify `Host`, `Proto`, `Port`, trusted client IP, `X-Forwarded-*` spoof rejection, safe HTTP logs and no Admin exposed.
- Check post-install/POST-restart NPM and old Portal/Nextcloud/VPN/Omada unchanged.
- Docker recreate and full reboot acceptance require separate window and rollback plan.

## Firewall rollback: exact-state ownership gate

1. Authorized operator stops **new** Flask; verify inactive and `ss` no listener on 18089; stops watchdog, confirms HOLD latched.
2. `net01-fw-rollback.sh` acquires exclusive NET01 lock and runs `net01-verify.py --firewall-only`, which ignores sticky HOLD but does not need Docker, and checks the entire approved owned ruleset.
3. If a rule is modified, missing, reordered, duplicated, stale, or unexpected: **HOLD with zero rule deletion**. Preserve exact `iptables -S`, `ip6tables -S` evidence and request manual security review; do not flush.
4. If exact posture verified, remove only named first INPUT jump, chain allow, terminal reject, empty chain, then first IPv6 reject. Error at any step: HOLD/manual review, never blanket cleanup.
5. Retain HOLD until reviewed recovery; rollback Compose only in approved maintenance window. Recheck SSH and old NPM proxies.
6. Recovery of HOLD is NOT automatic: owner reviews root-only state, identity, firewall and active unit, runs reviewed clear script after all PASS, resets failed states, manually starts Flask and rechecks watchdog.

## Unavoidable residual security risks

- A periodically sampled watchdog cannot atomically guarantee reaction to privileged firewall tampering. The interval is 2 sec + guard deadline 15 sec + service-stop latency; stalled kernel/systemd and root adversary can bypass.
- BindsTo lifecycle depends on functioning systemd and exact installed unit configuration; isolated stage is REQUIRED before trusting it.
- `flock` coordinates NET01 scripts, not arbitrary root modifications. Firewall deletion steps cannot be atomic against other root actors.
- Docker IP+MAC is not cryptographic container authentication. No public routing until all acceptance gates PASS.
