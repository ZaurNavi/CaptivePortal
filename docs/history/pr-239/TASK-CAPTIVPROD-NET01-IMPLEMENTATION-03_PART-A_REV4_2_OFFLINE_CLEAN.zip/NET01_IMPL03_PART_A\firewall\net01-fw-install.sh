#!/usr/bin/env bash
# REV4: network identity and systemd/listener checks fail-closed; review only.
set -euo pipefail
umask 077
(( EUID == 0 )) || { echo 'HOLD: root required' >&2; exit 75; }
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
PROBE=/usr/local/libexec/captiv-net01/net01-quiescent.py
MAINT=/usr/local/libexec/captiv-net01/net01-maintenance-state.py
CHAIN=CAPTIV_FLASK_18089
exec 9>/run/lock/captiv-net01-firewall.lock
flock -n 9 || { echo 'HOLD: NET01 operation busy' >&2; exit 75; }
# --maintenance-reinstall is MANUAL ONLY. Never set on systemd ExecStart.
if [[ "${1:-}" == '--maintenance-reinstall' && "$#" == 1 ]]; then
  /usr/bin/python3 "$MAINT" require || exit 75
  EXTRA=(--ignore-maintenance --ignore-hold)
else
  (( $# == 0 )) || { echo 'HOLD: unexpected arguments' >&2; exit 75; }
  /usr/bin/python3 "$MAINT" absent || exit 75
  EXTRA=()
fi
/usr/bin/python3 "$GUARD" --identity "${EXTRA[@]}" || exit 75
# install mode tolerates an ordered pending Flask start-job, never a live service.
/usr/bin/python3 "$PROBE" --mode install || exit 75
# Never confuse iptables query FAILURE with "no chain".
# A complete -S snapshot must be readable before *any* mutation.
POLICY=$(iptables -w -S) || { echo 'HOLD: cannot inspect IPv4 policy' >&2; exit 75; }
IPV6_POLICY=$(ip6tables -w -S INPUT) || { echo 'HOLD: cannot inspect IPv6 INPUT policy' >&2; exit 75; }
if grep -Fq -- "$CHAIN" <<< "$POLICY"; then
  # Existing exact firewall only; a partial/stale policy must HOLD.
  /usr/bin/python3 "$GUARD" --all "${EXTRA[@]}" || exit 75
  exit 0
fi
# If no dedicated chain exists, reject any stale rule already mentioning port.
if grep -Eq -- '(^|[[:space:]])--dport[[:space:]]+18089([[:space:]]|$)' <<< "$POLICY"; then
  echo 'HOLD: stale IPv4 port rules without approved chain' >&2; exit 75
fi
if grep -Eq -- '(^|[[:space:]])--dport[[:space:]]+18089([[:space:]]|$)' <<< "$IPV6_POLICY"; then
  echo 'HOLD: stale IPv6 backend rule' >&2; exit 75
fi
# NO listener, systemd states verified, no known chain; install deny-first.
iptables -w -N "$CHAIN"
iptables -w -A "$CHAIN" -j REJECT --reject-with tcp-reset
iptables -w -I INPUT 1 -p tcp --dport 18089 -j "$CHAIN"
iptables -w -I "$CHAIN" 1 \
  -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc \
  -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
iptables -w -I "$CHAIN" 2   -i lo -s 172.18.0.1/32 -d 172.18.0.1/32   -p tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
ip6tables -w -I INPUT 1 -p tcp --dport 18089 -j REJECT --reject-with tcp-reset
/usr/bin/python3 "$GUARD" --all "${EXTRA[@]}" || exit 75
