# NET01 REV4.2 — offline extension handoff (15 Oct 2026)

Source: accepted REV4.1 offline candidate, preserved unchanged.
Purpose: close exact local-origin Sensor TCP readiness path alongside unchanged Docker NPM-only path.
No target or NPM mutations. Architecture / independent review still HOLD.

## Exact intended protected chain
- IPv4 first INPUT hook: unconditional TCP dport 18089 -> CAPTIV_FLASK_18089.
- Chain position 1: NPM container 172.18.0.2, bridge br-627e7c1ca6d5, MAC b2:fa:fc:bf:d5:bc, destination 172.18.0.1:18089, conntrack NEW/ESTABLISHED.
- Position 2: -i lo, source 172.18.0.1/32, destination 172.18.0.1/32, TCP 18089, conntrack NEW/ESTABLISHED.
- Position 3: terminal REJECT (tcp-reset). IPv6 first INPUT: TCP 18089 REJECT.

IMPORTANT: position 2 authorizes host-local origin; it is NOT per-Sensor UID security. A stronger provenance control requires a separate reviewed OUTPUT owner/cgroup/app-auth policy. Do not imply process-level exclusivity.

## Synchronized changes
Firewall installer, exact verifier (chain length and ordered rule matching), rollback (six exact owned mutations), watchdog full-guard semantics, tests, and reference commands. REV4.1 maintenance-reinstall operator-root + 0600 MAINTENANCE latch remains.
Mock fixture uses real verifier main()/CLI with stubbed identity + packet-filter read primitives: no live iptables or Docker writes.
Linux WSL Ubuntu-22.04 isolated scratch: 104 pytest tests PASS (runner /tmp/net01_rev41_venv, synthetic fixtures).
Real WSL systemd PID1 synthetic watchdog/back-end: Type=notify readiness, BindsTo stop, listener removal, guard fail-closed PASS. These are synthetic service units, not actual production NET01 systemd+iptables lifecycle.
Run tests/staging_pid1_synthetic_manual.py only on disposable WSL Ubuntu with real PID1; it cleans up /run/systemd/system units and fixture files. Never run on captiv-prod.

## Remaining acceptance before part B
Real NET01 unit files and iptables in isolated throwaway host; deny probes from Docker non-NPM, other VLANs, WAN, IPv6; allow exact NPM/local; runtime watchdog drift, failure/recovery/rollback and Docker recreation identity checks; no public NPM change prior scoped GO.
ARCH06_PREINSTALL_READY=HOLD
