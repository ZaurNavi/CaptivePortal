# NET-01 P1-A/P1-B — Architect-approved integrated offline correction

Baseline: NET01_INTEGRATED_STARTUP_JOB_FIX_OFFLINE.zip (SHA-256: 850a978beec1de6ac6945b065841cdd7e5ccc09a24d5221645e73db0215a1428).

- P1-A: watchdog `ProtectSystem=strict` now explicitly permits writing **only** `/var/lib/captiv-net01` and `/run/lock/captiv-net01-firewall.lock`. Privileged start guard remains root-owned; Flask remains unprivileged and has no Docker socket. Systemd cold startup and `/run/lock` file reconstruction confirmed in isolated staging; file owner UID=0, mode 0600.
- P1-B: host-local INPUT admits TCP/18089 on `lo` with exact destination 172.18.0.1 and conntrack original source/destination both 172.18.0.1. Do **not** match the post-SNAT source host IP. Installed `--ctorigsrc 172.18.0.1/32` and `--ctorigdst 172.18.0.1/32` are canonicalized by iptables-nft `-S` to unmasked single-host addresses; verifier requires precisely that normalized output.
- OUTPUT remains destination-bound to 172.18.0.1:18089 and allow is restricted to `fingerprint-sensor` UID, local origin and `lo`, plus terminal REJECT. NPM INPUT allow remains pinned to approved interface, IPv4, MAC, state; IPv6 first-hook reject unchanged.
- Installer, exact verifier and rollback updated together. Existing sticky HOLD/MAINTENANCE and startup admission rules unchanged; runtime watchdog uses verifier `--all` unchanged.
- Addressed 10 targeted original-tuple / least-privilege lock fixtures. Tests: 180 passed.
- Real Docker 29.1.3 + NPM approved image, systemd 249 PID 1, iptables-nft and `conntrack` in isolated WSL2: positive/negative/connectivity/lifecycle/rollback/reinstall/lock cold start/foreign-container watchdog drift PASS, synthetic HTTP backend only. See TEST_RESULTS_P1AB_REAL_STAGING.txt.
- No Cisco, old Portal/Omada, new `captiv-prod`, NPM production, or CaptivePortal installation changed. No production activation authorized.
