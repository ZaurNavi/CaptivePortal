"""NPM+Sensor next revision: exact INPUT/OUTPUT shape and negative denial fixtures.
No privileged network/systemd/Docker operations.
"""
from __future__ import annotations
import importlib.util
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('net01_rev5_verify', ROOT/'firewall/net01-verify.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)
NPM_HOOK = '-A INPUT -p tcp -m tcp --dport 18089 -j CAPTIV_FLASK_18089\n'
SENSOR_HOOK = '-A OUTPUT -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -j CAPTIV_SENSOR_OUT_18089\n'
NPM_ALLOW = '-A CAPTIV_FLASK_18089 -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n'
SENSOR_IN = '-A CAPTIV_FLASK_18089 -i lo -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED --ctorigsrc 172.18.0.1 --ctorigdst 172.18.0.1 -j ACCEPT\n'
SENSOR_OUT = '-A CAPTIV_SENSOR_OUT_18089 -o lo -s 172.18.0.1/32 -d 172.18.0.1/32 -p tcp -m tcp --dport 18089 -m owner --uid-owner 17042 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT\n'
REJECT_IN='-A CAPTIV_FLASK_18089 -p tcp -j REJECT --reject-with tcp-reset\n'
REJECT_OUT='-A CAPTIV_SENSOR_OUT_18089 -p tcp -j REJECT --reject-with tcp-reset\n'
IP6='-P INPUT ACCEPT\n-A INPUT -p tcp -m tcp --dport 18089 -j REJECT --reject-with tcp-reset\n'


def proof(monkeypatch, *, input=None, output=None, inchain=None, outchain=None, ipv6=None, extra=''):
    inp=input if input is not None else '-P INPUT ACCEPT\n'+NPM_HOOK+'-A INPUT -d 192.168.0.99/32 -i enp2s0 -j CAPTIV_OMADA_GUARD\n'
    out=output if output is not None else '-P OUTPUT ACCEPT\n'+SENSOR_HOOK
    cin=inchain if inchain is not None else '-N CAPTIV_FLASK_18089\n'+NPM_ALLOW+SENSOR_IN+REJECT_IN
    cout=outchain if outchain is not None else '-N CAPTIV_SENSOR_OUT_18089\n'+SENSOR_OUT+REJECT_OUT
    ip6=ipv6 if ipv6 is not None else IP6
    def fake(*args):
        if args[:3]==('iptables','-w','-S'):
            if len(args)==3:return inp+out+cin+cout+extra
            return {'INPUT':inp,'OUTPUT':out,g.CHAIN:cin,g.SENSOR_OUT_CHAIN:cout}[args[3]]
        if args[:3]==('ip6tables','-w','-S'):
            return ip6
        raise AssertionError(args)
    monkeypatch.setattr(g,'command',fake)
    monkeypatch.setattr(g,'sensor_uid',lambda:'17042')
    g.check_firewall()


def test_dual_path_strict_positive(monkeypatch):
    proof(monkeypatch)


@pytest.mark.parametrize('which,old,new',[
    ('input',NPM_HOOK,NPM_HOOK.replace('-p tcp','-i br-627e7c1ca6d5 -p tcp')),
    ('input',NPM_HOOK,NPM_HOOK.replace('-p tcp','-s 172.18.0.2/32 -p tcp')),
    ('output',SENSOR_HOOK,SENSOR_HOOK.replace('-d 172.18.0.1/32','-d 172.18.0.2/32')),
    ('output',SENSOR_HOOK,SENSOR_HOOK.replace('-A OUTPUT ','-A OUTPUT -o lo ')),
    ('output',SENSOR_HOOK,SENSOR_HOOK.replace('-p tcp','-s 172.18.0.1/32 -p tcp')),
    ('inchain',NPM_ALLOW,NPM_ALLOW.replace('b2:fa:fc:bf:d5:bc','b2:fa:fc:bf:d5:bd')),
    ('inchain',SENSOR_IN,SENSOR_IN.replace('-i lo ','-i br-627e7c1ca6d5 ')),
    ('inchain',SENSOR_IN,SENSOR_IN.replace('--ctorigsrc 172.18.0.1','--ctorigsrc 0.0.0.0')),
    ('inchain',SENSOR_IN,SENSOR_IN.replace('-d 172.18.0.1/32 ','-d 0.0.0.0/0 ')),
    ('inchain',REJECT_IN,''),
    ('outchain',SENSOR_OUT,SENSOR_OUT.replace('--uid-owner 17042','--uid-owner 0')),
    ('outchain',SENSOR_OUT,SENSOR_OUT.replace('-o lo ','-o br-627e7c1ca6d5 ')),
    ('outchain',SENSOR_OUT,SENSOR_OUT.replace('-m owner --uid-owner 17042 ','')),
    ('outchain',REJECT_OUT,''),
    ('outchain',REJECT_OUT,REJECT_OUT.replace('REJECT','ACCEPT')),
    ('ipv6',IP6,IP6.replace('-A INPUT -p','-A INPUT -s ::1/128 -p')),
])
def test_exact_violation_holds(monkeypatch,which,old,new):
    base={
      'input':'-P INPUT ACCEPT\n'+NPM_HOOK+'-A INPUT -d 192.168.0.99/32 -i enp2s0 -j CAPTIV_OMADA_GUARD\n',
      'output':'-P OUTPUT ACCEPT\n'+SENSOR_HOOK,
      'inchain':'-N CAPTIV_FLASK_18089\n'+NPM_ALLOW+SENSOR_IN+REJECT_IN,
      'outchain':'-N CAPTIV_SENSOR_OUT_18089\n'+SENSOR_OUT+REJECT_OUT,
      'ipv6':IP6,
    }
    with pytest.raises(RuntimeError):
        proof(monkeypatch,**{which:base[which].replace(old,new)})


@pytest.mark.parametrize('which,line',[
    ('inchain','-A CAPTIV_FLASK_18089 -j ACCEPT\n'),
    ('outchain','-A CAPTIV_SENSOR_OUT_18089 -j ACCEPT\n'),
    ('input',NPM_HOOK),
    ('output',SENSOR_HOOK),
])
def test_unexpected_extra_rule_holds(monkeypatch,which,line):
    base={
      'input':'-P INPUT ACCEPT\n'+NPM_HOOK,
      'output':'-P OUTPUT ACCEPT\n'+SENSOR_HOOK,
      'inchain':'-N CAPTIV_FLASK_18089\n'+NPM_ALLOW+SENSOR_IN+REJECT_IN,
      'outchain':'-N CAPTIV_SENSOR_OUT_18089\n'+SENSOR_OUT+REJECT_OUT,
    }
    with pytest.raises(RuntimeError):
        proof(monkeypatch,**{which:base[which]+line})


def test_unexpected_global_reference_holds(monkeypatch):
    with pytest.raises(RuntimeError):
        proof(monkeypatch,extra='-A FORWARD -j CAPTIV_SENSOR_OUT_18089\n')


def test_uid_absent_holds(monkeypatch):
    monkeypatch.setattr(g.pwd,'getpwnam',lambda _: (_ for _ in ()).throw(KeyError('missing')))
    with pytest.raises(KeyError):g.sensor_uid()


def test_root_uid_holds(monkeypatch):
    monkeypatch.setattr(g.pwd,'getpwnam',lambda _:type('P',(),{'pw_uid':0})())
    with pytest.raises(RuntimeError):g.sensor_uid()


def test_watchdog_checks_verifier_all_mode():
    s=(ROOT/'firewall/net01-runtime-watchdog.py').read_text()
    assert "str(GUARD), '--all'" in s


def test_rollback_checks_complete_rules_before_deletion():
    s=(ROOT/'firewall/net01-fw-rollback.sh').read_text()
    assert s.index('"$GUARD" --firewall-only') < s.index('iptables -w -D INPUT')
    assert s.index('"$PROBE" --mode quiescent') < s.index('iptables -w -D INPUT')
    assert '-D OUTPUT' in s
    assert '-m owner --uid-owner "$SENSOR_UID"' in s

from rev4_fixture import isolated


def test_installer_holds_without_sensor_uid_no_mutation():
    with isolated(SENSOR_ID_FAIL='1') as (_root,_env,run,_hold,_maint,_log):
        result,mut=run('net01-fw-install.sh')
        assert result.returncode!=0
        assert mut==[]


def test_rollback_holds_without_sensor_uid_no_mutation():
    with isolated(SENSOR_ID_FAIL='1') as (_root,_env,run,hold,maint,_log):
        result,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
        assert result.returncode!=0
        assert mut==[]
        assert hold.exists() and maint.exists()


def test_install_mock_ten_owned_steps():
    with isolated() as (_root,_env,run,_hold,_maint,_log):
        result,mut=run('net01-fw-install.sh')
        assert result.returncode==0,(result.stderr,result.stdout)
        assert len(mut)==10 and any(' -I OUTPUT ' in m for m in mut)
        assert any('--uid-owner 17042' in m for m in mut)
        assert not any(' -F ' in m for m in mut)


def test_rollback_mock_ten_exact_steps_sticky_latches():
    with isolated() as (_root,_env,run,hold,maint,_log):
        result,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
        assert result.returncode==0,(result.stderr,result.stdout)
        assert len(mut)==10 and any(' -D OUTPUT ' in m for m in mut)
        assert hold.exists() and maint.exists()


@pytest.mark.parametrize('case',[
    {'SYSTEMCTL_FAIL':'1'}, {'SS_FAIL':'1'}, {'UNIT_STATE':'activating'},
    {'JOB_LIST':'start'}, {'SS_LISTENER':'1'}, {'GUARD_RC':'75'},
])
def test_integrated_rollback_no_changes_on_unsafe_state(case):
    with isolated(**case) as (_root,_env,run,hold,maint,_log):
        result,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
        assert result.returncode!=0
        assert mut==[] and hold.exists() and maint.exists()
