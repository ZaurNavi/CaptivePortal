# New Omada HTTPS/OpenAPI — read-only evidence and remaining gates

Endpoint 192.168.0.99:8043; controller reported 5.14.32.3 / apiVer=3.
Certificate CN=localhost / SAN DNS:Omada / self-signed; observed SHA256 leaf:
EE:07:E9:1D:2B:A9:62:81:3E:EA:10:23:E2:66:72:BC:76:1E:21:A9:61:CF:5D:E4:6F:14:80:89:D3:BC:28:DB

LIVE READ-ONLY anonymous strict TLS proof:
- Controlled mapping Omada:8043 -> 192.168.0.99
- Ephemeral trust of the observed leaf in --cacert process substitution
- URL https://Omada:8043/api/info, curl TLS verify_result=0 and HTTP 200.
- No -k / verify=False / credential submission in this test.
- This tests TLS chain & name when leaf is explicitly trusted, NOT independent
  third-party identity: before credential submission Owner must approve pinned
  leaf fingerprint out-of-band or new proper CA-issued cert with SAN.
- Permanent implementation: fixed root-owned PEM trust path, pin exact cert,
  hosts/resolver mapping for Omada (no global DNS mutation before GO), alert
  on fingerprint/expiry drift. Avoid trusting arbitrary leaf fetched live.

OMADA_SITE_ID=HOLD_CREDENTIALS_AND_APPROVED_CERT_PIN
OMADA_AP_WLAN_HOTSPOT_WEBHOOK=NOT_TESTED
OMADA_OPENAPI_PERMISSIONS=NOT_TESTED
`omadacId` is 32 hex controller identifier, NOT 24-hex Site ID.

After Owner-approved trusted certificate: use the separately provided new
Omada client id/secret exclusively from a root-protected temporary credential
source; no secrets in CLI, logs, URLs or reports. Invoke documented v5.14.32.3
client_credentials then read-only Site list, AP inventory, WLAN, Hotspot,
external portal, webhook and permissions. Record Site ID only from response.
Rotate client secret before go-live. No adopt/reconnect/mutation.
