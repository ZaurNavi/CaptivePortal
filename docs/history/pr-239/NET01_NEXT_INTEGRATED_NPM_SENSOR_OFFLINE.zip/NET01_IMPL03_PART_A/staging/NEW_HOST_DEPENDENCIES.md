# New Captiv-Prod dependency design — not installed

```
Docker + NPM pinned identity -> firewall INPUT+OUTPUT rules verified
  -> NET01 root watchdog Type=notify READY -> Flask non-root binds 172.18.0.1:18089
  -> Sensor (unprivileged fingerprint-sensor UID) readiness TCP connect
  -> Sensor validates Evidence CA/bearer/spool -> opens UNIX_DGRAM EVE socket
  -> Suricata on enp3s0 waits for verified live EVE socket (45 sec candidate)
  -> normalized network evidence to local HTTPS Evidence Receiver
```

The accepted repository's old Suricata template references enp8s0, uses
ExecStartPre socket wait 1830 sec but default effective start timeout 90 sec.
The socket is NOT created by Suricata: code path app/device_fingerprint_sensor/
cli.py -> runtime.start() -> eve.EveReceiver.open() creates UNIX_DGRAM,
mode 0660, group fingerprint-eve; parent 0750. Stale paths must not count
as ready: staging helper checks inode/mode/owner and connect(no send).

Do not infer EVE readiness from a Type=simple `After=sensor.service` alone.
Suricata candidate relies on dedicated ready check, bounded wait. Measure
actual `suricata -T` + startup latency in staging before selecting timeout.
Default-log-dir remains separate `/run/fingerprint-suricata`; socket-only EVE,
no raw PCAP/regular EVE file. NIC= enp3s0, no L3 address, forwarding=1 currently;
scoped forwarding=0 only after separate scoped Owner GO, preserve global=1.

Legacy dependency references are not new-host facts: old edge-bridge Requires
Core, network-metadata rotation is timer/oneshot with weaker After; do not
blindly copy IOWeights, TimeoutSec, or dependency loops.

Resource envelope: root `/` on ROTA=0 sda; `/srv/backups` on ROTA=1 sdb,
15GiB RAM with 13GiB available at read-only snapshot. Use explicit
CPUQuota/MemoryMax and collect physical disk IO (iostat, PSI, cgroup v2
io.stat) before selecting IOWeight/limits. No install or enabling services.
