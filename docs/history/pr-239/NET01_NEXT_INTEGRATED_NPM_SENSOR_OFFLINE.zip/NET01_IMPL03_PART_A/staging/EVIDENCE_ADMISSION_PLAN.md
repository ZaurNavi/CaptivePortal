# Evidence Receiver / Sensor and Portal Producer (offline only)

- Listener candidate: HTTPS 127.0.0.1:9443; no external bind/proxy.
- TLS: CA-controlled server certificate SAN IP:127.0.0.1; key 0600 and
  root-owned CA distribution. `https://127.0.0.1` must verify successfully.
- Distinct credential IDs and secrets for (a) network Sensor and (b) Portal
  Producer; use systemd LoadCredential for Sensor and protected external path
  for Portal, NOT in Git/env/reports. Rotate at admission and before go-live.
- Registration: explicit producer_id, capture_source_id, 24-hex site ID, guest
  CIDR, evidence families, caller transport policy; no inherited old identities.
- F-B1: separately validate source binding/clock/emitter/health/retention,
  freshness and admissibility, provenance, activation manifest, Owner gates.
  HTTP 200/acceptance does not imply F-B1 source admission.
- Storage: new empty Evidence SQLite and Sensor spool, permission/owner proof,
  never repurpose legacy nonempty store or change lineage in place.
- Portal Producer remains disabled until Core, TLS, identity and Source
  Admission acceptance. Evidence receiver currently not listening at :9443.
- Test negative localhost unrelated UID, bearer reuse, wrong Source/Site,
  expired/missing trust, malformed event, denied interface, old/new identity
  mix and undeclared evidence kinds in isolated staging.
