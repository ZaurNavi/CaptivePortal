# Isolated acceptance: tests NOT EXECUTED

1. Environment: isolated Ubuntu 22.04 VM with real systemd PID1, fresh Docker
   and NET01 network identity fixture; no production NPM/Omada/Cisco connection.
2. Before startup create dedicated `fingerprint-sensor` unprivileged user and
   group; pin numeric UID in evidence; verify no Docker group/socket access.
3. Deploy only staging diagnostic HTTP backend bound `172.18.0.1:18089`, which
   returns sanitized remote address, Host, scheme and proxy headers; no real Portal.
4. Install proposed dual-path firewall only after known quiescent state and
   app+watchdog stopped. Verify exact INPUT first hook + OUTPUT first hook,
   owned chains, IPv6 deny and idempotent re-install; test partial install HOLD.
5. Positive: actual NPM container connects on bridge; host process running with
   `fingerprint-sensor` UID connects to `172.18.0.1:18089` via lo.
6. Negative: root/other unprivileged host UIDs; different UID in same group;
   other Docker net, foreign container; LAN, Guest and WAN simulators; IPv6;
   spoofed Host and X-Forwarded-* through an actual configured NPM proxy.
   Avoid adding a test container to NPM network while membership guard==1.
7. Startup lifecycle: watchdog MUST be READY=1 first, then prestart guard,
   then Flask listener. Check no listener with watchdog absent or intentionally
   stopped, crashed, SIGKILLed, timed out, Docker unavailable, identity changed,
   policy drift, queued start-job and concurrent maintenance rollback.
8. Rollback: enter root-only MAINTENANCE; stop/kill only test app; verify no
   pending jobs/listener; exact owned firewall verification; delete only rules.
   Unknown state/partial policy must cause HOLD with zero mutations.
9. Cold boot: docker daemon ready, NPM not ready => HOLD; separate recovery
   with exact identity and manual restart, no automatic bypass.
10. Proxy: negative spoof XFF/XFP with controlled payload; correct downstream
    scheme/Host/client IP; TLS/SNI; new Proxy Host only after live GO.
11. Evidence: test TLS certificate SAN IP:127.0.0.1 & CA, distinct bearer
    rejected across producers, empty receiver SQLite/spool, F-B1 admission HOLD.

No systemd PID1, live firewall, NPM recreate or negative network acceptance has
been run in this task. All require new scoped GO on isolated staging.
