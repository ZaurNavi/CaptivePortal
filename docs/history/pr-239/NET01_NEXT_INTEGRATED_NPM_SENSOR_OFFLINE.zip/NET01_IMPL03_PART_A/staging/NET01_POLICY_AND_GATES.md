# NET-01 integrated policy — review candidate, NOT DEPLOYED

Source baseline NET01_REV4_1_FULL.zip SHA256:
`0bb12d269f8ae0826786c71c3ba2bb3f43ac54dc4c3c1a26500bf2d67a155687`
Existing network ID, gateway, bridge and NPM IP/MAC pin are unchanged.

1. IPv4 INPUT first hook intercepts all TCP :18089 into CAPTIV_FLASK_18089.
   Allow NPM exact (bridge, src, dst, MAC, conntrack), then local exact
   (iif=lo, src=172.18.0.1/32, dst=172.18.0.1/32); terminal REJECT.
2. IPv4 OUTPUT first hook intercepts local dst=172.18.0.1/32 TCP :18089
   into CAPTIV_SENSOR_OUT_18089. Allow iff locally generated traffic has
   out=lo, src/dst gateway/32, UID == dedicated fingerprint-sensor, conntrack;
   terminal REJECT. This is the per-process protection absent from loose lo
   input-only alternatives. No global OUTPUT policy changes.
3. IPv6 INPUT first hook rejects TCP :18089. Flask binds IPv4 bridge only.
4. Numeric sensor UID is resolved at installation/verification/rollback;
   missing user or owner changed -> HOLD, no backend activation. The service
   must be User=fingerprint-sensor and NOT in group Docker. Installing before
   creating unprivileged account must fail closed.
5. Keep root-only HOLD+MAINTENANCE and flock serialization, no app starts
   without exact policy and watchdog READY. Rollback requires root maintenance,
   quiescent services, no jobs/listener, exact firewall-only guard. No flush.
6. Watchdog's every-2-second `net01-verify.py --all` now evaluates BOTH
   INPUT & OUTPUT chains. Missing Docker/firewall/UID -> fails -> BindsTo
   must stop only new Flask and leave sticky HOLD. Real PID1 proof pending.
7. UID/IP/MAC are isolation layers, not cryptographic identities. A process
   deliberately running as fingerprint-sensor can reuse its allowed access;
   privileged root can modify firewall, the process or the watchdog. Periodic
   drift checks have a nonzero detection window. Approved threat boundary
   excludes malicious root, but not accidental operator/system changes.
8. This policy is strictly for READINESS TCP connect; other Sensor HTTP API
   operations are not automatically trusted. Sensor startup defaults still
   use 127.0.0.1:8088 until configured for new host.
9. Staging MUST verify kernel actual localhost OUTPUT/INPUT traversal and
   owner matching before acceptance. Never assume exact semantics of mocks.

Installation command references in firewall/commands-review-only.txt are
for review only. NPM recreate, Docker network mutation, firewall changes,
Flask install or persistent service activation require separate Owner GO.
