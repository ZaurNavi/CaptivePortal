#!/usr/bin/env python3
"""Read-only candidate EVE receiver ready gate; staging only, NOT DEPLOYED."""
import grp
import os
from pathlib import Path
import pwd
import socket
import stat
import sys
import time

PATH = Path('/run/captive-portal/fingerprint-sensor/suricata-eve.sock')
DEADLINE = 45.0


def ready_once():
    entry = PATH.lstat()  # no symlink following
    owner = pwd.getpwnam('fingerprint-sensor').pw_uid
    group = grp.getgrnam('fingerprint-eve').gr_gid
    if not stat.S_ISSOCK(entry.st_mode) or entry.st_uid != owner or entry.st_gid != group:
        raise RuntimeError('EVE socket identity/type differs from approved Sensor')
    if stat.S_IMODE(entry.st_mode) != 0o660:
        raise RuntimeError('EVE socket mode not 0660')
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
    sock.settimeout(1)
    try:
        # connect() only: no producer EVE frame is sent; stale socket fails.
        sock.connect(str(PATH))
    finally:
        sock.close()
    return True


def main():
    until = time.monotonic() + DEADLINE
    while True:
        try:
            if ready_once():
                print('EVE_SOCKET_READY=PASS')
                return 0
        except (OSError, RuntimeError, KeyError):
            pass
        if time.monotonic() >= until:
            print('EVE_SOCKET_READY=HOLD', file=sys.stderr)
            return 75
        time.sleep(.5)

if __name__ == '__main__':
    sys.exit(main())
