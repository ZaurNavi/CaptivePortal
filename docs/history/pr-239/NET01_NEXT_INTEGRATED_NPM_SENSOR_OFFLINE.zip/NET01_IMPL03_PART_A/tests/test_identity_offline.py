"""No Docker involved: independent registry manifest, local Image ID and endpoint identity fixtures."""
import importlib.util
import copy
import json
from pathlib import Path

base = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('net01_guard_identity', base/'firewall'/'net01-verify.py')
g = importlib.util.module_from_spec(spec)
spec.loader.exec_module(g)

container_id = 'b608b66e' + 'a' * 56
network = {'Id':g.NETWORK_ID,'Name':g.NETWORK,'Driver':'bridge','EnableIPv6':False,
           'IPAM':{'Config':[{'Subnet':g.NETWORK_CIDR,'Gateway':g.GATEWAY}]},
           'Containers':{container_id:{'Name':'npm','IPv4Address':g.NPM_IP+'/16','MacAddress':g.NPM_MAC}}}
container = {'Id':container_id,'Name':'/npm','State':{'Running':True},
             'Config':{'Image':g.NPM_IMAGE_REF},'Image':g.NPM_IMAGE_CONFIG_ID,
             'NetworkSettings':{'Networks':{g.NETWORK:{'NetworkID':g.NETWORK_ID,'Gateway':g.GATEWAY,
                       'IPAddress':g.NPM_IP,'MacAddress':g.NPM_MAC}}}}
image = {'Id':g.NPM_IMAGE_CONFIG_ID,'RepoDigests':['jc21/nginx-proxy-manager@'+g.NPM_MANIFEST_DIGEST],
         'Descriptor':{'digest':g.NPM_MANIFEST_DIGEST,'mediaType':'application/vnd.oci.image.index.v1+json'}}
link = [{'operstate':'UP','addr_info':[{'local':g.GATEWAY,'prefixlen':16}]}]


def fixture(n=network,c=container,img=image,lan=link, should_pass=True, name='baseline'):
    def command(*argv):
        if argv[:3] == ('docker','network','inspect'):
            return json.dumps([n])
        if argv[:2] == ('docker','inspect'):
            return json.dumps([c])
        if argv[:3] == ('docker','image','inspect'):
            return json.dumps([img])
        if argv[:3] == ('ip','-j','-4'):
            return json.dumps(lan)
        raise AssertionError(f'Unanticipated command in test: {argv}')
    g.command=command
    try:
        g.check_identity()
        if not should_pass:
            raise AssertionError(f'{name}: undeserved PASS')
    except RuntimeError as exc:
        if should_pass:
            raise AssertionError(f'{name}: false HOLD: {exc}')
    print(('PASS' if should_pass else 'HOLD_AS_EXPECTED')+' '+name)

fixture(name='observed_equal_digests')
# Deliberately simulate Docker platforms where OCI index digest != local image ID.
original = g.NPM_IMAGE_CONFIG_ID
try:
    g.NPM_IMAGE_CONFIG_ID = 'sha256:'+'a'*64
    changed_c = copy.deepcopy(container);changed_c['Image']=g.NPM_IMAGE_CONFIG_ID
    changed_img = copy.deepcopy(image);changed_img['Id']=g.NPM_IMAGE_CONFIG_ID
    fixture(c=changed_c,img=changed_img,name='manifest_and_image_id_can_differ')
finally:
    g.NPM_IMAGE_CONFIG_ID = original

cases = [
    ('config_ref_tampered','c',('Config','Image'),'jc21/nginx-proxy-manager:latest'),
    ('container_image_id_tampered','c',('Image',),'sha256:'+'b'*64),
    ('local_image_id_tampered','img',('Id',),'sha256:'+'c'*64),
    ('oci_descriptor_tampered','img',('Descriptor','digest'),'sha256:'+'d'*64),
    ('repo_manifest_tampered','img',('RepoDigests',),[]),
    ('endpoint_mac_tampered','n',('Containers',container_id,'MacAddress'),'02:00:00:00:00:01'),
    ('extra_bridge_member','n',('Containers','rogue'),{'Name':'rogue','IPv4Address':'172.18.0.9/16','MacAddress':'02:00:00:00:00:09'}),
    ('bridge_gateway_tampered','n',('IPAM','Config',0,'Gateway'),'172.18.0.5'),
]
for name, target, path, value in cases:
    n,c,img=copy.deepcopy(network),copy.deepcopy(container),copy.deepcopy(image)
    target_obj={'n':n,'c':c,'img':img}[target]
    for key in path[:-1]: target_obj=target_obj[key]
    target_obj[path[-1]]=value
    fixture(n=n,c=c,img=img,name=name,should_pass=False)
print(f'OFFLINE_IDENTITY_FIXTURES=PASS positives=2 negatives={len(cases)}')
