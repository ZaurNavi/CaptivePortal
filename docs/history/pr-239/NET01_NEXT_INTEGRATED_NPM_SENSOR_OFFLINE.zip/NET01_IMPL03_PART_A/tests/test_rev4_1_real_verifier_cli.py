"""REV4.1 actual verifier main() against maintenance-reinstall CLI; no host mutation."""
import importlib.util
from pathlib import Path
import sys
import pytest

P=Path(__file__).resolve().parents[1] / 'firewall' / 'net01-verify.py'
spec=importlib.util.spec_from_file_location('rev41verifier',P)
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)


def setup(monkeypatch,tmp_path,*,maintenance=True,hold=True,mode=0o600,root=0,dir_mode=0o700):
    d=tmp_path/'state';d.mkdir();d.chmod(dir_mode)
    monkeypatch.setattr(v,'HOLD_FILE',d/'HOLD')
    monkeypatch.setattr(v,'MAINTENANCE_FILE',d/'MAINTENANCE')
    monkeypatch.setattr(v,'check_identity',lambda:None)
    monkeypatch.setattr(v,'check_firewall',lambda:None)
    monkeypatch.setattr(v.os,'geteuid',lambda:root)
    if maintenance:
        m=d/'MAINTENANCE';m.write_text('offline');m.chmod(mode)
    if hold:
        h=d/'HOLD';h.write_text('offline');h.chmod(0o600)
    return d


def invoke(monkeypatch,*args):
    monkeypatch.setattr(sys,'argv',['net01-verify.py',*args])
    return v.main()


def test_maintenance_reinstall_identity_allow(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path)
    assert invoke(monkeypatch,'--identity','--ignore-maintenance','--ignore-hold')==0


def test_manual_all_maint_allow(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path)
    assert invoke(monkeypatch,'--all','--ignore-maintenance','--ignore-hold')==0

@pytest.mark.parametrize('flags',[
    ('--identity','--ignore-hold'),
    ('--all','--ignore-hold'),
    ('--identity','--ignore-maintenance'),
    ('--identity','--ignore-maintenance','--ignore-hold'),
])
def test_missing_maintenance_or_missing_bypass(monkeypatch,tmp_path,flags):
    setup(monkeypatch,tmp_path,maintenance=False)
    assert invoke(monkeypatch,*flags)==75


def test_nonroot_bypass_fails(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path,root=1000)
    assert invoke(monkeypatch,'--identity','--ignore-maintenance','--ignore-hold')==75


def test_bad_maintenance_mode_fails(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path,mode=0o644)
    assert invoke(monkeypatch,'--identity','--ignore-maintenance','--ignore-hold')==75


def test_symlink_maintenance_fails(monkeypatch,tmp_path):
    d=setup(monkeypatch,tmp_path,maintenance=False)
    (d/'MAINTENANCE').symlink_to(d/'HOLD')
    assert invoke(monkeypatch,'--identity','--ignore-maintenance','--ignore-hold')==75


def test_normal_start_still_fails_hold(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path)
    assert invoke(monkeypatch,'--all')==75


def test_unrelated_identity_ignore_hold_without_maintenance_flag_fails(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path)
    assert invoke(monkeypatch,'--identity','--ignore-hold')==75


def test_invalid_directory_mode_fails(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path,dir_mode=0o755)
    assert invoke(monkeypatch,'--identity','--ignore-maintenance','--ignore-hold')==75
