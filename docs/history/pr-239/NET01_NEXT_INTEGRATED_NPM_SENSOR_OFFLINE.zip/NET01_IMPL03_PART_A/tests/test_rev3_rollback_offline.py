"""REV3 regression scenarios, now exercised through REV4 exact quiescence/maintenance gates."""
from rev4_fixture import isolated


def scenario(name, guard_ok, expected_mutation, service_active=False, listener=False,
             watchdog_active=False):
    opts = {'GUARD_RC': '0' if guard_ok else '75'}
    if service_active or watchdog_active: opts['UNIT_STATE']='active'
    if listener:opts['SS_LISTENER']='1'
    with isolated(**opts) as (root,env,run,hold,maint,log):
        res,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
        assert (res.returncode == 0) == expected_mutation,(name,res.stderr,res.stdout)
        if expected_mutation:
            assert len(mut)==10 and all(' -F ' not in x for x in mut),(name,mut)
        else:
            assert not mut,(name,mut)
        assert hold.exists() and maint.exists()
        return res.returncode,mut


def test_clean_exact_policy_can_rollback_in_mock():scenario('baseline',True,True)
def test_drifted_chain_holds_before_mutation():scenario('modified-chain',False,False)
def test_modified_hook_holds_before_mutation():scenario('modified-input-hook',False,False)
def test_partial_install_holds_before_mutation():scenario('partial-install',False,False)
def test_stale_rules_holds_before_mutation():scenario('stale-rules',False,False)
def test_backend_active_holds():scenario('service-active',True,False,service_active=True)
def test_watchdog_active_holds():scenario('watchdog-active',True,False,watchdog_active=True)
def test_stray_listener_holds():scenario('stray-listener',True,False,listener=True)
