"""Offline only: check watchdog decisions with in-memory mocks; no systemctl executed."""
import importlib.util
import pathlib
import subprocess
from unittest.mock import patch, Mock

p=pathlib.Path(__file__).resolve().parents[1]/'firewall'/'net01-runtime-watchdog.py'
spec=importlib.util.spec_from_file_location('net01_watchdog',p)
w=importlib.util.module_from_spec(spec)
spec.loader.exec_module(w)

with patch.object(w,'HOLD',Mock(exists=lambda: False)):
    assert w.iteration(lambda *a,**kw: subprocess.CompletedProcess([],0)) is None
    assert w.iteration(lambda *a,**kw: subprocess.CompletedProcess([],75)) == 'guard-reported-drift'
    def failed(*a,**kw):
        raise FileNotFoundError('docker or guard unavailable')
    assert w.iteration(failed) == 'guard-unavailable-or-timeout'
    def timeout(*a,**kw):
        raise subprocess.TimeoutExpired('guard',15)
    assert w.iteration(timeout) == 'guard-unavailable-or-timeout'
with patch.object(w,'HOLD',Mock(exists=lambda: True)):
    assert w.iteration(lambda *a,**kw: (_ for _ in ()).throw(AssertionError('guard ran under HOLD'))) == 'sticky-hold-present'
print('OFFLINE_RUNTIME_WATCHDOG_TESTS=PASS positive=1 negatives=4')
