#!/usr/bin/env bash
# Validates syntax/resolved ordering of REV4 units in a throwaway synthetic systemd root.
# This DOES NOT start systemd or any production service.
set -euo pipefail
HERE=$(cd -- "$(dirname -- "$0")/.." && pwd)
T=$(mktemp -d)
trap 'rm -rf -- "$T"' EXIT
mkdir -p "$T/etc/systemd/system/captive-portal.service.d" "$T/usr/bin" "$T/usr/local/libexec/captiv-net01" "$T/bin"
cp "$HERE/systemd/"*.service "$T/etc/systemd/system/"
cp "$HERE/systemd/captive-portal-net01.drop-in.conf" "$T/etc/systemd/system/captive-portal.service.d/net01.conf"
cat > "$T/etc/systemd/system/captive-portal.service" <<'APP'
[Unit]
Description=Offline mock flask application only
[Service]
Type=simple
User=captivportal
Group=captivportal
ExecStart=/usr/bin/python3 /usr/local/libexec/captiv-net01/dummy-app.py
Restart=on-failure
APP
cat > "$T/etc/systemd/system/docker.service" <<'DOCKER'
[Unit]
Description=Offline mock docker only
[Service]
Type=oneshot
ExecStart=/bin/true
RemainAfterExit=yes
DOCKER
for t in sysinit.target basic.target sockets.target local-fs.target shutdown.target; do
  printf '[Unit]\nDescription=Offline %s fixture\n' "$t" > "$T/etc/systemd/system/$t"
done
for f in /bin/true /usr/bin/python3 /usr/local/libexec/captiv-net01/dummy-app.py /usr/local/libexec/captiv-net01/net01-fw-install.sh /usr/local/libexec/captiv-net01/net01-verify.py /usr/local/libexec/captiv-net01/net01-runtime-watchdog.py /usr/local/libexec/captiv-net01/net01-mark-hold.py /usr/local/libexec/captiv-net01/net01-hold-and-stop.py /usr/local/libexec/captiv-net01/net01-start-admit.sh; do
  touch "$T$f"; chmod 755 "$T$f"
done
systemd-analyze --root="$T" verify captive-portal.service captiv-net01-watchdog.service captiv-net01-firewall.service captiv-net01-failsafe.service
printf 'OFFLINE_SYSTEMD_ANALYZE_VERIFY=PASS root_fixture=YES running_systemd_test=NO\n'
