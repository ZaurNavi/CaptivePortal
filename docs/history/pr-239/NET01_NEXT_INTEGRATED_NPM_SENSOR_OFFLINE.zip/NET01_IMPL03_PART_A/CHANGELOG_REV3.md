# REV3 change log — 2026-10-14

- **P1-01:** Root-only privileged `ExecStartPre=+...` (only gate), app continues `User=captivportal` and no Docker socket/group. Synthetic systemd parse verifies directive; real staging identity test still required.
- **P1-02:** Inverted lifecycle direction. Flask `BindsTo`+`After` watchdog; watchdog `Type=notify`, emits READY only after initial full guard. No watchdog dependency back to Flask. Watchdog always latches HOLD on stop; `OnFailure` independent service, no self-stop; both `Restart=no`.
- **P1-03:** `net01-verify.py --firewall-only` exact posture (ignores HOLD but *does not* ignore syntax), one allowed jump globally, dedicated rollback preflight, lock, deletion of exact owned entries without flush. Drift/partial state => HOLD before changes.
- **P2-01:** emergency STOP mocks including marker error, timeout, SIGKILL, listener check, OnFailure dispatch, simulated systemd dependencies, notify readiness and synthetic unit verification.
- All REV2 firewall identity and image checks retained; original Docker/NPM config candidates unchanged.
- **NOT DONE:** production install, production firewall edits, Docker or Flask activation, real systemd PID1 lifecycle tests.
