# NET01 integrated two-path review candidate (supersedes REV4.1 single allow)

**NOT AUTHORIZED FOR PRODUCTION DEPLOYMENT.**

This is a complete offline package derived from audited REV4.1 archive
`sha256:0bb12d269f8ae0826786c71c3ba2bb3f43ac54dc4c3c1a26500bf2d67a155687`.

Additional integration: NPM container via exact bridge/IP/MAC + local Sensor
readiness via `lo` / exact bridge gateway source/dest + dedicated Linux UID
OUTPUT owner firewall. No other local user, LAN, Guest or WAN is admitted.
One exact verifier enforces both chains; watchdog executes it every 2 seconds.
See `CHANGELOG_INTEGRATED.md`, `INTEGRATED_DIFF.patch`, `staging/*`,
`TEST_RESULTS_INTEGRATED.txt`, and `MANIFEST.sha256`. Original REV3/REV4 files
are retained for lineage; historical examples are not activation instructions.

No NPM, Docker, Omada, Cisco, legacy production or CaptivePortal changed.
