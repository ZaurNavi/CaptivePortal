# NET-01 Part A REV4.1 — maintenance reinstall CLI contract

2026-10-15. Offline-only reconstruction of focused Windows workstation candidate, based on preserved REV4 ZIP. Not a production deployment.

- P1 corrected: `net01-fw-install.sh --maintenance-reinstall` invokes `net01-verify.py --identity --ignore-maintenance --ignore-hold`, which previously failed argument validation.
- Accept precisely that bypass only when EUID is root and MAINTENANCE is a root-owned regular file mode 0600 under verified root-owned 0700 directory; otherwise HOLD.
- `--all --ignore-hold --ignore-maintenance` manual recovery uses the same verified operator/latch requirement. Ordinary startup with zero bypass remains fail-closed.
- Unit/source networking, NPM, Docker and firewall contract UNCHANGED. Sensor-local path is **not** included and requires synchronized review in a separate revision.
- Additional fixtures exercise actual CLI arguments, error states and maintenance marker security.

No production files modified. PID1, live firewall, Docker recreate, network acceptance NOT_TESTED.
