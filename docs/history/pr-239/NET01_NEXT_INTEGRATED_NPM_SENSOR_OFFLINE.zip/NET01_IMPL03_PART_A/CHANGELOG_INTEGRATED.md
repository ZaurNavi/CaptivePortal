# NET01 next integrated revision — changes from accepted REV4.1

* `firewall/net01-verify.py`: exact first IPv4 INPUT + OUTPUT hooks, two
  IPv4 INPUT allows (original NPM plus tightly scoped local lo), dedicated
  OUTPUT UID allow for `fingerprint-sensor`, exact two terminal reject chains,
  global reference validation, existing IPv6 deny. Missing user => HOLD.
* `firewall/net01-fw-install.sh`: preflight numeric nonroot Sensor UID;
  install deny-first chains atomically enough to fail closed if interrupted;
  partial/ambiguous existing chain => HOLD. Does not start listener.
* `firewall/net01-fw-rollback.sh`: exact previous guard required; quiescent
  systemd/no listener/MAINTENANCE; deletes only ten exact owned rules;
  unknown/partial policy => HOLD without any mutation.
* `firewall/net01-runtime-watchdog.py`: no bypass, uses enhanced verifier
  every two seconds for BOTH paths. Unit lifecycle unchanged pending PID1.
* `firewall/commands-review-only.txt`: synchronized with integrated rules.
* `tests/test_net01_integrated_two_paths.py`: new exact positive/negative
  fixtures, UID failure/rollback failure, no mutation, watchdog path.
* Updated older mock fixtures to the new complete expected rule set.
* Added staging-only Suricata, EVE readiness, Sensor, Evidence, Omada TLS
  and isolated PID1/network acceptance plans.

No real systemd, iptables, credentialed Omada, Docker-recreate or active
network tests were run. This is a REVIEW CANDIDATE, not Part B acceptance.
