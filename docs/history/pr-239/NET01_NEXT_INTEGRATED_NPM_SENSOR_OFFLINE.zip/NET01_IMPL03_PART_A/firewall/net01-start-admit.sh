#!/usr/bin/env bash
# Privileged only via systemd ExecStartPre=+ (application remains unprivileged).
set -euo pipefail
umask 077
(( EUID == 0 )) || { echo 'HOLD: root-only prestart' >&2; exit 75; }
exec 9>/run/lock/captiv-net01-firewall.lock
flock -n 9 || { echo 'HOLD: NET01 maintenance/admission lock occupied' >&2; exit 75; }
/usr/bin/python3 /usr/local/libexec/captiv-net01/net01-maintenance-state.py absent
/usr/bin/python3 /usr/local/libexec/captiv-net01/net01-verify.py --all
