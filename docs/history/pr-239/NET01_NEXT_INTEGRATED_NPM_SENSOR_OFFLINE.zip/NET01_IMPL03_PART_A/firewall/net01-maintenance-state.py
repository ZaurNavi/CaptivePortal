#!/usr/bin/env python3
"""Root-owned sticky MAINTENANCE admission marker; does not stop any service."""
import argparse
import os
from pathlib import Path
import stat
import sys

DIR=Path('/var/lib/captiv-net01')
MARK=DIR/'MAINTENANCE'


def verify_dir(directory=DIR):
    st=directory.lstat()
    if not stat.S_ISDIR(st.st_mode) or st.st_uid != 0 or stat.S_IMODE(st.st_mode) != 0o700:
        raise RuntimeError('NET01 state dir must be root-owned 0700, not symlink')


def verify_marker(marker=MARK, required=True):
    try:
        st=marker.lstat()
    except FileNotFoundError:
        if not required:
            return False
        raise RuntimeError('MAINTENANCE marker absent')
    if not stat.S_ISREG(st.st_mode) or st.st_uid != 0 or stat.S_IMODE(st.st_mode) != 0o600:
        raise RuntimeError('invalid MAINTENANCE ownership/type/mode')
    return True


def put(directory=DIR, marker=MARK):
    verify_dir(directory)
    if verify_marker(marker, required=False):
        return
    fd=os.open(marker, os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW, 0o600)
    try:
        os.write(fd,b'NET01 maintenance admission: root-only; manual release required\n')
        os.fsync(fd)
    finally:
        os.close(fd)
    dirfd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY)
    try:
        os.fsync(dirfd)
    finally:
        os.close(dirfd)


def main(argv=None):
    p=argparse.ArgumentParser();p.add_argument('operation',choices=['enter','require','absent'])
    args=p.parse_args(argv)
    try:
        if os.geteuid()!=0:
            raise RuntimeError('root required')
        verify_dir()
        if args.operation=='enter':put()
        elif args.operation=='require':verify_marker()
        else:
            if verify_marker(required=False):raise RuntimeError('MAINTENANCE present')
        return 0
    except (OSError,RuntimeError) as exc:
        print('NET01_MAINTENANCE=HOLD: '+str(exc),file=sys.stderr)
        return 75

if __name__=='__main__':sys.exit(main())
