#!/usr/bin/env python3
"""REV3: atomic-ish sticky root-only HOLD marker. No systemd operations.

Must be invoked as root from watchdog ExecStopPost/independent failsafe.
Never delete marker here. Production execution requires separate GO.
"""
import os
import sys
import time
from pathlib import Path

HOLD = Path('/var/lib/captiv-net01/HOLD')


def mark(reason, path=HOLD):
    parent = path.parent
    if not parent.is_dir() or parent.is_symlink():
        raise RuntimeError('NET01 state directory missing or symlink')
    st = parent.stat()
    if st.st_uid != 0 or (st.st_mode & 0o777) != 0o700:
        raise RuntimeError('NET01 state directory not root-owned 0700')
    flags = os.O_WRONLY | os.O_CREAT | os.O_APPEND | os.O_NOFOLLOW
    fd = os.open(path, flags, 0o600)
    try:
        if (os.fstat(fd).st_mode & 0o777) != 0o600:
            raise RuntimeError('HOLD file permission mismatch')
        os.write(fd, (time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
                      + ' NET01=' + reason[:120] + '\n').encode())
        os.fsync(fd)
    finally:
        os.close(fd)
    # Sync parent to make new directory entry durable where supported.
    pfd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(pfd)
    finally:
        os.close(pfd)


def main():
    try:
        if os.geteuid() != 0:
            raise RuntimeError('NET01 HOLD requires root')
        mark(sys.argv[1] if len(sys.argv) > 1 else 'unspecified')
        return 0
    except BaseException as exc:
        print('NET01_HOLD_MARK_FAILED=' + type(exc).__name__, file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
