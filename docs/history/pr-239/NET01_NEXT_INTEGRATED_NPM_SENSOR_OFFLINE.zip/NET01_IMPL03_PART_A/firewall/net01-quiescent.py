#!/usr/bin/env python3
"""Fail-closed systemd + TCP-port admission probe, read-only, review-only.

Strict 'quiescent': rollback/HOLD clear/maintenance require loaded, inactive/dead,
no unit jobs, no TCP listener. 'install': supports a queued app start transaction
ordered AFTER the firewall unit, but never tolerates a live/activating app.
"""
import argparse
import re
import subprocess
import sys

UNITS = ('captive-portal.service', 'captiv-net01-watchdog.service',
         'captiv-net01-failsafe.service')
JOBS_GUARDED = UNITS + ('captiv-net01-firewall.service',)


def run_command(args):
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       text=True, check=False, timeout=5)
    if p.returncode:
        raise RuntimeError('status command failed: ' + args[0])
    return p.stdout


def query_unit(unit, runner=run_command):
    output = runner(['systemctl', 'show', '--no-pager',
                     '-p', 'LoadState', '-p', 'ActiveState',
                     '-p', 'SubState', '-p', 'Job', unit])
    data = {}
    for line in output.splitlines():
        if '=' not in line:
            raise RuntimeError('malformed systemd show line')
        key, value = line.split('=', 1)
        if key in data:
            raise RuntimeError('duplicate systemd property')
        data[key] = value
    if set(data) != {'LoadState', 'ActiveState', 'SubState', 'Job'}:
        raise RuntimeError('missing or unknown systemd properties')
    if data['LoadState'] != 'loaded' or data['ActiveState'] != 'inactive' or data['SubState'] != 'dead':
        raise RuntimeError('not fully inactive/dead: ' + unit)
    return data


def jobs_check(mode, runner):
    output = runner(['systemctl', 'list-jobs', '--all', '--no-legend', '--plain'])
    observed = set()
    for line in output.splitlines():
        if not line.strip() or line.strip() == 'No jobs running.':
            continue
        fields = line.split()
        if len(fields) < 4 or not fields[0].isdigit():
            raise RuntimeError('unparseable systemd job listing')
        unit, job_type = fields[1], fields[2]
        if unit not in JOBS_GUARDED:
            continue
        # An app start *may* be waiting on ordered firewall installation.
        if mode == 'install' and unit in UNITS[:2] and job_type == 'start':
            observed.add(unit)
            continue
        raise RuntimeError('NET01 systemd job pending: ' + unit)
    return observed


def check_listener(runner=run_command):
    output = runner(['ss', '-H', '-lnt'])
    for line in output.splitlines():
        fields = line.split()
        if len(fields) < 5 or fields[0] != 'LISTEN':
            raise RuntimeError('unparseable ss listener output')
        address = fields[3]
        if ':' not in address:
            raise RuntimeError('unparseable ss local address')
        port = address.rsplit(':', 1)[-1]
        if not port.isdigit():
            raise RuntimeError('non-numeric ss listener port')
        if int(port) == 18089:
            raise RuntimeError('TCP 18089 listener still present')


def check(mode='quiescent', runner=run_command):
    if mode not in ('quiescent', 'install'):
        raise ValueError('invalid mode')
    jobs = {}
    for unit in UNITS:
        jobs[unit] = query_unit(unit, runner)['Job']
    if mode == 'quiescent':
        if any(jobs.values()):
            raise RuntimeError('NET01 unit has pending systemd Job')
    else:
        # Only a systemd-ordered start transaction may be present. A list-jobs
        # inspection below also verifies types; status must remain inactive/dead.
        for unit, job in jobs.items():
            if job and (unit not in UNITS[:2] or not re.fullmatch(r'[0-9]+/start', job)):
                raise RuntimeError('unexpected pending systemd job: ' + unit)
    observed = jobs_check(mode, runner)
    if mode == 'install':
        stated = {unit for unit, job in jobs.items() if job}
        if observed != stated:
            raise RuntimeError('systemd show Job mismatches list-jobs')
    check_listener(runner)
    # Recheck service state/job after ss to narrow the observation gap.
    for unit in UNITS:
        after = query_unit(unit, runner)['Job']
        if mode == 'quiescent' and after:
            raise RuntimeError('job appeared during check: ' + unit)
    later = jobs_check(mode, runner)
    if later != observed:
        raise RuntimeError('systemd jobs changed during verification')
    return True


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--mode', choices=['quiescent', 'install'], default='quiescent')
    args = p.parse_args(argv)
    try:
        check(args.mode)
        print('NET01_QUIESCENCE=PASS mode=' + args.mode)
        return 0
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
        print('NET01_QUIESCENCE=HOLD ' + type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        return 75


if __name__ == '__main__':
    sys.exit(main())
