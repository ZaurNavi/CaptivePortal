#!/usr/bin/env python3
"""Root-only unlink of precisely verified root-owned 0600 latch, no symlinks."""
import os
from pathlib import Path
import stat
import sys

DIR=Path('/var/lib/captiv-net01')

def clear(which, directory=DIR):
    if which not in ('HOLD','MAINTENANCE'):
        raise RuntimeError('unknown marker')
    sd=directory.lstat()
    if not stat.S_ISDIR(sd.st_mode) or sd.st_uid != 0 or stat.S_IMODE(sd.st_mode) != 0o700:
        raise RuntimeError('invalid marker directory')
    marker=directory/which
    st=marker.lstat()
    if not stat.S_ISREG(st.st_mode) or st.st_uid != 0 or stat.S_IMODE(st.st_mode) != 0o600:
        raise RuntimeError('invalid marker file')
    marker.unlink()
    fd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)

def main():
    try:
        if os.geteuid()!=0:raise RuntimeError('root required')
        if len(sys.argv)!=2:raise RuntimeError('marker required')
        clear(sys.argv[1]);return 0
    except (OSError,RuntimeError) as e:
        print('NET01_MARKER_UNLINK=HOLD '+str(e),file=sys.stderr);return 75
if __name__=='__main__':sys.exit(main())
