#!/usr/bin/env bash
# REV4: operator only; HOLD cannot be cleared on unknown unit/ss state.
set -euo pipefail
umask 077
(( EUID == 0 )) || { echo 'HOLD: root required' >&2; exit 75; }
HOLD=/var/lib/captiv-net01/HOLD
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
PROBE=/usr/local/libexec/captiv-net01/net01-quiescent.py
MAINT=/usr/local/libexec/captiv-net01/net01-maintenance-state.py
exec 9>/run/lock/captiv-net01-firewall.lock
flock -n 9 || { echo 'HOLD: NET01 operation busy' >&2; exit 75; }
# During maintenance, marker keeps startup inhibited while clearing HOLD.
/usr/bin/python3 "$MAINT" require || exit 75
/usr/bin/python3 "$PROBE" --mode quiescent || exit 75
/usr/bin/python3 "$GUARD" --all --ignore-hold --ignore-maintenance || exit 75
/usr/bin/python3 "$PROBE" --mode quiescent || exit 75
/usr/bin/python3 "$MAINT" require || exit 75
# Fail closed if HOLD file is not a regular root-owned 0600 file.
/usr/bin/python3 /usr/local/libexec/captiv-net01/net01-marker-unlink.py HOLD
printf '%s\n' 'NET01_HOLD_CLEARED; MAINTENANCE_REMAINS_LATCHED'
