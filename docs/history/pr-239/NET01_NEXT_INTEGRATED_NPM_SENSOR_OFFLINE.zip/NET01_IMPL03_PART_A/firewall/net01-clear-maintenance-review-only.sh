#!/usr/bin/env bash
# Final manual recovery gate; never executed automatically.
set -euo pipefail
umask 077
(( EUID == 0 )) || exit 75
exec 9>/run/lock/captiv-net01-firewall.lock
flock -n 9 || exit 75
ROOT=/usr/local/libexec/captiv-net01
/usr/bin/python3 "$ROOT/net01-maintenance-state.py" require
/usr/bin/python3 "$ROOT/net01-quiescent.py" --mode quiescent
/usr/bin/python3 "$ROOT/net01-verify.py" --all --ignore-maintenance
/usr/bin/python3 "$ROOT/net01-quiescent.py" --mode quiescent
/usr/bin/python3 "$ROOT/net01-marker-unlink.py" MAINTENANCE
printf '%s\n' 'NET01_MAINTENANCE_CLEARED; MANUAL_START_ONLY'
