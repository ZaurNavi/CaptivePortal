#!/usr/bin/env python3
"""REV3 independent emergency containment, NEVER called by live watchdog.

Intended only for OnFailure failsafe or separate authorized root operator action.
Only targets new captive-portal.service. Mock-tested, not production-tested.
"""
import importlib.util
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/usr/local/libexec/captiv-net01')
UNIT = 'captive-portal.service'
PORT = ':18089'


def hold_and_stop(reason, *, run=subprocess.run, latch=None, unit=UNIT):
    if latch is None:
        spec = importlib.util.spec_from_file_location('net01_mark_hold', ROOT / 'net01-mark-hold.py')
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        latch = mod.mark

    marker_error = None
    try:
        latch(reason)
    except (OSError, RuntimeError) as exc:
        marker_error = exc

    errors = []
    def call(args, timeout):
        return run(args, capture_output=True, text=True, check=False, timeout=timeout)

    try:
        outcome = call(['systemctl', 'stop', unit], 15)
        if outcome.returncode != 0:
            errors.append('graceful-stop-nonzero')
    except (OSError, subprocess.TimeoutExpired):
        errors.append('graceful-stop-timeout')

    # Is the unit still active? If so escalate. Do not equate a successful
    # systemctl request with listener shutdown.
    try:
        active = call(['systemctl', 'is-active', '--quiet', unit], 4).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        active = True
    if active:
        try:
            result = call(['systemctl', 'kill', '--kill-whom=all', '--signal=SIGKILL', unit], 5)
            if result.returncode != 0:
                errors.append('sigkill-failed')
        except (OSError, subprocess.TimeoutExpired):
            errors.append('sigkill-timeout')
        try:
            call(['systemctl', 'stop', unit], 5)
        except (OSError, subprocess.TimeoutExpired):
            errors.append('post-sigkill-stop-timeout')

    try:
        unit_active = call(['systemctl', 'is-active', '--quiet', unit], 4).returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        unit_active = True
    try:
        p = call(['ss', '-H', '-lnt'], 4)
        # Port parse, rather than scanning raw header/body or matching substrings.
        bound = (p.returncode != 0 or any(
            len(cols) >= 4 and cols[3].rsplit(':', 1)[-1] == PORT[1:]
            for line in p.stdout.splitlines() if (cols := line.split())))
    except (OSError, subprocess.TimeoutExpired):
        bound = True
    if marker_error is not None or unit_active or bound or errors:
        raise RuntimeError('NET01 emergency containment not fully confirmed: ' +
                           ','.join(errors + (['marker-failed'] if marker_error else []) +
                                    (['unit-active'] if unit_active else []) +
                                    (['listener-still-present'] if bound else [])))
    return True


def main():
    try:
        hold_and_stop(sys.argv[1] if len(sys.argv) > 1 else 'unspecified')
        print('NET01_EMERGENCY_HOLD_AND_STOP_CONFIRMED')
        return 0
    except BaseException as exc:
        print('NET01_EMERGENCY_HOLD_STOP_UNCONFIRMED=' + type(exc).__name__, file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
