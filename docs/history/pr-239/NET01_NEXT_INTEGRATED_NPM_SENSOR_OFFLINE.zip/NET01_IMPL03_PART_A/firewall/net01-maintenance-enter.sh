#!/usr/bin/env bash
# Separate APPROVED operator action, not a production command in Part A.
set -euo pipefail
umask 077
(( EUID == 0 )) || { echo 'HOLD: root required' >&2; exit 75; }
exec 9>/run/lock/captiv-net01-firewall.lock
flock -n 9 || { echo 'HOLD: NET01 operation in progress' >&2; exit 75; }
# Barrier FIRST; all start guards and runtime monitor reject MAINTENANCE.
/usr/bin/python3 /usr/local/libexec/captiv-net01/net01-maintenance-state.py enter
# Service stop attempts are scoped to new NET01 services only. Never reset-failed.
systemctl stop captive-portal.service captiv-net01-watchdog.service || { echo 'HOLD: stop failed, maintenance remains latched' >&2; exit 75; }
/usr/bin/python3 /usr/local/libexec/captiv-net01/net01-quiescent.py --mode quiescent || { echo 'HOLD: quiescence unproven, maintenance remains latched' >&2; exit 75; }
echo 'NET01_MAINTENANCE=ADMITTED_AND_QUIESCENT'
