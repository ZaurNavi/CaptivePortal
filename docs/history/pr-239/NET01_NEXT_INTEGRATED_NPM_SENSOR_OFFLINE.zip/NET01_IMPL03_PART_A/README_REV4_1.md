# NET-01 REV4.1 offline candidate

Contains all REV4 source, scripts, systemd units, tests and exact-match firewall policy, with only targeted CLI maintenance-reinstall correction and offline fixtures. Do not deploy or use for final Sensor local readiness; current firewall admits NPM bridge source only. The attached REV4.1 recovery path must undergo isolated real PID1 staging before Owner GO. No secrets included.
