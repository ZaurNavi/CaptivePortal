# NET01 Reboot Lifecycle — scoped candidate for Architect/Owner review

Status: OFFLINE_CANDIDATE, NOT AUTHORIZED FOR LIVE DEPLOYMENT.
Frozen baseline (unchanged): SHA256 a2904ea42f7985ec266c803d81ff76e19ce563a89f300878418668eff3599e59.

Only new files: scripts/net01-watchdog-stop-post.py and systemd/50-net01-reboot-lifecycle.conf.
Boot activation requires systemctl add-wants multi-user.target captiv-net01-watchdog.service.
No modifications to NET01 firewall policy, conntrack, Docker identity, Sensor UID, watchdog ExecStart, or Portal.

Condition to skip NEW HOLD on stop: SERVICE_RESULT=success AND systemctl is-system-running=stopping AND
an explicit pending start job for reboot/poweroff/halt/kexec (or soft-reboot) target. No unknown state qualifies.
Previously existing HOLD is NEVER removed or auto-cleared. Any uncertainty creates HOLD via original marker.

Tests: 19 Python offline assertions PASS; real WSL2 systemd 249 PID1 transient test PASS for boot Wants
dependency, cold start, manual stop/HOLD, crash/HOLD, existing HOLD denial, simulated shutdown, and uncertain
shutdown fail-closed. No real OS reboot has been performed. Do NOT claim confirmed real reboot persistence.

Owner GO required before creating boot symlink, installing helper/drop-in or daemon-reloading on captiv-prod.
Do NOT restart or stop current watchdog, firewall, NPM, Omada or Portal for deployment.
