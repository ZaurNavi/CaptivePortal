import importlib.util
import pathlib
from subprocess import CompletedProcess, TimeoutExpired

p=pathlib.Path(__file__).resolve().parents[1]/'scripts/net01-watchdog-stop-post.py'
spec=importlib.util.spec_from_file_location('net01_reboot_lifecycle',p)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def test_cases():
    def run_for(state, jobs, code=0, exception=None):
        def go(cmd, **kwargs):
            if exception: raise exception
            if 'is-system-running' in cmd:
                return CompletedProcess(cmd, 1, stdout=state, stderr='')
            return CompletedProcess(cmd, code, stdout=jobs, stderr='')
        return go
    shutdown='42 shutdown.target start waiting\n43 reboot.target start waiting\n'
    clean={'SERVICE_RESULT':'success'}
    assert m.confirmed_orderly_shutdown(clean, run_for('stopping\n',shutdown))
    assert m.confirmed_orderly_shutdown(clean, run_for('stopping\n','43 poweroff.target start waiting\n'))
    assert m.confirmed_orderly_shutdown(clean, run_for('stopping\n','43 halt.target start waiting\n'))
    assert m.confirmed_orderly_shutdown(clean, run_for('stopping\n','43 kexec.target start waiting\n'))
    assert not m.confirmed_orderly_shutdown(clean,run_for('running\n',shutdown))
    assert not m.confirmed_orderly_shutdown(clean,run_for('degraded\n',shutdown))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n','42 shutdown.target start waiting\n'))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n','43 reboot.target stop waiting\n'))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n','43 reboot.target start wait-ing\n'))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n','43 reboot.target start waiting\n', code=1))
    assert not m.confirmed_orderly_shutdown({'SERVICE_RESULT':'exit-code'},run_for('stopping\n',shutdown))
    assert not m.confirmed_orderly_shutdown({'SERVICE_RESULT':'signal'},run_for('stopping\n',shutdown))
    assert not m.confirmed_orderly_shutdown({},run_for('stopping\n',shutdown))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n',shutdown,exception=TimeoutExpired('x',3)))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n',shutdown,exception=OSError('no-bus')))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n','garbage lines\n'))
    assert not m.confirmed_orderly_shutdown(clean,run_for('stopping\n','43 reboot.target start waiting\n99 bogus.target start waiting\n', code=127))
    # Pre-existing sticky HOLD is left to frozen admission; no deletion code here.
    assert 'unlink' not in p.read_text()
    assert 'os.execv(' in p.read_text()

if __name__=='__main__':
    test_cases()
    print('NET01_LIFECYCLE_DECISION_TESTS=19/19_PASS')
