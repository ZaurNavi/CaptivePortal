# ARCH-05 — fingerprint Source Identity, Source Health, F-B1 admission

This design supplies a **registration/admission procedure**, not fabricated records in an uninstalled application. New sources must use freshly scoped IDs and zero prior events; restore no old spool, evidence SQLite, analytics or identity epochs.

## Separation of trust planes

| Gate | Contract | Who checks / effect of failure |
|---|---|---|
| 1. TLS reachability | Client connects to Receiver `https://127.0.0.1:9443` with validated CA/SAN. | Client rejects wrong cert/expired chain; TCP 200 is not proof of trust |
| 2. Producer authentication | Per-producer bearer, exact token association and source-policy, required event schema. | Receiver rejects missing/invalid tokens; no data accepted |
| 3. Evidence ingestion | Event producer_id, capture_source_id, Site ID, kind, time/skew, guest scope, dedup, size, ack. | Receiver writer records only validated evidence, bounded retry/backpressure |
| 4. Source registration | Admin-controlled source record with owner, capture placement, type, trust, admission scope, epoch. | Absent registration leaves evidence unadmitted |
| 5. Source Health | Declared health owner and freshness/last signal, permission to report status. | Missing/stale health => UNKNOWN/DEGRADED, not positive admission |
| 6. F-B1 Admission | Binding epoch + identity + source health + Site + temporal event eligibility and policy. | Data not eligible for Classification if gate not met |
| 7. Classification/NI | Only admitted, provenance-rich evidence; versioned rules; readers source-of-truth separation. | No fingerprint intelligence claims from rejected sources |

## Proposed identities (CANDIDATES ONLY — not activated)

| Source | Producer ID candidate | Capture Source ID candidate | Scope | Credential / owner |
|---|---|---|---|---|
| Passive L2 Sensor | `captivprod-sensor-01` | `captivprod-span-01` | New Omada Site ID TBD, accepted SPAN guest VLAN/CIDR | dedicated `sensor` bearer under systemd LoadCredential; `captiv-sensor` systemd principal |
| Portal low-entropy UA/Client-Hints Producer | `captivprod-portal-01` | `captivprod-portal-http-01` | Same Site and SSIDs; only accepted HTTP guest context | separate `portal` bearer file, readable by app principal only |
| Suricata EVE | No independent trusted HTTP producer by default; telemetry supplied through Sensor | **Do not invent a second source** until design proves separate provenance | Frozen BPF/capture profile and EVE schema | sensor owns normalized accepted evidence |

Names above are syntax-compatible **proposals**, not newly registered identities. Confirm new Site 24-char ID, exact guest CIDR/SSID and actual allowed event kinds in the approved `7e84bc5...` implementation. On activation use new unique epochs and record source binding with immutable audit; never reuse old site or token by default.

## Registration protocol / ordering

1. `CAPTIVEPORTAL_INSTALLATION=HOLD`: prepare protected file paths, issuer/CA, identity manifest and intended site. **Do not write guessed SQLite records or manually create schemas.**
2. After separately authorized bootstrap, evidence/control-plane store is created by authoritative writer. Backup clean initialization and schema version. Use the application-supported registration API/CLI; if none exists, identify the exact reviewed implementation TASK. No direct SQL inserts.
3. Provision Receiver and exact producer allowlist, bearer and source policy. Bind Site/SSID/CIDR and event-kind permissions. Fail closed on invalid producer, wrong Site, wrong capture source, wrong token, large/late/replayed payload.
4. Confirm accepted ingest independently from Source Registration (`registered=true`), independently from F-B1 admission (`admitted=true`). Log cause codes and no secrets.
5. Admit only evidence with valid epoch and positive source health, after privacy/capture topology acceptance. Re-evaluate after service restart, source unregistration, credential rotation, NIC swap, clock skew, Site changes or broken TLS.
6. Classification/NI readers receive only admitted evidence; unknown/unavailable and source defects must be visible as status, not coerced to zero/no-device.

## Clock and durability

- Host `NTP=yes`, `NTPSynchronized=yes`, timezone `Etc/UTC` observed. Verify switch/controller clocks and accepted timestamp-skew budget; distinguish event time, receive time and durable time.
- Sensor spool candidate `/var/lib/captive-portal/fingerprint-sensor/spool.sqlite3`, unique and empty. Producer retries with exponential/bounded queue, at-least-once delivery with stable event IDs; Receiver idempotency. Replay after expired window is rejected; never widen TTL or relax SQLite synchronous to compensate slow HDD.
- Synthetic acceptance records and any simulated EVE data must be isolated, auditable and deleted/archived by supported application cleanup after tests. Keep no false visitors.
- Receiver unavailable: bound spool/cache, source-health DOWN, no silent drop-to-authorized classification, core guest authorization remains independent.

## Planned negative and restore checks

Wrong Site, wrong producer_id with correct token, old bearer, client cert SAN mismatch, rejected event kind, old epoch, source missing admission, stale source health, wrong guest CIDR, invalid observed DHCP Option 54, no EVE, clock rollback, receiver restart during spool replay, writer contention and synthetic event duplicates. Mark each as NOT_TESTED until components exist and are run against a disposable test Site.

**Status:** `IDENTITY_SCHEMA=DESIGNED`, `SITE_SCOPE=HOLD`, `SOURCE_REGISTRATION=PLANNED_ONLY`, `F_B1_ADMISSION=PLANNED_ONLY`, `EVENTS_INGESTED=0_BY_DESIGN_NOT_VERIFIED`, `FINGERPRINT_CLASSIFICATION=OFF`.
