# ARCH-05 — configuration, storage, secrets, backups, logging manifest

**Mode:** planned storage and ownership only; never copy legacy SQLite/JSONL/visitor data. **Live disk baseline:** Ubuntu 22.04.5, 15 GiB RAM (~13 GiB available), SSD root ext4 98 GiB / ~82 GiB free, HDD `/srv/backups` ext4 916 GiB / ~897 GiB free, NTP synchronized in UTC. The current application install directories and unit are absent.

## Config and identity sources

| Item | Proposed authoritative location / source | Mode, protection, action |
|---|---|---|
| Git deployment | `ZaurNavi/CaptivePortal` `7e84bc563f1b6dd3d72da66ae25849d9a7d96540`, tree `ea664b1d49ace86fc8a0c4ab2fc52945531e574a` | Approved revision, NOT installed. Future code root:root read-only to runtime, clean tree/hash evidence. Python deps pinned independently; no floating latest. |
| Core service environment | `/etc/captive-portal/portal.env` (future) | root:root 0600; values from new Omada/real Site. Never source `.env.example` as runtime authority; systemd EnvironmentFile explicit |
| NET01 scripts/markers | `/usr/local/libexec/captiv-net01/*`, `/var/lib/captiv-net01/{HOLD,MAINTENANCE}`, `/run/lock/captiv-net01-firewall.lock` | scripts root-owned; marker directory root 0700, marker files root 0600; absolutely no outside-writer access |
| NPM compose/certs | existing `/opt/nginx-proxy-manager` volumes `/data` + `/etc/letsencrypt`, Docker network identity | Keep untouched. New hostname gets independent Proxy Host and managed certificate only after approval; no host nginx |
| Omada OpenAPI credentials | protected root-owned service config/credential source | New Controller ONLY, per-client least privilege; secrets not written here; verify permissions read-only before enabling |
| Evidence Receiver leaf key/CA | `/etc/captive-portal/device-fingerprint/` (planned) | root/receiver ACL, SAN IP127.0.0.1, dedicated CA trust and renewal, no old key reuse |
| Sensor bearer | systemd `LoadCredential=device-fingerprint-bearer` | separate token file, no env dump or journald leak; exact new source registration |
| Portal evidence bearer | protected external absolute credential path | not the Sensor token, no test token reuse |
| Site/Guest/CAPPORT | new Omada read-only inventory + Cisco DHCP/SSID/capture scope | all unverified Site/CIDR/SSID marked HOLD until evidence; old `.202` defaults not authority |

## Planned data and runtime directories (no creation until approved)

| Family | Directory | Writer / status |
|---|---|---|
| Core authoritative SQLite and application logs | `/opt/CaptivePortal/data`, `/opt/CaptivePortal/logs` | `captivportal` single main writer; ABSENT |
| Visit Registry, Visit Lifecycle, Observation, Current State, Settings DB, Analytics, NI projections | per approved release `app/config.py` location in `data/`; unique DB path per owner and writer | respective application components; ALL OFF / no manual `sqlite3 CREATE` |
| Evidence authoritative SQLite, control plane and writer lock | approved release `DEVICE_FINGERPRINT_{DB_PATH,EVIDENCE_DB_PATH,CONTROL_PLANE_DB_PATH,...}` | `captiv-evidence` writer/explicit ACL (exact desired path from release), OFF |
| Sensor spool | `/var/lib/captive-portal/fingerprint-sensor/spool.sqlite3` | `captiv-sensor`; EMPTY from first boot, not copied |
| Sensor EVE Unix socket | `/run/captive-portal/fingerprint-sensor/suricata-eve.sock` | generated runtime directory/socket; Socket is created by Sensor and written by Suricata; OFF |
| Suricata EVE configuration | `/etc/captive-portal/device-fingerprint/suricata.yaml` | root-controlled, AF_PACKET points to **enp3s0**; not installed |
| Portal auth telemetry and normalized webhook | `/opt/CaptivePortal/logs/` | bounded structured logs, redacted query/MAC/token/secret; OFF until flags |
| Backups | `/srv/backups/app-data/captivportal-new/` (new isolated namespace) | root, mount UUID guard, write only app-consistent backup snapshots; directory NOT created |

Do not chown `/opt` recursively; ownership/mounts must be inventoried before creation. Source trees root-owned, writer data owned by corresponding dedicated principal; group ACL for shared Unix socket and CA *read* access only. Control `UMask=0027` or stricter, use systemd `ReadWritePaths`/`ProtectSystem`/`NoNewPrivileges` where verified compatible. CAP_NET_RAW only capture services; Flask and Receiver must not join Docker group.

## Existing backups and constraints

- Omada native config/history backup mirror timer `captiv-omada-native-mirror.timer` active, the disk `/srv/backups` mounted; last run observed 2026-10-15 ~12:20 UTC. NPM timer `captiv-npm-backup-online.timer`, host `captiv-backup.timer` active/scheduled. These do not automatically cover a future new Portal.
- Site-specific fresh service backup requires **consistent SQLite** (SQLite online-backup API or full quiesce with WAL/SHM snapshot, never raw `cp` active DB without correctness argument); durable secrets/CA dependency manifest encrypted and access-controlled; preserve writer schema/build/SHA.
- A restored data tree must be restored into **disposable isolated path** for smoke and must not accidentally bring up production services, old API credentials, legacy VLAN/SSID or accepted guest traffic.
- NPM private certificate material is already backed up under existing operations; new FQDN coverage and ACME renewal prove via separate new-domain TLS tests. Certificate stored by NPM, not separate Linux host nginx.

## Logging, retention, HDD I/O and observability

- Baseline journald and bounded per-service rotating logs (size cap, count, retention documented). No bearer, OAuth token, raw login URL query, raw MAC in general reports. Synthetic query-canary through new NPM route verifies proxy/access log privacy before public use.
- Future Loki via `192.168.0.220:3100` is an *option*, not a deployed log agent on `captiv-prod`. Must verify agent install, allowlist and PII field scrubbing; Admin never uses Loki as authoritative guest state.
- Collect baseline `iostat`/`vmstat`, FS read/write sectors, WAL sizes/checkpoints, fsync/COMMIT counts per writer under controlled load. No SSD-first workaround, no unreviewed SQLite `synchronous=OFF` or deletion/VACUUM in prod.
- Disk alarms: root `/` (82 GiB available), backup HDD (~897 GiB available), inode pressure, EVE socket backlog, spool queue and WAL growth, day-shift backup results, NTP skew.

## Optional component readiness matrix

| Family | Planned status until dependencies pass | Dependency/authoritative owner |
|---|---|---|
| Core Flask/Auth and CAPPORT | `CONFIGURED_DESIGN / DISABLED` | new Omada Site, NET01, safe bind, env credentials |
| NPM isolated Proxy Host/TLS | `DISABLED` | new FQDN SNI cert, NET01, synthetic probes |
| Omada webhook / Visit Lifecycle | `DISABLED` | real secured controller callback, normalized journal writer |
| Snapshot / Visitor Registry | `DISABLED` | accepted guest owner phone, correct Site, writer bootstrap |
| Observation / Current State | `DISABLED` | read-only OmadaProvider, polling budget, timestamp freshness |
| Analytics / Admin / Settings | `DISABLED` | authoritative readers, admin access separate, Settings master key if enabled |
| Pending Session Cleaner | `DISABLED` | explicit separate AP/traffic safety authorization |
| Fingerprint Sensor / EVE / Suricata | `DISABLED` | Cisco scope, AF_PACKET, NET01 local route, Receiver + source registration |
| Evidence Receiver / F-B1 / Classification | `DISABLED` | CA/identity/producer creds, control-plane writer and acceptance |
| NI-01/02A/02B/04, projection workers | `DISABLED` | admitted source/registry, separate writer lifecycle and disk budget |
| Traffic projection/materialization | `DISABLED` | tested sources, SQLite lock, rate/retention contract |

### Security finding

Current `app/config.py` historical `VERIFY_SSL=False` requires an explicit Omada TLS decision, even with a valid public Portal certificate. `DEVICE_FINGERPRINT_*` defaults can reference old `.202` and `enp8s0`, but startup-config override support is present in approved Git. Check **every** auxiliary unit for independent env/template defaults before activation. `OMADA_TCP_8088` belongs to new Omada; avoid binding Flask there.

**Current verdict:** storage headroom PASS; policies DESIGNED; newly provisioned files/keys/backups `NOT_STARTED`; independent restore validation `HOLD`.
