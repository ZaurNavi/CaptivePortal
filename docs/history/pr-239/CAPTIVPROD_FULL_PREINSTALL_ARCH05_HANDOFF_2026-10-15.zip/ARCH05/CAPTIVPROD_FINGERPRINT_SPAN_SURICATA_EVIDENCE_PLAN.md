# ARCH-05 — passive SPAN, Sensor, Suricata and Evidence infrastructure

## Physical and network evidence

`enp3s0` is the **new** NIC and is NOT `enp8s0`: Realtek RTL8111/8168 rev15 (RTL8168h/8111h), PCI `0000:03:00.0`, r8169, MAC `00:0a:cd:00:0c:ce`. Linux reports link 1000 Mb/s full and PROMISC. Active profile `/etc/systemd/network/10-captiv-span-enp3s0.network` matches name+permanent MAC, disables DHCP/link local/RA/LLMNR/mDNS. No L3 address, route or master. Cumulative RX ~34.7M packets, drops 1575. This proves frames arrive, **not** that all frames are in-scope guest traffic.

**Required Cisco evidence:** switch model/port connected to enp3s0; SPAN source ports and VLANs; RX/TX/both selection; monitor destination direction and STP/RSPAN semantics; exclusion of unrelated Home VLAN10, remote-mirror VLAN999 and any loop/amplification source if not justified. Collect aggregated port counters and redacted config, never full visitor payloads. During later maintenance first align Cisco capture policy, not run a packet capture on visitors as an exploration shortcut.

**Forwarding risk:** `net.ipv4.ip_forward=1` and `net.ipv4.conf.enp3s0.forwarding=1` observed. Propose per-interface explicit `net.ipv4.conf.enp3s0.forwarding=0` in a reviewed persistent sysctl drop-in, **only** after verifying no Docker/Omada dependency and checking actual kernel reload behavior. Do not disable global ip_forward (Docker NAT relies on forwarding). Negative check: no IPv4/IPv6, no RA, no DHCP daemon, no bridge/bond, no ARP responder, no promiscuous outside capture NIC.

## Frozen capture path

```text
Cisco accepted SPAN mirror -> enp3s0, no L3
    +-> Sensor AF_PACKET with frozen BPF -> Sensor spool (fresh SQLite)
    +-> Suricata AF_PACKET (separate config, selected interface enp3s0)
         -> EVE output filetype=unix_dgram
         -> /run/captive-portal/fingerprint-sensor/suricata-eve.sock
         -> Sensor consumer (producer of normalized signals, not full PCAP)
Sensor -> Core readiness via local TCP 172.18.0.1:18089, lo source
Sensor -> Evidence Receiver HTTPS 127.0.0.1:9443 (design candidate)
```

**Release-specific gotcha:** approved repo `deploy/device-fingerprint/fingerprint-suricata.service` still references **`enp8s0`** (`ExecStartPre` interface path). Adjust through a reviewed deployment template/drop-in, and coordinate `suricata.yaml` AF_PACKET interface, Sensor `DEVICE_FINGERPRINT_SENSOR_INTERFACE=enp3s0`, EVE socket, BPF and NI readers. Merely changing Sensor env does NOT adjust Suricata or NI automatically. Suricata is not installed now. Do not leave a service targeting a non-existent interface.

## Sensor→Core readiness security contract (separate from Evidence)

- Approved application release supports startup-only `DEVICE_FINGERPRINT_SENSOR_CORE_READY_HOST=172.18.0.1` and `_PORT=18089`; readiness is **TCP connect** only, not HTTP health or auth proof.
- Host routing measurement: `ip route get 172.18.0.1 from 172.18.0.1` returns `local ... dev lo`. Thus the proposed **narrow exact** NET01 local path is `-i lo -s 172.18.0.1/32 -d 172.18.0.1/32 -p tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT`, placed before terminal REJECT. **Do not install without updating all guards/install/rollback/fixtures.**
- All host-local processes can potentially use this rule; it is *not* per-Sensor UID. Stronger UID isolation through OUTPUT owner mark / connmark could be considered if tested without race/loopback side effects, but is not accepted yet. Do not claim UID isolation by app naming. No blanket host, subnet or other-container allow.
- New exact chain shape would be: NPM-only allow; tested local-origin allow; catch-all REJECT. Existing REV4 verifier expects two rules and will reject three: package extension with reviewed exact rules and watchdog is P1.

## Receiver location, transport and identities

Prefer **separate local HTTPS Receiver** bound to `127.0.0.1:9443` for both same-host producers; no LAN/Guest exposure, no external firewall port. On new install provide Receiver CA, service leaf cert with `subjectAltName=IP:127.0.0.1`, proper EKU/serverAuth, file ownership, expiry/renewal. Sensor and Portal clients trust only approved CA, verify hostname/IP and chain. Do not disable `verify` or reuse old `.202` trust keys.

Distinct producer credentials: `sensor` supplied via systemd `LoadCredential=device-fingerprint-bearer`; `Portal Producer` supplied separately from protected absolute file path. Receiver producer registration includes producer_id, capture_source_id, site_id, guest CIDRs, SSIDs/event kinds. Configured identity is **not** source registration/admission. Receiver source ACL should allow only loopback; `DEVICE_FINGERPRINT_API_ALLOWED_NETWORKS=127.0.0.0/8` is an explicit proposal subject to actual IPv4 peer tests. Allow no other network by default.

### Event/durability chain

1. Distinct sensor/portal events, authenticated TLS + bearer and same Site scope are required for ingest.
2. Receiver validates event kind, capture_source/site, timestamp skew, idempotency/ack, body size, replay/dedup and source binding before authoritative SQLite writer commits. Incorrect identity returns reject with no accepted evidence.
3. Source Registration and Source Health owner records are separate from successful insert; F-B1 Admission separate again. A valid HTTP response does not imply classification rights.
4. Bounded sender spool for transient outages, retry/jitter and idempotency limits. On new host empty spool only; never replay old production Evidence. Explicitly archive/purge synthetic preflight evidence before real production.
5. Receiver unavailable: Sensor/Portal producer fail controlled; evidence stays bounded/untrusted, guest login must NOT depend on fingerprint signals. EVE missing: do not invent EVE-supported classifications.

## Required tests/gates

- Before app installation: verify NIC identity, counters, Cisco scope and overrun/drop baseline; no long-term capture; verify port 9443 unused; prepare CA/credential custody; synthetic TLS endpoint probes on loopback, invalid cert+SAN, wrong bearer, wrong producer; check root directory/ACL. No visitor data.
- Before live Sensor: selected AF_PACKET interface, BPF syntax and immutable digest, Suricata `-T` offline config, actual `enp3s0` and EVE Unix socket permissions, consumer-before-producer startup, expected EVE JSON fields, negative missing-EVE and RX-drop alarms.
- Later after Portal bootstrap: registrations bound to new Site and F-B1; test controlled synthetic signal Source Health transition; avoid claiming real MAC/guest or classification without approved pilot.

**Status:** `SPAN_PHYSICAL_LINK=PASS`, `SPAN_SOURCE_SCOPE=HOLD`, `SURICATA_EVE=HOLD`, `SENSOR_LOCAL_FIREWALL=HOLD`, `RECEIVER_TLS/IDENTITY=HOLD`, `ACTIVATION=OFF`.
