# ARCH-05 — mandatory staged preinstall validation and rollback

**Hard boundary:** CaptivePortal installation remains NOT AUTHORIZED. The scope of this package is design, read-only evidence and offline NET01 patching. Isolated diagnostics may be proposed, but **no permanent firewall, NPM, new service or capture** has been installed on `captiv-prod` by this task.

## Change preconditions

Before each target mutation: (1) identify exact file/unit/iptables chain/container/network/certificate being changed; (2) Owner GO listing those objects and service impact; (3) backup current state with hashes; (4) verified independent console/management path; (5) rollback command after reversible preflight; (6) no active guest or AP reconfiguration. For each test, record UTC time, observed command exit status, source namespace, expected/actual result, whether data are synthetic, and SHA256 of artifacts. Refuse on mismatch; no open-ended iptables trial-and-error.

## Gate test matrix

| Gate | Test without new Portal | Required PASS, negative, failure behavior | Current |
|---|---|---|---|
| T01 Host/port | Read-only `ss -lntup`, systemd, routes, `df`, NTP | Old Omada ports intact; 18089/9443 free; new Portal absent | **PASS for snapshot** |
| T02 Docker identity | Read-only network/inspect; name, IP, MAC, bridge, digest, sole membership | Verifier exact values; unexpected container/network/image drift must block app | **Observed matching REV4 constants**, not live verifier |
| T03 DNS/TLS FQDN | `getent`, direct SNI TLS with `--resolve` | public DNS A + valid new cert and dedicated Proxy Host; negative unknown SNI must be correct before activation | **FAIL/HOLD** (`unrecognized name`) |
| T04 NET01 code/recovery | Offline Linux pytest + real verifier parser | bypass only root + valid MAINT; unknown status blocks; no blind firewall deletion | **104 passed**, real PID1 HOLD |
| T05 NET01 real PID1 | Disposable Ubuntu PID1, synthetic http server, deny-first rules | watchdog `Type=notify`, BindsTo stop, `ExecStartPre` root vs Flask unprivileged, rollback quiescence; crash/kill/queued-jobs negative | **HOLD** |
| T06 NET01 live reachability | Scoped Owner window: ephemeral listener `172.18.0.1:18089` and exact ephemeral firewall; NPM container to host | source NPM allows; management/guest/WAN/non-NPM container denied; IPv6 denied. No dangerous 0.0.0.0 bind | **HOLD** |
| T07 NET01 persistence/drift | Disposable Docker/NPM staging | recreate/restart changes bridge IP/MAC/member/image → watchdog STOP+HOLD; reinstall/clear intentional only | **HOLD** |
| T08 Sensor local route | Before Portal, synthetic TCP listener and local-origin exact policy | `ip route get` via lo (observed); sensor UID path connects, outside LAN/Guest/docker denied; note any host-local process trust | **HOLD/P1 extension** |
| T09 Capture identity | sysfs/netplan/networkctl, no packet payload | enp3s0 PCI/MAC/r8169, no address/route/master, promiscuity; explicit per-interface forwarding policy | **PARTIAL** |
| T10 SPAN policy | Cisco redacted `show monitor session` + interface counters | expected guest VLAN/port direction, no VLAN10/999 amplification unless approved, no loops, physical path documented | **HOLD** |
| T11 Suricata/EVE | Offline `suricata -T`, AF_PACKET config and synthetic datagram | correct `enp3s0`, frozen BPF, dedicated Unix socket perms, missing EVE → no false classification | **HOLD** |
| T12 Receiver TLS | synthetic loopback HTTPS service `127.0.0.1:9443`, valid CA/SAN, invalid chain/expiry negative | binds only loopback; separate bearer; reject nonlocal/wrong kind/source/site | **HOLD** |
| T13 Source F-B1 | future isolated control-plane bootstrap | ingest ≠ registration ≠ health ≠ admission; rejects wrong epoch or stale source | **RUNTIME_ONLY** |
| T14 Omada OpenAPI | target OS read-only OAuth/Site/client using new least-privilege creds | `errorCode=0`, correct controller/Site, no secrets logged, permission errors fail closed | **HOLD** |
| T15 Webhook & CAPPORT path | synthetic authenticated webhook and `/capport/api` once listener present | Source+SNI+ProxyFix, redacted logs, correct site/guest; DHCP114 OFF until pilot | **RUNTIME_ONLY** |
| T16 Backup/restore | isolated consistent SQLite synthetic backup + restore, root-owned env and keys manifest | no legacy history, no live DB raw cp, no accidental service activation | **HOLD** |
| T17 NPM route privacy | dedicated new Proxy Host only after cert/NET01 PASS | Host/Proto/Port/XFF client-IP spoof rejects; sensitive-query canary not persisted | **HOLD** |
| T18 Pilot AP guest auth | NOT in ARCH-05 | separately authorized single AP/owner phone, Omada authorize+readback `authStatus==2`, Internet | **NOT_AUTHORIZED** |

## NET01 REV4.1 offline findings

REV4 independent review found `net01-fw-install.sh --maintenance-reinstall` passed flags `--identity --ignore-maintenance --ignore-hold`; actual REV4 verifier rejected ignore-HOLD except with `--all`. In a **separate Windows Downloads** copy REV4.1 candidate, the real verifier now accepts the identity recovery combo ONLY for root and verified root-owned 0600 MAINTENANCE; normal startup still rejects markers. New test calls real verifier parser and validates exact installer flag sequence plus negative cases. Linux WSL native /tmp run **104 passed**, but entire reinstall shell+real verifier integration under an actual PID1 is **not yet validated**. This patch does not extend firewall to host-local Sensor.

**Package on owner's workstation:** `C:\Users\Zaur Navi\Downloads\TASK-CAPTIVPROD-NET01-IMPLEMENTATION-03_PART-A_REV4_1_OFFLINE_CLEAN.zip` (100145 bytes at build). This path is NOT on `captiv-prod`; the package is NOT final approved NET01 and must not be installed. Reviewer must inspect recovered manifest, exact source and test outcomes independently.

## Rollback contract

- On diagnostic listener test: stop only temporary listener; verify `ss` port closed, exact new diagnostic systemd transient unit inactive; no app core unit exists.
- On firewall staging: enter sticky MAINTENANCE under root and lock **before** stop; prove `systemctl` inactive/dead, no pending jobs, TCP 18089 not listening; verify exact chain/header IPv4 and IPv6 guards; remove **only** owned rules, with stop/hold on any mismatch or failed command. NEVER `iptables -F`, `iptables -P ACCEPT`, nft global flush or skip check based on failed `ss`/systemctl.
- On watchdog failed validation: maintain HOLD, stop only new diagnostic backend; NPM/Omada remain operating. Do not clear marker automatically or use blind service restarts.
- On NPM isolated test route: retain snapshots of three existing Proxy Hosts, dedicated hostname/SNI only; delete/disable only new Proxy Host after approval if test fails; verify old production TLS/Hestia route unaffected.
- On Sensor/Receiver: revoke **new synthetic** producer bearer, stop new services only, preserve evidence for audit, restore receiver source policy; never reclassify/erase actual visitors or alter old `.202`.
- On AP pilot: separate TASK rollback required; not permitted by this preinstall job.

## HOLD ledger for Architect acceptance

| Priority | Finding | Required decision |
|---|---|---|
| P1-NET01-LOCAL | REV4.1 only fixes maintenance P1, but Sensor→Core host-local allowance changes exactly matched firewall rules | Design-approved chain policy + scripts/verifier/watchdog/fixtures + independent review, PID1 acceptance |
| P1-NET01-STAGING | Real systemd PID1/rollback, Docker recreate and production-like firewall denial not performed | Isolated production-like lab with real docker/systemd, operational rollback evidence |
| P1-NEW-TLS | New FQDN points public but NPM has no Proxy Host; TLS SNI fails | dedicated host/certificate creation under controlled GO after backend security acceptance |
| P1-OMADA-SITE | New controller Site ID, production AP count, OpenAPI client scopes not validated | authenticated read-only API/UI capture with secret-free report |
| P1-CAPTURE | Cisco mirror source/direction, VLAN10/999 scope and forwarding contract unknown | Cisco redacted mirror config + per-interface sysctl policy |
| P1-EVIDENCE | Receiver TLS/CA/SAN and source registration, producer tokens, source health and F-B1 not created | trust+credentials+admission design approval and synthetic tests |
| P1-WEBHOOK | Controller same-host HTTPS callback path and preserved IP identity not selected | Test local FQDN→NPM, authenticated webhook, no WAN hairpin |

Acceptance can be `PREINSTALL_READY=PASS` only when network/service path matrix has no architecture UNKNOWNs, code package independent review PASS and relevant real systemd/firewall tests PASS. Runtime-only app behavior is listed separately, not misrepresented as preinstall verified. **Current result: HOLD**.
