# ARCH-05 — systemd startup, dependency and stop plan

**State:** design review; **nothing installed**. Ubuntu 22.04.5, systemd PID 1. The approved Git commit is `7e84bc563f1b6dd3d72da66ae25849d9a7d96540`. All proposed unit names, command paths, user accounts and privileges must be compared with the exact files in this commit before activation; listed unit edges are a plan, not an observed merged `systemctl cat`.

## Existing services (leave operational)

| Service | Live state | Boundary |
|---|---|---|
| `systemd-networkd`, `systemd-resolved` | running | primary `enp2s0`, capture-only `enp3s0` |
| `docker.service`, `containerd.service` | running | NPM Docker bridge |
| `npm` Docker container | running | public TLS/3 existing Proxy Hosts; never recreate outside a separate maintenance window |
| `tpeap.service` | running | Omada controller owns ports 8043/8088/8843 and discovery/adoption ports |
| `captiv-omada-guard.service` | active | existing access policy for Omada |
| `captiv-npm-admin-firewall.service` | enabled | NPM port 81 management restriction |
| existing backup timers | active/enabled | do not alter existing root/Omada/NPM backups |

## Target dependency DAG

```text
networkd / enp2s0 + systemd-resolved
                 |
           Docker Engine --------------------- existing npm (remain running)
                 |                               |
                 +-> NET01 firewall (root, exact identity + rules, fail-closed)
                                      |
                               NET01 watchdog (root, Type=notify,
                               startup verifies Docker+firewall BEFORE READY)
                                      |
                               new captive-portal.service (single run.py process,
                               User=captivportal, Group=captivportal,
                               binds exactly 172.18.0.1:18089)
                                      |
                               Optional Portal Producer (inside main composition,
                               separate feature/admission gate)

new Evidence Receiver (separate unit/user, 127.0.0.1:9443)
                 |     ^
                 |     | Sensor and Portal evidence producers (TLS+separate bearer)
                 v     |
       source registration and health data (writer owned)
                 |
     optional F-B1 / classification / NI readers (gate)

networkd / enp3s0 stable capture-only
                 |
     Fingerprint Sensor (CAP_NET_RAW, validated NIC, waits Core TCP readiness,
                 |     initializes Unix datagram EVE socket, starts only after
                 |     Receiver+registration+scope+NET01 local-origin gate)
                 |
      Suricata AF_PACKET (separate CAP_NET_RAW user; waits for Sensor EVE socket)
```

**Avoid cycle:** Sensor creates `/run/captive-portal/fingerprint-sensor/suricata-eve.sock`; Suricata must NOT be `Before=` Sensor if its ExecStartPre waits for the socket. Determine whether the Sensor readiness checks Core before creating the socket from real code during staging. Do not force Suricata→Sensor→Core→Suricata cycle. All auxiliary processes remain disabled in preinstall.

## NET01 intended main unit contract

- `captiv-net01-firewall.service`: root, `RemainAfterExit`, ordered after Docker/network but before watchdog/Flask; verifies Docker identity and installs deny-first exact IPv4/IPv6 filter. Firewall install only when `net01-quiescent.py --mode install` PASS, or special root MAINTENANCE recovery. Never change existing Omada or NPM rules.
- `captiv-net01-watchdog.service`: root `Type=notify`, `NotifyAccess=main`, emits READY only after full exact guard; checks drift periodically; on fail or stop latches HOLD and allows `BindsTo` to stop Flask. Failsafe service responsible for bounded stop/SIGKILL/listener closure on abnormal failure; do not let watchdog recursively stop itself.
- `captive-portal.service`: unprivileged dedicated principal, root-only `ExecStartPre=+` guard, `BindsTo=captiv-net01-watchdog.service`, `After=captiv-net01-watchdog.service`; `ExecStart` NEVER privileged. `Restart=no` until real lifecycle acceptance. One Python `run.py`, no Gunicorn multiworker. Not installed before Architect preinstall PASS.
- `MAINTENANCE` / `HOLD`: root-owned 0700 directory, 0600 regular latch files; serialized operator maintenance lock with no emergency bypass via ordinary service startup. Reinstall must verify inactive/dead/no jobs/no listener before firewall mutation. Rollback removes only owned rules after exact checks; any unknown leaves HOLD.
- NET01 REV4.1 code in isolated owner workstation Downloads is **offline candidate**, never installed. Real PID1 `systemctl show`, `systemctl cat`, `ExecStartPre` privilege, `Type=notify` READY, `BindsTo` stop propagation and rollback races remain HOLD.

## Service identity/permissions proposal

| Runtime | User/Group | Capabilities / storage | Restart/stop policy |
|---|---|---|---|
| NPM | existing Docker owner | no Docker socket passed to app, existing volumes | **untouched** |
| Omada | existing `omada` | its own Mongo, runtime and backups | **untouched** |
| NET01 helpers | root, root-owned read-only scripts | Docker inspect, restricted iptables operations, root-only latches | fail closed, watchdog drift STOP |
| CaptivePortal core | `captivportal:captivportal` | only app `data`, `logs` writers; no Docker group/sudo/CAP_NET_RAW | one process, operator start after PASS |
| Evidence Receiver | dedicated `captiv-evidence` (candidate) | protected CA/server key, evidence/control-plane SQLite writer | fail-closed invalid identities, no public 9443 |
| Sensor | dedicated `captiv-sensor` (candidate) | `CAP_NET_RAW` only if required; own empty spool, read-only credential; socket directory group | stop when core readiness/Receiver identity cannot be established; bounded retry, no blind replay |
| Suricata | dedicated `captiv-suricata` (candidate) | CAP_NET_RAW/NET_ADMIN only as empirically needed; EVE socket write access via group | no persistent capture until approved |
| NI / analytics / admin / webhook workers | separated when implementation requires | derived read stores, reviewed background write ownership | remain OFF |

## Admission/activation order

1. Preserve baseline/backup of original systemd and Docker config. Verify candidate approved SHA/tree and unit templates offline.
2. NET01 final source/fixture review; real disposable PID1 staging with synthetic backend. Prove deny-first and watchdog/rollback negative conditions before live host.
3. On production host only after scoped authorization: install hardened config and unit files **disabled**; `systemd-analyze verify` plus root permissions; deny-first NET01 and diagnostic-only listener in isolated window. Validate exact allowed/denied sources, then stop test listener and leave new units stopped.
4. Provision separate Evidence Receiver trust/certs/data and verify loopback TLS, credentials and source policy with synthetic events. Enable only after admission plan.
5. Post-ARCH-05 installation approval only: install app from approved Git SHA/tree, configure fresh data+secrets, start guarded single Flask; never reuse `.202` DB/secret or overwrite `*:8088`.
6. Later, gated phases: NPM new Proxy Host + certificate, one pilot AP/phone, webhook/visit, observations/current state, fingerprint capture/EVE, classification/NI, Admin/Settings.

## Staging tests required before READY

- Synthetic test Ubuntu PID1 with `Type=notify` READY ordering; negative Docker identity check, marker sticky and stop propagation; no service executes insecurely as root.
- Gate that PORT `18089` is unavailable if firewall not installed; real `ss -lntp` verifies listen only on 172.18.0.1 after install.
- Docker NPM `restart` and `recreate` change scenarios: stop/hold without affecting unrelated production hosts.
- Authorized `systemctl stop` and crash/kill watchdog cause core socket to disappear; rollback refuses active service and unknown jobs; ordinary startup never ignores HOLD/MAINTENANCE.
- Sensor-before-Suricata Unix socket order; bad EVE socket fail safe; new service process capabilities checked by `/proc/<pid>/status`.
- Backups/restore smoke on isolated paths; no side effects on Omada/NPM timers.

**Acceptance now:** `SYSTEMD_DEPENDENCY_GRAPH=DESIGNED_NOT_VERIFIED`, `NET01_REAL_SYSTEMD_ACCEPTANCE=HOLD`, `NEW_SERVICE_INSTALL=NOT_STARTED`.
