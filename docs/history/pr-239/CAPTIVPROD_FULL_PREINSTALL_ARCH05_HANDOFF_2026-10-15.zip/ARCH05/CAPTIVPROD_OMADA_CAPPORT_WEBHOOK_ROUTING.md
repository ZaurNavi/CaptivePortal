# ARCH-05 — Omada, CAPPORT, Guest and webhook routing

## Observed live controller baseline

| Property | Linux new Omada (`captiv-prod`) | Legacy Windows (do not alter) |
|---|---|---|
| URL/UI | `https://192.168.0.99:8043` and local `https://127.0.0.1:8043` | `https://192.168.0.222:8043` |
| Version | 5.14.32.3 | 5.14.32.3 |
| Omada controller ID from `/api/info` | `68ba0bb73ec9f9f0add0a21382f1b810` | `fe6867ddf84e4c18c4e280e984e4266d` |
| Service | `tpeap.service` active | externally reachable, API information responds |
| HTTP `errorCode` | `0` on `/api/info` | `0` on `/api/info` |
| Site ID, SSID, rights, AP count | **UNVERIFIED (requires credentialed read-only UI/OpenAPI)** | Must remain untouched; ownership evidence before pilot |

`/api/info` confirms controller identity and health, **not** OpenAPI authentication or read permissions. Omada also has TCP `8088` bound by Java; new Flask must not use it. No OpenAPI client secret or bearer was retrieved or copied. The old controller is NOT the dependency for new code.

## Backend controller/OpenAPI path

Proposed effective controller API endpoint for co-resident new portal: `https://127.0.0.1:8043` only if TLS certificate SAN and CA verification support the identity. If the controller certificate is for its management FQDN and excludes loopback IP, use that verified FQDN with local routing (not `VERIFY_SSL=False` as a substitute). TLS trust decision is an explicit security gate, including library default behavior. Code `OMADA_URL`, `OMADA_ID`, `OMADA_CLIENT_ID`, `OMADA_CLIENT_SECRET` will be placed in root-owned service env/credential store, NOT Git or report. Validate OAuth2 `client_credentials` token exchange + non-destructive Site/client GET; require JSON `errorCode=0` and expected actual Site; protect token in process logs and response.

- Capture actual Site list/IDs, WLAN/SSID names, Hotspot profile, authorized client lookup, API permission scopes from **new** controller.
- No auth/unblock/cleaner/reconnect operations on production devices; only after separate pilot AP GO and owner phone.
- Wrong Site, revoked token, insufficient scope and expired token must fail closed without false AUTHORIZED.
- The derived Site ID must be matched against CAPPORT, sensor, portal evidence, producer registration, webhook Site map and Admin allowlists. Historical `6a64f17630da7c70d232187a` is **only legacy default, not verified new Site**.

## External guest path / split DNS

Planned new hostname `captivprod-navi.duckdns.org` DNS A resolves to static public `85.132.110.97` from new host, but no current NPM Proxy Host covers it. Direct TLS SNI to `192.168.0.99:443` failed (`unrecognized name`). This is **not** HTTPS acceptance. Preserve old `captivportal-navi.duckdns.org` Proxy Host, certificate and Hestia upstream exactly.

Guest route after approval: guest DHCP resolver → new FQDN DNS → public/NAT/NPM HTTPS 443 → dedicated new Proxy Host cert → guarded `172.18.0.1:18089` Flask. Confirm guest walled garden pre-auth access to DNS+FQDN:443, whether split DNS or Cisco hairpin required, and IPv6/AAAA behavior. Never open SSH/Admin/Omada or 18089 to Guest. No new public Nginx or Cisco NAT changes.

Proxy headers at the *single* NPM trusted hop must be overwritten, not copied from a visitor: `Host` exact FQDN, `X-Forwarded-For` generated from `$remote_addr`, `X-Forwarded-Proto=https`, forwarded host/port, URI+query unchanged to app but **query values redacted/not persisted in access logs**. Application `ProxyFix(x_for=1,x_proto=1,x_host=1,x_port=1)` must be verified. Conduct synthetic spoofed `X-Forwarded-*` canaries through new isolated test route. Current legacy 2-hop Hestia workaround is NOT a candidate for direct new backend.

## CAPPORT acceptance

Approved Git release has deploy-configured host/port and CAPPORT; do not redo code change. Populate **from actual new controller**: `CAPPORT_SITE_ID`, `CAPPORT_PUBLIC_BASE_URL=https://captivprod-navi.duckdns.org`, `CAPPORT_ALLOWED_CLIENT_NETWORKS`. Validate CIDR against Guest VLAN at Cisco (prior `192.168.8.0/22`, gateway `192.168.10.1`, SSID `Zefer_Parki` are only historical candidates). Test `GET /capport/api` correct content type `application/captive+json`, login URL, no cross-Site identity confusion; synthetic unauthenticated probes may correctly return a bounded 4xx. DHCP option 114 remains **OFF** until basic External Portal pilot passes. Current DHCP 114 state on the guest gateway is NOT verified.

## Omada → new Portal webhook

Destination design: `https://captivprod-navi.duckdns.org/api/integrations/omada/webhook`, reaching dedicated NPM Proxy Host with verified certificate and SNI, not the old `.202` endpoint. Omada resides on the same Linux host; the preferred route to NPM should stay local (e.g. controlled name resolution to `192.168.0.99` **only if** approved and proven) instead of relying on hairpin NAT. Prove callback source at the Flask side after trusted ProxyFix: actual Omada source must be distinguishable from other clients; if all callers collapse to NPM IP, **IP-only webhook auth is insufficient**. Choose validated header token / shared-secret mode bound to new Controller, source allowlist and negative tests. Omada webhook delivery version/secret acceptance must be verified in its UI and checked in app docs. No webhooks redirected prior to pilot/feature GO.

Mapping gate: incoming site name → exact new Site ID; event allowlist, replay/idempotency, normalized JSONL to owned writer, protected access logs with hashed/redacted identities. Startup failures or Controller outage must cause controlled unavailable/unknown, never fabricated visitor/offline events. No independent webhook consumer starts on legacy stream.

## Pilot AP migration plan (later TASK only)

Record live production and new controller AP inventories *without changes*. Choose one owner-controlled AP and test SSID, reserve rollback path to old Omada, do not simultaneously adopt/manage on two controllers. Pilot must use new FQDN and corresponding Site, test owner's stable-MAC phone only. Require redirect→HTTPS→Omada authorize→controller `authStatus==2` read-back→Internet. Test randomized MAC separately. If failure, roll back pilot AP and profile through pre-approved network steps; original APs/old Portal untouched.

**Current status:** `NEW_OMADA_VERSION=PASS`, `NEW_SITE_ID=HOLD`, `OPENAPI_OAUTH_READONLY=HOLD`, `GUEST_DNS_A=PASS`, `GUEST_TLS=HOLD`, `CAPPORT=DESIGNED/NOT_TESTED`, `WEBHOOK=DESIGNED/NOT_TESTED`, `OLD_OMADA_UNCHANGED=YES` (no mutation by this work).
