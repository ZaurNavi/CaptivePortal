"""Architect-approved offline lock-path verification, no production mutation."""
import fcntl
import os
from pathlib import Path
import pytest
from rev4_fixture import isolated

ROOT=Path(__file__).resolve().parents[1]
NAMES=(
    'net01-clear-hold-review-only.sh',
    'net01-clear-maintenance-review-only.sh',
    'net01-fw-install.sh',
    'net01-fw-rollback.sh',
    'net01-maintenance-enter.sh',
    'net01-start-admit.sh',
)


def test_all_six_use_identical_nonremoving_lock_and_shared_inode():
    snippets=[]
    for name in NAMES:
        code=(ROOT/'firewall'/name).read_text()
        assert code.count('NET01_LOCK_DIR=/var/lib/captiv-net01')==1
        assert code.count('NET01_LOCK_FILE="$NET01_LOCK_DIR/net01-firewall.lock"')==1
        assert code.count('exec 9>"$NET01_LOCK_FILE"')==1
        assert 'flock -n 9' in code
        assert 'stat -Lc' in code
        assert 'unlink "$NET01_LOCK_FILE"' not in code
        snippets.append(code[code.index('# Single persistent, root-owned inode.'):code.index('flock -n 9')])
    assert len(set(snippets))==1
    unit=(ROOT/'systemd/captiv-net01-watchdog.service').read_text()
    assert 'ReadWritePaths=/var/lib/captiv-net01\n' in unit
    assert '/run/lock/captiv-net01-firewall.lock' not in unit
    firewall=(ROOT/'systemd/captiv-net01-firewall.service').read_text()
    assert 'StateDirectory=captiv-net01\n' in firewall
    assert 'StateDirectoryMode=0700\n' in firewall
    assert 'User=root\n' in firewall
    assert 'User=root\n' in unit
    assert 'ExecStartPre=+/usr/local/libexec/captiv-net01/net01-start-admit.sh' in (ROOT/'systemd/captive-portal-net01.drop-in.conf').read_text()


def test_cold_creation_and_persistence_across_repeated_admission():
    with isolated() as (root, env, run, hold, maint, log):
        f=root/'net01-firewall.lock'
        assert not f.exists()
        p, changes=run('net01-start-admit.sh')
        assert p.returncode==0, p.stderr
        st=f.stat()
        assert (st.st_uid,st.st_gid,st.st_mode & 0o777,st.st_nlink)==(0,0,0o600,1)
        inode=st.st_ino
        p, changes=run('net01-start-admit.sh')
        assert p.returncode==0, p.stderr
        assert f.stat().st_ino==inode


@pytest.mark.parametrize('name',NAMES)
def test_external_flock_blocks_every_participant_without_unlink(name):
    with isolated() as (root, env, run, hold, maint, log):
        f=root/'net01-firewall.lock'
        with f.open('w') as h:
            fcntl.flock(h,fcntl.LOCK_EX | fcntl.LOCK_NB)
            p,changes=run(name)
            assert p.returncode==75,(name,p.stdout,p.stderr)
            assert f.stat().st_ino==os.fstat(h.fileno()).st_ino
        assert f.exists()


@pytest.mark.parametrize('bad', ['world_readable_dir','dir_symlink','missing_dir','bad_mode','lock_symlink','lock_hardlink','lock_directory'])
def test_fail_closed_for_insecure_path_or_inode(bad):
    with isolated() as (root, env, run, hold, maint, log):
        d=root/'locktest';d.mkdir(mode=0o700)
        target=d
        lock=d/'net01-firewall.lock'
        if bad=='world_readable_dir':d.chmod(0o755)
        elif bad=='dir_symlink':
            alias=root/'alias';alias.symlink_to(d, target_is_directory=True);target=alias
        elif bad=='missing_dir': target=root/'missing'
        elif bad=='bad_mode':lock.touch(mode=0o644);lock.chmod(0o644)
        elif bad=='lock_symlink':
            outside=root/'protected_target';outside.write_text('PRESERVE_ME');lock.symlink_to(outside)
        elif bad=='lock_hardlink':
            outside=root/'protected_target'; outside.write_text('PRESERVE_ME'); outside.chmod(0o600);os.link(outside,lock)
        elif bad=='lock_directory':lock.mkdir(mode=0o700)
        p, changes=run('net01-start-admit.sh', lock_dir=target)
        assert p.returncode==75,(bad,p.stdout,p.stderr)
        assert changes==[]
        if bad in ('lock_symlink','lock_hardlink'):
            assert (root/'protected_target').read_text()=='PRESERVE_ME'


def test_rollback_does_not_remove_lock_under_maintenance():
    with isolated() as (root, env, run, hold, maint, log):
        p,changes=run('net01-start-admit.sh')
        assert p.returncode==0,p.stderr
        f=root/'net01-firewall.lock';ino=f.stat().st_ino
        # Mocked rollback may HOLD in later guards; lock release still preserves inode.
        p,changes=run('net01-fw-rollback.sh',marker=True)
        assert f.exists() and f.stat().st_ino==ino
        p,changes=run('net01-fw-install.sh',args=('--maintenance-reinstall',),marker=True)
        assert f.exists() and f.stat().st_ino==ino
