"""Focused Architect-approved P1-A/P1-B regressions (offline, no privileged calls)."""
from pathlib import Path
import pytest
from test_net01_integrated_two_paths import proof, SENSOR_IN, NPM_ALLOW, REJECT_IN
ROOT = Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('invalid', [
    SENSOR_IN.replace('--ctorigsrc 172.18.0.1','--ctorigsrc 192.168.0.99'),
    SENSOR_IN.replace('--ctorigdst 172.18.0.1','--ctorigdst 172.18.0.2'),
    SENSOR_IN.replace(' --ctorigsrc 172.18.0.1',''),
    SENSOR_IN.replace(' --ctorigdst 172.18.0.1',''),
    SENSOR_IN.replace('-i lo ','-i br-627e7c1ca6d5 '),
    SENSOR_IN.replace('-i lo ','-i lo -s 192.168.0.99/32 '),
    SENSOR_IN.replace('--ctorigsrc 172.18.0.1','--ctorigsrc 0.0.0.0'),
    SENSOR_IN.replace('--ctorigdst 172.18.0.1','--ctorigdst 0.0.0.0'),
])
def test_wrong_original_tuple_or_broad_allow_is_hold(monkeypatch, invalid):
    with pytest.raises(RuntimeError):
        proof(monkeypatch, inchain='-N CAPTIV_FLASK_18089\n'+NPM_ALLOW+invalid+REJECT_IN)


def test_installer_and_rollback_exact_original_tuple():
    needle='--ctorigsrc 172.18.0.1/32 --ctorigdst 172.18.0.1/32 -j ACCEPT'
    for name in ('net01-fw-install.sh','net01-fw-rollback.sh'):
        text=(ROOT/'firewall'/name).read_text()
        assert text.count('--ctorigsrc 172.18.0.1/32')==1
        assert text.count('--ctorigdst 172.18.0.1/32')==1
        assert ' -i lo -s 172.18.0.1/32' not in text
        assert '-m owner --uid-owner "$SENSOR_UID"' in text
        assert '-i br-627e7c1ca6d5 -s 172.18.0.2/32' in text
    v=(ROOT/'firewall/net01-verify.py').read_text()
    assert "'--ctorigsrc', GATEWAY, '--ctorigdst', GATEWAY" in v
    assert "'--ctorigsrc', GATEWAY + '/32'" not in v


def test_watchdog_exact_rw_exception_with_cold_lock_creation():
    unit=(ROOT/'systemd/captiv-net01-watchdog.service').read_text()
    assert 'ProtectSystem=strict' in unit
    assert 'ReadWritePaths=/var/lib/captiv-net01\n' in unit
    assert 'ReadWritePaths=/run\n' not in unit
    for name in ('net01-fw-install.sh','net01-fw-rollback.sh','net01-start-admit.sh'):
        text=(ROOT/'firewall'/name).read_text()
        assert 'umask 077' in text
        assert 'NET01_LOCK_DIR=/var/lib/captiv-net01' in text
        assert 'exec 9>"$NET01_LOCK_FILE"' in text
        assert "'0:0:700'" in text
        assert "'0:0:600:1'" in text
        assert 'flock -n 9' in text
