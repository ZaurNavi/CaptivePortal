#!/usr/bin/env bash
# REV4: network identity and systemd/listener checks fail-closed; review only.
set -euo pipefail
umask 077
(( EUID == 0 )) || { echo 'HOLD: root required' >&2; exit 75; }
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
PROBE=/usr/local/libexec/captiv-net01/net01-quiescent.py
MAINT=/usr/local/libexec/captiv-net01/net01-maintenance-state.py
CHAIN=CAPTIV_FLASK_18089
OUTCHAIN=CAPTIV_SENSOR_OUT_18089
# Single persistent, root-owned inode. Do not unlink on unlock/rollback.
NET01_LOCK_DIR=/var/lib/captiv-net01
NET01_LOCK_FILE="$NET01_LOCK_DIR/net01-firewall.lock"
if [[ -L "$NET01_LOCK_DIR" || ! -d "$NET01_LOCK_DIR" || \
      "$(stat -c '%u:%g:%a' -- "$NET01_LOCK_DIR")" != '0:0:700' ]]; then
  echo 'HOLD: insecure NET01 lock directory' >&2; exit 75
fi
# Reject any pre-existing symlink, nonregular file, incorrect owner/mode or hardlink.
if [[ -L "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock symlink' >&2; exit 75
fi
if [[ -e "$NET01_LOCK_FILE" ]]; then
  if [[ ! -f "$NET01_LOCK_FILE" || \
        "$(stat -c '%u:%g:%a:%h' -- "$NET01_LOCK_FILE")" != '0:0:600:1' ]]; then
    echo 'HOLD: insecure NET01 lock file' >&2; exit 75
  fi
fi
# umask 077 above creates mode 0600 on cold start; never remove this file.
exec 9>"$NET01_LOCK_FILE"
flock -n 9 || { echo 'HOLD: NET01 operation busy' >&2; exit 75; }
# Verify the descriptor still references the canonical root-owned 0600 inode.
if [[ -L "$NET01_LOCK_FILE" || \
      "$(stat -Lc '%u:%g:%a:%h:%d:%i' -- /proc/self/fd/9)" != \
      "$(stat -c '%u:%g:%a:%h:%d:%i' -- "$NET01_LOCK_FILE")" || \
      ! -f "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock inode/permissions mismatch' >&2; exit 75
fi
# --maintenance-reinstall is MANUAL ONLY. Never set on systemd ExecStart.
if [[ "${1:-}" == '--maintenance-reinstall' && "$#" == 1 ]]; then
  /usr/bin/python3 "$MAINT" require || exit 75
  EXTRA=(--ignore-maintenance --ignore-hold)
else
  (( $# == 0 )) || { echo 'HOLD: unexpected arguments' >&2; exit 75; }
  /usr/bin/python3 "$MAINT" absent || exit 75
  EXTRA=()
fi
/usr/bin/python3 "$GUARD" --identity "${EXTRA[@]}" || exit 75
# install mode tolerates an ordered pending Flask start-job, never a live service.
/usr/bin/python3 "$PROBE" --mode install || exit 75
# Never confuse iptables query FAILURE with "no chain".
# A complete -S snapshot must be readable before *any* mutation.
POLICY=$(iptables -w -S) || { echo 'HOLD: cannot inspect IPv4 policy' >&2; exit 75; }
IPV6_POLICY=$(ip6tables -w -S INPUT) || { echo 'HOLD: cannot inspect IPv6 INPUT policy' >&2; exit 75; }
if grep -Fq -- "$CHAIN" <<< "$POLICY" || grep -Fq -- "$OUTCHAIN" <<< "$POLICY"; then
  # Existing exact firewall only; a partial/stale policy must HOLD.
  /usr/bin/python3 "$GUARD" --all "${EXTRA[@]}" || exit 75
  exit 0
fi
# If no dedicated chain exists, reject any stale rule already mentioning port.
if grep -Eq -- '(^|[[:space:]])--dport[[:space:]]+18089([[:space:]]|$)' <<< "$POLICY"; then
  echo 'HOLD: stale IPv4 port rules without approved chain' >&2; exit 75
fi
if grep -Eq -- '(^|[[:space:]])--dport[[:space:]]+18089([[:space:]]|$)' <<< "$IPV6_POLICY"; then
  echo 'HOLD: stale IPv6 backend rule' >&2; exit 75
fi
# NO listener, systemd states verified, no known chain; install deny-first.
# Dedicated user MUST exist before firewall mutation, with a nonzero UID.
SENSOR_UID=$(id -u fingerprint-sensor) || { echo "HOLD: sensor identity unavailable" >&2; exit 75; }
[[ "$SENSOR_UID" =~ ^[1-9][0-9]*$ ]] || { echo "HOLD: unsafe sensor UID" >&2; exit 75; }
iptables -w -N "$CHAIN"
iptables -w -A "$CHAIN" -p tcp -j REJECT --reject-with tcp-reset
iptables -w -I INPUT 1 -p tcp --dport 18089 -j "$CHAIN"
iptables -w -I "$CHAIN" 1 \
  -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc \
  -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
# Restrict host-local traffic at BOTH OUTPUT (UID) and INPUT (lo + original conntrack tuple).
# The TCP-wide INPUT REJECT is already installed and Flask MUST be stopped.
iptables -w -I "$CHAIN" 2 \
  -i lo -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED \
  --ctorigsrc 172.18.0.1/32 --ctorigdst 172.18.0.1/32 -j ACCEPT
iptables -w -N "$OUTCHAIN"
iptables -w -A "$OUTCHAIN" -p tcp -j REJECT --reject-with tcp-reset
iptables -w -I OUTPUT 1 -d 172.18.0.1/32 -p tcp --dport 18089 -j "$OUTCHAIN"
iptables -w -I "$OUTCHAIN" 1 \
  -o lo -s 172.18.0.1/32 -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m owner --uid-owner "$SENSOR_UID" \
  -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
ip6tables -w -I INPUT 1 -p tcp --dport 18089 -j REJECT --reject-with tcp-reset
/usr/bin/python3 "$GUARD" --all "${EXTRA[@]}" || exit 75
