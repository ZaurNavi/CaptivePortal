#!/usr/bin/env bash
# REV4: strict preconditions + sticky maintenance barrier; NO partial auto-cleanup.
set -euo pipefail
umask 077
(( EUID == 0 )) || { echo 'HOLD: root required' >&2; exit 75; }
CHAIN=CAPTIV_FLASK_18089
OUTCHAIN=CAPTIV_SENSOR_OUT_18089
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
PROBE=/usr/local/libexec/captiv-net01/net01-quiescent.py
MAINT=/usr/local/libexec/captiv-net01/net01-maintenance-state.py
# Single persistent, root-owned inode. Do not unlink on unlock/rollback.
NET01_LOCK_DIR=/var/lib/captiv-net01
NET01_LOCK_FILE="$NET01_LOCK_DIR/net01-firewall.lock"
if [[ -L "$NET01_LOCK_DIR" || ! -d "$NET01_LOCK_DIR" || \
      "$(stat -c '%u:%g:%a' -- "$NET01_LOCK_DIR")" != '0:0:700' ]]; then
  echo 'HOLD: insecure NET01 lock directory' >&2; exit 75
fi
# Reject any pre-existing symlink, nonregular file, incorrect owner/mode or hardlink.
if [[ -L "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock symlink' >&2; exit 75
fi
if [[ -e "$NET01_LOCK_FILE" ]]; then
  if [[ ! -f "$NET01_LOCK_FILE" || \
        "$(stat -c '%u:%g:%a:%h' -- "$NET01_LOCK_FILE")" != '0:0:600:1' ]]; then
    echo 'HOLD: insecure NET01 lock file' >&2; exit 75
  fi
fi
# umask 077 above creates mode 0600 on cold start; never remove this file.
exec 9>"$NET01_LOCK_FILE"
flock -n 9 || { echo 'HOLD: operation in progress' >&2; exit 75; }
# Verify the descriptor still references the canonical root-owned 0600 inode.
if [[ -L "$NET01_LOCK_FILE" || \
      "$(stat -Lc '%u:%g:%a:%h:%d:%i' -- /proc/self/fd/9)" != \
      "$(stat -c '%u:%g:%a:%h:%d:%i' -- "$NET01_LOCK_FILE")" || \
      ! -f "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock inode/permissions mismatch' >&2; exit 75
fi
# MAINTENANCE must have been set BEFORE stop/quiescence by manual admission.
/usr/bin/python3 "$MAINT" require || exit 75
/usr/bin/python3 "$PROBE" --mode quiescent || exit 75
# Strict ownership check deliberately ignores sticky HOLD; no Docker required.
/usr/bin/python3 "$GUARD" --firewall-only || { echo 'HOLD: unknown/partial firewall; no deletion' >&2; exit 75; }
# Double-check near mutation; maintenance prevents ordinary new starts.
/usr/bin/python3 "$PROBE" --mode quiescent || exit 75
/usr/bin/python3 "$MAINT" require || exit 75
# No global flush or policy change; any failure => HOLD/manual review.
SENSOR_UID=$(id -u fingerprint-sensor) || { echo "HOLD: sensor UID unavailable" >&2; exit 75; }
[[ "$SENSOR_UID" =~ ^[1-9][0-9]*$ ]] || exit 75
iptables -w -D INPUT -p tcp --dport 18089 -j "$CHAIN"
iptables -w -D "$CHAIN" -i br-627e7c1ca6d5 -s 172.18.0.2/32 -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m mac --mac-source b2:fa:fc:bf:d5:bc \
  -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
iptables -w -D "$CHAIN" -i lo -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED \
  --ctorigsrc 172.18.0.1/32 --ctorigdst 172.18.0.1/32 -j ACCEPT
iptables -w -D "$CHAIN" -p tcp -j REJECT --reject-with tcp-reset
iptables -w -X "$CHAIN"
iptables -w -D OUTPUT -d 172.18.0.1/32 -p tcp --dport 18089 -j "$OUTCHAIN"
iptables -w -D "$OUTCHAIN" -o lo -s 172.18.0.1/32 -d 172.18.0.1/32 \
  -p tcp --dport 18089 -m owner --uid-owner "$SENSOR_UID" \
  -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
iptables -w -D "$OUTCHAIN" -p tcp -j REJECT --reject-with tcp-reset
iptables -w -X "$OUTCHAIN"
ip6tables -w -D INPUT -p tcp --dport 18089 -j REJECT --reject-with tcp-reset
printf '%s\n' 'NET01_ROLLBACK=COMPLETED_FOR_EXACT_REVIEWED_RULESET; MAINTENANCE_REMAINS_LATCHED'
