#!/usr/bin/env bash
# Final manual recovery gate; never executed automatically.
set -euo pipefail
umask 077
(( EUID == 0 )) || exit 75
# Single persistent, root-owned inode. Do not unlink on unlock/rollback.
NET01_LOCK_DIR=/var/lib/captiv-net01
NET01_LOCK_FILE="$NET01_LOCK_DIR/net01-firewall.lock"
if [[ -L "$NET01_LOCK_DIR" || ! -d "$NET01_LOCK_DIR" || \
      "$(stat -c '%u:%g:%a' -- "$NET01_LOCK_DIR")" != '0:0:700' ]]; then
  echo 'HOLD: insecure NET01 lock directory' >&2; exit 75
fi
# Reject any pre-existing symlink, nonregular file, incorrect owner/mode or hardlink.
if [[ -L "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock symlink' >&2; exit 75
fi
if [[ -e "$NET01_LOCK_FILE" ]]; then
  if [[ ! -f "$NET01_LOCK_FILE" || \
        "$(stat -c '%u:%g:%a:%h' -- "$NET01_LOCK_FILE")" != '0:0:600:1' ]]; then
    echo 'HOLD: insecure NET01 lock file' >&2; exit 75
  fi
fi
# umask 077 above creates mode 0600 on cold start; never remove this file.
exec 9>"$NET01_LOCK_FILE"
flock -n 9 || exit 75
# Verify the descriptor still references the canonical root-owned 0600 inode.
if [[ -L "$NET01_LOCK_FILE" || \
      "$(stat -Lc '%u:%g:%a:%h:%d:%i' -- /proc/self/fd/9)" != \
      "$(stat -c '%u:%g:%a:%h:%d:%i' -- "$NET01_LOCK_FILE")" || \
      ! -f "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock inode/permissions mismatch' >&2; exit 75
fi
ROOT=/usr/local/libexec/captiv-net01
/usr/bin/python3 "$ROOT/net01-maintenance-state.py" require
/usr/bin/python3 "$ROOT/net01-quiescent.py" --mode quiescent
/usr/bin/python3 "$ROOT/net01-verify.py" --all --ignore-maintenance
/usr/bin/python3 "$ROOT/net01-quiescent.py" --mode quiescent
/usr/bin/python3 "$ROOT/net01-marker-unlink.py" MAINTENANCE
printf '%s\n' 'NET01_MAINTENANCE_CLEARED; MANUAL_START_ONLY'
