#!/usr/bin/env bash
# REV4: operator only; HOLD cannot be cleared on unknown unit/ss state.
set -euo pipefail
umask 077
(( EUID == 0 )) || { echo 'HOLD: root required' >&2; exit 75; }
HOLD=/var/lib/captiv-net01/HOLD
GUARD=/usr/local/libexec/captiv-net01/net01-verify.py
PROBE=/usr/local/libexec/captiv-net01/net01-quiescent.py
MAINT=/usr/local/libexec/captiv-net01/net01-maintenance-state.py
# Single persistent, root-owned inode. Do not unlink on unlock/rollback.
NET01_LOCK_DIR=/var/lib/captiv-net01
NET01_LOCK_FILE="$NET01_LOCK_DIR/net01-firewall.lock"
if [[ -L "$NET01_LOCK_DIR" || ! -d "$NET01_LOCK_DIR" || \
      "$(stat -c '%u:%g:%a' -- "$NET01_LOCK_DIR")" != '0:0:700' ]]; then
  echo 'HOLD: insecure NET01 lock directory' >&2; exit 75
fi
# Reject any pre-existing symlink, nonregular file, incorrect owner/mode or hardlink.
if [[ -L "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock symlink' >&2; exit 75
fi
if [[ -e "$NET01_LOCK_FILE" ]]; then
  if [[ ! -f "$NET01_LOCK_FILE" || \
        "$(stat -c '%u:%g:%a:%h' -- "$NET01_LOCK_FILE")" != '0:0:600:1' ]]; then
    echo 'HOLD: insecure NET01 lock file' >&2; exit 75
  fi
fi
# umask 077 above creates mode 0600 on cold start; never remove this file.
exec 9>"$NET01_LOCK_FILE"
flock -n 9 || { echo 'HOLD: NET01 operation busy' >&2; exit 75; }
# Verify the descriptor still references the canonical root-owned 0600 inode.
if [[ -L "$NET01_LOCK_FILE" || \
      "$(stat -Lc '%u:%g:%a:%h:%d:%i' -- /proc/self/fd/9)" != \
      "$(stat -c '%u:%g:%a:%h:%d:%i' -- "$NET01_LOCK_FILE")" || \
      ! -f "$NET01_LOCK_FILE" ]]; then
  echo 'HOLD: NET01 lock inode/permissions mismatch' >&2; exit 75
fi
# During maintenance, marker keeps startup inhibited while clearing HOLD.
/usr/bin/python3 "$MAINT" require || exit 75
/usr/bin/python3 "$PROBE" --mode quiescent || exit 75
/usr/bin/python3 "$GUARD" --all --ignore-hold --ignore-maintenance || exit 75
/usr/bin/python3 "$PROBE" --mode quiescent || exit 75
/usr/bin/python3 "$MAINT" require || exit 75
# Fail closed if HOLD file is not a regular root-owned 0600 file.
/usr/bin/python3 /usr/local/libexec/captiv-net01/net01-marker-unlink.py HOLD
printf '%s\n' 'NET01_HOLD_CLEARED; MAINTENANCE_REMAINS_LATCHED'
