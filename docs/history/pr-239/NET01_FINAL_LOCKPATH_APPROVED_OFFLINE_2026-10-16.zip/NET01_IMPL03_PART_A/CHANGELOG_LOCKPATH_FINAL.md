# NET-01 final lock-path hardening — Architect offline authorization 2026-10-16

Source ZIP: `NET01_INTEGRATED_P1AB_APPROVED_OFFLINE(1).zip` SHA-256 `594ec49f486085a130ab741b669c830746129db42691907683db87dfca279808`.

Only active lock acquisition is changed, identically in six shell scripts, from `/run/lock/captiv-net01-firewall.lock` to `/var/lib/captiv-net01/net01-firewall.lock`. On every acquisition, scripts require a nonsymlink root:root `0700` directory. For existing lock, require regular nonsymlink root:root `0600` single-link inode. Cold creation uses existing `umask 077`; after nonblocking flock scripts verify descriptor and path refer to the same root:root `0600` single-link inode. Lock is **never unlinked**, including rollback, reinstall and maintenance; file descriptors release flock on process exit.

`captiv-net01-firewall.service` remains the existing root-run `StateDirectory=captiv-net01`, `StateDirectoryMode=0700` owner; dependent watchdog and privileged `ExecStartPre=+` guards run as root. `captiv-net01-watchdog.service` retains `ProtectSystem=strict` and restricts `ReadWritePaths` to `/var/lib/captiv-net01` only. No permissive exception for `/run` remains. If directory or file is missing/insecure, operations fail closed (except permitted creation of missing lock **within an already-secure StateDirectory**).

Original historical `.diff`/`.patch` files and earlier staging results remain as immutable provenance: they contain superseded `/run/lock` examples and MUST NOT be used for deployment. Only the top-level active `firewall/*` and `systemd/*` files, the current tests and this changelog are operative. No TCP firewall policy, NPM/Docker identity, conntrack, Sensor UID, watchdog design or startup ordering changes.

For installation, deploy the six `.sh` as root-owned executable `0755` with explicit `install -m 0755`, not recursive chmod, and Python scripts root-owned `0644` (invoked by `/usr/bin/python3`); install systemd units as root-owned `0644`, only after exact preflight and Owner GO. Never execute scripts directly from ZIP. Do not delete lock as a means of recovery.

Offline test outcomes and precise deployment change-set recorded in `NET01_LOCKPATH_REVIEW_AND_DEPLOYMENT.md`.
