"""Prove no firewall mutation and sticky latches when systemd/ss/job are unknown."""
import importlib.util
from pathlib import Path
import pytest
from rev4_fixture import isolated

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('quiescence',ROOT/'firewall/net01-quiescent.py')
probe=importlib.util.module_from_spec(spec);spec.loader.exec_module(probe)


def runner(**issues):
    def run(args):
        if args[:2]==['systemctl','show']:
            if issues.get('systemctl_failure'):raise RuntimeError('manager offline')
            state=issues.get('state','inactive')
            sub={'inactive':'dead','active':'running','activating':'start','deactivating':'stop','failed':'failed'}[state]
            return '\n'.join(['LoadState='+issues.get('load','loaded'),'ActiveState='+state,'SubState='+sub,'Job='+(issues.get('job','') if args[-1]=='captive-portal.service' else '')])
        if args[:2]==['systemctl','list-jobs']:
            return issues.get('jobs','')
        if args[0]=='ss':
            if issues.get('ss_failure'):raise RuntimeError('ss unavailable')
            if issues.get('malformed'):return 'not a socket listing'
            return 'LISTEN 0 128 0.0.0.0:18089 0.0.0.0:*' if issues.get('listener') else ''
        raise AssertionError(args)
    return run


@pytest.mark.parametrize('problem',[
    {'systemctl_failure':True}, {'ss_failure':True}, {'state':'active'},
    {'state':'activating'}, {'state':'deactivating'}, {'state':'failed'},
    {'job':'314/start'}, {'jobs':'314 captive-portal.service start waiting'},
    {'jobs':'315 captiv-net01-watchdog.service stop running'},
    {'listener':True}, {'malformed':True}, {'load':'not-found'},
])
def test_strict_rollback_probe_holds_on_errors_jobs_states(problem):
    with pytest.raises(RuntimeError):probe.check('quiescent',runner(**problem))


def test_probe_clean_and_install_ordered_start():
    assert probe.check('quiescent',runner())
    assert probe.check('install',runner(job='314/start',jobs='314 captive-portal.service start waiting'))
    with pytest.raises(RuntimeError):probe.check('quiescent',runner(job='314/start',jobs='314 captive-portal.service start waiting'))
    with pytest.raises(RuntimeError):probe.check('install',runner(state='activating'))


@pytest.mark.parametrize('changes',[
    {'SYSTEMCTL_FAIL':'1'}, {'SS_FAIL':'1'}, {'SS_MALFORMED':'1'},
    {'UNIT_STATE':'activating'}, {'UNIT_STATE':'deactivating'},
    {'UNIT_STATE':'active'}, {'JOB':'314/start'}, {'JOB_LIST':'start'},
    {'JOB_LIST':'watchdog'}, {'SS_LISTENER':'1'}, {'GUARD_RC':'75'},
])
def test_rollback_refuses_unsafe_and_keeps_maintenance(changes):
    with isolated(**changes) as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
        assert result.returncode != 0,(result.stdout,result.stderr)
        assert mut==[],mut
        assert hold.exists() and maint.exists()


def test_rollback_positive_exact_mock_five_owned_mutations():
    with isolated() as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
        assert result.returncode==0,(result.stdout,result.stderr)
        assert len(mut)==5 and all(' -F ' not in m for m in mut)
        assert hold.exists() and maint.exists()


def test_rollback_rejects_without_maintenance():
    with isolated() as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-rollback.sh',existing_hold=True)
        assert result.returncode!=0 and not mut
        assert hold.exists()


@pytest.mark.parametrize('changes',[
    {'SYSTEMCTL_FAIL':'1'}, {'SS_FAIL':'1'}, {'SS_MALFORMED':'1'},
    {'UNIT_STATE':'activating'}, {'UNIT_STATE':'deactivating'},
    {'UNIT_STATE':'active'}, {'JOB':'314/start'}, {'JOB_LIST':'start'},
    {'JOB_LIST':'watchdog'}, {'SS_LISTENER':'1'}, {'GUARD_RC':'75'},
])
def test_clear_hold_refuses_unsafe_and_preserves_latch(changes):
    with isolated(**changes) as (root,env,run,hold,maint,log):
        result,mut=run('net01-clear-hold-review-only.sh',marker=True,existing_hold=True)
        assert result.returncode!=0,(result.stdout,result.stderr)
        assert hold.exists() and maint.exists() and not mut


def test_clear_hold_positive_preserves_maintenance():
    with isolated() as (root,env,run,hold,maint,log):
        result,mut=run('net01-clear-hold-review-only.sh',marker=True,existing_hold=True)
        assert result.returncode==0,(result.stdout,result.stderr)
        assert not hold.exists() and maint.exists() and not mut


@pytest.mark.parametrize('changes',[
    {'SYSTEMCTL_FAIL':'1'}, {'SS_FAIL':'1'}, {'SS_MALFORMED':'1'},
    {'UNIT_STATE':'activating'}, {'UNIT_STATE':'deactivating'},
    {'UNIT_STATE':'active'}, {'SS_LISTENER':'1'}, {'GUARD_RC':'75'},
    {'JOB_LIST':'watchdog'},
])
def test_install_refuses_unsafe_before_firewall_modification(changes):
    with isolated(**changes) as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-install.sh')
        assert result.returncode!=0,(result.stdout,result.stderr)
        assert mut==[]


def test_install_allows_only_ordered_waiting_start_job():
    with isolated(JOB='314/start',JOB_LIST='start') as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-install.sh')
        assert result.returncode==0,(result.stdout,result.stderr)
        assert len(mut)==5


def test_install_fails_closed_when_maintenance_already_active():
    with isolated() as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-install.sh',marker=True)
        assert result.returncode!=0 and not mut


def test_install_explicit_reinstall_during_maintenance():
    with isolated() as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-install.sh',marker=True,existing_hold=True,args=('--maintenance-reinstall',))
        assert result.returncode==0,(result.stdout,result.stderr)
        assert len(mut)==5 and hold.exists() and maint.exists()


def test_maintenance_enter_sets_marker_then_fails_closed_if_stop_fails():
    with isolated(STOP_FAIL='1') as (root,env,run,hold,maint,log):
        result,mut=run('net01-maintenance-enter.sh')
        assert result.returncode != 0 and maint.exists() and not mut


def test_maintenance_enter_positive_sets_marker_first():
    with isolated() as (root,env,run,hold,maint,log):
        result,mut=run('net01-maintenance-enter.sh')
        assert result.returncode==0,(result.stdout,result.stderr)
        assert maint.exists() and not mut


def test_start_admit_denied_on_maintenance_no_guard_override():
    with isolated() as (root,env,run,hold,maint,log):
        result,_=run('net01-start-admit.sh',marker=True)
        assert result.returncode!=0
        app_unit = (ROOT/'systemd/captive-portal-net01.drop-in.conf').read_text()
        wd_unit = (ROOT/'systemd/captiv-net01-watchdog.service').read_text()
        assert 'ExecStartPre=+/usr/local/libexec/captiv-net01/net01-start-admit.sh' in app_unit
        assert 'ExecStartPre=/usr/local/libexec/captiv-net01/net01-start-admit.sh' in wd_unit
        # Listener absence under real PID1 is NOT proven by this mocked contract test.


def test_preheld_net01_operation_lock_blocks_rollback():
    import fcntl
    with isolated() as (root,env,run,hold,maint,log):
        (root/'lock').touch()
        with (root/'lock').open('w') as h:
            fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB)
            result,mut=run('net01-fw-rollback.sh',marker=True,existing_hold=True)
            assert result.returncode!=0 and not mut
            assert hold.exists() and maint.exists()


def test_preheld_net01_operation_lock_blocks_clear_hold():
    import fcntl
    with isolated() as (root,env,run,hold,maint,log):
        (root/'lock').touch()
        with (root/'lock').open('w') as h:
            fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB)
            result,mut=run('net01-clear-hold-review-only.sh',marker=True,existing_hold=True)
            assert result.returncode!=0 and not mut and hold.exists()


@pytest.mark.parametrize('kind',[{'IPTABLES_QUERY_FAIL':'1'}, {'IP6_QUERY_FAIL':'1'}])
def test_install_policy_query_error_no_mutation(kind):
    with isolated(**kind) as (root,env,run,hold,maint,log):
        result,mut=run('net01-fw-install.sh')
        assert result.returncode!=0 and not mut


def test_clear_maintenance_requires_no_hold_and_guard_pass():
    with isolated(GUARD_RC='75') as (root,env,run,hold,maint,log):
        result,mut=run('net01-clear-maintenance-review-only.sh',marker=True)
        assert result.returncode!=0 and maint.exists() and not mut
    with isolated() as (root,env,run,hold,maint,log):
        result,mut=run('net01-clear-maintenance-review-only.sh',marker=True)
        assert result.returncode==0 and not maint.exists() and not mut


@pytest.mark.parametrize('scenario',[{'SS_FAIL':'1'}, {'SYSTEMCTL_FAIL':'1'},
                                    {'JOB':'9/start'}, {'UNIT_STATE':'activating'}])
def test_maintenance_enter_does_not_authorize_rollback_when_unproven(scenario):
    with isolated(**scenario) as (root,env,run,hold,maint,log):
        result,_=run('net01-maintenance-enter.sh')
        assert result.returncode!=0 and maint.exists()
        later,mut=run('net01-fw-rollback.sh')
        assert later.returncode!=0 and not mut


def test_start_guard_and_maintenance_compete_on_same_lock():
    # Maintenance admission wins the lock, pending ExecStartPre must HOLD.
    import fcntl
    with isolated() as (root,env,run,hold,maint,log):
        (root/'lock').touch()
        with (root/'lock').open('w') as h:
            fcntl.flock(h,fcntl.LOCK_EX|fcntl.LOCK_NB)
            result,mut=run('net01-start-admit.sh')
            assert result.returncode!=0 and not mut


def test_real_root_marker_rejects_symlink_and_missing():
    import importlib.util
    spec=importlib.util.spec_from_file_location('maintenance',ROOT/'firewall/net01-maintenance-state.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    from tempfile import TemporaryDirectory
    import os
    with TemporaryDirectory() as t:
        basedir=Path(t)/'state';basedir.mkdir(mode=0o700);basedir.chmod(0o700)
        mark=basedir/'MAINTENANCE'
        with pytest.raises(RuntimeError):m.verify_marker(mark)
        m.put(basedir,mark)
        assert m.verify_marker(mark)
        mark.unlink()
        mark.symlink_to(Path(t)/'another')
        with pytest.raises(RuntimeError):m.verify_marker(mark)


def test_install_rejects_unknown_job_type_and_inconsistent_job_listing():
    with pytest.raises(RuntimeError):probe.check('install',runner(job='314/stop',jobs='314 captive-portal.service start waiting'))
    with pytest.raises(RuntimeError):probe.check('install',runner(job='314/start',jobs=''))
    with pytest.raises(RuntimeError):probe.check('install',runner(job='',jobs='314 captive-portal.service start waiting'))
