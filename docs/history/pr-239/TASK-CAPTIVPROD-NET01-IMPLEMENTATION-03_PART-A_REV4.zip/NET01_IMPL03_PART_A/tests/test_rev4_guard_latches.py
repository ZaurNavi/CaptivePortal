"""REV4 immutable start guard marker contract; mock-only, no Docker or host rules."""
import importlib.util
from pathlib import Path
import sys
import pytest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('rev4_guard',ROOT/'firewall/net01-verify.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)


def prepare(monkeypatch,tmp_path,marker):
    d=tmp_path/'state';d.mkdir(mode=0o700);d.chmod(0o700)
    monkeypatch.setattr(g,'HOLD_FILE',d/'HOLD')
    monkeypatch.setattr(g,'MAINTENANCE_FILE',d/'MAINTENANCE')
    monkeypatch.setattr(g,'check_identity',lambda:None)
    monkeypatch.setattr(g,'check_firewall',lambda:None)
    if marker:
        (d/marker).write_text('latch')
    return d


def test_normal_start_blocked_by_maintenance(monkeypatch,tmp_path):
    d=prepare(monkeypatch,tmp_path,'MAINTENANCE')
    monkeypatch.setattr(sys,'argv',['net01-verify.py','--all'])
    assert g.main()==75
    assert (d/'MAINTENANCE').exists()


def test_operator_bypass_maintenance_requires_explicit_flag(monkeypatch,tmp_path):
    d=prepare(monkeypatch,tmp_path,'MAINTENANCE')
    monkeypatch.setattr(sys,'argv',['net01-verify.py','--all','--ignore-maintenance'])
    assert g.main()==0
    assert (d/'MAINTENANCE').exists()


def test_ignore_maintenance_does_not_bypass_hold(monkeypatch,tmp_path):
    d=prepare(monkeypatch,tmp_path,'HOLD')
    (d/'MAINTENANCE').write_text('maintenance')
    monkeypatch.setattr(sys,'argv',['net01-verify.py','--all','--ignore-maintenance'])
    assert g.main()==75
    assert (d/'MAINTENANCE').exists() and (d/'HOLD').exists()


def test_manual_both_bypass_is_verification_only(monkeypatch,tmp_path):
    d=prepare(monkeypatch,tmp_path,'HOLD')
    (d/'MAINTENANCE').write_text('maintenance')
    monkeypatch.setattr(sys,'argv',['net01-verify.py','--all','--ignore-hold','--ignore-maintenance'])
    assert g.main()==0
    assert (d/'MAINTENANCE').exists() and (d/'HOLD').exists()
