#!/usr/bin/env bash
# Roll back only source path systemd drop-ins installed by this task.
set -uo pipefail
[[ "${1:-}" == '--approved-path-cutover-rollback' ]] || { echo 'Rollback authority missing' >&2; exit 2; }
[[ $(id -u) -eq 0 ]] || exit 2
UNITS=(captive-portal fingerprint-evidence fingerprint-classification traffic-projection network-metadata network-metadata-projection network-service-recognition)
STOP=(network-service-recognition network-metadata-projection network-metadata traffic-projection fingerprint-classification captive-portal fingerprint-evidence)
START=(fingerprint-evidence captive-portal fingerprint-classification traffic-projection network-metadata network-metadata-projection network-service-recognition)
ret=0
for u in "${STOP[@]}"; do systemctl stop "$u.service" || ret=1; done
for u in "${UNITS[@]}"; do
 f="/etc/systemd/system/$u.service.d/90-captivprod-canonical-path.conf"
 if [[ -e "$f" ]]; then
   if grep -q '^# CAPTIVPROD-PATH-CUTOVER-01$' "$f"; then rm -f -- "$f"; else echo "Refusing to remove unknown override: $f" >&2; ret=1; fi
 fi
done
systemctl daemon-reload || ret=1
for u in "${START[@]}"; do systemctl start "$u.service" || ret=1; done
for u in "${UNITS[@]}"; do
 if [[ "$(systemctl show "$u.service" -p WorkingDirectory --value)" != /opt/captivprod-portal-v2fix ]] || ! systemctl is-active --quiet "$u.service"; then
   echo "ROLLBACK UNIT FAILURE: $u" >&2; ret=1
 fi
done
echo "ROLLBACK_RESULT=$([[ $ret -eq 0 ]] && echo 'SOURCE_PATH_RESTORED' || echo 'FAILED_NEEDS_IMMEDIATE_SYSADMIN')"
exit "$ret"
