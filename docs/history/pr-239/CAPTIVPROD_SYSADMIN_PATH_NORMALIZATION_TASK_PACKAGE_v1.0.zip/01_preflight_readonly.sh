#!/usr/bin/env bash
# CaptivProd path normalization — inspection only. No server writes.
set -euo pipefail
SRC=/opt/captivprod-portal-v2fix
ANCHOR=/opt/captivprod-portal
SHA=b6152459421b48514ddc8af114bcc96e30351cf7
TREE=3dd3588bdae279660fcbf4e9c5310282041c01e9
CURRENT=/opt/captivprod/portal/current
UNITS=(captive-portal fingerprint-evidence fingerprint-classification traffic-projection network-metadata network-metadata-projection network-service-recognition)
fail() { echo "FAIL: $*" >&2; exit 2; }
[[ "$(hostname -s)" == captiv-prod ]] || fail 'Wrong host'
[[ -d "$SRC" && -d "$ANCHOR/.git" ]] || fail 'Missing source / Git anchor'
[[ ! -e "$CURRENT" && ! -L "$CURRENT" ]] || fail 'Target current already exists: task requires separate drift review'
[[ "$(env GIT_OPTIONAL_LOCKS=0 git -c safe.directory="$SRC" -C "$SRC" rev-parse HEAD)" == "$SHA" ]] || fail 'Source SHA drift'
[[ "$(env GIT_OPTIONAL_LOCKS=0 git -c safe.directory="$SRC" -C "$SRC" rev-parse HEAD^{tree})" == "$TREE" ]] || fail 'Source TREE drift'
[[ -z "$(env GIT_OPTIONAL_LOCKS=0 git -c safe.directory="$SRC" -C "$SRC" status --porcelain=v1)" ]] || fail 'Source Git worktree dirty'
[[ "$(env GIT_OPTIONAL_LOCKS=0 git -c safe.directory="$ANCHOR" -C "$ANCHOR" rev-parse --show-toplevel)" == "$ANCHOR" ]] || fail 'Git anchor mismatch'
for u in "${UNITS[@]}"; do
  [[ "$(systemctl show "$u.service" -p LoadState --value)" == loaded ]] || fail "$u not loaded"
  [[ "$(systemctl show "$u.service" -p ActiveState --value)" == active ]] || fail "$u not active"
  wd=$(systemctl show "$u.service" -p WorkingDirectory --value)
  [[ "$wd" == "$SRC" ]] || fail "$u unexpected WD $wd"
  unitfile=$(systemctl show "$u.service" -p FragmentPath --value)
  [[ "$unitfile" == "/etc/systemd/system/$u.service" ]] || fail "$u unit file changed"
  [[ ! -e "/etc/systemd/system/$u.service.d/90-captivprod-canonical-path.conf" ]] || fail "$u target override exists"
  echo "PASS unit $u active, WD=$wd"
done
for u in tpeap fingerprint-sensor fingerprint-suricata captiv-net01-firewall captiv-net01-watchdog; do
 [[ "$(systemctl show "$u.service" -p ActiveState --value)" == active ]] || fail "Protected service $u not active"
done
[[ -x /opt/captivprod-portal-venv/bin/python ]] || fail 'Existing Python venv missing'
[[ -d /opt/CaptivePortal/data && -d /opt/CaptivePortal/logs ]] || fail 'Data/log dirs missing'
[[ ! -e /opt/captivprod/portal/releases/$SHA ]] || fail 'Release path already present'
echo '--- baseline ---'
date -u '+UTC %Y-%m-%dT%H:%M:%SZ'
findmnt -T /opt -o TARGET,SOURCE,FSTYPE,OPTIONS -n
df -hP /opt
systemctl list-timers --all --no-pager | grep -E 'captiv-backup|captiv-npm-backup|metadata-rotation' || true
printf 'Git HEAD=%s TREE=%s\n' "$SHA" "$TREE"
echo 'PREFLIGHT=PASS / WRITES=NONE; operational GO and backup verification still required'
