#!/usr/bin/env bash
# Owner-approved change window only. Requires prior 01 + 02, backups and production GO.
set -euo pipefail
[[ "${1:-}" == '--owner-go-deploy-recorded' ]] || { echo 'Missing recorded Owner deploy GO' >&2; exit 2; }
[[ $(id -u) -eq 0 ]] || exit 2
SRC=/opt/captivprod-portal-v2fix
CURRENT=/opt/captivprod/portal/current
SHA=b6152459421b48514ddc8af114bcc96e30351cf7
TREE=3dd3588bdae279660fcbf4e9c5310282041c01e
UNITS=(captive-portal fingerprint-evidence fingerprint-classification traffic-projection network-metadata network-metadata-projection network-service-recognition)
STOP=(network-service-recognition network-metadata-projection network-metadata traffic-projection fingerprint-classification captive-portal fingerprint-evidence)
START=(fingerprint-evidence captive-portal fingerprint-classification traffic-projection network-metadata network-metadata-projection network-service-recognition)
[[ "$(hostname -s)" == captiv-prod ]] || exit 2
[[ "$(readlink -f "$CURRENT")" == "/opt/captivprod/portal/releases/$SHA" ]] || exit 2
[[ "$(git -c safe.directory="$CURRENT" -C "$CURRENT" rev-parse HEAD)" == "$SHA" ]] || exit 2
[[ "$(git -c safe.directory="$CURRENT" -C "$CURRENT" rev-parse HEAD^{tree})" == "$TREE" ]] || exit 2
[[ -z "$(git -c safe.directory="$CURRENT" -C "$CURRENT" status --porcelain)" ]] || exit 2
for user in captivportal captiv-evidence; do
  got=$(runuser -u "$user" -- env GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0="$CURRENT" git -C "$CURRENT" rev-parse HEAD) || exit 2
  [[ "$got" == "$SHA" ]] || { echo "Git provenance under $user failed; NO STOP" >&2; exit 2; }
done
for u in "${UNITS[@]}"; do
  [[ "$(systemctl show "$u.service" -p WorkingDirectory --value)" == "$SRC" ]] || exit 2
  [[ ! -e "/etc/systemd/system/$u.service.d/90-captivprod-canonical-path.conf" ]] || exit 2
done
# Store rollback-critical unit files on verified backup volume (not arbitrary root fs fallback).
[[ -d /srv/backups ]] || { echo '/srv/backups missing' >&2; exit 2; }
[[ "$(findmnt -T /srv/backups -n -o TARGET)" == /srv/backups ]] || { echo '/srv/backups not an independent mount' >&2; exit 2; }
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
DEST=/srv/backups/captivprod-path-cutover/$STAMP
install -d -m 0700 -o root -g root "$DEST"
for u in "${UNITS[@]}"; do
  cp -a "/etc/systemd/system/$u.service" "$DEST/$u.service"
  systemctl cat "$u.service" > "$DEST/$u.effective-before.txt"
done
chmod 0600 "$DEST"/*
echo "PRECHANGE_UNITS_BACKUP=$DEST"
# Stop producer/consumer services gracefully. Sensor and Suricata are out-of-scope.
for u in "${STOP[@]}"; do systemctl stop "$u.service"; done
rollback_on_failure() {
  rc=$?
  trap - EXIT
  if ((rc != 0)); then
    echo 'ACTIVATE FAILED: invoking rollback' >&2
    "$(dirname "$(readlink -f "$0")")/04_rollback.sh" --approved-path-cutover-rollback || true
  fi
  exit "$rc"
}
trap rollback_on_failure EXIT
for u in "${UNITS[@]}"; do
  dir="/etc/systemd/system/$u.service.d"
  install -d -m 0755 "$dir"
  tmp=$(mktemp "$dir/.90-captivprod-canonical-path.conf.XXXXXX")
  {
    echo '# CAPTIVPROD-PATH-CUTOVER-01'
    echo '[Service]'
    echo "WorkingDirectory=$CURRENT"
    if [[ "$u" != fingerprint-classification ]]; then
      echo "Environment=GIT_CONFIG_VALUE_0=$CURRENT"
    fi
    if [[ "$u" == captive-portal ]]; then
      echo 'ExecStart='
      echo "ExecStart=/opt/captivprod-portal-venv/bin/python $CURRENT/run.py"
    fi
  } > "$tmp"
  chmod 0644 "$tmp"
  mv -f -- "$tmp" "$dir/90-captivprod-canonical-path.conf"
done
systemctl daemon-reload
for u in "${UNITS[@]}"; do
  [[ "$(systemctl show "$u.service" -p WorkingDirectory --value)" == "$CURRENT" ]] || { echo "Unit override failed $u" >&2; exit 2; }
done
for u in "${START[@]}"; do systemctl start "$u.service"; done
for u in "${UNITS[@]}"; do systemctl is-active --quiet "$u.service" || { echo "$u failed" >&2; exit 2; }; done
sleep 60
for u in "${UNITS[@]}"; do
  systemctl is-active --quiet "$u.service" || { echo "$u failed 60s health" >&2; exit 2; }
  pid=$(systemctl show "$u.service" -p MainPID --value)
  [[ "$pid" =~ ^[1-9][0-9]*$ ]] || exit 2
  [[ "$(readlink -f /proc/$pid/cwd)" == "$(readlink -f "$CURRENT")" ]] || { echo "$u CWD mismatch" >&2; exit 2; }
done
trap - EXIT
printf 'PATH_CUTOVER_BASIC_HEALTH=PASS SHA=%s BACKUP=%s\n' "$SHA" "$DEST"
echo 'Still required: NPM/CAPPORT/Admin and controlled guest E2E; monitor 10+ min; owner acceptance.'
