#!/usr/bin/env bash
# Requires explicit recorded Owner PREPARATION GO. Prepares code, does NOT switch services.
set -euo pipefail
[[ "${1:-}" == '--owner-go-prep-recorded' ]] || { echo 'Missing recorded Owner PREP GO' >&2; exit 2; }
[[ $(id -u) -eq 0 ]] || { echo 'Run as root' >&2; exit 2; }
ANCHOR=/opt/captivprod-portal
SRC=/opt/captivprod-portal-v2fix
SHA=b6152459421b48514ddc8af114bcc96e30351cf7
TREE=3dd3588bdae279660fcbf4e9c5310282041c01e9
PARENT=/opt/captivprod/portal
RELEASE=$PARENT/releases/$SHA
CURRENT=$PARENT/current
[[ "$(hostname -s)" == captiv-prod ]] || exit 2
[[ "$(git -c safe.directory="$SRC" -C "$SRC" rev-parse HEAD)" == "$SHA" ]] || exit 2
[[ -z "$(git -c safe.directory="$SRC" -C "$SRC" status --porcelain)" ]] || exit 2
[[ ! -e "$CURRENT" && ! -L "$CURRENT" && ! -e "$RELEASE" ]] || { echo 'Target exists; abort' >&2; exit 2; }
install -d -o root -g root -m 0755 "$PARENT" "$PARENT/releases"
git -c safe.directory="$ANCHOR" -C "$ANCHOR" worktree add --detach "$RELEASE" "$SHA"
[[ "$(git -c safe.directory="$RELEASE" -C "$RELEASE" rev-parse HEAD)" == "$SHA" ]] || exit 2
[[ "$(git -c safe.directory="$RELEASE" -C "$RELEASE" rev-parse HEAD^{tree})" == "$TREE" ]] || exit 2
[[ -z "$(git -c safe.directory="$RELEASE" -C "$RELEASE" status --porcelain)" ]] || exit 2
ln -s "$RELEASE" "$CURRENT"
[[ "$(readlink -f "$CURRENT")" == "$RELEASE" ]] || exit 2
for user in captivportal captiv-evidence; do
  got=$(runuser -u "$user" -- env GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0="$CURRENT" git -C "$CURRENT" rev-parse HEAD) || exit 2
  [[ "$got" == "$SHA" ]] || { echo "Git safe.directory mismatch: $user" >&2; exit 2; }
done
for user in captivportal captiv-evidence; do
  runuser -u "$user" -- test -r "$CURRENT/run.py" || { echo "No read access: $user" >&2; exit 2; }
done
# A source import check exercises the CWD under both affected service users.
for user in captivportal captiv-evidence; do
  runuser -u "$user" -- sh -c 'cd "$1" && /opt/captivprod-portal-venv/bin/python -B -c "import app; print(\"IMPORT_OK\")"' _ "$CURRENT" || exit 2
done
printf 'PREPARE=PASS SHA=%s TREE=%s CURRENT=%s\n' "$SHA" "$TREE" "$CURRENT"
echo 'No unit altered, no service restarted. Await activation Owner GO.'
