# TASK-06 / Omada webhook local routing and new FQDN — reviewed candidate

## Fixed endpoints and trust boundaries

- New external hostname: `captivprod-navi.duckdns.org` (read-only DNS A resolved to `85.132.110.97`; registration/ownership and DDNS policies still require Owner evidence). The **old** `captivportal-navi.duckdns.org` Proxy Host remains untouched.
- NPM on host `192.168.0.99:443` (Docker `npm`, bridge `172.18.0.2`, host bridge `172.18.0.1`), SSL owner stays NPM. Current NPM Proxy Hosts cover old Portal/cloud/VPN **only**; new FQDN currently gives TLS `unrecognized name`. Certificate issuance/new Proxy Host **NOT APPROVED OR EXECUTED**.
- Backend proposed `172.18.0.1:18089` through strictly firewalled Docker-to-host path (NET01). NPM container `127.0.0.1` is NOT host loopback. Omada's current own `*:8088` listener precludes default Flask port.

## Internal webhook path

Desired `Omada process on host -> https://captivprod-navi.duckdns.org/api/integrations/omada/webhook -> 192.168.0.99:443 NPM -> approved bridge backend 172.18.0.1:18089`.

Make only a **scoped host-local resolver** mapping for new hostname to `192.168.0.99`, not public DNS/Cisco/NAT rewrite; before/after verify that `curl --resolve captivprod-navi.duckdns.org:443:192.168.0.99 https://captivprod-navi.duckdns.org/` uses the new trusted NPM certificate, preserves SNI/Host, avoids hairpin and reaches an approved synthetic backend. After successful test, bind local Omada hostname resolution via the chosen reviewed resolver mechanism with explicit rollback. Do not use `-k` for readiness; self-signed staging diagnostics are distinct from production acceptance. **Do not** modify existing old production Proxy Host, Hestia routing, NAT, guest pre-auth ACL or external controller webhook target until separate GO.

## Client identity and authentication (P1)

NPM must overwrite untrusted `X-Forwarded-For`, `X-Forwarded-Proto`, `X-Forwarded-Host`, `X-Forwarded-Port` for one trusted hop, preserve path/query to upstream while **redacting all sensitive query strings from persistent access logs**. Test synthetic spoofed inbound `X-Forwarded-*` and real forwarded client IP after `ProxyFix(x_for=1,x_proto=1,x_host=1,x_port=1)`; two-hop Hestia workaround is not automatically valid. For Omada on the same host, the local source may appear to NPM as `192.168.0.99`, which is **not authentication**: a different local process could share it and users may be normalized by proxy. Therefore IP-only webhook authentication is explicitly NOT accepted. Confirm the actual new Omada webhook publisher supports a cryptographically verifiable shared secret or unforgeable custom header token compatible with CaptivePortal's release. Test wrong/missing token rejection and replay/idempotency. Do not claim supported header names until verified in the controller UI/docs.

## Scoped change set/rollback (not executed)

**Prerequisites**: NET01 exact firewall and PID1 staging independently accepted; new FQDN cert in NPM and trusted from host/guest; approved disposable backend; header spoof/log privacy test plan; explicit Owner GO naming new FQDN/new Proxy Host ID only.

1. Backup NPM config/cert metadata without secrets in evidence; verify protected old routes.
2. Add **new** NPM Proxy Host for new FQDN, TLS, restricted backend pointing to NET01 protected bridge gateway. No duplicate host entry and no changes to 3 existing hosts.
3. Run 443 HTTPS with SNI + synthetic backend and negative header canaries from permitted and denied networks; perform diagnostic webhook only if cryptographic authentication can be enforced.
4. If failure, remove **only newly added** host/cert/resolver record; verify old Portal/cloud/VPN routes and NPM service remain unchanged. Do not restart/replace NPM image or Docker network as shortcut.

## Runtime-only tests

Actual webhook Site mapping, Omada publisher secret provisioning, business auth events, CAPPORT/guest pilot and full Flasks routes cannot be proven before authorized Portal install and an isolated pilot AP. These are explicit runtime-only gates and must not be used to pretend infrastructure transport is ready.

**Current:** `OLD_NPM_PROXY_HOST=UNCHANGED`, `NEW_FQDN_DNS_A=PASS`, `NEW_FQDN_TLS=HOLD`, `OMADA_WEBHOOK_INTERNAL_ROUTE=DESIGNED_NOT_TESTED`, `NPM_ISOLATED_PROXY_HOST=NOT_CREATED`.
