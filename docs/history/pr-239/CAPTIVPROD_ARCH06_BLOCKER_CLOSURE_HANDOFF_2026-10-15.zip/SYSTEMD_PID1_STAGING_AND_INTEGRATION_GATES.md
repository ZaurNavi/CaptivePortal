# TASK-06 / Systemd real PID1 (isolated WSL) and uncompleted integration matrix

## Executed test (not just synthetic parser)

On Owner workstation WSL Ubuntu-22.04, a **real systemd manager is PID 1** (observed `ps -p 1`: systemd; `systemctl is-system-running`: running). An ephemeral test script was written to `C:\Users\Zaur Navi\Downloads\arch06_wsl_pid1_synthetic.py`. It operates **only in WSL**. It created uniquely named runtime service units in `/run/systemd/system`:

- `captivprod-arch06-watchdog.service` — synthetic root `Type=notify` watchdog with READY only when synthetic guard flag absent;
- `captivprod-arch06-backend.service` — unprivileged (`User=nobody`) diagnostic HTTP backend, `BindsTo=` and `After=` watchdog, listening on **WSL-only 127.0.0.1:48089**.

Observed output:

```text
PID1_PRESENT=PASS
UNIT_SYNTAX=PASS
NOTIFY_READY_ORDERING=PASS
DIAGNOSTIC_LISTENER_BEFORE_STOP=PASS
BINDSTO_STOP_PROPAGATION=PASS
LISTENER_DISAPPEARANCE_ON_GUARD_STOP=PASS
GUARD_NOT_READY_PREVENTS_BACKEND=PASS
FAIL_CLOSED_DIAGNOSTIC=PASS
WSL_STAGING_CLEANUP=COMPLETED
```

Units were stopped, deleted from `/run/systemd/system`, `systemctl reset-failed` and `daemon-reload` called, and only the scratch fixture directory removed. No `captiv-prod` or Cisco/NPM/Omada configuration changed. The script is also included as a **manual-only** staging file in the Owner's local NET01 REV4.2 working directory; it must not be run on production.

**What PASS means:** actual systemd PID1 semantics for a *disposable conceptual dependency graph*, not acceptance of production NET01 firewall, production watchdog binary, Docker identity guard or race closure. Continue using `NET01_PID1_PRODUCTION_STAGING=HOLD` for actual units.

## Required future disposable-host tests, with exact status

| Test | Current evidence | Status |
|---|---|---|
| NPM-only Docker bridge exact ingress, unchanged IP/MAC/network ID | Live identity read-only; offline exact rule fixture | HOLD real packet acceptance |
| Host-local Sensor to `172.18.0.1:18089` via `lo`, NPM allowed, other LAN/Guest/WAN/containers denied | Read-only route + offline exact rule | HOLD real packet acceptance |
| IPv6 TCP 18089 unconditional deny | offline exact rule fixture | HOLD real packet acceptance |
| Firewall deny-first installation and exact rollback under root MAINTENANCE | offline script logic; Bash CRLF defect found | HOLD |
| Full real NET01 PID1 watchdog `Type=notify`/`BindsTo` and sticky marker on failure | synthetic PID1 PASS, actual NET01 not installed | HOLD |
| Docker network/container re-create identity drift revokes backend before serving | not run | HOLD |
| NPM Host/SNI/forwarded header spoof and query redaction tests | new Proxy Host absent | HOLD |
| Evidence Receiver loopback certificate and two bearer reject matrix | 10/10 synthetic isolated test PASS | PASS synthetic, HOLD real Receiver |
| SPAN Cisco source VLAN20 RX, dest Gi1/0/45, RSPAN999 via Gi1/0/48 | authenticated switch show commands | PASS read-only |
| SPAN per-interface forwarding set 0 and persists after Docker/reboot | planned, no approved mutation | HOLD |
| Suricata AF_PACKET enp3s0 and unix_dgram EVE Sensor socket | source template reviewed, not installed | HOLD |
| Omada credentialed Site/AP/OpenAPI read rights | unauthed `errorCode=-44116`; cert SAN mismatch | HOLD |
| Webhook internal FQDN/SNI path to *new* NPM Proxy Host | DNS A only, new hostname currently SNI fails | HOLD |
| Config/storage/logging/backup paths and consistent restore test for new stores | directories and backup disk existing; fresh Portal not installed | PLAN, runtime-writer restore HOLD |

## Preinstall vs runtime-only separation

Before Portal install, close packet-filter/NPM/Omada trust via **diagnostic-only** backend and Receiver testing, and prove systemd/packet-path guarantees. Actual Omada site authorization on a pilot AP, Portal CAPPORT responses, auth worker transitions, fingerprint durable ingest and F-B1 materialization require the installed components and separate Authorizations. Their status must be RUNTIME_ONLY, not fake PASS.
