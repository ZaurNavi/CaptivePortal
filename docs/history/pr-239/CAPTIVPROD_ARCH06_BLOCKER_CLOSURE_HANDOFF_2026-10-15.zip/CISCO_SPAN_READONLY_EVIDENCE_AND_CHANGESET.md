# TASK-06 / Cisco SPAN: live read-only evidence and proposed change boundary

Date: 2026-10-15. Host Cisco SSH profile `Cisco2960-Auto`, management `192.168.0.6`, read-only `show` commands. No Cisco configuration changes.

## Exact observations

From `show monitor session all` and `show monitor session 1 detail`/`2 detail`:

| Session | Type | Source VLAN and direction | Destination | Other |
|---|---|---|---|---|
| 1 | Remote Source Session | **VLAN 20, RX only** | RSPAN VLAN **999** | No source port, TX or both; no filter |
| 2 | Local Session | **VLAN 20, RX only** | **Gi1/0/45** | Native encapsulation, ingress disabled; no VLAN10 source |

`show interfaces status`: Gi1/0/45 state **monitoring**, link 1000 Mbps full duplex. `show interfaces Gi1/0/45`: interface physically up and line protocol down **because monitoring** (normal SPAN destination semantics), five-minute output ~2.85 Mbps / 330 pps, cumulative 36,682,190 packets and 32,320,792,915 bytes outbound; total output drops 0. Host `enp3s0` previously showed RX ~34.7M / 30.4 GB, 1000/full, PROMISC, no IPv4/IPv6/master, strong correlation with this destination. No cable/LLDP endpoint identity was independently photographed, so physical continuity is strongly inferred rather than proven by visual tracing.

`show interfaces trunk`: Gi1/0/48 trunk native VLAN40, **VLANs allowed 40,999**, both active and STP forwarding. `show vlan id 999`: VLAN name `RSPAN_DEVICE_FP`, remote-span enabled, associated port Gi1/0/48. The other trunks have 10/20/30/50 as appropriate but **VLAN999 is not allowed there**. Thus session 1 mirrors guest VLAN20 RX across Gi1/0/48 using VLAN999; session 2 separately mirrors VLAN20 RX to the capture NIC. VLAN10 is *not* a SPAN source in either session. This does not prove a switching loop or duplicate delivery into `enp3s0`.

Gi1/0/48 cumulative `OutDiscards=1,626,415,261` (FCS/input errors 0), Gi1/0/45 cumulative `OutDiscards=0`. Counters have unknown age; **a one-time cumulative value does not prove current drop rate or RSPAN causation**. CDP for Gi1/0/48 returned no neighbor; does not establish no connected equipment.

## Decisions and scoped change sets (NOT executed)

1. **Capture scope:** accept VLAN20 RX-only local session 2 as observed. Confirm Guest SSID/VLAN actual authoritative mapping in new and old Omada. Record Cisco trunk/AP VLAN settings. No VLAN10 added. No capture of private/Home VLAN10 or camera VLAN30 by default.
2. **RSPAN session 1:** determine whether VLAN999 consumer on Gi1/0/48 still exists. If not, propose a dedicated scoped config change removing only `monitor session 1` (exact change commands prepared by switch change owner after inventory). Do NOT blindly delete VLAN999 or remove it from all trunks; its L2 user/rollback needs approval. Before/after capture counters and permitted VLAN table. Current *test* baseline stays unchanged.
3. **Gi1/0/48 discards:** take two spaced read-only counter snapshots (time and delta, output rate/queue statistics), plus receiving-switch health if accessible; diagnose congestion/queue/RSPAN amplification before any truncation of VLANs. Avoid `clear counters` without an approved measurement window.
4. **SPAN NIC per-interface forwarding:** host currently `net.ipv4.ip_forward=1`, `net.ipv4.conf.enp3s0.forwarding=1`. Preferred single-interface setting `net.ipv4.conf.enp3s0.forwarding=0`; NEVER set global `ip_forward=0` as this can break Docker. Candidate persistent sysctl drop-in after Owner GO, with explicit post-Docker startup/restart verification since changing global forwarding may reset per-interface values. Check no DHCP/IPv6/RA, bridge, bond, IP, default route or ARP responder on `enp3s0`. A zero-address NIC is not automatically a routed forwarder merely because kernel global forwarding is enabled.
5. **Sensor InterfacePreflight:** expected UP/carrier, no L3/master/forwarding, promiscuous capture, no DHCP-client profile, exact `enp3s0`, low/bounded drops, monitored VLAN20. After approved per-interface change, run the real release's read-only preflight; **not yet PASS**.

**Cisco read-only scope evidence = PASS. Cisco cleanup decision = HOLD. Capture-only forward change = PLAN ONLY.**
