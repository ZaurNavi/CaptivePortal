# TASK-06 / Evidence Receiver: production contract and synthetic proof

## Proposed target (not installed)

- `Receiver bind=127.0.0.1:9443`, protocol HTTPS; **never bind 0.0.0.0, bridge IP, WAN, management LAN or guest VLAN by default**. Loopback peer address only. No public NPM route to port 9443.
- Certificate issuer: locally held dedicated project/private CA under root custody, NOT an Omada or public NPM certificate copied blindly. Proposed server leaf: ECDSA P-256, SAN `IP:127.0.0.1` (exact IP identity), EKU `serverAuth`, basicConstraints `CA:FALSE`, Subject/Authority Key Identifiers, short controlled validity, rotation with overlapping CA trust and synthetic test before cutover. Client verifies CA chain, expiry and SAN with ordinary verification enabled; `verify=False` forbidden.
- Key custody: root-only directory `/etc/captive-portal/device-fingerprint` (0700) with Receiver private key 0600 readable only by Receiver's dedicated service principal through a scoped credential/ACL and with no broader directory traverse. Do not make entire key directory readable by Portal/Sensor or share a certificate key via Git. Final principal/ACL needs tested systemd credentials.
- Sensor client: independent random high-entropy bearer in systemd `LoadCredential` with credential name `device-fingerprint-bearer`; only Sensor service gets its token. Producer identity proposal `captivprod-sensor-01`, capture source `captivprod-span-01`.
- Portal Producer client: distinct independent high-entropy bearer in a protected absolute file, readable only by Portal principal. Proposal `captivprod-portal-01`, source `captivprod-portal-http-01`. No token sharing, no old `.202` token/spool/store migration.
- Receiver's configured `DEVICE_FINGERPRINT_API_ALLOWED_NETWORKS` proposal `127.0.0.0/8`, after actual request peer-IP verification. Even with loopback restriction, bearer and exact producer+capture+Site policy are mandatory. Distinct scopes and rate/size limits required.

## Source registration and F-B1 ordering

1. Obtain **actual** new Omada Site ID, guest SSID/VLAN/CIDR, DHCP authority and accepted SPAN scope; explicit approval for each Source ID.
2. Prepare fresh writable directories for Receiver data (SQLite writer only) and Sensor spool **empty**, controlled owner/mode and backup manifest. No manual SQL schema creation, no copying old WAL/DB/spool.
3. Register each producer with exact producer_id, capture_source_id, real Site ID, admitted guest CIDRs, allowed SSIDs and event kinds, source key/epoch and rate/retention bounds; a configured environment string alone is NOT registration.
4. Verify independent bearer auth, correct CA/SAN, event schema, replay/bounds checks, rejection of wrong producer/Source/Site, and source health heartbeat in an isolated instance.
5. Complete F-B1 admission only after durable source-binding record, healthy source and current evidence epoch; stale/unregistered/mismatched evidence must remain inadmissible for classification. Validate expiry/rotation/rollback with audit of epoch transitions, not arbitrary database edits.
6. Disable producer and close admission on Receiver failure without blocking core guest authorization. Recovered spool is bounded and verified against event-ID dedup windows; no optimistic acceptance of replay after retention.

## Completed synthetic isolated test (not production)

Source: `receiver_staging/test_receiver_tls_synthetic.py`, run in ChatGPT isolated container; **10/10 PASS** after adding CA SubjectKeyIdentifier and leaf AuthorityKeyIdentifier needed by current strict OpenSSL. The harness creates a temporary CA and ephemeral leaf with SAN IP:127.0.0.1 and serverAuth EKU, serves on an **ephemeral** loopback HTTPS port, uses in-memory independent synthetic bearer tokens, and denies incorrect token/producer/capture source/Site, duplicate event, untrusted CA and hostname mismatch. Its accepted 202 means accepted by a **non-durable stub only**; NOT real Evidence Receiver acceptance and NOT F-B1 admission.

Private CA key, leaf key and synthetic bearer are destroyed with the temporary directory/memory after the run. No production credentials or IDs are present in the script. No real visitor MAC, packets, APs or controllers contacted.

**Status:** `TLS_TRANSPORT_SYNTHETIC=PASS`, `PRODUCER_AUTH_SYNTHETIC=PASS`, `RECEIVER_REAL_LISTENER=NOT_INSTALLED`, `REAL_OMADA_SITE_ID=HOLD`, `SOURCE_REGISTRATION=HOLD`, `F_B1_ADMISSION=HOLD`, `DURABLE_REPLAY=NOT_TESTED`.
