#!/usr/bin/env python3
"""DISPOSABLE TLS + bearer + producer boundary demo; NOT the CaptivePortal Receiver.

No real Omada identity, production certificates, devices, network capture or stores.
Binds ephemeral loopback only; all keys live in a temporary chmod-0700 directory.
"""
import contextlib
import datetime as dt
import http.server
import ipaddress
import json
from pathlib import Path
import secrets
import socket
import ssl
import tempfile
import threading
import unittest
import urllib.error
import urllib.request

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID

UTC = dt.timezone.utc
SYNTHETIC_SITE = 'a' * 24
PATH = '/api/internal/device-fingerprint/v1'


def make_certificates(base: Path):
    now = dt.datetime.now(UTC)
    cakey = ec.generate_private_key(ec.SECP256R1())
    ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'CaptivProd SYNTHETIC TEST CA')])
    ca = (x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name)
          .public_key(cakey.public_key()).serial_number(x509.random_serial_number())
          .not_valid_before(now - dt.timedelta(minutes=5)).not_valid_after(now + dt.timedelta(days=1))
          .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
          .add_extension(x509.SubjectKeyIdentifier.from_public_key(cakey.public_key()), critical=False)
          .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
                         key_encipherment=False, data_encipherment=False, key_agreement=False,
                         key_cert_sign=True, crl_sign=True, encipher_only=False, decipher_only=False),critical=True)
          .sign(cakey, hashes.SHA256()))
    leafkey = ec.generate_private_key(ec.SECP256R1())
    leaf = (x509.CertificateBuilder().subject_name(x509.Name([
                x509.NameAttribute(NameOID.COMMON_NAME, 'CaptivProd synthetic receiver')]))
            .issuer_name(ca.subject).public_key(leafkey.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - dt.timedelta(minutes=5)).not_valid_after(now + dt.timedelta(hours=12))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None),critical=True)
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(leafkey.public_key()),critical=False)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(cakey.public_key()),critical=False)
            .add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]), critical=False)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]),critical=False)
            .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
                          key_encipherment=False,data_encipherment=False,key_agreement=False,
                          key_cert_sign=False,crl_sign=False,encipher_only=False,decipher_only=False),critical=True)
            .sign(cakey,hashes.SHA256()))
    ca_path=base/'synthetic-ca.pem'; leaf_path=base/'synthetic-leaf.pem'; key_path=base/'synthetic-leaf.key'
    ca_path.write_bytes(ca.public_bytes(serialization.Encoding.PEM))
    leaf_path.write_bytes(leaf.public_bytes(serialization.Encoding.PEM))
    key_path.write_bytes(leafkey.private_bytes(serialization.Encoding.PEM,
                          serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
    for p in (ca_path,leaf_path,key_path):p.chmod(0o600)
    return ca_path,leaf_path,key_path,leaf


class SyntheticReceiver(http.server.BaseHTTPRequestHandler):
    server_version='SyntheticReceiver/0'; sys_version=''
    def log_message(self, *_):
        pass  # No request paths or bearer tokens in persistent logs

    def respond(self, code, reason):
        payload=json.dumps({'synthetic':True,'status':reason}).encode()
        self.send_response(code);self.send_header('Content-Type','application/json')
        self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)

    def do_POST(self):
        if self.path != PATH: return self.respond(404,'not-found')
        try:
            size=int(self.headers.get('Content-Length','-1'))
            if size<1 or size>2048: return self.respond(413,'size')
            raw=self.rfile.read(size);msg=json.loads(raw)
            if not isinstance(msg,dict):return self.respond(400,'object-required')
        except (ValueError,json.JSONDecodeError):return self.respond(400,'invalid-json')
        token=self.headers.get('Authorization','')
        found=None
        for producer,(bearer,source) in self.server.producers.items():
            if secrets.compare_digest(token,'Bearer '+bearer):found=(producer,source);break
        if found is None: return self.respond(401,'invalid-token')
        if msg.get('producer_id')!=found[0] or msg.get('capture_source_id')!=found[1]:
            return self.respond(403,'source-not-admitted')
        if msg.get('site_id')!=SYNTHETIC_SITE:return self.respond(403,'site-not-admitted')
        evid=msg.get('event_id')
        if not isinstance(evid,str) or not (1<=len(evid)<=80):return self.respond(400,'event-id')
        if evid in self.server.seen:return self.respond(409,'duplicate-event')
        self.server.seen.add(evid)
        return self.respond(202,'accepted-by-stub-not-durable')


class DisposableTLSAndProducerMatrix(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='captivprod-arch06-synthetic-')
        base=Path(cls.temp.name);base.chmod(0o700)
        ca,leaf,key,cert=make_certificates(base)
        cls.ca=ca;cls.cert=cert
        cls.sensor=secrets.token_hex(24);cls.portal=secrets.token_hex(24)
        # Tokens only in memory; no actual secrets are emitted or reused.
        cls.server=http.server.ThreadingHTTPServer(('127.0.0.1',0),SyntheticReceiver)
        cls.server.producers={
            'arch06-sensor-synthetic':(cls.sensor,'arch06-span-synthetic'),
            'arch06-portal-synthetic':(cls.portal,'arch06-http-synthetic')}
        cls.server.seen=set();context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(str(leaf),str(key));cls.server.socket=context.wrap_socket(cls.server.socket,server_side=True)
        cls.port=cls.server.server_address[1]
        cls.thread=threading.Thread(target=cls.server.serve_forever,daemon=True);cls.thread.start()
        cls.trusted=ssl.create_default_context(cafile=str(ca))

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown();cls.server.server_close();cls.thread.join(timeout=2);cls.temp.cleanup()

    def call(self,producer,source,token,site=SYNTHETIC_SITE,ca=None,event=None):
        data=json.dumps({'producer_id':producer,'capture_source_id':source,'site_id':site,
                         'event_id':event or secrets.token_hex(8)}).encode()
        req=urllib.request.Request(f'https://127.0.0.1:{self.port}{PATH}',data=data,
                                   headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'},
                                   method='POST')
        try:
            with urllib.request.urlopen(req,context=ca or self.trusted,timeout=3) as r:
                return r.status
        except urllib.error.HTTPError as e:return e.code

    def test_01_SAN_contains_exact_loopback_IP(self):
        names=self.cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
        self.assertIn(ipaddress.ip_address('127.0.0.1'),names.get_values_for_type(x509.IPAddress))

    def test_02_valid_sensor_bearer_and_scope(self):
        self.assertEqual(202,self.call('arch06-sensor-synthetic','arch06-span-synthetic',self.sensor))

    def test_03_valid_separate_portal_bearer(self):
        self.assertEqual(202,self.call('arch06-portal-synthetic','arch06-http-synthetic',self.portal))

    def test_04_bad_token_denied(self):
        self.assertEqual(401,self.call('arch06-sensor-synthetic','arch06-span-synthetic','wrong'))

    def test_05_swapped_identity_denied(self):
        self.assertEqual(403,self.call('arch06-portal-synthetic','arch06-http-synthetic',self.sensor))

    def test_06_wrong_site_denied(self):
        self.assertEqual(403,self.call('arch06-sensor-synthetic','arch06-span-synthetic',self.sensor,'b'*24))

    def test_07_wrong_capture_source_denied(self):
        self.assertEqual(403,self.call('arch06-sensor-synthetic','unknown-source',self.sensor))

    def test_08_duplicate_event_denied(self):
        e='synthetic-duplicate-01'
        self.assertEqual(202,self.call('arch06-sensor-synthetic','arch06-span-synthetic',self.sensor,event=e))
        self.assertEqual(409,self.call('arch06-sensor-synthetic','arch06-span-synthetic',self.sensor,event=e))

    def test_09_untrusted_CA_denied_without_verify_bypass(self):
        with tempfile.TemporaryDirectory() as p:
            wrong_ca,_,_,_=make_certificates(Path(p))
            wrong=ssl.create_default_context(cafile=str(wrong_ca))
            with self.assertRaises((ssl.SSLCertVerificationError,urllib.error.URLError)):
                self.call('arch06-sensor-synthetic','arch06-span-synthetic',self.sensor,ca=wrong)

    def test_10_hostname_mismatch_denied(self):
        # TLS expects an IP SAN; connecting with a different DNS identity must fail.
        with socket.create_connection(('127.0.0.1', self.port), timeout=3) as sock:
            with self.assertRaises(ssl.SSLCertVerificationError):
                with self.trusted.wrap_socket(sock, server_hostname='bad.example.invalid'):
                    pass


if __name__=='__main__':unittest.main(verbosity=2)
