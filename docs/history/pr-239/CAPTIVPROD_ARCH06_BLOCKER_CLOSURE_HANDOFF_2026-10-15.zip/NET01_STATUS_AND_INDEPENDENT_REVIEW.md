# TASK-06 / NET-01: targeted status and independent review handoff

Date: 2026-10-15. **No production NET01 firewall, Docker, NPM or systemd changes performed.**

## Artifact identity and transfer

The original complete offline candidate is **on the Owner's Windows workstation**, not in the ARCH-05 ZIP:

- `C:\Users\Zaur Navi\Downloads\TASK-CAPTIVPROD-NET01-IMPLEMENTATION-03_PART-A_REV4_1_OFFLINE_CLEAN.zip`
- Prior SHA256: `422f2cbc1a37535c26c934ddcd244740d6c2408940a57269350c075e4ae68ee7`
- REV4.1 tests observed: 104 PASS in WSL Ubuntu 22.04. Full transfer to a separate Architect conversation is still **NOT DONE**; user must attach this exact original file. The current model cannot silently attach Windows binary ZIP into another chat.

Subsequent offline-only work on workstation:

- Working directory `C:\Users\Zaur Navi\Downloads\NET01_REV4_2_WORKING\NET01_IMPL03_PART_A\`
- Derived review ZIP `TASK-CAPTIVPROD-NET01-IMPLEMENTATION-03_PART-A_REV4_2_OFFLINE_CLEAN.zip`, SHA256 `5f03d474155a04101cf34811cd8b0aba9bc622dee7115370af50dd339054ed49` **REJECTED** because the real installer/rollback shell files contain CRLF and fail actual `bash -n`. Do **not** submit or deploy this rejected ZIP.
- The 104 mocked tests passed because the Bash fixture rewrote scripts with normalized Linux newlines; this does **not** demonstrate packaged on-disk shell correctness. Direct inspection caught the failure.
- Offline-only repair script accompanies this handoff: `repair_net01_rev42_crlf_offline.py`. It creates a **new** ZIP after normalizing Bash line endings, verifying `bash -n` for all package `.sh` files, verifying SHA256 manifest, and adding a fixture test for real packaged scripts. It does not execute any firewall rules. The repaired ZIP has **not** been produced or independently reviewed by this report; do not claim PASS based on the repair instructions alone.

## Proposed exact Sensor extension (offline implementation, review pending)

The guarded destination is host bridge `172.18.0.1:18089` (Omada already uses 8088). Observed local route is `local 172.18.0.1 dev lo src 172.18.0.1`; requires confirmation when full integration runs.

Dedicated IPv4 `CAPTIV_FLASK_18089` INPUT hook must be unconditional for tcp/dport 18089 and **first** in INPUT. Three chain rules, in strict order:

1. existing Docker/NPM-only allow: interface `br-627e7c1ca6d5`, source `172.18.0.2/32`, destination `172.18.0.1/32`, source MAC `b2:fa:fc:bf:d5:bc`, TCP/18089, conntrack NEW/ESTABLISHED;
2. host-local-origin allow: `-i lo -s 172.18.0.1/32 -d 172.18.0.1/32 -p tcp --dport 18089 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT`;
3. terminal TCP-reset REJECT.

An unconditional **first** IPv6 INPUT denial of TCP/18089 remains. The installer inserts the new rule at index 2, the exact verifier now expects three ordered rules, rollback removes six owned modifications after strict quiescence, and watchdog still runs the actual `net01-verify.py --all` and fails closed on drift. Existing protections of port 81 and Omada ports must not be disturbed.

**Trust limit:** local-origin rule is not per-Sensor-UID isolation. Any eligible host-local process may connect. The Linux INPUT `owner` match cannot establish a Sensor UID security boundary; a separately designed OUTPUT owner/cgroup policy or application-layer identity is required if the security contract demands Sensor-exclusive access. No guest, WAN, arbitrary bridge or other-container allowance is included.

## Test evidence

- WSL isolated Python fixture suite after extending to three firewall rules: `104 passed in 12.04s`.
- WSL isolated suite after replacing fake guard with the real verifier CLI parser and mocked identity/firewall read primitives: `104 passed in 11.15s`.
- Additional **actual packaged Bash syntax**: **FAIL** on REV4.2 installer and rollback (CRLF). This overrides any apparent package PASS from mock tests; fixed output not yet retested.
- Independent review of REV4.1 by Architect: pending. Independent review of local rule extension: pending.
- Real PID1: a **separate synthetic** WSL systemd test passed Type=notify, BindsTo stop, listener disappearance and refusal to start when guard failed. **Actual NET01 units/iptables/Docker under PID1 were not exercised.**

## Preconditions to Part B

Complete original REV4.1 transfer; run offline repair with a **new** versioned archive and verify SHA/manifests and shell syntax; independent review of exact three-rule firewall and trust limit; actual disposable-host systemd PID1 + synthetic socket with matching Docker/network identity; allowed NPM + local-origin and denied all other paths, Docker recreate drift, rollback/failed reinstall and watchdog failure; approved Owner-scoped maintenance order. Until then `NET01_PART_B=HOLD` and `NET01_FIREWALL_ACCEPTANCE=HOLD`.
