# TASK-06 / new Linux Omada: verified TLS and OpenAPI facts; credentialed gate HOLD

Current timestamp: 2026-10-15. Read-only Linux controller: `https://192.168.0.99:8043` (local API also answers on `127.0.0.1:8043`), Omada Software Controller `5.14.32.3`. `api/info` returned `errorCode=0`, controller ID (not Site ID) `68ba0bb73ec9f9f0add0a21382f1b810`. Old Windows controller `192.168.0.222` remained accessible and has separate controller ID `fe6867ddf84e4c18c4e280e984e4266d`.

## New verified blocker: HTTPS peer identity

Read-only OpenSSL `s_client`/`x509` on `127.0.0.1:8043` showed:

- Subject: `CN=localhost, O=TP-Link, OU=TP-Link`.
- Issuer identical (self-signed).
- Valid from **2026-10-11 18:29:35 UTC** to **2029-01-13 18:29:35 UTC**.
- Subject Alternative Name: **DNS:Omada**, with **no IP:127.0.0.1 and no IP:192.168.0.99**.

Therefore `OMADA_URL=https://127.0.0.1:8043` **cannot be treated as verified TLS based on current evidence**: DNS/IP identity mismatch plus missing configured trust chain. Successful `curl -k` is only an encrypted-but-unverified diagnostic. Acceptable proposed solutions (separate Owner-scoped change): (A) install a reviewed controller server certificate whose SAN contains chosen local endpoint and whose issuer is trusted by Portal, rotation monitored; (B) verify using existing `DNS:Omada` name with a *controlled* local name-to-loopback mapping and explicitly pinned trusted certificate/CA, if Omada behavior and certificate policy permit. Reject unreviewed `VERIFY_SSL=false` as a security workaround. Approved Git release must expose/use actual peer verification; historical code constant `VERIFY_SSL=False` is separate app security debt.

## Credentialed API gate

Read-only unauthenticated GET to `/openapi/v1/<CONTROLLER_ID>/sites` returned `errorCode=-44116` (Open API Authorized failed), **not** a Site inventory. This is expected without OAuth credentials, and does not establish Site ID, Site name, AP adoption count, SSID/Hotspot policies or scopes. No `auth/unblock/adopt/forget` actions were performed. No established AP control TCP sessions on ports 29811-29817 were observed at the snapshot, but that observation **is not proof** of adopted inventory being empty.

Needed **credentialed read-only** acceptance after TLS trust and service credentials are approved/provisioned: request OAuth2 `client_credentials` with a dedicated minimally scoped OpenAPI client; token and client secret remain outside chat/logs; run Site list and Site detail, AP list (adopted/offline/connected counts), WLAN/SSID and Hotspot/External Portal profile reads, effective client privileges; check response JSON `errorCode=0`, correct 24-hex-character Site ID, Site name, SSID/VLAN/CIDR and no production AP ownership. Compare AP inventory *read-only* against old controller and check actual active inform connections. Record non-secret identity and rights in an approved evidence manifest. If no access, keep HOLD; do not assume legacy Site ID `6a64f17630da7c70d232187a`.

## Downstream bindings remain unpopulated

Until the above read-only gate passes, do **not** populate new `CAPPORT_SITE_ID`, Sensor `SITE_ID`, Portal Producer `SITE_ID`, Receiver producer Site allowlist, webhook Site map or Admin allowlist from historical defaults. Proposed identities are placeholders only. Actual OAuth token/permissions gate cannot be marked PASS.

`NEW_OMADA_CONTROLLER_INFO=PASS; NEW_OMADA_TLS_PEER=HOLD; SITE_ID/SSID/HOTSPOT/AP_INVENTORY=HOLD; OPENAPI_READONLY_PERMISSIONS=HOLD.`
