"""Focused tests for approved systemd-249 numerical Job ID admission."""
import importlib.util
from pathlib import Path
import pytest

P = Path(__file__).resolve().parents[1] / 'firewall/net01-quiescent.py'
spec = importlib.util.spec_from_file_location('net01_quiescence_numerical', P)
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


def sim(states=None, jobs=None, listener=False, failures=()):
    states = states or {}
    jobs = jobs or {}
    def run(args):
        if args[0] in failures:
            raise RuntimeError('mock command unavailable: '+args[0])
        if args[:2] == ['systemctl','show']:
            unit = args[-1]
            active, sub = states.get(unit, ('inactive', 'dead'))
            jid = jobs[unit][0] if unit in jobs else ''
            return '\n'.join(('LoadState=loaded','ActiveState='+active,'SubState='+sub,'Job='+jid))
        if args[:2] == ['systemctl','list-jobs']:
            return '\n'.join(' '.join((jid,unit,typ,state)) for unit,(jid,typ,state) in jobs.items())
        if args[0] == 'ss':
            return 'LISTEN 0 128 172.18.0.1:18089 0.0.0.0:*' if listener else ''
        raise AssertionError(args)
    return run


def good_start():
    return ({probe.FIREWALL: ('activating','start')},
            {probe.APP: ('10316','start','waiting'),
             probe.WATCHDOG: ('10317','start','waiting'),
             probe.FIREWALL: ('10376','start','running')})


def test_real_systemd_249_three_start_jobs_and_activating_firewall_accepted():
    states,jobs=good_start()
    assert probe.check('install',sim(states,jobs))
    with pytest.raises(RuntimeError): probe.check('quiescent',sim(states,jobs))


def test_install_manual_without_jobs_quiescent_admissible():
    assert probe.check('install',sim())


@pytest.mark.parametrize('fault',[
    'wrong_id','wrong_job_type','wrong_job_state','other_job','other_unit_active',
    'watchdog_activating','core_activating','firewall_no_job','firewall_queued',
    'firewall_wrong_substate','failsafe_job','listener','systemctl_failure',
    'ss_failure','duplicate_job','malformed_jobid','missing_start_listing',
])
def test_startup_job_mismatch_rejected(fault):
    state,jobs=good_start()
    if fault=='wrong_id':
        # Construct a divergent list-jobs view but keep show unchanged.
        base=sim(state,jobs)
        def run(args):
            output=base(args)
            if args[:2]==['systemctl','list-jobs']:
                output=output.replace('10317 captiv-net01-watchdog','999 captiv-net01-watchdog')
            return output
    else:
        if fault=='wrong_job_type':jobs[probe.APP]=('10316','stop','waiting')
        if fault=='wrong_job_state':jobs[probe.WATCHDOG]=('10317','start','cancelled')
        if fault=='other_job':jobs['network.target']=('41','start','waiting')
        if fault=='other_unit_active':state[probe.FAILSAFE]=('active','exited')
        if fault=='watchdog_activating':state[probe.WATCHDOG]=('activating','start')
        if fault=='core_activating':state[probe.APP]=('activating','start')
        if fault=='firewall_no_job':jobs.pop(probe.FIREWALL)
        if fault=='firewall_queued':jobs[probe.FIREWALL]=('10376','start','waiting')
        if fault=='firewall_wrong_substate':state[probe.FIREWALL]=('activating','start-pre')
        if fault=='failsafe_job':jobs[probe.FAILSAFE]=('85','start','waiting')
        if fault=='missing_start_listing':
            base=sim(state,jobs)
            def run(args):
                output=base(args)
                if args[:2]==['systemctl','list-jobs']:
                    output='\n'.join(row for row in output.splitlines() if 'captiv-net01-watchdog.service' not in row)
                return output
        if fault=='malformed_jobid':jobs[probe.APP]=('10316/start','start','waiting')
        if fault=='duplicate_job':jobs[probe.APP]=('10376','start','waiting')
        if fault!='missing_start_listing':
            run=sim(state,jobs,listener=fault=='listener',failures=(fault.split('_')[0],) if fault in ('ss_failure','systemctl_failure') else ())
    with pytest.raises(RuntimeError): probe.check('install',run)


def test_quiescent_rejects_pending_even_if_all_services_inactive():
    assert probe.check('quiescent',sim())
    with pytest.raises(RuntimeError):
        probe.check('quiescent',sim(jobs={probe.APP:('1','start','waiting')}))


def test_quiescent_allows_idle_active_exited_firewall_unit_only():
    assert probe.check('quiescent',sim(states={probe.FIREWALL:('active','exited')}))
