"""Disposable mocks for REV4 *offline only*; never invoke privileged host commands."""
from pathlib import Path
from tempfile import TemporaryDirectory
import os, subprocess
from contextlib import contextmanager

ROOT=Path(__file__).resolve().parents[1]


def executable(path, code):
    path.write_text('#!/usr/bin/env python3\n'+code)
    path.chmod(0o755)


@contextmanager
def isolated(**options):
    with TemporaryDirectory(prefix='net01-rev4-offline-') as tmp:
        root=Path(tmp); b=root/'bin';b.mkdir();log=root/'mutation.log';hold=root/'HOLD';maint=root/'MAINTENANCE'
        executable(b/'systemctl', '''import os,sys
args=sys.argv[1:]
if os.getenv('SYSTEMCTL_FAIL')=='1':sys.exit(42)
if args[0]=='show':
    unit=args[-1]
    mode=os.getenv('MODE_'+unit.split('.')[0].replace('-','_').upper(),os.getenv('UNIT_STATE','inactive'))
    sub='dead' if mode=='inactive' else ('running' if mode=='active' else 'start' if mode=='activating' else 'stop')
    job=os.getenv('JOB','') if unit=='captive-portal.service' else ''
    if os.getenv('LOAD_STATE')=='not-found':mode='inactive';load='not-found'
    else:load='loaded'
    print('LoadState='+load+'\\nActiveState='+mode+'\\nSubState='+sub+'\\nJob='+job)
    sys.exit(0)
if args[0]=='list-jobs':
    if os.getenv('JOB_LIST')=='start':print('314 captive-portal.service start waiting')
    elif os.getenv('JOB_LIST')=='watchdog':print('210 captiv-net01-watchdog.service stop running')
    elif os.getenv('JOB_LIST')=='bad':print('unparseable output')
    sys.exit(0)
if args[0]=='stop':
    if os.getenv('STOP_FAIL')=='1':sys.exit(8)
    with open(os.environ['STOPLOG'],'a') as out:out.write(' '.join(args)+'\\n')
    sys.exit(0)
sys.exit(43)
''')
        executable(b/'id', '''import os,sys
if os.getenv('SENSOR_ID_FAIL')=='1':sys.exit(9)
print('17042')
''')
        executable(b/'ss','''import os,sys
if os.getenv('SS_FAIL')=='1':sys.exit(8)
if os.getenv('SS_LISTENER')=='1':print('LISTEN 0 128 172.18.0.1:18089 0.0.0.0:*')
if os.getenv('SS_MALFORMED')=='1':print('garbage')
sys.exit(0)
''')
        executable(b/'iptables','''import os,sys
args=sys.argv[1:]
if args[:2]==['-w','-S']:
    if os.getenv('IPTABLES_QUERY_FAIL')=='1':sys.exit(5)
    if len(args)==3 and args[2] in ('CAPTIV_FLASK_18089','CAPTIV_SENSOR_OUT_18089') and os.getenv('CHAIN_EXISTS')!='1':sys.exit(1)
    print('-N CAPTIV_FLASK_18089' if os.getenv('CHAIN_EXISTS')=='1' else '-P INPUT ACCEPT')
    sys.exit(0)
with open(os.environ['MUTLOG'],'a') as f:f.write('iptables '+' '.join(args)+'\\n')
sys.exit(0)
''')
        executable(b/'ip6tables','''import os,sys
args=sys.argv[1:]
if args[:2]==['-w','-S']:
    if os.getenv('IP6_QUERY_FAIL')=='1':sys.exit(5)
    print('-P INPUT ACCEPT')
    sys.exit(0)
with open(os.environ['MUTLOG'],'a') as f:f.write('ip6tables '+' '.join(args)+'\\n')
sys.exit(0)
''')
        executable(root/'guard.py','''import os,sys
sys.exit(int(os.getenv('GUARD_RC','0')))
''')
        executable(root/'maint.py','''import os,sys
from pathlib import Path
p=Path(os.environ['MAINT_MARKER']);a=sys.argv[1]
if os.getenv('MAINT_FAIL')=='1':sys.exit(75)
if a=='enter':p.write_text('MAINTENANCE');sys.exit(0)
if a=='require':sys.exit(0 if p.exists() else 75)
if a=='absent':sys.exit(75 if p.exists() else 0)
sys.exit(75)
''')
        executable(root/'marker-unlink.py','''import os,sys
from pathlib import Path
if os.getenv('UNLINK_FAIL')=='1':sys.exit(75)
if sys.argv[1]=='HOLD':Path(os.environ['HOLD_MARKER']).unlink()
elif sys.argv[1]=='MAINTENANCE':Path(os.environ['MAINT_MARKER']).unlink()
else:sys.exit(75)
''')
        env={**os.environ,'PATH':str(b)+':/usr/bin:/bin',
             'MUTLOG':str(log),'STOPLOG':str(root/'stops.log'),
             'MAINT_MARKER':str(maint),'HOLD_MARKER':str(hold)}
        env.update({k:str(v) for k,v in options.items()})
        def run(name, *, args=(), marker=False, existing_hold=False, **kw):
            if marker:maint.write_text('MAINTENANCE')
            if existing_hold:hold.write_text('HOLD')
            env2={**env,**{k:str(v) for k,v in kw.items()}}
            script=(ROOT/'firewall'/name).read_text()
            script=script.replace('GUARD=/usr/local/libexec/captiv-net01/net01-verify.py',f'GUARD={root}/guard.py')
            script=script.replace('PROBE=/usr/local/libexec/captiv-net01/net01-quiescent.py',f'PROBE={ROOT}/firewall/net01-quiescent.py')
            script=script.replace('MAINT=/usr/local/libexec/captiv-net01/net01-maintenance-state.py',f'MAINT={root}/maint.py')
            script=script.replace('ROOT=/usr/local/libexec/captiv-net01',f'ROOT={root}')
            script=script.replace('\"$ROOT/net01-maintenance-state.py\"', f'\"{root}/maint.py\"')
            script=script.replace('\"$ROOT/net01-quiescent.py\"', f'\"{ROOT}/firewall/net01-quiescent.py\"')
            script=script.replace('\"$ROOT/net01-verify.py\"', f'\"{root}/guard.py\"')
            script=script.replace('\"$ROOT/net01-marker-unlink.py\"', f'\"{root}/marker-unlink.py\"')
            script=script.replace('/usr/local/libexec/captiv-net01/net01-maintenance-state.py',f'{root}/maint.py')
            script=script.replace('/usr/local/libexec/captiv-net01/net01-quiescent.py',f'{ROOT}/firewall/net01-quiescent.py')
            script=script.replace('/usr/local/libexec/captiv-net01/net01-marker-unlink.py',f'{root}/marker-unlink.py')
            script=script.replace('HOLD=/var/lib/captiv-net01/HOLD',f'HOLD={hold}')
            script=script.replace('exec 9>/run/lock/captiv-net01-firewall.lock',f'exec 9>{root}/lock')
            p=root/name;p.write_text(script);p.chmod(0o755)
            process=subprocess.run(['bash',str(p),*args],capture_output=True,text=True,env=env2,timeout=9)
            mutations=log.read_text().splitlines() if log.exists() else []
            return process,mutations
        yield root,env,run,hold,maint,log
