#!/usr/bin/env python3
"""Fail-closed NET01 systemd and listener gate.

All show Job properties are numerical job IDs (or empty), crosschecked with
systemctl list-jobs (ID, unit, type, state). A systemd ordered install start
transaction admits only expected starts; maintenance/rollback admits NO jobs.
"""
import argparse
import re
import subprocess
import sys

APP = 'captive-portal.service'
WATCHDOG = 'captiv-net01-watchdog.service'
FAILSAFE = 'captiv-net01-failsafe.service'
FIREWALL = 'captiv-net01-firewall.service'
UNITS = (APP, WATCHDOG, FAILSAFE, FIREWALL)
INSTALL_START_JOBS = frozenset((APP, WATCHDOG, FIREWALL))


def run_command(args):
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       text=True, check=False, timeout=5)
    if p.returncode:
        raise RuntimeError('status command failed: ' + args[0])
    return p.stdout


def query_unit(unit, runner=run_command):
    output = runner(['systemctl', 'show', '--no-pager', '-p', 'LoadState',
                     '-p', 'ActiveState', '-p', 'SubState', '-p', 'Job', unit])
    data = {}
    for line in output.splitlines():
        if '=' not in line:
            raise RuntimeError('malformed systemd show line')
        key, value = line.split('=', 1)
        if key in data:
            raise RuntimeError('duplicate systemd property')
        data[key] = value
    if set(data) != {'LoadState', 'ActiveState', 'SubState', 'Job'}:
        raise RuntimeError('missing or unknown systemd properties')
    if data['LoadState'] != 'loaded':
        raise RuntimeError('NET01 unit not loaded: ' + unit)
    if data['Job'] and not re.fullmatch('[1-9][0-9]*', data['Job']):
        raise RuntimeError('invalid numerical systemd Job ID: ' + unit)
    return data


def jobs_check(mode, runner=run_command):
    output = runner(['systemctl', 'list-jobs', '--all', '--no-legend', '--plain'])
    jobs = {}
    seen_ids = set()
    for line in output.splitlines():
        if not line.strip() or line.strip() == 'No jobs running.':
            continue
        fields = line.split()
        if len(fields) != 4 or not re.fullmatch('[1-9][0-9]*', fields[0]):
            raise RuntimeError('unparseable systemd job listing')
        ident, unit, kind, state = fields
        if ident in seen_ids or unit in jobs:
            raise RuntimeError('duplicate systemd job')
        seen_ids.add(ident)
        # Unknown jobs must HOLD, not silently disappear from the comparison.
        if mode != 'install' or unit not in INSTALL_START_JOBS or kind != 'start' \
                or state not in ('waiting', 'running'):
            raise RuntimeError('unexpected pending systemd job: ' + unit)
        jobs[unit] = (ident, kind, state)
    return jobs


def check_listener(runner=run_command):
    output = runner(['ss', '-H', '-lnt'])
    for line in output.splitlines():
        fields = line.split()
        if len(fields) < 5 or fields[0] != 'LISTEN':
            raise RuntimeError('unparseable ss listener output')
        address = fields[3]
        if ':' not in address:
            raise RuntimeError('unparseable ss local address')
        port = address.rsplit(':', 1)[-1]
        if not port.isdigit():
            raise RuntimeError('non-numeric ss listener port')
        if int(port) == 18089:
            raise RuntimeError('TCP 18089 listener still present')


def snapshot(mode, runner):
    shown = {unit: query_unit(unit, runner) for unit in UNITS}
    observed = jobs_check(mode, runner)
    for unit, value in shown.items():
        job = value['Job']
        listed = observed.get(unit)
        if (job or None) != (listed[0] if listed else None):
            raise RuntimeError('systemd Job ID mismatch for ' + unit)
        active, sub = value['ActiveState'], value['SubState']
        if unit in (APP, WATCHDOG, FAILSAFE):
            if (active, sub) != ('inactive', 'dead'):
                raise RuntimeError('not fully inactive/dead: ' + unit)
            if unit == FAILSAFE and job:
                raise RuntimeError('failsafe cannot have pending job')
        else:  # firewall unit
            if mode == 'quiescent':
                if job or (active, sub) not in (('inactive', 'dead'), ('active', 'exited')):
                    raise RuntimeError('firewall unit not quiescent')
            elif (active, sub) == ('activating', 'start'):
                if not listed or listed[1:] != ('start', 'running'):
                    raise RuntimeError('firewall activating without own running start job')
            elif (active, sub) not in (('inactive', 'dead'), ('active', 'exited')) or job:
                raise RuntimeError('unexpected firewall install state')
    return shown, observed


def check(mode='quiescent', runner=run_command):
    if mode not in ('quiescent', 'install'):
        raise ValueError('invalid mode')
    first = snapshot(mode, runner)
    check_listener(runner)
    second = snapshot(mode, runner)
    if first != second:
        raise RuntimeError('systemd job or unit state changed during verification')
    check_listener(runner)
    return True


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--mode', choices=['quiescent', 'install'], default='quiescent')
    args = p.parse_args(argv)
    try:
        check(args.mode)
        print('NET01_QUIESCENCE=PASS mode=' + args.mode)
        return 0
    except (OSError, RuntimeError, ValueError, subprocess.TimeoutExpired) as exc:
        print('NET01_QUIESCENCE=HOLD ' + type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
        return 75


if __name__ == '__main__':
    sys.exit(main())
