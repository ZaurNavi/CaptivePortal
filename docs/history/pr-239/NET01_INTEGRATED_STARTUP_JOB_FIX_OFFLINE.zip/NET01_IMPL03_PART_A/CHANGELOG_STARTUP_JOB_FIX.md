# NET01 approved startup admission correction — isolated staging follow-up

- Approved 2026-10-16 by Architect: parse **numeric** `Job=<ID>` from `systemctl show`, match to `systemctl list-jobs` ID/unit/type/state. No `/start` assumption.
- Install mode accepts only expected `start` jobs for Core, watchdog and firewall installer; firewall may be `activating/start` only with its own running start job. Core and watchdog must be `inactive/dead` until permitted by ordering. Unexpected jobs, mismatched IDs, service states, listening TCP 18089, changed snapshots all HOLD.
- Quiescent/maintenance/rollback mode rejects ALL pending jobs and active Core/watchdog/failsafe; firewall remains quiescent inactive/dead or active/exited (oneshot).
- Existing policy, installer, verifier, watchdog, rollback and Docker image/reference are unchanged by this narrowly authorized startup patch.
- Tests changed for numeric `Job` output and 21 focused positive/negative test cases added; 170/170 total offline PASS.

## Real WSL2 isolated staging (systemd 249, Docker 29.1.3, iptables-nft)

- Actual upstream NPM image and digest used; source image digest verified.
- Original startup-admission failure reproduced before patch; a **functionally equivalent but not byte-identical shortened copy** of the corrected admission probe PASSed; firewall install and strict verifier from the package PASSed; test HTTP backend started via systemd. Therefore exact archived verifier/probe PID1 end-to-end acceptance remains NOT_TESTED pending the two blockers.
- **New blocker 1:** watchdog `ProtectSystem=strict` denies write to `/run/lock/captiv-net01-firewall.lock` from `ExecStartPre`. Staging-only adding `ReadWritePaths=/run/lock/captiv-net01-firewall.lock` and explicit operator recovery allowed backend startup. This unit change is NOT in package and needs Architect approval.
- NPM container → backend connectivity PASS; maintenance, exact rollback, maintenance reinstall, HOLD clear, maintenance clear and repeated startup PASS with staging-only RW override.
- **New blocker 2:** Sensor UID matched OUTPUT but INPUT rejected. tcpdump captured WSL `lo IN 172.24.12.111 -> 172.18.0.1:18089`. Docker `nat/POSTROUTING -s 172.18.0.0/16 ! -o bridge -j MASQUERADE` SNATs the local source. Read-only verification found equivalent MASQUERADE on `captiv-prod`, whose LAN IP is 192.168.0.99. Production runtime Sensor source and exact narrow allow need separate approval. No UID/source exception added to this package.
- WSL Docker container, staging network, service units, NET01 firewall rules and diagnostic listener CLEANED (RC=0); Docker package installed only on separate WSL2 test machine.

## Status

STARTUP_JOB_FIX=PASS_OFFLINE_AND_ISOLATED_SYSTEMD
FULL_NET01_INTEGRATION=HOLD_NEW_RUNTIME_BLOCKERS
PRODUCTION_MODIFICATIONS=NONE
PART_B=NOT_AUTHORIZED
CAPTIVEPORTAL_INSTALL=NOT_AUTHORIZED
