WEB-UX-PACK-03 / R1 — Coder Handoff

Authoritative task:
WEB-UX-PACK-03_R1_IMPLEMENTATION_CONTRACT.md

Exact baseline:
commit be3fe14f929b45e4a1ca3991bc6a2a3011792641
tree   16a16d87c7dc821e0a5c4e6fe8ad67d4962d129d

No commit/push/PR/merge/deploy/production action is authorized.
Return a review candidate + unified patch + tests + visual evidence.
