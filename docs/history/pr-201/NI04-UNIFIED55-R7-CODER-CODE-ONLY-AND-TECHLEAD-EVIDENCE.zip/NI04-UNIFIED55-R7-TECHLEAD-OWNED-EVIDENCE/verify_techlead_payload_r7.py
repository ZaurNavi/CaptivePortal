"""Independent TechLead frozen-data validation; no network and no production access.
Checks structure/content/hash/uniqueness, provenance-reference integrity and 330 synthetic expectations.
NOT a replacement for application loader/matcher tests or live traffic evidence.
"""
from pathlib import Path
import json,hashlib,datetime,re,zipfile,collections
ROOT=Path(__file__).resolve().parent
files={k:ROOT/f for k,f in [('tax','recognition-taxonomy-v2.json'),('mani','recognition-knowledge-manifest-v2.json'),('rules','recognition-ruleset-v2.json')]}
def canon(o):return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def digest(o,k):return hashlib.sha256(canon({a:b for a,b in o.items() if a!=k})).hexdigest()
def load(k):
 raw=files[k].read_bytes();obj=json.loads(raw)
 assert canon(obj)==raw
 return obj

tax,mani,rules=[load(x) for x in files]
for obj,pref,key in [(tax,'taxonomy','taxonomy'),(mani,'knowledge_manifest','knowledge_manifest'),(rules,'ruleset','ruleset')]:
 assert obj[pref+'_digest_sha256']==digest(obj,pref+'_digest_sha256'),key
 assert obj[pref+'_version']==2
 assert obj['schema_version']==1
ids='captivportal.network-intelligence.'
assert tax['taxonomy_id']==ids+'recognition-taxonomy'
assert mani['knowledge_manifest_id']==ids+'recognition-knowledge'
assert rules['ruleset_id']==ids+'service-recognition'
for key,parent in [('taxonomy',tax),('knowledge_manifest',mani)]:
 for suffix in ('_id','_version','_digest_sha256'):
  assert rules[key+suffix]==parent[key+suffix]
allowed_categories={'category.'+x for x in ('video_streaming','audio_streaming','messaging','social','cloud_storage','productivity_collaboration','gaming','software_distribution','web_search','other_supported')}
assert {x['service_category_id'] for x in tax['service_categories']}==allowed_categories
assert len(tax['services'])==55
assert len(rules['rules'])==53
assert len(mani['sources'])==57
for rows,key in [(tax['services'],'service_id'),(tax['organizations'],'organization_id'),(tax['service_categories'],'service_category_id'),(mani['sources'],'knowledge_ref'),(rules['rules'],'rule_id')]:
 vals=[x[key] for x in rows];assert vals==sorted(set(vals)),key
services={x['service_id']:x for x in tax['services']}
orgs={x['organization_id'] for x in tax['organizations']}
cats={x['service_category_id'] for x in tax['service_categories']}
sources={x['knowledge_ref']:x for x in mani['sources']}

parse=lambda value: datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
check_fields={ 'org':r'org\.[a-z0-9][a-z0-9._-]{1,62}[a-z0-9]', 'service':r'service\.[a-z0-9][a-z0-9._-]{1,58}[a-z0-9]', 'knowledge':r'knowledge\.[a-z0-9][a-z0-9._-]{1,94}[a-z0-9]', 'rule':r'rule\.[a-z0-9][a-z0-9._-]{1,94}[a-z0-9]' }
for org in tax['organizations']:
 assert org['organization_kind'] in ('service_operator','infrastructure_provider','mixed')
 assert re.fullmatch(check_fields['org'],org['organization_id'])
for row in services.values():
 assert re.fullmatch(check_fields['service'],row['service_id'])
 assert row['lifecycle_state']=='active' and row['organization_id'] in orgs and row['service_category_id'] in cats

def review(row):
 a,b=parse(row['reviewed_at_utc']),parse(row['review_due_at_utc'])
 assert datetime.timedelta(0)<b-a<=datetime.timedelta(days=365)
 return a,b
review(mani)
for s in mani['sources']:
 assert re.fullmatch(check_fields['knowledge'],s['knowledge_ref'])
 assert s['source_class']=='first_party_public'
 assert s['source_locator'].startswith('https://')
 assert len(s['claim_summary'])<=512
 assert review(s)[0]<=review(mani)[0]<review(s)[1]

by_host={}
for r in rules['rules']:
 assert re.fullmatch(check_fields['rule'],r['rule_id'])
 assert r['rule_kind']=='service_sni_exact' and r['target_type']=='service' and r['lifecycle_state']=='active'
 assert r['ambiguity_group_id'] is None
 assert r['target_id'] in services
 assert re.fullmatch(r'[a-z0-9]+(?:[.-][a-z0-9]+)*',r['hostname_pattern'])
 assert r['hostname_pattern'] not in by_host
 by_host[r['hostname_pattern']]=r['target_id']
 assert r['knowledge_refs']==sorted(set(r['knowledge_refs']))
 assert all(x in sources for x in r['knowledge_refs'])
 assert review(r)[0]>=review(mani)[0]
 for k in r['knowledge_refs']:assert review(r)[0]>=review(sources[k])[0]

z=zipfile.ZipFile('/mnt/data/NI04K-LANE-A-BOUNDED-REPAIR-FOR-ARCHITECT-R3.zip')
old_pre='NI04K-LANE-A-BOUNDED-REPAIR-FOR-ARCHITECT-R3/'
old=json.loads(z.read(old_pre+'recognition-ruleset-v1.json'))
for prev in old['rules']:
 matches=[r for r in rules['rules'] if r['rule_id']==prev['rule_id']]
 assert len(matches)==1
 ignore={'reviewed_at_utc','review_due_at_utc'}
 assert {k:v for k,v in matches[0].items() if k not in ignore}=={k:v for k,v in prev.items() if k not in ignore}
old_tax=json.loads(z.read(old_pre+'recognition-taxonomy-v1.json'))
for s in old_tax['services']:
 assert services[s['service_id']]==s

ledger=json.loads((ROOT/'TECHLEAD-55-HOST-DECISIONS.json').read_bytes())
assert len(ledger['services'])==55
assert {s['service_id'] for s in ledger['services']}==set(services)
assert all(by_host.get(s['host'])==s['service_id'] for s in ledger['services'] if s['service_id'] not in {'service.messenger','service.viber'})
assert services['service.chatgpt']['service_category_id']=='category.other_supported'
fixtures=json.loads((ROOT/'TECHLEAD-55-SYNTHETIC-TEST-VECTORS.json').read_bytes())['vectors']
assert len(fixtures)==330
for v in fixtures:
 actual=by_host.get(v['hostname']) if v['signal'] in ('tls_sni','quic_sni') else None
 assert actual==v['expected'],v
rawsum={k:hashlib.sha256(f.read_bytes()).hexdigest() for k,f in files.items()}
print(json.dumps({'status':'TECHLEAD_FROZEN_ARTIFACT_OFFLINE_STRUCTURAL_PASS','records':55,'active_exact_rules':53,'sources':57,'fixtures':len(fixtures),'orgs':len(orgs),'categories':len(cats),'raw_sha256':rawsum,'semantic_digests':{'taxonomy':tax['taxonomy_digest_sha256'],'manifest':mani['knowledge_manifest_digest_sha256'],'ruleset':rules['ruleset_digest_sha256']},'provenance_limit':'source URLs were researched but no 55 native-client traffic traces collected; Viber official web-page URL is not proof of app messaging'},sort_keys=True,ensure_ascii=False))
