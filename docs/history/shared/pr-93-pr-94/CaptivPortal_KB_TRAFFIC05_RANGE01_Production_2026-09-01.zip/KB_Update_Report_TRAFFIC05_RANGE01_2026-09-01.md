# CaptivPortal KB Controlled Update — TRAFFIC-05 + TRAFFIC-RANGE-01

Prepared: 2026-09-01

Exact implementation / production baseline:

```text
HEAD: daf68e91fc759188980cf8741913e6b60a58eb62
tree: b0e2f028eecf6aec9d86e35542c33e7105209335
```

## Repository verification

GitHub `main` is merge PR #94 (`TASK-TRAFFIC-RANGE-01 — Independent Traffic
Range per Panel`) at the exact baseline above.

`TASK-TRAFFIC-05 — Traffic by AP` was merged previously as PR #93.

## Documentation drift found

Current/canonical docs still contained post-TRAFFIC-04 state:

- `TRAFFIC-05 — Traffic by AP` marked `NEXT / NOT IMPLEMENTED`;
- next stage still pointed to TRAFFIC-05;
- current baseline still pointed to `a9cd8a9... / f53f204...`;
- Traffic surface ended at Peak Load;
- Traffic by AP repository/production flags were undocumented;
- Independent Ranges flag/current production state were undocumented;
- Admin/Architecture docs still described History/Statistics/Peak as sharing one
  selected range;
- canonical `products=` projection was undocumented;
- page-local broker/coalescing/generation state was undocumented;
- permanent 10-second historical admission guard was undocumented;
- latest testing/deployment evidence still described TRAFFIC-04.

Repository-wide search did not identify an additional current canonical Traffic
status document under plans/agent docs that required modification. Historical
FINAL/master-roadmap/archive material is intentionally left unchanged.

## Documentation scope

Exactly 12 current/canonical documentation files:

- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/admin-web.md`
- `docs/modules/analytics.md`
- `docs/modules/traffic.md`
- `docs/project-inventory.md`
- `docs/testing.md`

Application code: unchanged.
Tests: unchanged.
Runtime config: unchanged.
Production: unchanged.

## Current Traffic roadmap after reconciliation

```text
TRAFFIC-00         DONE
TRAFFIC-01         DONE / PRODUCTION ACTIVE
TRAFFIC-02-READ    DONE
TRAFFIC-02         DONE / PRODUCTION ACTIVE
TRAFFIC-02-PERF-01 DONE
TRAFFIC-03         DONE / PRODUCTION ACTIVE
TRAFFIC-04         DONE / PRODUCTION ACTIVE
TRAFFIC-05         DONE / PRODUCTION ACTIVE
TRAFFIC-RANGE-01   DONE / PRODUCTION ACTIVE / PRODUCTION ACCEPTANCE PASS
TRAFFIC-06         NEXT / DRAFT REQUESTED / NOT IMPLEMENTED
```

## Production feature state

```text
WEB_ADMIN_TRAFFIC_ENABLED=true
WEB_ADMIN_TRAFFIC_HISTORY_ENABLED=true
WEB_ADMIN_TRAFFIC_STATISTICS_ENABLED=true
WEB_ADMIN_TRAFFIC_PEAK_ENABLED=true
WEB_ADMIN_TRAFFIC_BY_AP_ENABLED=true
WEB_ADMIN_TRAFFIC_INDEPENDENT_RANGES_ENABLED=true
```

Repository defaults for these flags remain false.

## Independent-range architecture

The update documents:

- independent selected/applied state for History/Statistics/Peak/AP;
- page-lifetime only state, reset to 24h on reload;
- prior successful payload survives a failed range switch;
- canonical `products=history,statistics,peak,aps`;
- legacy `include=` compatibility;
- strict invalid projection 400 behavior;
- `TrafficHistoricalRequestBroker` as page-local intent/coalescing/response layer;
- `CaptivPortalTrafficCoordinator` as scheduler/lifecycle owner;
- max one historical HTTP request in flight;
- 10-second dispatch-based admission guard;
- product-intent priority/coalescing/generation rules;
- compact AP-only `ap_bucket_axis`.

## Performance / acceptance

The update records RANGE-01 Linux production-size §97 PERF PASS, exact B24/C24/A7
evidence and immutable snapshot `b65a2ce7718454571f08c474c1b59045c3da415d1e160a55725d5095e49287eb` / `273235968` bytes.

QueryDeadline remains 10 seconds. Browser timeout and Admin concurrency were not
increased.

Known Windows SQLite infinity behavior remains reviewed compatibility and not a
TASK regression.

## Publication plan

Branch:

```text
docs/traffic05-range01-production-kb-2026-09-01
```

Commit:

```text
docs: reconcile TRAFFIC-05 and independent ranges production state
```

Draft PR:

```text
Docs: reconcile TRAFFIC-05 and independent ranges production state
```

Publisher performs fail-closed exact SHA/tree verification, full current-content
precheck before first write, exact 12-file scope verification, canonical/stale
assertions, `git diff --check`, staged diff check, staged unified-diff export,
single commit, push and Draft PR creation.

Merge is not performed.
