from __future__ import annotations
import os, re, subprocess
from pathlib import Path

BASE='c1dc3344bc778a32cdc6b0edce278ee40b287c29'
TREE='0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c'
BRANCH='docs/test-baseline-cleanup-kb-2026-09-12'
V7_SHA='45d3b37150a2c3b3d3e95460b2a1c6cab8d97aa333c3d3e0cd3507ef1c994f77'
PUB_COMMIT='ef3e8ca20e2303c29437c6c087919a6715afac96'
ACCEPTED_BASE='75df5af1500ebcaf7d4950abccbaabc0a03610e1'
PREV_PROD='043a13bc1e3aa3353e27af1859dc0bb698df4955'
SCOPE=['README.md', 'README_RU.md', 'docs/README.md', 'docs/agents/repository-actions.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/analytics.md', 'docs/modules/traffic.md', 'docs/operations-command-lessons-learned.md', 'docs/project-inventory.md', 'docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md', 'docs/testing-environments.md', 'docs/testing.md']
DIRTY12=['README.md', 'README_RU.md', 'docs/README.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/analytics.md', 'docs/modules/traffic.md', 'docs/operations-command-lessons-learned.md', 'docs/project-inventory.md', 'docs/testing-environments.md']
TASK_FINAL='# TASK-TEST-BASELINE-CLEANUP-01 — Windows Compatibility Debt Removal — FINAL\n\nStatus: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS\nUpdated: 2026-09-12\n\n## Final identity\n\n```text\nTASK=TASK-TEST-BASELINE-CLEANUP-01\nPR=#116\nPR title=TASK-TEST-BASELINE-CLEANUP-01: remove Windows compatibility debt\npublication branch=feature/test-baseline-cleanup-01\npublication commit=ef3e8ca20e2303c29437c6c087919a6715afac96\npublication parent / accepted baseline=75df5af1500ebcaf7d4950abccbaabc0a03610e1\nmerge / current production HEAD=c1dc3344bc778a32cdc6b0edce278ee40b287c29\naccepted / merged / production tree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\n```\n\nCritical identity invariant:\n\n```text\naccepted candidate tree\n=\npublication commit tree\n=\nmerge commit tree\n=\nproduction tree\n=\n0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\n```\n\n## Implementation scope\n\nExactly four implementation/test files changed:\n\n```text\napp/analytics/source_gateway.py\ntests/analytics/test_historical_traffic.py\ntests/test_auth_retry_frontend.py\ntests/visitor_registry/test_device_registry_worker.py\n```\n\nFinal diff:\n\n```text\n4 files changed\n30 insertions\n16 deletions\nNO EXTRAS\n```\n\nOnly `app/analytics/source_gateway.py` is production runtime code.\n\n## SQLite finite/nonnegative portability\n\nThe platform-sensitive max-double comparison was removed.\n\nCanonical fail-closed SQL shape:\n\n```text\ntypeof(value) IN (\'integer\',\'real\')\nAND value >= 0\nAND COALESCE((value - value) = 0, 0)\n```\n\nFinite numeric values satisfy `value - value = 0`.\n\nInfinity produces non-finite/NULL semantics through self-subtraction and fails\nthe predicate closed.\n\nThis applies to current and historical Analytics read paths.\n\nHistorical regression evidence now includes `float("inf")`.\n\n## Node retry tests\n\nProduction JavaScript was not changed.\n\nThe test harness no longer assumes the production click handler returns a\nPromise. Tests invoke the listener and separately drain asynchronous work using\n`setImmediate`.\n\n```text\nproduction JavaScript change=NO\ntest synchronization change=YES\n```\n\n## Visitor Registry timing tests\n\nProduction Visitor Registry runtime was not changed.\n\nThe test helper now accepts a parametrized `scan_interval_seconds`. The three\ntiming/background cases use a test-only 5.0 second interval so a second scan\ncannot begin before stop.\n\n```text\nproduction Visitor Registry change=NO\ntest timing synchronization change=YES\n```\n\n## Home Health\n\nProduction Home Health implementation was not changed.\n\nThe previously known Windows compatibility case is now an ordinary strict\nregression test.\n\n## Windows compatibility debt closure\n\nBefore this TASK, Windows Central Lab V6 had six special compatibility cases:\n\n```text\n1. SQLite infinity edge\n2. Node retry async timing\n3. Visitor Registry long audit\n4. Visitor Registry previous-ready\n5. Visitor Registry previous-stopping\n6. Home Health unavailable analytics baseline\n```\n\nThat is historical V6 evidence only.\n\nCurrent contract:\n\n```text\nformer six compatibility cases=ordinary strict regression tests\ncompatibility allowlist for former six=EMPTY\nsix-case --deselect path=REMOVED\nseparate six-case compatibility stage=REMOVED\nsix-case compatibility WARN escape=REMOVED\n```\n\nA failure in any of these cases is a normal strict regression failure.\n\n## Windows Central Lab V7\n\nCurrent canonical Windows full-regression runner:\n\n```text\nC:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd\nSHA256=45d3b37150a2c3b3d3e95460b2a1c6cab8d97aa333c3d3e0cd3507ef1c994f77\n```\n\nV7 stages:\n\n```text\n[1/4] ordinary full strict pytest\n[2/4] compileall\n[3/4] branch diff check\n[4/4] exact-artifact immutability\n```\n\nAccepted run evidence:\n\n```text\n3129 passed\n30 skipped\n0 failed\n0 deselected\nstrict regressions=0\ncompileall=PASS\nbranch diff=PASS\nexact-artifact immutability=PASS\n```\n\n`3129 passed / 30 skipped` is evidence from this accepted run, not a permanent\nhardcoded test-count invariant.\n\nPermanent invariant:\n\n```text\nformer six compatibility cases execute as ordinary strict tests\nand cannot degrade to WARN\n```\n\nV6 runner:\n\n```text\nC:\\CaptivPortal-Lab\\lab-test-v6-fixed.cmd\nstatus=HISTORICAL / AUDIT ONLY\n```\n\nV6 was not deleted or rewritten.\n\n## Production deployment\n\nPrevious production:\n\n```text\nHEAD=043a13bc1e3aa3353e27af1859dc0bb698df4955\n```\n\nMerged target:\n\n```text\nHEAD=c1dc3344bc778a32cdc6b0edce278ee40b287c29\ntree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\n```\n\nProduction `/opt/CaptivePortal` was updated FROM GIT using exact detached\nartifact identity.\n\nPost-deploy:\n\n```text\nHEAD=c1dc3344bc778a32cdc6b0edce278ee40b287c29\ntree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\nworktree=CLEAN\n```\n\nBecause `app/analytics/source_gateway.py` is runtime code and is also imported by\nthe Traffic Projection source path, production activation restarted:\n\n```text\ntraffic-projection.service\ncaptive-portal.service\n```\n\nNot required for this delivery:\n\n```text\nDB migration=NO\nschema change=NO\nconfiguration change=NO\nfeature flag change=NO\nsystemd unit change=NO\ndaemon-reload=NO\n```\n\n## Production acceptance\n\nTraffic Projection:\n\n```text\ntraffic-projection.service=active\nartifact_sha=c1dc3344bc778a32cdc6b0edce278ee40b287c29\nartifact_tree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\nprojection_version=historical_traffic_projection.v1\nstatus=healthy\nbacklog_cycle_count=0\n```\n\nCaptive Portal:\n\n```text\ncaptive-portal.service=active\nartifact_sha=c1dc3344bc778a32cdc6b0edce278ee40b287c29\nartifact_tree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\nanalytics startup=analytics.api_runtime_active\nserver=127.0.0.1:8088 / debug=False\nlistener=127.0.0.1:8088 LISTEN\nHTTP readiness=400\n```\n\nHTTP `400` on `/` without required Omada request parameters is the expected\nproduction readiness contract.\n\nObservation continued successful cycles after restart. Admin Current State reads\nexecuted after startup. No startup traceback or critical failure attributable to\nthis delivery was observed.\n\n## Startup observation\n\nThe first readiness probe was early:\n\n```text\nsystemd state=active\nlistener=absent\nHTTP=000\n```\n\nThe same PID then continued normal startup composition and reached:\n\n```text\nanalytics.api_runtime_active\nStarting server on 127.0.0.1:8088\nLISTEN\nHTTP=400\n```\n\nThis is not a TASK regression.\n\nPermanent operational rule:\n\n```text\nsystemd active != HTTP readiness\n```\n\nAfter restart, wait for actual listener/readiness evidence. Do not issue a second\nrestart solely because systemd is already active while the HTTP listener has not\nyet appeared if the same process is still making normal startup progress.\n\n## Existing warning\n\nProduction logs contain `urllib3 InsecureRequestWarning` for HTTPS access to the\nOmada Controller at `192.168.0.222`.\n\nThis warning pre-dates TASK-TEST-BASELINE-CLEANUP-01 and is not a regression of\nthis delivery.\n\n## Final verdict\n\n```text\nTASK-TEST-BASELINE-CLEANUP-01=FINAL ACCEPTED\nPR #116=MERGED\nPRODUCTION DEPLOY=PASS\nPRODUCTION ACCEPTANCE=PASS\nCURRENT WINDOWS FULL RUNNER=V7 STRICT\nV6=HISTORICAL / AUDIT ONLY\nFORMER SIX COMPATIBILITY EXCLUSIONS=ORDINARY STRICT\nCOMPATIBILITY WARN ESCAPE FOR FORMER SIX=REMOVED\n```\n'

def cap(args,cwd,check=True):
    p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding="utf-8",errors="replace")
    if check and p.returncode!=0:
        if p.stdout: print(p.stdout,end="")
        if p.stderr: print(p.stderr,end="")
        raise SystemExit("STOP: command failed: "+" ".join(args))
    return p.stdout or "",p.stderr or ""

def txt(args,cwd,check=True): return cap(args,cwd,check)[0]

def run(args,cwd):
    p=subprocess.run(args,cwd=cwd)
    if p.returncode!=0: raise SystemExit("STOP: command failed: "+" ".join(args))

def norm(s): return s.replace("\r\n","\n").replace("\r","\n")
def read(p): return norm(Path(p).read_text(encoding="utf-8-sig"))
def write(p,s):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(norm(s),encoding="utf-8",newline="\n")

def status_paths(repo):
    out,_=cap(["git","status","--porcelain","--untracked-files=all"],repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def diff_names(repo,cached=False):
    args=["git","diff"]
    if cached: args.append("--cached")
    args += ["--name-only","--"]
    out,_=cap(args,repo)
    return sorted({line.strip() for line in out.splitlines() if line.strip()})

def replace_once(text,old,new,label):
    n=text.count(old)
    if n!=1: raise SystemExit(f"STOP: {label} matched {n} times")
    return text.replace(old,new,1)

def replace_regex_once_literal(text,pattern,replacement,label,flags=0):
    rx=re.compile(pattern,flags)
    ms=list(rx.finditer(text))
    if len(ms)!=1: raise SystemExit(f"STOP: {label} matched {len(ms)} times")
    m=ms[0]
    return text[:m.start()] + replacement + text[m.end():]

def insert_before(text,anchor,block,label):
    if block.strip().splitlines()[0] in text:
        raise SystemExit(f"STOP: {label} already applied")
    return replace_once(text,anchor,block.rstrip()+"\n\n"+anchor,label)

def update_date(text):
    pat=re.compile(r"(?m)^Updated: \d{4}-\d{2}-\d{2}$")
    ms=list(pat.finditer(text))
    if len(ms)!=1: raise SystemExit(f"STOP: Updated date matched {len(ms)} times")
    m=ms[0]
    return text[:m.start()] + "Updated: 2026-09-12" + text[m.end():]

def update_global_headers(text,path):
    pairs=[
      (r"(?m)^Documentation/current-state implementation baseline: `main@[0-9a-f]{40}`$",f"Documentation/current-state implementation baseline: `main@{BASE}`"),
      (r"(?m)^Production deployed HEAD: `[0-9a-f]{40}`$",f"Production deployed HEAD: `{BASE}`"),
      (r"(?m)^Production tree: `[0-9a-f]{40}`$",f"Production tree: `{TREE}`"),
    ]
    for pat,repl in pairs:
        rx=re.compile(pat)
        ms=list(rx.finditer(text))
        if len(ms)!=1: raise SystemExit(f"STOP: {path} header matched {len(ms)} times: {pat}")
        m=ms[0]; text=text[:m.start()]+repl+text[m.end():]
    return text

def self_test():
    sample="""### Current verified full runner

OLD

### Gate-version anti-drift rule
"""
    repl="""### Current verified full runner

```text
C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd
```
"""
    got=replace_regex_once_literal(sample,r"### Current verified full runner\n[\s\S]*?(?=\n### Gate-version anti-drift rule)",repl.rstrip()+"\n","windows-path replacement",re.M)
    assert r"C:\CaptivPortal-Lab\lab-test-v7-strict.cmd" in got
    assert "OLD" not in got

    # Execute the exact remaining V1 stage against a synthetic baseline shape.
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        (root/"docs/agents").mkdir(parents=True)
        (root/"docs/tasks").mkdir(parents=True)
        testing=f"""# Testing

Status: current
Updated: 2026-09-12
Central Lab governance effective: 2026-08-27
Documentation/current-state implementation baseline: `main@043a13bc1e3aa3353e27af1859dc0bb698df4955`
Production deployed HEAD: `043a13bc1e3aa3353e27af1859dc0bb698df4955`
Production tree: `c2a9a01b2f8507c192fe2ef034ed4b9c850deed4`

### Current verified full runner

As of 2026-08-29, the verified current Windows Central Lab runner is:

```text
C:\\CaptivPortal-Lab\\lab-test-v6-fixed.cmd
```

V6 is current because the reviewed Windows compatibility model now includes the
known Home Health baseline case.

### Gate-version anti-drift rule

1. exact candidate;
2. exact approved baseline;
3. actual runner files;
4. reviewed runner;
5. runner strict/compatibility contract against the known compatibility baseline;
6. whether a new reviewed compatibility case exists;

```text
TEST RUNNER
+
REPOSITORY BASELINE
+
KNOWN COMPATIBILITY BASELINE
+
CURRENT TEST SET
```

### Latest Admin Web presentation acceptance — WEB-ASSET-LIBRARY-01 + FIX

old
"""
        write(root/"docs/testing.md",testing)
        write(root/"docs/agents/repository-actions.md","# Repository actions\n\nStatus: current\nUpdated: 2026-09-12\n\n- Central Lab full/V6 gate;\n")
        finish_remaining(root)
        after=read(root/"docs/testing.md")
        assert r"C:\CaptivPortal-Lab\lab-test-v7-strict.cmd" in after
        assert "V6 is current because" not in after
        assert "compatibility allowlist=EMPTY" in after
        assert (root/"docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md").exists()
        assert "current official full-regression gate (currently V7 strict)" in read(root/"docs/agents/repository-actions.md")
    print("SELF-TEST=PASS (literal Windows path + remaining-stage simulation)")

def finish_remaining(repo):
    # V1 crashed in this replacement before docs/testing.md was written.
    path="docs/testing.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    current_runner=f"""### Current verified full runner

As of 2026-09-12, the current Windows Central Lab full-regression runner is:

```text
C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd
SHA256={V7_SHA}
```

Canonical invocation:

```bat
call C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd C:\\CaptivPortal-UI-Preview
```

V7 contract:

```text
[1/4] ordinary full strict pytest
[2/4] compileall
[3/4] branch diff check
[4/4] exact-artifact immutability
```

The six former Windows compatibility exclusions are now ordinary strict tests:

```text
SQLite infinity edge
Node retry async timing
Visitor Registry long audit
Visitor Registry previous-ready
Visitor Registry previous-stopping
Home Health unavailable analytics baseline
```

Current handling for those six:

```text
compatibility allowlist=EMPTY
special --deselect path=NO
separate compatibility stage=NO
compatibility WARN counter/path=NO
strict failure degrades to WARN=NO
```

A failure in any of these cases is a normal strict regression failure.

Accepted TASK-TEST-BASELINE-CLEANUP-01 V7 evidence:

```text
3129 passed
30 skipped
0 failed
0 deselected
strict regressions=0
compileall=PASS
branch diff=PASS
exact-artifact immutability=PASS
```

The exact `3129 / 30` counts are evidence of that accepted run, not a permanent
hardcoded acceptance invariant. The durable invariant is that the former six
cases execute in the ordinary strict suite and cannot escape as compatibility
WARN.

Historical runner:

```text
C:\\CaptivPortal-Lab\\lab-test-v6-fixed.cmd
status=HISTORICAL / AUDIT ONLY
```

V6 is deliberately retained and not rewritten because it records the older
compatibility contract. It is no longer the current/default gate.
"""
    t=replace_regex_once_literal(t,r"### Current verified full runner\n[\s\S]*?(?=\n### Gate-version anti-drift rule)",current_runner.rstrip()+"\n",path+" current runner",re.M)
    t=replace_once(t,
        "5. runner strict/compatibility contract against the known compatibility baseline;\n6. whether a new reviewed compatibility case exists;",
        "5. runner strict/platform-exception contract against the current approved baseline;\n6. reviewed platform exception list (EMPTY for the former six compatibility cases);",
        path+" anti-drift list")
    t=replace_once(t,
        "KNOWN COMPATIBILITY BASELINE\n+\nCURRENT TEST SET",
        "REVIEWED PLATFORM EXCEPTIONS (if any)\n+\nCURRENT TEST SET",
        path+" anti-drift formula")
    latest=f"""### Latest Windows baseline cleanup acceptance — TASK-TEST-BASELINE-CLEANUP-01

Artifact identity:

```text
accepted baseline={ACCEPTED_BASE}
publication commit={PUB_COMMIT}
PR #116=MERGED
merge / production={BASE}
accepted / merged / production tree={TREE}
```

Current Windows gate:

```text
V7 strict=PASS
runner SHA256={V7_SHA}
former six compatibility exclusions=ordinary strict tests
compatibility allowlist for former six=EMPTY
WARN escape for former six=REMOVED
```

Accepted run evidence:

```text
3129 passed
30 skipped
0 failed
0 deselected
strict regressions=0
compileall=PASS
branch diff=PASS
exact-artifact immutability=PASS
```

Production acceptance:

```text
traffic-projection.service=active
Projection status=healthy
backlog=0
captive-portal.service=active
analytics.api_runtime_active
127.0.0.1:8088 LISTEN
HTTP readiness=400
```

Historical `Windows Central Full V6=PASS` entries below remain valid evidence for
the older TASKs that actually used V6; they do not define the current runner.
"""
    t=insert_before(t,"### Latest Admin Web presentation acceptance — WEB-ASSET-LIBRARY-01 + FIX\n",latest,path+" latest TASK")
    write(repo/path,t)

    path="docs/agents/repository-actions.md"
    t=update_date(read(repo/path))
    t=replace_once(t,"- Central Lab full/V6 gate;","- Central Lab current official full-regression gate (currently V7 strict);",path+" gate wording")
    write(repo/path,t)

    final=repo/"docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md"
    if final.exists(): raise SystemExit("STOP: FINAL file unexpectedly already exists")
    write(final,TASK_FINAL.rstrip()+"\n")

def assert_all(repo):
    required={
      "README.md":[f"Repository implementation checkpoint | `main@{BASE}`","Windows Central Lab | **V7 STRICT — CURRENT**","TASK-TEST-BASELINE-CLEANUP-01"],
      "README_RU.md":[f"Repository implementation checkpoint | `main@{BASE}`","Windows Central Lab | **V7 STRICT — CURRENT**"],
      "docs/README.md":[f"Current-state implementation baseline: `main@{BASE}`","TASK-TEST-BASELINE-CLEANUP-01-FINAL.md","current runner=C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd"],
      "docs/testing.md":[f"Documentation/current-state implementation baseline: `main@{BASE}`","lab-test-v7-strict.cmd","compatibility allowlist=EMPTY","strict failure degrades to WARN=NO","status=HISTORICAL / AUDIT ONLY","Latest Windows baseline cleanup acceptance"],
      "docs/testing-environments.md":["lab-test-v7-strict.cmd","V7 is the current full Windows strict gate","lab-test-v6-fixed.cmd"],
      "docs/deployment.md":[f"Confirmed production deployed HEAD: `{BASE}`","TASK-TEST-BASELINE-CLEANUP-01 production deployment","systemd active != HTTP readiness","urllib3 InsecureRequestWarning"],
      "docs/project-inventory.md":[f"Runtime commit: `{BASE}`","Windows test baseline / production closure"],
      "docs/modules/analytics.md":[f"Baseline: `main@{BASE}`","COALESCE((value - value) = 0, 0)"],
      "docs/modules/traffic.md":[f"Repository implementation baseline: `main@{BASE}`",f"Production deployed HEAD: `{BASE}`","platform-sensitive max-double check=REMOVED"],
      "docs/architecture.md":[f"Runtime implementation baseline: `main@{BASE}`","Analytics numeric portability invariant"],
      "docs/configuration.md":[f"Baseline: `main@{BASE}`","configuration changes=NO"],
      "docs/module-index.md":[f"Runtime implementation baseline: `main@{BASE}`",f"HEAD: {BASE}","TASK-TEST-BASELINE-CLEANUP-01: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS"],
      "docs/operations-command-lessons-learned.md":["systemd active != HTTP readiness","HTTP=000","same PID"],
      "docs/agents/repository-actions.md":["Central Lab current official full-regression gate (currently V7 strict)"],
      "docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md":["Status: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS",f"merge / current production HEAD={BASE}",f"SHA256={V7_SHA}","compatibility allowlist for former six=EMPTY"],
    }
    for path,needles in required.items():
        t=read(repo/path)
        for n in needles:
            if n not in t: raise SystemExit(f"STOP: missing assertion in {path}: {n}")
    t=read(repo/"docs/testing.md")
    for stale in ["As of 2026-08-29, the verified current Windows Central Lab runner is:","V6 is current because"]:
        if stale in t: raise SystemExit(f"STOP: stale current V6 wording remains: {stale}")
    for path in ["docs/deployment.md","docs/agents/repository-actions.md"]:
        if "full/V6" in read(repo/path): raise SystemExit(f"STOP: stale full/V6 current reference remains in {path}")

def stale_audit(repo):
    print("=== REPOSITORY-WIDE STALE-REFERENCE AUDIT ===")
    for title,term in [("V6 runner","lab-test-v6-fixed.cmd"),("V7 runner","lab-test-v7-strict.cmd"),("old PR114 production SHA",PREV_PROD)]:
        out,_=cap(["git","grep","-n",term,"--","docs","README.md","README_RU.md"],repo,check=False)
        print("---",title,"---")
        print(out.strip() or "(none)")
    print("Historical V6/old SHA references are allowed only as explicit dated/history evidence; current checkpoints are asserted separately.")

def main():
    self_test()
    repo=Path(os.environ.get("CAPTIVPORTAL_KB_REPO",str(Path(os.environ.get("USERPROFILE",str(Path.home())))/"Downloads"/"CaptivPortal-KB-Work")))
    print("Finish: TEST-BASELINE-CLEANUP KB from failed V1")
    print("=== PRECHECK ===")
    if not (repo/".git").exists(): raise SystemExit(f"STOP: repo missing: {repo}")
    run(["git","fetch","origin","main"],repo)
    remote=txt(["git","rev-parse","origin/main"],repo).strip(); tree=txt(["git","rev-parse","origin/main^{tree}"],repo).strip()
    branch=txt(["git","branch","--show-current"],repo).strip(); head=txt(["git","rev-parse","HEAD"],repo).strip()
    print("origin/main:",remote); print("origin tree:",tree); print("branch:",branch); print("HEAD:",head)
    if remote!=BASE or tree!=TREE: raise SystemExit("STOP: origin/main moved")
    if branch!=BRANCH or head!=BASE: raise SystemExit("STOP: not exact failed-V1 dedicated branch")
    if txt(["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo).strip(): raise SystemExit("STOP: remote publication branch already exists")
    dirty=status_paths(repo)
    print("Current failed-V1 files:"); [print(" ",p) for p in dirty]
    if dirty!=DIRTY12: raise SystemExit("STOP: dirty set is not exact failed-V1 state")
    if diff_names(repo,True): raise SystemExit("STOP: unexpected staged changes")
    print("PASS: exact failed-V1 state")

    print("=== FINISH REMAINING 3 DOCS ===")
    finish_remaining(repo)
    actual=status_paths(repo)
    if actual!=SCOPE:
        print("Actual:",*actual,sep="\n  "); print("Expected:",*SCOPE,sep="\n  ")
        raise SystemExit("STOP: final 15-file scope mismatch")
    assert_all(repo)
    run(["git","diff","--check"],repo)
    print("PASS: all canonical assertions")
    print("PASS: exact 15-file docs-only scope")
    print("PASS: git diff --check")
    stale_audit(repo)

    run(["git","add","--"]+SCOPE,repo)
    if diff_names(repo,False): raise SystemExit("STOP: unstaged changes remain")
    if diff_names(repo,True)!=SCOPE: raise SystemExit("STOP: staged scope mismatch")
    run(["git","diff","--cached","--check"],repo)
    print("PASS: exact staged scope")
    print("PASS: git diff --cached --check")

    patch=Path(__file__).resolve().parent/"CaptivPortal_KB_TEST_BASELINE_CLEANUP_2026-09-12.patch"
    with patch.open("wb") as fh:
        q=subprocess.run(["git","diff","--cached","--binary","--"]+SCOPE,cwd=repo,stdout=fh,stderr=subprocess.PIPE)
    if q.returncode!=0 or patch.stat().st_size==0: raise SystemExit("STOP: patch generation failed")

    print("=== COMMIT ===")
    run(["git","commit","-m","docs: close Windows compatibility baseline cleanup","-m","Canonicalize Windows Central Lab V7 strict, preserve V6 as historical evidence, document TASK-TEST-BASELINE-CLEANUP-01 production acceptance, and update current production identity."],repo)
    commit=txt(["git","rev-parse","HEAD"],repo).strip()
    if status_paths(repo): raise SystemExit("STOP: worktree not clean after commit")
    print("=== PUSH ==="); run(["git","push","-u","origin",BRANCH],repo)
    body=f"""## Purpose
Canonical KB synchronization after TASK-TEST-BASELINE-CLEANUP-01.

## Current truth
- current main / production HEAD: {BASE}
- current production tree: {TREE}
- TASK-TEST-BASELINE-CLEANUP-01: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS
- Windows Central Lab current runner: V7 strict
- V6 fixed: historical / audit only
- former six compatibility exclusions: ordinary strict regressions
- compatibility WARN escape for former six: removed

## Scope
- exactly 15 documentation files
- implementation/tests/runner/config changed by this docs PR: NO
- production changed by this docs PR: NO

Historical evidence is preserved. Draft only; merge remains Owner-controlled.
"""
    print("=== CREATE DRAFT PR ===")
    pr=txt(["gh","pr","create","--repo","ZaurNavi/CaptivePortal","--base","main","--head",BRANCH,"--title","Docs: close Windows compatibility baseline cleanup","--body",body,"--draft"],repo).strip()
    print("=== DONE ===")
    print("Branch:",BRANCH); print("Commit:",commit); print("Draft PR:",pr); print("Changed docs: 15"); print("Implementation/tests/runtime changed: NO"); print("Merge performed: NO"); print("Unified diff:",patch)

if __name__=="__main__": main()
