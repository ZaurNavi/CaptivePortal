# TASK-TEST-BASELINE-CLEANUP-01 KB — V2 FINISH FINAL

V1 failure classification: publisher harness defect.

Exact failure:
`re.sub()` parsed a Windows path in replacement text and raised
`re.error: bad escape \C`.

This finish does not reset or reapply the first 12 documents.

It requires the exact failed-V1 state:
- branch `docs/test-baseline-cleanup-kb-2026-09-12`
- HEAD `c1dc3344bc778a32cdc6b0edce278ee40b287c29`
- remote publication branch absent
- zero staged changes
- exactly the 12 documentation files already written by V1 are dirty

Then it performs only the unfinished stage:
1. updates `docs/testing.md`
2. updates `docs/agents/repository-actions.md`
3. creates `docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md`
4. verifies the complete 15-document scope
5. runs `git diff --check`
6. stages the exact 15 files
7. runs `git diff --cached --check`
8. commits and pushes
9. creates one Draft PR
10. merge/deploy remain NO

Defect prevention:
- regex block replacement uses literal string slicing, not replacement-template parsing
- `python -W error::SyntaxWarning -m py_compile` = PASS
- Windows-path helper self-test = PASS
- synthetic remaining-stage simulation = PASS
- remote target branch absence independently verified through GitHub connector

Publisher SHA256:
`a2162e05a75af359d36135663e30b66f041798e0921cabedd5767efd6ba60a9d`
