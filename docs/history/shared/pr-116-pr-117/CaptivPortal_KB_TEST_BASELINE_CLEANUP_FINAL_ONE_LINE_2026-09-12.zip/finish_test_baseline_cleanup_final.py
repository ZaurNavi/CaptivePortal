from __future__ import annotations
import os, subprocess
from pathlib import Path

BASE='c1dc3344bc778a32cdc6b0edce278ee40b287c29'
TREE='0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c'
BRANCH='docs/test-baseline-cleanup-kb-2026-09-12'
SCOPE=['README.md', 'README_RU.md', 'docs/README.md', 'docs/agents/repository-actions.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/analytics.md', 'docs/modules/traffic.md', 'docs/operations-command-lessons-learned.md', 'docs/project-inventory.md', 'docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md', 'docs/testing-environments.md', 'docs/testing.md']

def run_capture(args,cwd,check=True):
    p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                     encoding="utf-8",errors="replace")
    if check and p.returncode != 0:
        if p.stdout:
            print(p.stdout,end="")
        if p.stderr:
            print(p.stderr,end="")
        raise SystemExit("STOP: command failed: "+" ".join(args))
    return p.stdout or "", p.stderr or ""

def text(args,cwd,check=True):
    return run_capture(args,cwd,check)[0]

def run(args,cwd):
    p=subprocess.run(args,cwd=cwd)
    if p.returncode != 0:
        raise SystemExit("STOP: command failed: "+" ".join(args))

def status_paths(repo):
    out,_=run_capture(["git","status","--porcelain","--untracked-files=all"],repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def diff_names(repo,cached=False):
    args=["git","diff"]
    if cached:
        args.append("--cached")
    args += ["--name-only","--"]
    out,_=run_capture(args,repo)
    return sorted({line.strip() for line in out.splitlines() if line.strip()})

def main():
    repo=Path(os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) /
            "Downloads" / "CaptivPortal-KB-Work")
    ))

    print("Finish: TEST-BASELINE-CLEANUP KB publication — one-line repair")
    print("=== PRECHECK ===")

    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")

    branch=text(["git","branch","--show-current"],repo).strip()
    head=text(["git","rev-parse","HEAD"],repo).strip()
    print("branch:",branch)
    print("HEAD:",head)

    if branch != BRANCH:
        raise SystemExit("STOP: wrong branch")
    if head != BASE:
        raise SystemExit("STOP: branch HEAD moved")

    run(["git","fetch","origin","main"],repo)
    remote=text(["git","rev-parse","origin/main"],repo).strip()
    remote_tree=text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:",remote)
    print("origin tree:",remote_tree)

    if remote != BASE or remote_tree != TREE:
        raise SystemExit("STOP: origin/main moved")

    remote_branch=text(
        ["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo
    ).strip()
    if remote_branch:
        raise SystemExit("STOP: remote publication branch already exists")

    dirty=status_paths(repo)
    print("Prepared KB files:",len(dirty))
    for p in dirty:
        print(" ",p)

    if dirty != SCOPE:
        raise SystemExit("STOP: expected exact 15-file prepared KB state")
    if diff_names(repo,True):
        raise SystemExit("STOP: staged changes unexpectedly present")

    print("PASS: exact 15-file prepared state")

    print("=== ONE-LINE REPAIR ===")
    path=repo/"docs/deployment.md"
    content=path.read_text(encoding="utf-8-sig")

    old="Mandatory gates may include functional, targeted, full/V6, Linux compatibility,"
    new="Mandatory gates may include functional, targeted, the current official Central Lab full-regression gate, Linux compatibility,"

    count=content.count(old)
    print("stale deployment phrase matches:",count)
    if count != 1:
        raise SystemExit("STOP: expected exactly one stale deployment phrase")

    content=content.replace(old,new,1)
    path.write_text(content,encoding="utf-8",newline="\n")

    if old in path.read_text(encoding="utf-8"):
        raise SystemExit("STOP: deployment phrase replacement failed")

    print("PASS: docs/deployment.md repaired")

    print("=== FINAL GATES ===")
    testing=(repo/"docs/testing.md").read_text(encoding="utf-8-sig")
    for needle in [
        r"C:\CaptivPortal-Lab\lab-test-v7-strict.cmd",
        "compatibility allowlist=EMPTY",
        "status=HISTORICAL / AUDIT ONLY",
    ]:
        if needle not in testing:
            raise SystemExit("STOP: testing assertion missing: "+needle)

    final_task=(repo/"docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md").read_text(encoding="utf-8-sig")
    for needle in [
        "Status: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS",
        "PR #116=MERGED",
        "FORMER SIX COMPATIBILITY EXCLUSIONS=ORDINARY STRICT",
    ]:
        if needle not in final_task:
            raise SystemExit("STOP: FINAL TASK assertion missing: "+needle)

    if status_paths(repo) != SCOPE:
        raise SystemExit("STOP: file scope changed unexpectedly")

    run(["git","diff","--check"],repo)
    print("PASS: content assertions")
    print("PASS: exact 15-file scope")
    print("PASS: git diff --check")

    print("=== COMMIT ===")
    run(["git","add","--"]+SCOPE,repo)
    if diff_names(repo,False):
        raise SystemExit("STOP: unstaged changes remain")
    if diff_names(repo,True) != SCOPE:
        raise SystemExit("STOP: staged scope mismatch")
    run(["git","diff","--cached","--check"],repo)
    print("PASS: git diff --cached --check")

    run([
        "git","commit",
        "-m","docs: close Windows compatibility baseline cleanup",
        "-m","Canonicalize Windows Central Lab V7 strict, preserve V6 as historical evidence, document TASK-TEST-BASELINE-CLEANUP-01 production acceptance, and update current production identity."
    ],repo)

    commit=text(["git","rev-parse","HEAD"],repo).strip()

    if status_paths(repo):
        raise SystemExit("STOP: worktree not clean after commit")

    print("=== PUSH ===")
    run(["git","push","-u","origin",BRANCH],repo)

    print("=== DRAFT PR ===")
    body=f"""## Purpose

Canonical KB synchronization after TASK-TEST-BASELINE-CLEANUP-01.

## Current truth

- current main / production HEAD: {BASE}
- current production tree: {TREE}
- TASK-TEST-BASELINE-CLEANUP-01: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS
- Windows Central Lab current runner: V7 strict
- V6 fixed: historical / audit only
- former six Windows compatibility exclusions: ordinary strict regressions
- compatibility WARN escape for former six: removed

## Scope

- exactly 15 documentation files
- implementation changed by this docs PR: NO
- tests changed by this docs PR: NO
- V7 runner changed: NO
- V6 runner changed: NO
- runtime/config changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""

    pr=text([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main",
        "--head",BRANCH,
        "--title","Docs: close Windows compatibility baseline cleanup",
        "--body",body,
        "--draft"
    ],repo).strip()

    print("=== DONE ===")
    print("Commit:",commit)
    print("Draft PR:",pr)
    print("Changed docs: 15")
    print("Implementation/tests/runtime changed: NO")
    print("MERGE=NO")
    print("DEPLOY=NO")

if __name__=="__main__":
    main()
