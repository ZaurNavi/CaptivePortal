# CaptivPortal KB sync — TASK-TEST-BASELINE-CLEANUP-01

Date: 2026-09-12

## Live GitHub identity verified

```text
main=c1dc3344bc778a32cdc6b0edce278ee40b287c29
tree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c
PR #116 merged=true
publication head=ef3e8ca20e2303c29437c6c087919a6715afac96
accepted baseline=75df5af1500ebcaf7d4950abccbaabc0a03610e1
```

## Current contract after synchronization

```text
TASK-TEST-BASELINE-CLEANUP-01=FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS
Windows Central Lab current runner=V7 strict
V7 SHA256=45d3b37150a2c3b3d3e95460b2a1c6cab8d97aa333c3d3e0cd3507ef1c994f77
V6 fixed=historical / audit only
former six compatibility exclusions=ordinary strict regressions
compatibility allowlist for former six=EMPTY
compatibility WARN escape for former six=REMOVED
```

## Exact docs scope

- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/agents/repository-actions.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/analytics.md`
- `docs/modules/traffic.md`
- `docs/operations-command-lessons-learned.md`
- `docs/project-inventory.md`
- `docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md`
- `docs/testing-environments.md`
- `docs/testing.md`

No implementation/test/runner/config/deploy changes are made by this KB publisher.

## Historical evidence policy

Historical TASK/FINAL and old acceptance records are not blanket-rewritten.
Old V6 and old production SHA references are retained where they are explicitly
dated historical evidence. Current headers/checkpoints are separately asserted
against `c1dc3344bc778a32cdc6b0edce278ee40b287c29` / `0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c`.

## Publisher validation performed before delivery

```text
Python compile=PASS
embedded self-test=PASS
critical regex uniqueness test=PASS
static required-symbol audit=PASS
remote target branch absent=verified via GitHub
```

Publisher SHA256:

`503381ddda30433ba20792eeaa72b27cf8f00ccc9109d311aca5281f79091065`
