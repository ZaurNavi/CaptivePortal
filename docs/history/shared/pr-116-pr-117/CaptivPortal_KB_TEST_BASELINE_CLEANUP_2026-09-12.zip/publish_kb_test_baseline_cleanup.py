from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
from pathlib import Path

P = json.loads('{"base": "c1dc3344bc778a32cdc6b0edce278ee40b287c29", "tree": "0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c", "prev_prod": "043a13bc1e3aa3353e27af1859dc0bb698df4955", "branch": "docs/test-baseline-cleanup-kb-2026-09-12", "date": "2026-09-12", "scope": ["README.md", "README_RU.md", "docs/README.md", "docs/agents/repository-actions.md", "docs/architecture.md", "docs/configuration.md", "docs/deployment.md", "docs/module-index.md", "docs/modules/analytics.md", "docs/modules/traffic.md", "docs/operations-command-lessons-learned.md", "docs/project-inventory.md", "docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md", "docs/testing-environments.md", "docs/testing.md"], "task_final": "# TASK-TEST-BASELINE-CLEANUP-01 — Windows Compatibility Debt Removal — FINAL\\n\\nStatus: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS\\nUpdated: 2026-09-12\\n\\n## Final identity\\n\\n```text\\nTASK=TASK-TEST-BASELINE-CLEANUP-01\\nPR=#116\\nPR title=TASK-TEST-BASELINE-CLEANUP-01: remove Windows compatibility debt\\npublication branch=feature/test-baseline-cleanup-01\\npublication commit=ef3e8ca20e2303c29437c6c087919a6715afac96\\npublication parent / accepted baseline=75df5af1500ebcaf7d4950abccbaabc0a03610e1\\nmerge / current production HEAD=c1dc3344bc778a32cdc6b0edce278ee40b287c29\\naccepted / merged / production tree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\\n```\\n\\nCritical identity invariant:\\n\\n```text\\naccepted candidate tree\\n=\\npublication commit tree\\n=\\nmerge commit tree\\n=\\nproduction tree\\n=\\n0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\\n```\\n\\n## Implementation scope\\n\\nExactly four implementation/test files changed:\\n\\n```text\\napp/analytics/source_gateway.py\\ntests/analytics/test_historical_traffic.py\\ntests/test_auth_retry_frontend.py\\ntests/visitor_registry/test_device_registry_worker.py\\n```\\n\\nFinal diff:\\n\\n```text\\n4 files changed\\n30 insertions\\n16 deletions\\nNO EXTRAS\\n```\\n\\nOnly `app/analytics/source_gateway.py` is production runtime code.\\n\\n## SQLite finite/nonnegative portability\\n\\nThe platform-sensitive max-double comparison was removed.\\n\\nCanonical fail-closed SQL shape:\\n\\n```text\\ntypeof(value) IN (\'integer\',\'real\')\\nAND value >= 0\\nAND COALESCE((value - value) = 0, 0)\\n```\\n\\nFinite numeric values satisfy `value - value = 0`.\\n\\nInfinity produces non-finite/NULL semantics through self-subtraction and fails\\nthe predicate closed.\\n\\nThis applies to current and historical Analytics read paths.\\n\\nHistorical regression evidence now includes `float(\\"inf\\")`.\\n\\n## Node retry tests\\n\\nProduction JavaScript was not changed.\\n\\nThe test harness no longer assumes the production click handler returns a\\nPromise. Tests invoke the listener and separately drain asynchronous work using\\n`setImmediate`.\\n\\n```text\\nproduction JavaScript change=NO\\ntest synchronization change=YES\\n```\\n\\n## Visitor Registry timing tests\\n\\nProduction Visitor Registry runtime was not changed.\\n\\nThe test helper now accepts a parametrized `scan_interval_seconds`. The three\\ntiming/background cases use a test-only 5.0 second interval so a second scan\\ncannot begin before stop.\\n\\n```text\\nproduction Visitor Registry change=NO\\ntest timing synchronization change=YES\\n```\\n\\n## Home Health\\n\\nProduction Home Health implementation was not changed.\\n\\nThe previously known Windows compatibility case is now an ordinary strict\\nregression test.\\n\\n## Windows compatibility debt closure\\n\\nBefore this TASK, Windows Central Lab V6 had six special compatibility cases:\\n\\n```text\\n1. SQLite infinity edge\\n2. Node retry async timing\\n3. Visitor Registry long audit\\n4. Visitor Registry previous-ready\\n5. Visitor Registry previous-stopping\\n6. Home Health unavailable analytics baseline\\n```\\n\\nThat is historical V6 evidence only.\\n\\nCurrent contract:\\n\\n```text\\nformer six compatibility cases=ordinary strict regression tests\\ncompatibility allowlist for former six=EMPTY\\nsix-case --deselect path=REMOVED\\nseparate six-case compatibility stage=REMOVED\\nsix-case compatibility WARN escape=REMOVED\\n```\\n\\nA failure in any of these cases is a normal strict regression failure.\\n\\n## Windows Central Lab V7\\n\\nCurrent canonical Windows full-regression runner:\\n\\n```text\\nC:\\\\CaptivPortal-Lab\\\\lab-test-v7-strict.cmd\\nSHA256=45d3b37150a2c3b3d3e95460b2a1c6cab8d97aa333c3d3e0cd3507ef1c994f77\\n```\\n\\nV7 stages:\\n\\n```text\\n[1/4] ordinary full strict pytest\\n[2/4] compileall\\n[3/4] branch diff check\\n[4/4] exact-artifact immutability\\n```\\n\\nAccepted run evidence:\\n\\n```text\\n3129 passed\\n30 skipped\\n0 failed\\n0 deselected\\nstrict regressions=0\\ncompileall=PASS\\nbranch diff=PASS\\nexact-artifact immutability=PASS\\n```\\n\\n`3129 passed / 30 skipped` is evidence from this accepted run, not a permanent\\nhardcoded test-count invariant.\\n\\nPermanent invariant:\\n\\n```text\\nformer six compatibility cases execute as ordinary strict tests\\nand cannot degrade to WARN\\n```\\n\\nV6 runner:\\n\\n```text\\nC:\\\\CaptivPortal-Lab\\\\lab-test-v6-fixed.cmd\\nstatus=HISTORICAL / AUDIT ONLY\\n```\\n\\nV6 was not deleted or rewritten.\\n\\n## Production deployment\\n\\nPrevious production:\\n\\n```text\\nHEAD=043a13bc1e3aa3353e27af1859dc0bb698df4955\\n```\\n\\nMerged target:\\n\\n```text\\nHEAD=c1dc3344bc778a32cdc6b0edce278ee40b287c29\\ntree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\\n```\\n\\nProduction `/opt/CaptivePortal` was updated FROM GIT using exact detached\\nartifact identity.\\n\\nPost-deploy:\\n\\n```text\\nHEAD=c1dc3344bc778a32cdc6b0edce278ee40b287c29\\ntree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\\nworktree=CLEAN\\n```\\n\\nBecause `app/analytics/source_gateway.py` is runtime code and is also imported by\\nthe Traffic Projection source path, production activation restarted:\\n\\n```text\\ntraffic-projection.service\\ncaptive-portal.service\\n```\\n\\nNot required for this delivery:\\n\\n```text\\nDB migration=NO\\nschema change=NO\\nconfiguration change=NO\\nfeature flag change=NO\\nsystemd unit change=NO\\ndaemon-reload=NO\\n```\\n\\n## Production acceptance\\n\\nTraffic Projection:\\n\\n```text\\ntraffic-projection.service=active\\nartifact_sha=c1dc3344bc778a32cdc6b0edce278ee40b287c29\\nartifact_tree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\\nprojection_version=historical_traffic_projection.v1\\nstatus=healthy\\nbacklog_cycle_count=0\\n```\\n\\nCaptive Portal:\\n\\n```text\\ncaptive-portal.service=active\\nartifact_sha=c1dc3344bc778a32cdc6b0edce278ee40b287c29\\nartifact_tree=0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c\\nanalytics startup=analytics.api_runtime_active\\nserver=127.0.0.1:8088 / debug=False\\nlistener=127.0.0.1:8088 LISTEN\\nHTTP readiness=400\\n```\\n\\nHTTP `400` on `/` without required Omada request parameters is the expected\\nproduction readiness contract.\\n\\nObservation continued successful cycles after restart. Admin Current State reads\\nexecuted after startup. No startup traceback or critical failure attributable to\\nthis delivery was observed.\\n\\n## Startup observation\\n\\nThe first readiness probe was early:\\n\\n```text\\nsystemd state=active\\nlistener=absent\\nHTTP=000\\n```\\n\\nThe same PID then continued normal startup composition and reached:\\n\\n```text\\nanalytics.api_runtime_active\\nStarting server on 127.0.0.1:8088\\nLISTEN\\nHTTP=400\\n```\\n\\nThis is not a TASK regression.\\n\\nPermanent operational rule:\\n\\n```text\\nsystemd active != HTTP readiness\\n```\\n\\nAfter restart, wait for actual listener/readiness evidence. Do not issue a second\\nrestart solely because systemd is already active while the HTTP listener has not\\nyet appeared if the same process is still making normal startup progress.\\n\\n## Existing warning\\n\\nProduction logs contain `urllib3 InsecureRequestWarning` for HTTPS access to the\\nOmada Controller at `192.168.0.222`.\\n\\nThis warning pre-dates TASK-TEST-BASELINE-CLEANUP-01 and is not a regression of\\nthis delivery.\\n\\n## Final verdict\\n\\n```text\\nTASK-TEST-BASELINE-CLEANUP-01=FINAL ACCEPTED\\nPR #116=MERGED\\nPRODUCTION DEPLOY=PASS\\nPRODUCTION ACCEPTANCE=PASS\\nCURRENT WINDOWS FULL RUNNER=V7 STRICT\\nV6=HISTORICAL / AUDIT ONLY\\nFORMER SIX COMPATIBILITY EXCLUSIONS=ORDINARY STRICT\\nCOMPATIBILITY WARN ESCAPE FOR FORMER SIX=REMOVED\\n```\\n", "pr": 116, "pub_commit": "ef3e8ca20e2303c29437c6c087919a6715afac96", "accepted_base": "75df5af1500ebcaf7d4950abccbaabc0a03610e1", "v7_sha": "45d3b37150a2c3b3d3e95460b2a1c6cab8d97aa333c3d3e0cd3507ef1c994f77"}')
BASE=P["base"]
TREE=P["tree"]
PREV_PROD=P["prev_prod"]
BRANCH=P["branch"]
DATE=P["date"]
SCOPE=sorted(P["scope"])
TASK_FINAL=P["task_final"]
PR=P["pr"]
PUB_COMMIT=P["pub_commit"]
ACCEPTED_BASE=P["accepted_base"]
V7_SHA=P["v7_sha"]

def cap(args,cwd,check=True):
    q=subprocess.run(
        args,cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and q.returncode != 0:
        if q.stdout:
            print(q.stdout,end="")
        if q.stderr:
            print(q.stderr,end="")
        raise SystemExit("STOP: command failed: "+" ".join(args))
    return q.stdout or "", q.stderr or ""

def txt(args,cwd,check=True):
    return cap(args,cwd,check)[0]

def run(args,cwd):
    q=subprocess.run(args,cwd=cwd)
    if q.returncode != 0:
        raise SystemExit("STOP: command failed: "+" ".join(args))

def norm(s):
    return s.replace("\r\n","\n").replace("\r","\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def write(path,text):
    path=Path(path)
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(norm(text),encoding="utf-8",newline="\n")

def status_paths(repo):
    out,_=cap(["git","status","--porcelain","--untracked-files=all"],repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def diff_names(repo,cached=False):
    args=["git","diff"]
    if cached:
        args.append("--cached")
    args += ["--name-only","--"]
    out,_=cap(args,repo)
    return sorted({line.strip() for line in out.splitlines() if line.strip()})

def replace_once(text,old,new,label):
    count=text.count(old)
    if count != 1:
        raise SystemExit(f"STOP: {label} matched {count} times")
    return text.replace(old,new,1)

def regex_once(text,pattern,repl,label,flags=0):
    rx=re.compile(pattern,flags)
    matches=list(rx.finditer(text))
    if len(matches) != 1:
        raise SystemExit(f"STOP: {label} matched {len(matches)} times")
    return rx.sub(repl,text,count=1)

def insert_before(text,anchor,block,label):
    first=block.strip().splitlines()[0]
    if first in text:
        raise SystemExit(f"STOP: {label} already applied")
    return replace_once(text,anchor,block.rstrip()+"\n\n"+anchor,label)

def update_date(text):
    if re.search(r"(?m)^Updated: \d{4}-\d{2}-\d{2}$",text):
        return re.sub(r"(?m)^Updated: \d{4}-\d{2}-\d{2}$",f"Updated: {DATE}",text,count=1)
    return text

def update_table_identity(text,label,value,path):
    pattern=rf"(?m)^\| {re.escape(label)} \| .* \|$"
    if not re.search(pattern,text):
        raise SystemExit(f"STOP: {path}: missing table identity {label}")
    return re.sub(pattern,f"| {label} | `{value}` |",text,count=1)

def update_global_headers(text,path):
    rules=[
        (r"(?m)^Current-state implementation baseline: `main@[0-9a-f]{40}`$",
         f"Current-state implementation baseline: `main@{BASE}`"),
        (r"(?m)^Current implementation tree: `[0-9a-f]{40}`$",
         f"Current implementation tree: `{TREE}`"),
        (r"(?m)^Runtime implementation baseline: `main@[0-9a-f]{40}`$",
         f"Runtime implementation baseline: `main@{BASE}`"),
        (r"(?m)^Runtime tree: `[0-9a-f]{40}`$",
         f"Runtime tree: `{TREE}`"),
        (r"(?m)^Current repository implementation baseline: `main@[0-9a-f]{40}`$",
         f"Current repository implementation baseline: `main@{BASE}`"),
        (r"(?m)^Confirmed production deployed HEAD: `[0-9a-f]{40}`$",
         f"Confirmed production deployed HEAD: `{BASE}`"),
        (r"(?m)^Confirmed production tree: `[0-9a-f]{40}`$",
         f"Confirmed production tree: `{TREE}`"),
        (r"(?m)^Documentation/current-state implementation baseline: `main@[0-9a-f]{40}`$",
         f"Documentation/current-state implementation baseline: `main@{BASE}`"),
        (r"(?m)^Production deployed HEAD: `[0-9a-f]{40}`$",
         f"Production deployed HEAD: `{BASE}`"),
        (r"(?m)^Production tree: `[0-9a-f]{40}`$",
         f"Production tree: `{TREE}`"),
        (r"(?m)^Repository implementation baseline: `main@[0-9a-f]{40}`$",
         f"Repository implementation baseline: `main@{BASE}`"),
        (r"(?m)^Repository tree: `[0-9a-f]{40}`$",
         f"Repository tree: `{TREE}`"),
        (r"(?m)^Baseline: `main@[0-9a-f]{40}`$",
         f"Baseline: `main@{BASE}`"),
    ]
    for pattern,repl in rules:
        if re.search(pattern,text):
            text=regex_once(text,pattern,repl,f"{path}: global header")
    return text

def transform(repo):
    # README EN
    path="README.md"
    t=read(repo/path)
    for label,value in [
        ("Repository implementation checkpoint",f"main@{BASE}"),
        ("Repository tree",TREE),
        ("Production deployed HEAD",BASE),
        ("Production tree",TREE),
    ]:
        t=update_table_identity(t,label,value,path)
    row="| DB baseline gate | `TASK-DB-BASELINE-SYNC-01` — **CLOSED / PASS** |"
    t=replace_once(
        t,row,
        row+"\n| Windows Central Lab | **V7 STRICT — CURRENT**; V6 historical/audit only |\n"
            "| Windows compatibility cleanup | `TASK-TEST-BASELINE-CLEANUP-01` — **FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS** |",
        path+" status rows"
    )
    # Current asset is still active on later runtime.
    t=t.replace(f"production HEAD={PREV_PROD}\nproduction tree=c2a9a01b2f8507c192fe2ef034ed4b9c850deed4",
                f"current production HEAD={BASE}\ncurrent production tree={TREE}",1)
    block=f"""## Windows strict baseline cleanup

`TASK-TEST-BASELINE-CLEANUP-01` is production-accepted.

```text
PR #116=MERGED
current production HEAD={BASE}
current production tree={TREE}
Windows Central Lab current runner=V7 strict
V6=historical / audit only
former six Windows compatibility exclusions=ordinary strict tests
compatibility WARN escape for former six=removed
```

The accepted V7 run recorded `3129 passed / 30 skipped / 0 failed / 0 deselected`.
Those exact counts are evidence for that run, not a permanent hardcoded gate
invariant.
"""
    t=insert_before(t,"## Traffic Projection lifecycle P0 — closed\n",block,path+" V7 section")
    write(repo/path,t)

    # README RU
    path="README_RU.md"
    t=read(repo/path)
    for label,value in [
        ("Repository implementation checkpoint",f"main@{BASE}"),
        ("Repository tree",TREE),
        ("Production deployed HEAD",BASE),
        ("Production tree",TREE),
    ]:
        t=update_table_identity(t,label,value,path)
    row="| DB baseline gate | `TASK-DB-BASELINE-SYNC-01` — **CLOSED / PASS** |"
    t=replace_once(
        t,row,
        row+"\n| Windows Central Lab | **V7 STRICT — CURRENT**; V6 historical/audit only |\n"
            "| Windows compatibility cleanup | `TASK-TEST-BASELINE-CLEANUP-01` — **FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS** |",
        path+" status rows"
    )
    t=t.replace(f"production HEAD={PREV_PROD}\nproduction tree=c2a9a01b2f8507c192fe2ef034ed4b9c850deed4",
                f"current production HEAD={BASE}\ncurrent production tree={TREE}",1)
    block=f"""## Windows strict baseline cleanup

`TASK-TEST-BASELINE-CLEANUP-01` принят и находится в production.

```text
PR #116=MERGED
current production HEAD={BASE}
current production tree={TREE}
Windows Central Lab current runner=V7 strict
V6=historical / audit only
former six Windows compatibility exclusions=ordinary strict tests
compatibility WARN escape for former six=removed
```

Accepted V7 run дал `3129 passed / 30 skipped / 0 failed / 0 deselected`.
Это evidence конкретного принятого прогона, а не вечный hardcoded test-count
invariant.
"""
    t=insert_before(t,"## Traffic Projection lifecycle P0 — закрыт\n",block,path+" V7 section")
    write(repo/path,t)

    # docs/README
    path="docs/README.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    t=re.sub(
        r"Current Traffic state at implementation baseline `main@[0-9a-f]{40}`:",
        f"Current Traffic state at implementation baseline `main@{BASE}`:",
        t,count=1
    )
    # Current runtime checkpoint under Device Card.
    t=re.sub(
        r"Current implementation / production baseline:\n\n```text\nmain = [0-9a-f]{40}\ntree = [0-9a-f]{40}\n```",
        f"Current implementation / production checkpoint:\n\n```text\nmain = {BASE}\ntree = {TREE}\n```",
        t,count=1
    )
    t=t.replace(
        f"production HEAD={PREV_PROD}\nproduction tree=c2a9a01b2f8507c192fe2ef034ed4b9c850deed4",
        f"current production HEAD={BASE}\ncurrent production tree={TREE}",1
    )
    maprow="| WEB-ASSET-LIBRARY-01 Android FIX closure | `tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md` |"
    t=replace_once(
        t,maprow,
        maprow+"\n| Windows compatibility baseline cleanup | `tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md` |",
        path+" knowledge map"
    )
    block=f"""## Current Windows full-regression contract

```text
current runner=C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd
runner SHA256={V7_SHA}
V6 fixed=historical / audit only
former six compatibility exclusions=ordinary strict regressions
compatibility allowlist for former six=EMPTY
WARN escape for former six=REMOVED
```

Canonical closure:
`tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md`.
"""
    t=insert_before(t,"## Traffic Projection lifecycle P0 closure\n",block,path+" current runner")
    write(repo/path,t)

    # architecture
    path="docs/architecture.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    block="""### Analytics numeric portability invariant

Analytics source validation for current and historical rate evidence must be
portable across supported SQLite/Windows/Linux environments and fail closed for
non-finite values.

Canonical finite/nonnegative shape:

```text
typeof(value) IN ('integer','real')
AND value >= 0
AND COALESCE((value - value) = 0, 0)
```

Do not reintroduce a platform-sensitive max-double literal as the finite-value
authority.
"""
    t=insert_before(t,"## 7. Traffic analytics\n",block,path+" finite invariant")
    write(repo/path,t)

    # configuration: only current repository identity changed; TASK added no config.
    path="docs/configuration.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    block="""### TASK-TEST-BASELINE-CLEANUP-01

This production delivery changed no configuration contract:

```text
configuration changes=NO
feature flag changes=NO
systemd unit changes=NO
DB/schema changes=NO
```
"""
    t=insert_before(t,"### Pending Session Cleaner\n",block,path+" task no-config")
    write(repo/path,t)

    # deployment
    path="docs/deployment.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    t=t.replace("Central Lab full/V6 gate;","Central Lab current official full-regression gate (V7 strict);",1)
    dep=f"""## TASK-TEST-BASELINE-CLEANUP-01 production deployment — 2026-09-12

```text
PR #116=MERGED
publication={PUB_COMMIT}
accepted baseline={ACCEPTED_BASE}
merge / production HEAD={BASE}
accepted / merged / production tree={TREE}
previous production={PREV_PROD}
production worktree=CLEAN
```

The accepted tree identity was preserved across candidate, publication, merge
and production.

This TASK was not fully test-only: `app/analytics/source_gateway.py` changed and
is used by CaptivPortal Analytics and the Traffic Projection source path.

Activation therefore restarted:

```text
traffic-projection.service
captive-portal.service
```

Not required:

```text
DB migration=NO
schema change=NO
configuration change=NO
feature flag change=NO
systemd unit change=NO
daemon-reload=NO
```

Production acceptance:

```text
traffic-projection.service=active
traffic projection artifact_sha={BASE}
traffic projection artifact_tree={TREE}
projection status=healthy
backlog_cycle_count=0

captive-portal.service=active
captive portal artifact_sha={BASE}
captive portal artifact_tree={TREE}
analytics.api_runtime_active=observed
127.0.0.1:8088=LISTEN
HTTP readiness=400
```

HTTP `400` on `/` without Omada request parameters is expected readiness
behavior.

Startup lesson:

```text
systemd active != HTTP readiness
```

The first probe may see `HTTP 000` while the same PID is still progressing
through normal startup composition. Do not perform a second restart solely
because the listener has not appeared yet; first check startup progress and wait
for bounded listener/readiness evidence.

Existing `urllib3 InsecureRequestWarning` messages for Omada HTTPS
`192.168.0.222` pre-date this deployment and are not a regression of this TASK.
"""
    t=insert_before(t,"## Feature activation\n",dep,path+" task deploy")
    write(repo/path,t)

    # module index
    path="docs/module-index.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    t=re.sub(
        r"Owner-provided production checkpoint \d{4}-\d{2}-\d{2}:",
        "Owner-provided production checkpoint 2026-09-12:",
        t,count=1
    )
    t=re.sub(
        r"HEAD: [0-9a-f]{40}\ntree: [0-9a-f]{40}",
        f"HEAD: {BASE}\ntree: {TREE}",
        t,count=1
    )
    status_line="TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION: CLOSED / PRODUCTION PASS"
    t=replace_once(
        t,status_line,
        status_line+"\nTASK-TEST-BASELINE-CLEANUP-01: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS\n"
                    "Windows Central Lab current runner: V7 strict\n"
                    "Windows Central Lab V6 fixed: historical / audit only",
        path+" current status"
    )
    if "traffic-projection.service=active" not in t:
        t=t.replace("captive-portal.service=active\n",
                    "captive-portal.service=active\ntraffic-projection.service=active\n",1)
    write(repo/path,t)

    # analytics module
    path="docs/modules/analytics.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    block="""## SQLite finite/nonnegative portability

`TASK-TEST-BASELINE-CLEANUP-01` removed the platform-sensitive max-double SQL
check from `AnalyticsSourceGateway`.

Current and historical rate validation use the same fail-closed portable shape:

```text
typeof(value) IN ('integer','real')
AND value >= 0
AND COALESCE((value - value) = 0, 0)
```

Finite values pass. Infinity/non-finite evidence fails closed.

This is a read-validation portability rule only; Analytics remains read-only and
does not add source writes, migrations or query-time Omada access.
"""
    t=insert_before(t,"## Services\n",block,path+" portable finite")
    write(repo/path,t)

    # Traffic module: shared source gateway changed, product semantics unchanged.
    path="docs/modules/traffic.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    note="""## Windows portability closure in shared Analytics source validation

`TASK-TEST-BASELINE-CLEANUP-01` updated the shared
`AnalyticsSourceGateway` finite/nonnegative validation used by current and
historical Analytics reads.

```text
platform-sensitive max-double check=REMOVED
portable fail-closed finite/nonnegative predicate=ACTIVE
Historical Traffic product semantics=UNCHANGED
```

The TASK does not create a new Traffic product, source, projection or metric.
"""
    t=insert_before(t,"## Current roadmap state\n",note,path+" source gateway note")
    write(repo/path,t)

    # operations lessons: replace the existing readiness section as one bounded unit.
    path="docs/operations-command-lessons-learned.md"
    t=update_date(read(repo/path))
    readiness="""## 3. Service readiness after restart

After:

```text
systemctl restart captive-portal.service
```

`active/running` proves process state, not immediate HTTP readiness.

Permanent invariant:

```text
systemd active != HTTP readiness
```

Port `127.0.0.1:8088` may become ready after systemd already reports the service
active.

During the 2026-09-12 production acceptance, the first probe saw:

```text
systemd=active
listener=absent
HTTP=000
```

The same PID then continued normal startup composition and reached:

```text
analytics.api_runtime_active
127.0.0.1:8088 LISTEN
HTTP=400
```

No second restart was required.

Use a bounded readiness loop with listener/startup-progress evidence and multiple
HTTP attempts. Do not classify one early `HTTP 000` as a product failure, and do
not restart again solely because the listener is not yet present while the same
process is still progressing normally.

HTTP `400` on `/` without required Omada request parameters is expected
CaptivPortal readiness behavior.
"""
    t=regex_once(
        t,
        r"## 3\. Service readiness after restart\n[\s\S]*?(?=\n## 4\. Git status and identity checks)",
        readiness.rstrip()+"\n",
        path+" readiness section",
        flags=re.M
    )
    write(repo/path,t)

    # project inventory
    path="docs/project-inventory.md"
    t=update_date(read(repo/path))
    t=regex_once(t,r"(?m)^Runtime commit: `[0-9a-f]{40}`$",f"Runtime commit: `{BASE}`",path+" runtime commit")
    t=regex_once(t,r"(?m)^Runtime tree: `[0-9a-f]{40}`$",f"Runtime tree: `{TREE}`",path+" runtime tree")
    t=regex_once(
        t,r"(?m)^Commit source: .*$",
        "Commit source: merge PR #116 / Windows compatibility debt removal, 2026-09-12",
        path+" commit source"
    )
    # Current asset block follows current runtime, not the historical PR #114 deployment identity.
    t=t.replace(
        f"production HEAD={PREV_PROD}\nproduction tree=c2a9a01b2f8507c192fe2ef034ed4b9c850deed4",
        f"current production HEAD={BASE}\ncurrent production tree={TREE}",1
    )
    block=f"""## Windows test baseline / production closure

```text
TASK-TEST-BASELINE-CLEANUP-01=FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS
PR #116=MERGED
current production HEAD={BASE}
current production tree={TREE}
Windows Central Lab current runner=V7 strict
V6 fixed=historical / audit only
former six compatibility exclusions=ordinary strict regressions
```

Runtime change is limited to Analytics source validation portability.
Node retry and Visitor Registry changes in PR #116 are test-harness/timing
changes only; Home Health production implementation is unchanged.
"""
    t=insert_before(t,"## 13. Admin security facts\n",block,path+" test baseline closure")
    write(repo/path,t)

    # testing environments
    path="docs/testing-environments.md"
    t=update_date(read(repo/path))
    block=f"""### Current Windows full-regression runner

```text
C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd
SHA256={V7_SHA}
status=CURRENT
```

V7 is the current full Windows strict gate.

```text
former six compatibility exclusions=ordinary strict regression tests
compatibility allowlist for former six=EMPTY
separate six-case compatibility stage=NO
WARN escape for former six=NO
```

`lab-test-v6-fixed.cmd` is retained as historical/audit evidence and must not be
used as the current canonical full-regression runner.

The exact `3129 passed / 30 skipped` result belongs to the accepted
TASK-TEST-BASELINE-CLEANUP-01 run; exact test counts are not permanent gate
invariants.
"""
    t=insert_before(t,"## 3. Dedicated WSL/Linux Lab\n",block,path+" V7 runner")
    write(repo/path,t)

    # testing
    path="docs/testing.md"
    t=update_global_headers(update_date(read(repo/path)),path)
    current_runner=f"""### Current verified full runner

As of 2026-09-12, the current Windows Central Lab full-regression runner is:

```text
C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd
SHA256={V7_SHA}
```

Canonical invocation:

```bat
call C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd C:\\CaptivPortal-UI-Preview
```

V7 contract:

```text
[1/4] ordinary full strict pytest
[2/4] compileall
[3/4] branch diff check
[4/4] exact-artifact immutability
```

The six former Windows compatibility exclusions are now ordinary strict tests:

```text
SQLite infinity edge
Node retry async timing
Visitor Registry long audit
Visitor Registry previous-ready
Visitor Registry previous-stopping
Home Health unavailable analytics baseline
```

Current handling for those six:

```text
compatibility allowlist=EMPTY
special --deselect path=NO
separate compatibility stage=NO
compatibility WARN counter/path=NO
strict failure degrades to WARN=NO
```

A failure in any of these cases is a normal strict regression failure.

Accepted TASK-TEST-BASELINE-CLEANUP-01 V7 evidence:

```text
3129 passed
30 skipped
0 failed
0 deselected
strict regressions=0
compileall=PASS
branch diff=PASS
exact-artifact immutability=PASS
```

The exact `3129 / 30` counts are evidence of that accepted run, not a permanent
hardcoded acceptance invariant. The durable invariant is that the former six
cases execute in the ordinary strict suite and cannot escape as compatibility
WARN.

Historical runner:

```text
C:\\CaptivPortal-Lab\\lab-test-v6-fixed.cmd
status=HISTORICAL / AUDIT ONLY
```

V6 is deliberately retained and not rewritten because it records the older
compatibility contract. It is no longer the current/default gate.
"""
    t=regex_once(
        t,
        r"### Current verified full runner\n[\s\S]*?(?=\n### Gate-version anti-drift rule)",
        current_runner.rstrip()+"\n",
        path+" current runner",
        flags=re.M
    )
    # Update anti-drift wording without changing historical acceptance records below.
    t=t.replace(
        "5. runner strict/compatibility contract against the known compatibility baseline;\n"
        "6. whether a new reviewed compatibility case exists;",
        "5. runner strict/platform-exception contract against the current approved baseline;\n"
        "6. reviewed platform exception list (EMPTY for the former six compatibility cases);",
        1
    )
    t=t.replace(
        "KNOWN COMPATIBILITY BASELINE\n+\nCURRENT TEST SET",
        "REVIEWED PLATFORM EXCEPTIONS (if any)\n+\nCURRENT TEST SET",
        1
    )
    latest=f"""### Latest Windows baseline cleanup acceptance — TASK-TEST-BASELINE-CLEANUP-01

Artifact identity:

```text
accepted baseline={ACCEPTED_BASE}
publication commit={PUB_COMMIT}
PR #116=MERGED
merge / production={BASE}
accepted / merged / production tree={TREE}
```

Current Windows gate:

```text
V7 strict=PASS
runner SHA256={V7_SHA}
former six compatibility exclusions=ordinary strict tests
compatibility allowlist for former six=EMPTY
WARN escape for former six=REMOVED
```

Accepted run evidence:

```text
3129 passed
30 skipped
0 failed
0 deselected
strict regressions=0
compileall=PASS
branch diff=PASS
exact-artifact immutability=PASS
```

Production acceptance:

```text
traffic-projection.service=active
Projection status=healthy
backlog=0
captive-portal.service=active
analytics.api_runtime_active
127.0.0.1:8088 LISTEN
HTTP readiness=400
```

Historical `Windows Central Full V6=PASS` entries below remain valid evidence for
the older TASKs that actually used V6; they do not define the current runner.
"""
    t=insert_before(t,"### Latest Admin Web presentation acceptance — WEB-ASSET-LIBRARY-01 + FIX\n",latest,path+" latest task evidence")
    write(repo/path,t)

    # repository actions: version-neutral current gate, with V7 current.
    path="docs/agents/repository-actions.md"
    t=update_date(read(repo/path))
    t=t.replace(
        "- Central Lab full/V6 gate;",
        "- Central Lab current official full-regression gate (currently V7 strict);",
        1
    )
    write(repo/path,t)

    # canonical FINAL task
    write(repo/"docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md",TASK_FINAL.rstrip()+"\n")

def assertions(repo):
    required={
        "README.md":[
            f"Repository implementation checkpoint | `main@{BASE}`",
            "Windows Central Lab | **V7 STRICT — CURRENT**",
            "TASK-TEST-BASELINE-CLEANUP-01",
        ],
        "README_RU.md":[
            f"Repository implementation checkpoint | `main@{BASE}`",
            "Windows Central Lab | **V7 STRICT — CURRENT**",
        ],
        "docs/README.md":[
            f"Current-state implementation baseline: `main@{BASE}`",
            "TASK-TEST-BASELINE-CLEANUP-01-FINAL.md",
            "current runner=C:\\CaptivPortal-Lab\\lab-test-v7-strict.cmd",
        ],
        "docs/testing.md":[
            f"Documentation/current-state implementation baseline: `main@{BASE}`",
            "lab-test-v7-strict.cmd",
            "compatibility allowlist=EMPTY",
            "strict failure degrades to WARN=NO",
            "status=HISTORICAL / AUDIT ONLY",
            "Latest Windows baseline cleanup acceptance",
        ],
        "docs/testing-environments.md":[
            "lab-test-v7-strict.cmd",
            "V7 is the current full Windows strict gate",
            "lab-test-v6-fixed.cmd",
        ],
        "docs/deployment.md":[
            f"Confirmed production deployed HEAD: `{BASE}`",
            "TASK-TEST-BASELINE-CLEANUP-01 production deployment",
            "systemd active != HTTP readiness",
            "urllib3 InsecureRequestWarning",
        ],
        "docs/project-inventory.md":[
            f"Runtime commit: `{BASE}`",
            "Windows test baseline / production closure",
        ],
        "docs/modules/analytics.md":[
            f"Baseline: `main@{BASE}`",
            "COALESCE((value - value) = 0, 0)",
        ],
        "docs/modules/traffic.md":[
            f"Repository implementation baseline: `main@{BASE}`",
            f"Production deployed HEAD: `{BASE}`",
            "platform-sensitive max-double check=REMOVED",
        ],
        "docs/architecture.md":[
            f"Runtime implementation baseline: `main@{BASE}`",
            "Analytics numeric portability invariant",
        ],
        "docs/configuration.md":[
            f"Baseline: `main@{BASE}`",
            "configuration changes=NO",
        ],
        "docs/module-index.md":[
            f"Runtime implementation baseline: `main@{BASE}`",
            f"HEAD: {BASE}",
            "TASK-TEST-BASELINE-CLEANUP-01: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS",
        ],
        "docs/operations-command-lessons-learned.md":[
            "systemd active != HTTP readiness",
            "HTTP=000",
            "same PID",
        ],
        "docs/agents/repository-actions.md":[
            "Central Lab current official full-regression gate (currently V7 strict)",
        ],
        "docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md":[
            "Status: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS",
            f"merge / current production HEAD={BASE}",
            f"SHA256={V7_SHA}",
            "compatibility allowlist for former six=EMPTY",
        ],
    }
    for path,needles in required.items():
        text=read(repo/path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: missing canonical assertion in {path}: {needle}")

    # Current-only stale contract checks. Historical sections are intentionally not blanket-rewritten.
    testing=read(repo/"docs/testing.md")
    old_current=[
        "As of 2026-08-29, the verified current Windows Central Lab runner is:",
        "V6 is current because",
        "treated\nas reviewed compatibility behavior rather than a new TASK regression",
    ]
    for marker in old_current:
        if marker in testing:
            raise SystemExit(f"STOP: stale current V6 contract remains in docs/testing.md: {marker}")

    for path in ["docs/deployment.md","docs/agents/repository-actions.md"]:
        if "full/V6" in read(repo/path):
            raise SystemExit(f"STOP: stale full/V6 current reference remains in {path}")

    # Do not allow current top-level identity to remain on PR114.
    for path in ["README.md","README_RU.md","docs/README.md","docs/deployment.md",
                 "docs/module-index.md","docs/project-inventory.md","docs/testing.md"]:
        text=read(repo/path)
        # We allow PREV_PROD deeper in historical sections, but all current header/table assertions above must be new.
        if path=="docs/project-inventory.md" and f"Runtime commit: `{PREV_PROD}`" in text:
            raise SystemExit("STOP: stale project inventory runtime commit")
        if path=="docs/deployment.md" and f"Confirmed production deployed HEAD: `{PREV_PROD}`" in text:
            raise SystemExit("STOP: stale deployment current HEAD")

def stale_audit(repo):
    print("=== REPOSITORY-WIDE STALE-REFERENCE AUDIT ===")
    checks=[
        ("V6 runner references",["git","grep","-n","lab-test-v6-fixed.cmd","--","docs"]),
        ("V7 runner references",["git","grep","-n","lab-test-v7-strict.cmd","--","docs","README.md","README_RU.md"]),
        ("old PR114 production SHA references",["git","grep","-n",PREV_PROD,"--","docs","README.md","README_RU.md"]),
        ("old Projection fix SHA references",["git","grep","-n","7472d67274ea5aaea2a20df6b613b78d5bb70f42","--","docs","README.md","README_RU.md"]),
    ]
    for title,args in checks:
        out,_=cap(args,repo,check=False)
        print(f"--- {title} ---")
        print(out.strip() or "(none)")
    print("Classification:")
    print("- V6 references are allowed only as explicitly historical/audit or historical acceptance evidence.")
    print("- old production SHAs are allowed inside dated historical TASK/deployment/acceptance evidence.")
    print("- current headers/checkpoints are asserted separately against current main/production.")

def self_test():
    # Test the two highest-risk transformations against exact live-shape fragments.
    sample_testing="""### Current verified full runner

As of 2026-08-29, the verified current Windows Central Lab runner is:

```text
C:\\CaptivPortal-Lab\\lab-test-v6-fixed.cmd
```

V6 is current because the reviewed Windows compatibility model now includes the
known Home Health baseline case.

### Gate-version anti-drift rule
"""
    replacement="""### Current verified full runner

V7

"""
    got=regex_once(
        sample_testing,
        r"### Current verified full runner\n[\s\S]*?(?=\n### Gate-version anti-drift rule)",
        replacement.rstrip()+"\n",
        "self-test runner",
        flags=re.M,
    )
    assert "V7" in got and "V6 is current because" not in got

    sample_ops="""## 3. Service readiness after restart

old body

## 4. Git status and identity checks
"""
    got=regex_once(
        sample_ops,
        r"## 3\. Service readiness after restart\n[\s\S]*?(?=\n## 4\. Git status and identity checks)",
        "## 3. Service readiness after restart\n\nnew\n",
        "self-test readiness",
        flags=re.M,
    )
    assert "\nnew\n" in got
    print("SELF-TEST=PASS")

def main():
    self_test()

    ap=argparse.ArgumentParser()
    ap.add_argument(
        "--repo",
        default=os.environ.get(
            "CAPTIVPORTAL_KB_REPO",
            str(Path(os.environ.get("USERPROFILE",str(Path.home()))) /
                "Downloads" / "CaptivPortal-KB-Work")
        )
    )
    ap.add_argument("--no-push",action="store_true")
    ns=ap.parse_args()
    repo=Path(ns.repo)

    print("Publisher: TEST-BASELINE-CLEANUP-KB-V1-2026-09-12")
    print("=== PRECHECK ===")
    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if status_paths(repo):
        print("Dirty paths:",*status_paths(repo),sep="\n  ")
        raise SystemExit("STOP: worktree must be clean")

    run(["git","fetch","origin","main"],repo)
    remote=txt(["git","rev-parse","origin/main"],repo).strip()
    remote_tree=txt(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:",remote)
    print("origin tree:",remote_tree)
    if remote != BASE or remote_tree != TREE:
        raise SystemExit("STOP: origin/main moved; KB package must be rebound")

    run(["git","switch","main"],repo)
    run(["git","merge","--ff-only","origin/main"],repo)
    if status_paths(repo):
        raise SystemExit("STOP: main dirty after fast-forward")

    remote_branch=txt(
        ["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo
    ).strip()
    if remote_branch:
        raise SystemExit("STOP: remote publication branch already exists")

    local=txt(["git","branch","--list",BRANCH],repo).strip()
    if local:
        local_sha=txt(["git","rev-parse",BRANCH],repo).strip()
        if local_sha != BASE:
            raise SystemExit("STOP: existing local publication branch has moved")
        run(["git","branch","-D",BRANCH],repo)

    run(["git","switch","-c",BRANCH],repo)

    new_task=repo/"docs/tasks/TASK-TEST-BASELINE-CLEANUP-01-FINAL.md"
    if new_task.exists():
        raise SystemExit("STOP: TASK final file already exists on baseline")

    print("=== APPLY KB SYNC ===")
    transform(repo)

    actual=status_paths(repo)
    print("Changed files:")
    for p in actual:
        print(" ",p)
    if actual != SCOPE:
        print("Expected:")
        for p in SCOPE:
            print(" ",p)
        raise SystemExit("STOP: exact docs scope mismatch")

    assertions(repo)
    run(["git","diff","--check"],repo)
    print("PASS: exact 15-file docs-only scope")
    print("PASS: V7 current / V6 historical")
    print("PASS: former six compatibility cases ordinary strict")
    print("PASS: current production identity")
    print("PASS: runtime/tests/config not modified")
    print("PASS: git diff --check")

    stale_audit(repo)

    run(["git","add","--"]+SCOPE,repo)
    if diff_names(repo,False):
        raise SystemExit("STOP: unstaged changes remain")
    if diff_names(repo,True) != SCOPE:
        raise SystemExit("STOP: staged scope mismatch")
    run(["git","diff","--cached","--check"],repo)

    patch=Path(__file__).resolve().parent/"CaptivPortal_KB_TEST_BASELINE_CLEANUP_2026-09-12.patch"
    with patch.open("wb") as fh:
        q=subprocess.run(
            ["git","diff","--cached","--binary","--"]+SCOPE,
            cwd=repo,stdout=fh,stderr=subprocess.PIPE
        )
    if q.returncode != 0 or not patch.exists() or patch.stat().st_size == 0:
        raise SystemExit("STOP: patch generation failed")

    if ns.no_push:
        print("NO-PUSH mode: changes staged only")
        print("Unified diff:",patch)
        return

    print("=== COMMIT ===")
    run([
        "git","commit",
        "-m","docs: close Windows compatibility baseline cleanup",
        "-m","Canonicalize Windows Central Lab V7 strict, preserve V6 as historical evidence, document TASK-TEST-BASELINE-CLEANUP-01 production acceptance, and update current production identity."
    ],repo)
    commit=txt(["git","rev-parse","HEAD"],repo).strip()
    if status_paths(repo):
        raise SystemExit("STOP: worktree not clean after commit")

    print("=== PUSH ===")
    run(["git","push","-u","origin",BRANCH],repo)

    body=f"""## Purpose

Canonical KB synchronization after TASK-TEST-BASELINE-CLEANUP-01.

## Current truth

- current main / production HEAD: {BASE}
- current production tree: {TREE}
- TASK-TEST-BASELINE-CLEANUP-01: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS
- Windows Central Lab current runner: V7 strict
- V6 fixed: historical / audit only
- former six Windows compatibility exclusions: ordinary strict regressions
- compatibility WARN escape for former six: removed

## Evidence

Accepted V7 run:
- 3129 passed
- 30 skipped
- 0 failed
- 0 deselected
- strict regressions: 0
- compileall: PASS
- branch diff: PASS
- exact-artifact immutability: PASS

Exact counts are run evidence, not a permanent hardcoded invariant.

## Scope

- exactly 15 documentation files
- implementation changed by this docs PR: NO
- tests changed by this docs PR: NO
- V7 runner logic changed: NO
- V6 historical runner changed: NO
- runtime config/flags changed: NO
- production changed by this docs PR: NO

Historical TASK/FINAL/V6 evidence is preserved rather than retroactively rewritten.

Draft only. Merge remains Owner-controlled.
"""
    print("=== CREATE DRAFT PR ===")
    pr=txt([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main",
        "--head",BRANCH,
        "--title","Docs: close Windows compatibility baseline cleanup",
        "--body",body,
        "--draft",
    ],repo).strip()

    print("=== FINAL HANDOFF ===")
    print("Branch:",BRANCH)
    print("Commit:",commit)
    print("Changed docs:",len(SCOPE))
    for p in SCOPE:
        print(" ",p)
    print("Implementation changed: NO")
    print("Tests changed: NO")
    print("V7 runner changed: NO")
    print("V6 runner changed: NO")
    print("Runtime/config changed: NO")
    print("Production changed: NO")
    print("Draft PR:",pr)
    print("Merge performed: NO")
    print("Unified diff:",patch)

if __name__=="__main__":
    main()
