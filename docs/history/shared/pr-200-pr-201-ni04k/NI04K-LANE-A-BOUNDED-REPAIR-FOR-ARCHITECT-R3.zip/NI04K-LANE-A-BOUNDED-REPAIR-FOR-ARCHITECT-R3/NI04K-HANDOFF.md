# NI-04K — Research Candidate Handoff

- **TASK:** `TASK-DTI-NI-04K`
- **Execution:** independent first-party public-document research + offline knowledge-candidate preparation; no production network observations
- **Research artifact:** local immutable candidate only; not yet production-admitted
- **Architect R1 SHA256:** `788879cec606f88b13bcf3a759dc19dd68eebe426e5584a727a4e6aa66d1a17e`
- **Current GitHub main checked:** `22cdde5d4168de02d142c840028a4d66167e47f7`
- **Artifact set:** `recognition-taxonomy-v1.json`, `recognition-knowledge-manifest-v1.json`, `recognition-ruleset-v1.json`
- **Taxonomy:** ID `captivportal.network-intelligence.recognition-taxonomy`, version `1`, SHA256 `7e122a828c0877d4fb61382646604a2b4a8421a40c4388e513460c84c69c8278`
- **Manifest:** ID `captivportal.network-intelligence.recognition-knowledge`, version `1`, SHA256 `7ecca6dc42ef73c2dd4b40e4d56d4115078f548cd3693e510f095968be1f0210`
- **Ruleset:** ID `captivportal.network-intelligence.service-recognition`, version `1`, SHA256 `46d9485b6aea5c6a0b40a4b9a969eed553a4353904a1667fe85cb0620c02a56a`
- **Proposed real services:** `service.netflix`, `service.spotify`, `service.telegram`, `service.whatsapp`, `service.youtube` = 5
- **Active proposed direct-SNI service rules:** 5, all exact; 0 suffix, 0 DNS-connected, 0 IP-only
- **Knowledge provenance entries:** 9, all first_party_public, with URLs and claims
- **Positive fixtures:** 10 synthetic expected-result vectors (not executed with production matcher)
- **Negative fixtures:** 24 synthetic expected-result vectors (not executed with production matcher)
- **Canonical reference digests:** 3/3 PASS
- **Candidate self-digests/cross-references:** PASS via bounded offline validation
- **Invalid bundle probes:** 19/19 rejected in research-only harness (not production validation)
- **Privacy:** no client trace, no personal SNI, no PCAP, no packet collection, no production DB access
- **Architect independent semantic admission:** R1 RETURNED ONE FIXTURE REPAIR; RE-REVIEW PENDING
- **Tech Lead independent admission:** PENDING (researcher self-check does not constitute independence)
- **Owner exact bundle authorization:** PENDING
- **NI-04K status:** BOUNDED R1 FIXTURE REPAIR READY FOR ARCHITECT RE-REVIEW / ADMISSION HOLD
- **NI-04A-CODE:** HOLD
- **MAIN NI-04:** HOLD
- **Production / GitHub mutations:** NONE

## Exact next governance action

Give `EVIDENCE-PACK-v1.md`, the three JSON artifacts, the fixture and validation files to **Architect** for independent semantic admission decision against original NI-04 v1 + R1. Architect must explicitly PASS/REPAIR/REJECT specific Service rules and organization/category relations. After Architect PASS, require independent Tech Lead review by a reviewer who did not prepare the evidence; then obtain Owner approval for **this exact ID/version/digest bundle**, not generic permission to write code. Only then issue a separate exact `NI-04A-CODE` implementation TASK.
