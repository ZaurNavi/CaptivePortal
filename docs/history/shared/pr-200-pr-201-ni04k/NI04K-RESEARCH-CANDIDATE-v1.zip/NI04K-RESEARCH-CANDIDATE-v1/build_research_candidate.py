#!/usr/bin/env python3
"""OFFLINE NI-04K RESEARCH ARTIFACT GENERATOR AND VALIDATION ONLY.
This is NOT the NI-04A production matcher, loader, API, or deployment code.
The research fixture oracle covers exact hostname equality only, not runtime orchestration.
"""
import hashlib, json, re, unicodedata
from pathlib import Path
from datetime import datetime, timezone, timedelta
from copy import deepcopy

OUT = Path(__file__).resolve().parent
ARCHITECT_R1 = Path('/mnt/data/TASK-DTI-NI-04-ARCHITECTURE-CONTRACT-v1-R1(1).md')
STAMP='2026-10-11T20:04:00.000000Z'
DUE='2027-01-09T20:04:00.000000Z'  # +90 days
SOURCES = [
 ('google.youtube.host','Google / YouTube','https://support.google.com/youtube/answer/171780?hl=en','Google YouTube Help uses https://www.youtube.com for embedded YouTube player and distinguishes youtube-nocookie.com as an alternative embed domain.'),
 ('google.youtube.operator','Google','https://about.google/products/','Google lists YouTube, YouTube Kids, and YouTube Music as distinct products; YouTube is a Google service, not all Google-hosted traffic.'),
 ('meta.whatsapp.host','WhatsApp Help Center','https://faq.whatsapp.com/668538004658079/?cms_platform=windows-desktop&locale=ja_JP','WhatsApp official Help Center directs users to web.whatsapp.com for WhatsApp Web.'),
 ('meta.whatsapp.operator','Meta Newsroom','https://about.fb.com/news/2026/09/introducing-meta-one-subscription-service-more-features-ai/','Meta lists WhatsApp alongside Instagram and Facebook as a distinct Meta app; shared Meta infrastructure is not proof of WhatsApp.'),
 ('telegram.web.host','Telegram','https://web.telegram.org/?lang=ru','Official Telegram Web login interface is hosted at web.telegram.org.'),
 ('telegram.apps.operator','Telegram','https://telegram.org/apps','Telegram lists Telegram WebA/WebK as its own official Telegram web apps.'),
 ('spotify.web.host','Spotify Support','https://support.spotify.com/us/article/web-player-help/','Spotify Web Player help identifies open.spotify.com as its web player host.'),
 ('spotify.service','Spotify Support','https://support.spotify.com/az-az/article/what-is-spotify/','Spotify describes itself as a music, podcast, and video service, and the web player is a client for Spotify.'),
 ('netflix.web.host','Netflix Help Center','https://help.netflix.com/en/node/133134','Netflix directs customers to type www.netflix.com in browser address bar to access Netflix.'),
]
CAT=[('category.audio_streaming','Audio Streaming'),('category.messaging','Messaging'),('category.video_streaming','Video Streaming')]
ORG=[('org.google','Google'),('org.meta','Meta'),('org.netflix','Netflix'),('org.spotify','Spotify'),('org.telegram','Telegram')]
SERVICES=[('service.netflix','Netflix','org.netflix','category.video_streaming'),('service.spotify','Spotify','org.spotify','category.audio_streaming'),('service.telegram','Telegram','org.telegram','category.messaging'),('service.whatsapp','WhatsApp','org.meta','category.messaging'),('service.youtube','YouTube','org.google','category.video_streaming')]
RULES=[
 ('rule.netflix.www_sni','www.netflix.com','service.netflix',('netflix.web.host',)),
 ('rule.spotify.open_sni','open.spotify.com','service.spotify',('spotify.service','spotify.web.host')),
 ('rule.telegram.web_sni','web.telegram.org','service.telegram',('telegram.apps.operator','telegram.web.host')),
 ('rule.whatsapp.web_sni','web.whatsapp.com','service.whatsapp',('meta.whatsapp.host','meta.whatsapp.operator')),
 ('rule.youtube.www_sni','www.youtube.com','service.youtube',('google.youtube.host','google.youtube.operator')),
]
def canonical(obj):
    def normalize(x):
        if isinstance(x,str):
            if unicodedata.normalize('NFC',x)!=x: raise ValueError('NFC violation')
            return x
        if isinstance(x,list):return [normalize(v) for v in x]
        if isinstance(x,dict):return {normalize(k):normalize(v) for k,v in x.items()}
        if isinstance(x,float):raise ValueError('no floats')
        return x
    return json.dumps(normalize(obj),sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
def digest(obj,key): return hashlib.sha256(canonical({k:v for k,v in obj.items() if k!=key})).hexdigest()
def write(name,obj):
    (OUT/name).write_bytes(canonical(obj))
    return hashlib.sha256((OUT/name).read_bytes()).hexdigest()

taxonomy=dict(schema_version=1,taxonomy_id='captivportal.network-intelligence.recognition-taxonomy',taxonomy_version=1,
 organizations=[dict(organization_id=i,display_name=n,organization_kind='service_operator') for i,n in ORG],
 service_categories=[dict(service_category_id=i,display_name=n) for i,n in CAT],
 services=[dict(service_id=i,display_name=n,organization_id=o,service_category_id=c,lifecycle_state='active') for i,n,o,c in SERVICES])
taxonomy['taxonomy_digest_sha256']=digest(taxonomy,'taxonomy_digest_sha256')
manifest=dict(schema_version=1,knowledge_manifest_id='captivportal.network-intelligence.recognition-knowledge',knowledge_manifest_version=1,reviewed_at_utc=STAMP,review_due_at_utc=DUE,
 sources=[dict(knowledge_ref='knowledge.'+sid,source_class='first_party_public',publisher_or_owner=owner,source_locator=url,claim_summary=claim,reviewed_at_utc=STAMP,review_due_at_utc=DUE) for sid,owner,url,claim in SOURCES]);manifest['sources'].sort(key=lambda x:x['knowledge_ref'])
manifest['knowledge_manifest_digest_sha256']=digest(manifest,'knowledge_manifest_digest_sha256')
ruleset=dict(schema_version=1,ruleset_id='captivportal.network-intelligence.service-recognition',ruleset_version=1,
 taxonomy_id=taxonomy['taxonomy_id'],taxonomy_version=taxonomy['taxonomy_version'],taxonomy_digest_sha256=taxonomy['taxonomy_digest_sha256'],
 knowledge_manifest_id=manifest['knowledge_manifest_id'],knowledge_manifest_version=manifest['knowledge_manifest_version'],knowledge_manifest_digest_sha256=manifest['knowledge_manifest_digest_sha256'],
 rules=[dict(rule_id=r,rule_kind='service_sni_exact',target_type='service',target_id=service,hostname_pattern=host,knowledge_refs=sorted('knowledge.'+s for s in source_ids),reviewed_at_utc=STAMP,review_due_at_utc=DUE,lifecycle_state='active',ambiguity_group_id=None) for r,host,service,source_ids in RULES]);ruleset['rules'].sort(key=lambda x:x['rule_id'])
ruleset['ruleset_digest_sha256']=digest(ruleset,'ruleset_digest_sha256')

# Research-only bounded bundle integrity checks. Not a runtime/production validator.
ID={'taxonomy':r'^org\.[a-z0-9][a-z0-9._-]{1,62}[a-z0-9]$',
    'service':r'^service\.[a-z0-9][a-z0-9._-]{1,58}[a-z0-9]$',
    'rule':r'^rule\.[a-z0-9][a-z0-9._-]{1,94}[a-z0-9]$',
    'knowledge':r'^knowledge\.[a-z0-9][a-z0-9._-]{1,94}[a-z0-9]$'}
def valid_bundle(t,m,r,at=STAMP):
    for obj,key in [(t,'taxonomy_digest_sha256'),(m,'knowledge_manifest_digest_sha256'),(r,'ruleset_digest_sha256')]:
        if obj[key]!=digest(obj,key): raise ValueError('digest mismatch '+key)
    if r['taxonomy_id']!=t['taxonomy_id'] or r['taxonomy_version']!=t['taxonomy_version'] or r['taxonomy_digest_sha256']!=t['taxonomy_digest_sha256']:raise ValueError('taxonomy ref mismatch')
    if r['knowledge_manifest_id']!=m['knowledge_manifest_id'] or r['knowledge_manifest_version']!=m['knowledge_manifest_version'] or r['knowledge_manifest_digest_sha256']!=m['knowledge_manifest_digest_sha256']:raise ValueError('manifest ref mismatch')
    def sorted_unique(a,key):
        x=[o[key] for o in a]
        if x!=sorted(set(x)):raise ValueError('ordering/duplicate '+key)
    for k,i in [('organizations','organization_id'),('services','service_id'),('service_categories','service_category_id')]:sorted_unique(t[k],i)
    sorted_unique(m['sources'],'knowledge_ref');sorted_unique(r['rules'],'rule_id')
    orgs={o['organization_id'] for o in t['organizations']};cats={o['service_category_id'] for o in t['service_categories']};services={s['service_id'] for s in t['services']}
    for s in t['services']:
        if s['organization_id'] not in orgs or s['service_category_id'] not in cats:raise ValueError('taxonomy refs')
    src={s['knowledge_ref']:s for s in m['sources']}
    for s in m['sources']:
        if not re.fullmatch(ID['knowledge'],s['knowledge_ref']):raise ValueError('source ID')
        if not s['reviewed_at_utc']<=m['reviewed_at_utc']<s['review_due_at_utc']:raise ValueError('source review order')
    def parse(s):return datetime.fromisoformat(s.replace('Z','+00:00'))
    if not parse(m['reviewed_at_utc'])<parse(m['review_due_at_utc']) or parse(m['review_due_at_utc'])-parse(m['reviewed_at_utc'])>timedelta(days=365):raise ValueError('manifest time')
    seen=set()
    for rule in r['rules']:
        if not re.fullmatch(ID['rule'],rule['rule_id']):raise ValueError('rule ID')
        if rule['target_type']!='service' or rule['target_id'] not in services:raise ValueError('target missing')
        if rule['rule_kind']!='service_sni_exact' or rule['lifecycle_state']!='active':raise ValueError('unsafe rule kind')
        if rule['ambiguity_group_id'] is not None:raise ValueError('unsound ambiguity')
        if not rule['hostname_pattern'] or rule['hostname_pattern'].lower()!=rule['hostname_pattern']:raise ValueError('host')
        if not rule['knowledge_refs'] or rule['knowledge_refs']!=sorted(set(rule['knowledge_refs'])):raise ValueError('rule refs ordering')
        if any(i not in src for i in rule['knowledge_refs']):raise ValueError('dangling refs')
        if rule['reviewed_at_utc']<m['reviewed_at_utc'] or any(rule['reviewed_at_utc']<src[i]['reviewed_at_utc'] for i in rule['knowledge_refs']):raise ValueError('review order')
        due=min([rule['review_due_at_utc'],m['review_due_at_utc']]+[src[i]['review_due_at_utc'] for i in rule['knowledge_refs']])
        if at>=due or rule['reviewed_at_utc']>=due:raise ValueError('expired rule')
        k=(rule['rule_kind'],rule['hostname_pattern'])
        if k in seen:raise ValueError('static matcher collision')
        seen.add(k)
    return True

valid_bundle(taxonomy,manifest,ruleset)
# Independently recompute 3 Architect synthetic fixtures, no generated knowledge accepted from them.
s=ARCHITECT_R1.read_text().split('## 3.14 Synthetic canonical positive example')[1].split('## 3.15 Digest-invalid rejection example')[0]
refs=[json.loads(b) for b in re.findall(r'```json\n(.*?)\n```',s,re.S)]
assert len(refs)==3
for fixture,key in zip(refs,('taxonomy_digest_sha256','knowledge_manifest_digest_sha256','ruleset_digest_sha256')):
    assert digest(fixture,key)==fixture[key],key
# Semantic fixture assertions represent only equality & disallowed sources, not production matcher.
fixtures=[]
for r in ruleset['rules']:
    hostname=r['hostname_pattern']; sid=r['target_id']
    fixtures.append(dict(case_id='positive.'+sid,expected='service_resolved',expected_service_id=sid,signal_family='tls_sni',source='synthetic_qualifying_outbound_external_authoritative_edge',observed_hostname=hostname,rule_id=r['rule_id']))
    fixtures.append(dict(case_id='positive.quic.'+sid,expected='service_resolved',expected_service_id=sid,signal_family='quic_sni',source='synthetic_qualifying_outbound_external_authoritative_edge',observed_hostname=hostname,rule_id=r['rule_id']))
    for name,test_host in [('near_match','not'+hostname),('parent_only',hostname.split('.',1)[1])]:
        fixtures.append(dict(case_id=name+'.'+sid,expected='unknown',expected_service_id=None,signal_family='tls_sni',source='synthetic_qualifying_outbound_external_authoritative_edge',observed_hostname=test_host,rule_id=None))
    fixtures.append(dict(case_id='dns_only.'+sid,expected='no_service_resolution',expected_service_id=None,signal_family='dns_query_name',source='synthetic_dns_query_and_answers_no_direct_sni',observed_hostname=hostname,rule_id=None))
# Negative organization, CDN, attribution, privacy, ECH scenarios shared among rules.
for nm,host,kind in [('shared_meta', 'www.instagram.com','tls_sni'),('shared_google','accounts.google.com','tls_sni'),('shared_cloud','cdn.cloudflare.net','tls_sni'),('peer_ip_only','', 'peer_ip_only'),('ech_absent_sni','', 'tls_sni'),('local_edge','web.whatsapp.com','tls_sni'),('inbound_edge','open.spotify.com','tls_sni'),('wrong_device','www.youtube.com','tls_sni')]:
    fixtures.append(dict(case_id='negative.'+nm,expected='no_service_resolution',expected_service_id=None,signal_family=kind,source='synthetic_disallowed_context' if nm in ('local_edge','inbound_edge','wrong_device') else 'synthetic_no_direct_admitted_service_evidence',observed_hostname=host,rule_id=None))

# Standalone invariant probes on rehashed mutated artifacts; self-hash always recomputed
# after the mutation, so integrity checks cannot mask semantic validation errors.
def rehash(t,m,r):
    t['taxonomy_digest_sha256']=digest(t,'taxonomy_digest_sha256')
    m['knowledge_manifest_digest_sha256']=digest(m,'knowledge_manifest_digest_sha256')
    r['taxonomy_digest_sha256']=t['taxonomy_digest_sha256']
    r['knowledge_manifest_digest_sha256']=m['knowledge_manifest_digest_sha256']
    r['ruleset_digest_sha256']=digest(r,'ruleset_digest_sha256')
neg_cases=[]
def expect_reject(label,edit, rehashed=True, at=STAMP):
    t,m,r=deepcopy((taxonomy,manifest,ruleset));edit(t,m,r)
    if rehashed:rehash(t,m,r)
    try:valid_bundle(t,m,r,at=at)
    except ValueError as e:neg_cases.append(dict(case_id=label,status='REJECTED_AS_REQUIRED',reason=str(e)))
    else:raise AssertionError('negative case falsely admitted: '+label)
expect_reject('taxonomy_digest_corrupt',lambda t,m,r:t.update(taxonomy_digest_sha256='0'*64),False)
expect_reject('manifest_digest_corrupt',lambda t,m,r:m.update(knowledge_manifest_digest_sha256='0'*64),False)
expect_reject('ruleset_digest_corrupt',lambda t,m,r:r.update(ruleset_digest_sha256='0'*64),False)
expect_reject('unsorted_manifest_sources',lambda t,m,r:m['sources'].reverse())
expect_reject('duplicate_knowledge_ref',lambda t,m,r:m['sources'].append(deepcopy(m['sources'][-1])))
expect_reject('unsorted_rules',lambda t,m,r:r['rules'].reverse())
expect_reject('duplicate_rule_id',lambda t,m,r:r['rules'].append(deepcopy(r['rules'][-1])))
expect_reject('duplicate_matcher_target',lambda t,m,r:r['rules'].append(dict(deepcopy(r['rules'][-1]),rule_id='rule.z_duplicate')))
expect_reject('unsorted_rule_refs',lambda t,m,r:r['rules'][-1]['knowledge_refs'].reverse())
expect_reject('dangling_knowledge_ref',lambda t,m,r:r['rules'][-1].update(knowledge_refs=['knowledge.absent']))
expect_reject('bad_manifest_reference_digest',lambda t,m,r:r.update(knowledge_manifest_digest_sha256='f'*64),False)
expect_reject('source_review_after_manifest',lambda t,m,r:m['sources'][0].update(reviewed_at_utc='2026-10-12T00:00:00.000000Z'))
expect_reject('rule_review_before_source',lambda t,m,r:r['rules'][0].update(reviewed_at_utc='2026-10-01T00:00:00.000000Z'))
expect_reject('expired_all_rules_at_exact_due',lambda t,m,r:None,at=DUE)
expect_reject('active_dns_rule',lambda t,m,r:r['rules'][0].update(rule_kind='service_dns_connected_exact'))
expect_reject('same_matcher_different_service_undeclared',lambda t,m,r:r['rules'][1].update(hostname_pattern=r['rules'][0]['hostname_pattern']))
expect_reject('missing_taxonomy_target',lambda t,m,r:r['rules'][0].update(target_id='service.unknown'))
expect_reject('unsorted_services',lambda t,m,r:t['services'].reverse())
expect_reject('category_target_missing',lambda t,m,r:t['services'][0].update(service_category_id='category.unknown'))

names=[('recognition-taxonomy-v1.json',taxonomy),('recognition-knowledge-manifest-v1.json',manifest),('recognition-ruleset-v1.json',ruleset),('research-fixtures-v1.json',{'schema_note':'Research test vectors only; no packet capture performed and no production matcher executed', 'vectors':fixtures,'invalid_artifact_probes':neg_cases})]
file_digests={filename:write(filename,obj) for filename,obj in names}
allchecks=dict(architect_reference_digests_pass=3,real_services=len(taxonomy['services']),active_exact_sni_rules=len(ruleset['rules']),first_party_knowledge_sources=len(manifest['sources']),research_vectors=len(fixtures),bounded_invalid_bundle_probes_pass=len(neg_cases),canonical_file_sha256=file_digests,artifact_semantic_sha256={'taxonomy':taxonomy['taxonomy_digest_sha256'],'manifest':manifest['knowledge_manifest_digest_sha256'],'ruleset':ruleset['ruleset_digest_sha256']})
(OUT/'offline-validation-summary.json').write_bytes(canonical(allchecks))
(OUT/'SHA256SUMS.txt').write_text(''.join(f'{hashlib.sha256((OUT/filename).read_bytes()).hexdigest()}  {filename}\n' for filename in [n for n,_ in names]+['offline-validation-summary.json']),encoding='utf-8')
print(json.dumps(allchecks,indent=2))
