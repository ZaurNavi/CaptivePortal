# WEB-ASSET-LIBRARY KB — V4 Recovery

This recovery replaces the failed V1/V2/V3 publisher chain.

It is designed specifically for the current state left by V3:

```text
local branch=docs/web-asset-library-production-kb-2026-09-12
local HEAD=043a13bc1e3aa3353e27af1859dc0bb698df4955
remote target branch=absent
partial dirty files=only previous publisher scope
```

Safety:
- verifies origin/main SHA/tree;
- refuses to reset any dirty path outside previous publisher scope;
- hard-resets only the dedicated failed publisher branch;
- validates canonical Android SVG and admin.js from Git objects;
- does not inspect or hash Windows working-tree asset bytes;
- applies a simplified 15-file docs/governance reconciliation;
- does not modify runtime code or tests;
- runs diff and staged-diff checks;
- creates one commit, pushes one branch, creates one Draft PR;
- does not merge or deploy.

Static verification:
```text
Python compile=PASS
undefined runtime globals=NONE
```

Publisher SHA256:
`2487e07751283fe218746b8657c0226c8bd05140e60396d88cc6ed1581920b19`
