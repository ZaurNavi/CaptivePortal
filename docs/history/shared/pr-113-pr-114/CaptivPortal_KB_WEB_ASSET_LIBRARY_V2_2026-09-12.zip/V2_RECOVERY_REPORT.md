# V2 publisher recovery — WEB-ASSET-LIBRARY-01 KB

V1 stopped before branch creation because it hashed Windows working-tree bytes.
The checkout had CRLF translation, so working-tree SHA256 was:

`11b054bd23b4324f7beee014550945bb0ada885f81b2bc1d9d42f5cc3724d64e`

Canonical Git blob bytes at:

`043a13bc1e3aa3353e27af1859dc0bb698df4955:app/admin_web/static/icons/platforms/android.svg`

have the accepted SHA256:

`2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc`

V2 hashes the canonical blob with `git show` and separately proves that the
working-tree copy differs, if at all, only by CRLF/LF translation.

Expected starting state:
- branch: `main`
- clean worktree
- main/origin-main: `043a13bc1e3aa3353e27af1859dc0bb698df4955`
- target publication branch absent

No V1 branch, commit, push or PR was created.
