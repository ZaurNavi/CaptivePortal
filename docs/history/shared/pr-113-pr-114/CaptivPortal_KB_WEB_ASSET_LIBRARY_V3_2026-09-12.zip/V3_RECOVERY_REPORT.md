# WEB-ASSET-LIBRARY-01 KB publisher — V3 recovery

V2 stopped before branch creation because its source accidentally contained
double-escaped byte literals:

```text
b"\\r\\n"
b"\\n"
```

so it searched for the four literal characters `\r\n` instead of CRLF bytes.

Observed hashes prove the asset itself is correct:

```text
canonical Git LF SHA256:
2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc

Windows working-tree CRLF SHA256:
11b054bd23b4324f7beee014550945bb0ada885f81b2bc1d9d42f5cc3724d64e
```

V3 calculates the expected CRLF materialization directly from canonical Git blob
bytes and accepts only:
- exact canonical Git bytes; or
- exact LF→CRLF Windows checkout materialization.

V2 made no KB changes, branch, commit, push, or PR.
