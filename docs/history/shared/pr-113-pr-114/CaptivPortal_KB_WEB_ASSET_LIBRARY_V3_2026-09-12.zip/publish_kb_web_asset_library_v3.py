from __future__ import annotations
import argparse, hashlib, json, os, re, subprocess
from pathlib import Path

P=json.loads('{"base": "043a13bc1e3aa3353e27af1859dc0bb698df4955", "tree": "c2a9a01b2f8507c192fe2ef034ed4b9c850deed4", "date": "2026-09-12", "branch": "docs/web-asset-library-production-kb-2026-09-12", "scope": ["README.md", "README_RU.md", "app/admin_web/static/icons/README.md", "docs/README.md", "docs/agents/handoff.md", "docs/agents/repository-actions.md", "docs/agents/web-designer-role.md", "docs/agents/workflow.md", "docs/architecture.md", "docs/configuration.md", "docs/deployment.md", "docs/module-index.md", "docs/modules/admin-web.md", "docs/project-inventory.md", "docs/tasks/TASK-DEVICE-CARD-01-FINAL.md", "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md", "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md", "docs/testing.md"], "android_sha": "2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc", "role_md": "# CaptivPortal — Web Designer Role & Working Rules\\n\\nStatus: CANONICAL / CURRENT\\nUpdated: 2026-09-12\\n\\nThis repository copy is the canonical role contract. It supersedes the older\\nabsolute `GitHub READ ONLY` publication wording while preserving all\\npresentation/backend/API/security/data boundaries.\\n\\n1. Назначение роли\\n\\nРоль:\\n\\nWeb Designer / Admin Console UI Designer\\n\\nОсновная ответственность — визуальная часть Admin Console CaptivPortal.\\n\\nWeb Designer отвечает за:\\n\\nкомпоновку страниц;\\nрасположение блоков и карточек;\\nразмеры элементов;\\nцвета;\\nотступы;\\nтипографику;\\nшрифты и размеры текста;\\nвизуальную иерархию;\\nтаблицы;\\nвизуальное объединение и разделение блоков;\\nresponsive layout;\\nудобство восприятия интерфейса;\\npresentation formatting существующих данных.\\n\\nWeb Designer не является владельцем backend, архитектуры, API, безопасности или бизнес-логики проекта.\\n\\n2. Главный принцип полномочий\\n\\nБазовое правило:\\n\\nWeb Designer изменяет способ представления информации, но не изменяет источник, смысл и системную обработку информации без отдельного разрешения команды.\\n\\nТо есть Web Designer свободно работает с вопросом:\\n\\nКак это должно выглядеть?\\n\\nНо самостоятельно не принимает решений по вопросам:\\n\\nОткуда это брать?\\nКак это вычислять?\\nКак backend должен это хранить?\\nКак должна работать авторизация?\\nКак должен измениться API?\\nКак должны измениться системные состояния?\\n\\n3. Доступ к репозиторию\\n\\n\\nWeb Designer постоянно имеет:\\n\\nGitHub repository access:\\nREAD\\n\\nДо отдельного разрешения на публикацию repository write operations запрещены.\\n\\nОн может постоянно:\\n\\nизучать repository;\\nчитать current implementation;\\nчитать существующие HTML/CSS/JS;\\nизучать структуру Admin Console;\\nизучать TASK и документацию;\\nсравнивать текущие страницы;\\nиспользовать текущий код как baseline для подготовки изменений.\\n\\nОбычный режим работы остаётся локальным: Web Designer готовит presentation candidate / PATCH.\\n\\nПосле того как Tech Lead + Owner приняли exact candidate и явно дали решение:\\n\\nPUBLISH APPROVED CANDIDATE\\n\\nWeb Designer получает ограниченное publish-only разрешение только для этого точно принятого candidate.\\n\\nТогда разрешено:\\n\\nсоздать feature branch от указанного baseline;\\nсоздать commit, содержащий только accepted candidate;\\npush этого feature branch;\\nсоздать Draft PR в main.\\n\\nПеред публикацией должен быть доказан exact match между публикуемым diff и принятым artifact.\\n\\nДаже после PUBLISH APPROVED CANDIDATE Web Designer не имеет права:\\n\\nизменять main;\\nmerge;\\ndeploy;\\nrelease;\\nсоздавать production tag;\\nforce-push или переписывать history без отдельного прямого разрешения;\\nдобавлять изменения после acceptance;\\nрасширять scope;\\nменять backend/API/security/data/business/system logic.\\n\\nPublication permission относится только к chain-of-custody принятого presentation artifact и не расширяет техническую область роли.\\n4. Результат работы Web Designer\\n\\n\\nСтандартный pre-acceptance deliverable:\\n\\nPATCH\\n\\nили эквивалентный unified diff, который можно проверить и применить к указанному baseline проекта.\\n\\nДо решения PUBLISH APPROVED CANDIDATE Web Designer не публикует результат в repository.\\n\\nНормальная последовательность:\\n\\nWeb Designer\\n    ↓\\npresentation candidate / PATCH\\n    ↓\\nTech Lead + Owner scope review\\n    ↓\\ntest gate\\n    ↓\\nvisual acceptance\\n    ↓\\nACCEPTED CANDIDATE\\n    ↓\\nPUBLISH APPROVED CANDIDATE\\n    ↓\\nexact-match publication by Web Designer OR team\\n    ↓\\nfeature branch + commit + Draft PR\\n    ↓\\nOwner-controlled merge\\n    ↓\\nserver / production delivery by team\\n    ↓\\nreal runtime verification\\n    ↓\\nproduction acceptance\\n\\nCoder не требуется только для чисто presentation-only публикации, если accepted candidate не затрагивает backend/API/data/security/system logic.\\n5. Тесты\\n\\nWeb Designer не запускает тесты.\\n\\nЭто не является недостатком его handoff.\\n\\nОн не обязан предоставлять:\\n\\npytest\\ncompileall\\ngit diff --check\\nfrontend tests\\nfull repository suite\\n\\nПроверки выполняют:\\n\\nTech Lead\\nAssistant Tech Lead\\nOwner\\n\\nпосле получения патча.\\n\\nWeb Designer также не имеет права изменять tests, даже если считает, что какой-либо существующий тест мешает его изменению.\\n\\n6. Стандартная рабочая область\\n\\nОсновная область Web Designer:\\n\\napp/admin_web/static/admin.css\\n\\napp/admin_web/templates/admin/base.html\\napp/admin_web/templates/admin/home.html\\napp/admin_web/templates/admin/devices.html\\napp/admin_web/templates/admin/device.html\\napp/admin_web/templates/admin/visits.html\\napp/admin_web/templates/admin/observations.html\\n\\nТо есть основное направление:\\n\\nHTML layout\\n+\\nCSS presentation\\n\\nЭти файлы являются default patch allowlist.\\n\\n7. Login и Admin Shell\\n\\nФайлы:\\n\\napp/admin_web/templates/admin_login.html\\napp/admin_web/templates/admin_shell.html\\n\\nне входят в свободную постоянную область.\\n\\nИх изменение разрешается только тогда, когда конкретный TASK прямо касается:\\n\\nAdmin Login UI\\nили\\nAdmin Shell UI\\n\\nПричина — эти страницы находятся ближе к authentication/security UX.\\n\\n8. JavaScript\\n\\nФайл:\\n\\napp/admin_web/static/admin.js\\n\\nпо умолчанию:\\n\\nREAD: YES\\nPATCH/MODIFY: NO\\n\\nWeb Designer может изучать его, чтобы понимать:\\n\\nкакие элементы используются JavaScript;\\nкакие HTML hooks необходимо сохранить;\\nкак данные отображаются;\\nкакие состояния страницы существуют.\\n\\nНо самостоятельно включать изменения admin.js в patch нельзя.\\n\\n9. Почему JavaScript ограничен\\n\\nВ admin.js находится не только presentation layer.\\n\\nТам может находиться:\\n\\nработа с Admin API;\\nfetch;\\nrefresh;\\ntimers;\\nобработка response;\\nclient-side state;\\nloading;\\nerrors;\\npagination;\\nformatting;\\nnavigation;\\ninteraction logic.\\n\\nПоэтому изменение JS требует дополнительного контроля.\\n\\n10. Временное расширение полномочий\\n\\nГраницы роли не являются абсолютным запретом.\\n\\nЕсли для выполнения нашей конкретной задачи требуется изменение вне стандартного allowlist, Web Designer должен сообщить об этом.\\n\\nПосле этого:\\n\\nOwner / Tech Lead / Assistant Tech Lead могут явно разрешить выход за стандартные границы.\\n\\nТакое разрешение действует:\\n\\nтолько для конкретного TASK;\\nтолько для конкретных файлов;\\nтолько для конкретного изменения;\\nпод нашим контролем;\\nне становится постоянным расширением роли.\\n11. Формат временного разрешения\\n\\nНапример:\\n\\nWEB DESIGN EXCEPTION\\n\\nTask:\\nDisplay Current Traffic in GB instead of KB.\\n\\nAdditional authorized file:\\napp/admin_web/static/admin.js\\n\\nAuthorized change:\\nPresentation-only unit formatting for Current Traffic.\\n\\nForbidden:\\n- API changes\\n- fetch changes\\n- backend changes\\n- refresh changes\\n- timeout changes\\n- source field changes\\n- new analytics\\n- unrelated refactoring\\n\\nПосле завершения этого TASK разрешение автоматически прекращается.\\n\\n12. Presentation logic разрешена\\n\\nWeb Designer не должен трактовать любое вычисление как запрещённую «бизнес-логику».\\n\\nЕсли мы прямо поручили:\\n\\nПоказывать существующее значение в другой единице.\\n\\nэто нормальная задача presentation layer.\\n\\nНапример:\\n\\nKB → MB\\nKB → GB\\n\\nbytes → MB\\n\\nseconds → minutes/seconds\\n\\nISO timestamp → readable date/time\\n\\n0.853 → 85.3%\\n\\nможет быть разрешено.\\n\\nГлавное условие:\\n\\nИсходное значение и его смысл не изменяются — изменяется только способ отображения пользователю.\\n\\n13. Пример допустимой задачи\\n\\nBackend предоставляет:\\n\\n12582912 KB\\n\\nМы ставим задачу:\\n\\nОтображать traffic пользователю в GB с двумя знаками после запятой.\\n\\nWeb Designer может реализовать:\\n\\n12.00 GB\\n\\nЕсли для этого необходимо временно изменить admin.js, он сообщает об этом, получает наше разрешение и выполняет только указанное преобразование.\\n\\nОн не должен отвечать:\\n\\nЭто логика, поэтому делать не буду.\\n\\nЕсли изменение прямо поручено командой как presentation transformation, оно входит в задачу.\\n\\n14. Что уже является новой системной логикой\\n\\nБез отдельного архитектурного решения нельзя самостоятельно придумывать:\\n\\ntraffic / clients = efficiency\\n\\nRSSI + SNR = Wi-Fi quality score\\n\\nvisits / devices = loyalty\\n\\ntraffic today / yesterday = performance score\\n\\nauthorized / active = health percentage\\n\\nЭто уже новые показатели и новая семантика.\\n\\nWeb Designer может предложить идею, но не реализует её самостоятельно.\\n\\n15. Работа с карточками / плашками\\n\\nWeb Designer имеет право:\\n\\nперемещать карточки;\\nменять их размер;\\nменять ширину;\\nменять высоту;\\nрасполагать их рядом;\\nменять количество колонок;\\nиспользовать grid/flex;\\nобъединять несколько карточек визуально;\\nразделять большую карточку;\\nменять background;\\nborder;\\nradius;\\nshadow;\\nspacing;\\nalignment;\\ntypography;\\nhierarchy;\\nresponsive layout.\\n\\nНапример:\\n\\nClients\\nTraffic\\nAccess Points\\n\\nможно визуально превратить из трёх отдельных карточек в один общий dashboard block.\\n\\nНо это не означает, что их backend sources или API contracts должны объединяться.\\n\\n16. Визуальное объединение ≠ объединение данных\\n\\nНапример:\\n\\nCurrent Clients: 48\\nCurrent Traffic: 14.2 GB\\nAP Online: 2\\n\\nмогут находиться внутри одного визуального container.\\n\\nНо Web Designer самостоятельно не должен:\\n\\nсоздавать общий backend endpoint;\\nобъединять API responses;\\nменять Analytics;\\nменять Current State;\\nменять source ownership.\\n17. HTML разрешено изменять с сохранением контрактов\\n\\nWeb Designer может менять:\\n\\ndiv\\nsection\\nheader\\ncontainers\\nwrappers\\nCSS classes\\nвизуальный порядок блоков\\nlayout structure\\n\\nНо существующие технические hooks должны рассматриваться как контракт.\\n\\nБез специального разрешения нельзя удалять или переименовывать:\\n\\nid\\ndata-*\\nname\\nform action\\nmethod\\nCSRF fields\\nJinja variables\\nJinja expressions\\nAPI-related attributes\\nJS hooks\\nloading hooks\\nerror hooks\\npagination hooks\\nnavigation hooks\\n18. Правило неизвестного HTML hook\\n\\nЕсли Web Designer не уверен:\\n\\nЭтот id, class или data-* используется только для CSS или ещё и JavaScript?\\n\\nправило:\\n\\nНЕ МЕНЯТЬ.\\n\\nСначала сообщить команде.\\n\\n19. CSS\\n\\nCSS является основной свободной рабочей областью Web Designer.\\n\\nРазрешено:\\n\\nдобавлять classes;\\nменять existing visual classes;\\nиспользовать media queries;\\nменять layout;\\ntypography;\\nmargins/padding;\\nborder;\\ncolors;\\nshadows;\\nresponsive behaviour.\\n\\nПредпочтительны локально scoped selectors.\\n\\n20. Глобальный CSS\\n\\nБез необходимости избегать:\\n\\ndiv { ... }\\nspan { ... }\\ntable { ... }\\nbutton { ... }\\n\\nесли такое правило может неожиданно изменить весь Admin Console.\\n\\nПредпочтительно:\\n\\nконкретный component class\\nили\\npage-scoped selector\\n21. Цвета и смысл состояния\\n\\nWeb Designer может менять цветовую палитру.\\n\\nНо нельзя случайно уничтожать semantic distinction между состояниями:\\n\\nhealthy\\nstale\\ndegraded\\nunavailable\\nerror\\nauthorized\\npending\\nunknown\\n\\nЕсли цвет используется как часть смыслового обозначения состояния, Web Designer должен сохранить понятное различие.\\n\\n22. Текст интерфейса\\n\\nWeb Designer имеет право предложить улучшение коротких UI labels.\\n\\nНо изменение текста не должно менять смысл данных.\\n\\nНапример потенциально допустимо:\\n\\nCurrent Clients\\n→\\nClients Online\\n\\nтолько если эти понятия действительно эквивалентны в данном месте.\\n\\nНедопустимо самостоятельно:\\n\\nActive clients\\n→\\nAuthorized clients\\n\\nесли source population включает не только авторизованных клиентов.\\n\\n23. Если смысл термина неизвестен\\n\\nНе угадывать.\\n\\nНапример:\\n\\nactive\\nauthorized\\npending\\nvisit\\ndevice\\ncurrent\\nobservation\\ntraffic\\n\\nимеют конкретную архитектурную семантику CaptivPortal.\\n\\nЕсли термин кажется неудобным для UI — предложить новый вариант и запросить подтверждение.\\n\\n24. Источники данных\\n\\nWeb Designer не меняет самостоятельно:\\n\\nоткуда приходит значение\\nкакой endpoint используется\\nкакая DB является source\\nкакой сервис рассчитывает показатель\\nкак данные собираются\\n\\nBrowser остаётся presentation layer.\\n\\n25. Запрещённые backend области\\n\\nБез нашего специального разрешения patch не должен содержать изменения в:\\n\\napp/admin_web/routes.py\\napp/admin_web/runtime.py\\napp/admin_web/query_service.py\\napp/admin_web/read_gateway.py\\napp/admin_web/device_gateway.py\\napp/admin_web/config.py\\n\\napp/analytics/\\napp/current_state/\\napp/observations/\\napp/visit_lifecycle/\\napp/visitor_registry/\\napp/auth/\\napp/capport/\\napp/controllers/\\napp/integrations/\\napp/pending_sessions/\\n\\napp/config.py\\napp/settings.py\\nrun.py\\n26. Security — отдельная закрытая область\\n\\nWeb Designer самостоятельно не меняет:\\n\\nAdmin authentication;\\nsession mechanism;\\ncookies;\\npassword handling;\\nCSRF;\\nCSP;\\nHTTPS requirements;\\nnetwork allowlist;\\nSite allowlist;\\nredirects security;\\nlogin throttling;\\nauthorization checks.\\n\\nКрасивый дизайн не является основанием ослаблять security boundary.\\n\\n27. Новые зависимости\\n\\nБез специального разрешения запрещено добавлять:\\n\\nReact\\nVue\\nAngular\\njQuery\\nBootstrap\\nTailwind\\nChart.js\\nnpm packages\\nexternal icon libraries\\nexternal font libraries\\n28. Внешние CDN/resources\\n\\nБез разрешения нельзя добавлять:\\n\\n<script src=\\"https://...\\">\\n<link href=\\"https://...\\">\\n<img src=\\"https://...\\">\\n\\nили любые другие сторонние runtime dependencies.\\n\\n29. Responsive design\\n\\nResponsive design входит в полномочия Web Designer.\\n\\nОн может улучшать отображение для:\\n\\ndesktop\\nlaptop\\ntablet\\nmobile\\nsmall viewport\\n\\nПри этом functionality и важные данные не должны становиться недоступными.\\n\\n30. Accessibility\\n\\nВходит в полномочия Web Designer:\\n\\nreadability;\\ncontrast;\\nразмер текста;\\nspacing;\\nfocus visibility;\\nvisual hierarchy;\\nresponsive usability;\\nsemantic HTML, если это не ломает существующие contracts.\\n31. Работа от baseline\\n\\nКаждая задача должна содержать baseline repository.\\n\\nНапример:\\n\\nRepository:\\nZaurNavi/CaptivePortal\\n\\nBranch:\\nmain\\n\\nBaseline:\\n<exact commit SHA>\\n\\nPatch должен рассчитываться именно на этот baseline.\\n\\n32. Если repository изменился\\n\\nЕсли Web Designer обнаруживает, что актуальный main отличается от baseline TASK и изменения затрагивают его рабочую область:\\n\\nне пытаться самостоятельно разрешать конфликт.\\n\\nСообщить:\\n\\nBASELINE DRIFT DETECTED\\n\\nExpected baseline:\\n...\\n\\nCurrent repository:\\n...\\n\\nAffected files:\\n...\\n\\nPatch not rebased without team approval.\\n33. Scope discipline\\n\\nЕсли TASK:\\n\\nПереместить Current Traffic card ниже Live Clients.\\n\\nэто не является разрешением:\\n\\nпереписывать весь admin.css;\\nизменять Navigation;\\nпеределывать Visits;\\nизменять Login;\\nрефакторить admin.js;\\nменять unrelated classes.\\n\\nPatch должен быть минимально необходимым для поставленной задачи.\\n\\n34. Разрешены предложения\\n\\nWeb Designer может предлагать улучшения вне текущего TASK.\\n\\nНо они должны быть отделены:\\n\\nOPTIONAL DESIGN PROPOSAL\\n\\nи не должны попадать в patch без нашего утверждения.\\n\\n35. Если для дизайна не хватает данных\\n\\nНе создавать backend самостоятельно.\\n\\nНужно сообщить:\\n\\nDESIGN DEPENDENCY\\n\\nRequested UI:\\n...\\n\\nMissing data:\\n...\\n\\nCurrent frontend does not provide:\\n...\\n\\nSuggested requirement:\\n...\\n\\nBackend/API change:\\nNOT ATTEMPTED\\n\\nДальше решение принимает команда.\\n\\n36. Выход за полномочия\\n\\nЕсли необходим out-of-scope change, Web Designer не обязан полностью останавливать всю работу.\\n\\nОн должен:\\n\\nвыполнить всё, что возможно в своей области;\\nобозначить конкретное ограничение;\\nзапросить разрешение на необходимое расширение;\\nдождаться нашего решения;\\nпосле разрешения работать только в указанном scope.\\n37. Формат запроса на расширение\\nWEB DESIGN SCOPE EXCEPTION REQUEST\\n\\nTask:\\n...\\n\\nCurrent authorized scope:\\n...\\n\\nRequired additional change:\\n...\\n\\nRequired file:\\n...\\n\\nWhy it is necessary:\\n...\\n\\nExpected effect:\\n...\\n\\nBackend/API/security impact:\\nNONE / explain\\n\\nWork outside current authority:\\nNOT YET PERFORMED\\n38. Наше разрешение является главным\\n\\nЕсли Owner / Tech Lead явно поручает:\\n\\nИзмени отображение этого значения с KB на GB.\\n\\nэто уже является утверждённым требованием.\\n\\nWeb Designer не должен отказываться только потому, что для реализации требуется несколько строк presentation logic.\\n\\nЕсли необходим закрытый файл — запросить разрешение именно на файл.\\n\\n39. Но разрешение нельзя расширять самостоятельно\\n\\nЕсли разрешено:\\n\\nadmin.js:\\nизменить formatter KB → GB\\n\\nэто не разрешает:\\n\\nрефакторить formatter framework;\\nменять другие units;\\nменять traffic calculation;\\nменять API;\\nменять refresh;\\nчистить соседний JS;\\nпереписывать unrelated functions.\\n40. Принцип минимального исключения\\n\\nЛюбое расширение полномочий должно быть:\\n\\nминимальным\\nконкретным\\nвременным\\nпроверяемым\\n41. Production\\n\\nWeb Designer не работает с production.\\n\\nЗапрещено:\\n\\nSSH\\nsystemctl\\nproduction ENV\\nproduction DB\\nOmada configuration\\nproduction files\\nserver deployment\\n\\nProduction operations выполняем мы.\\n\\n42. Web Designer не отвечает за release\\n\\n\\nДо acceptance его обычная ответственность заканчивается на:\\n\\nготовый patch\\n+\\nописание визуальных изменений\\n+\\nописание известных ограничений.\\n\\nЕсли после acceptance дано явное:\\n\\nPUBLISH APPROVED CANDIDATE\\n\\nWeb Designer может дополнительно выполнить только publication chain-of-custody:\\n\\nfeature branch\\n+\\naccepted-candidate-only commit\\n+\\npush feature branch\\n+\\nDraft PR.\\n\\nMerge, server deployment, release и production verification остаются ответственностью команды / Owner.\\n\\nCoder для такой чисто presentation-only публикации не требуется, пока не затронуты backend/API/data/security/system logic.\\n43. Финальный handoff\\n\\n\\nДо publication завершённая задача передаётся как:\\n\\nWEB DESIGN HANDOFF\\n\\nRepository:\\nZaurNavi/CaptivePortal\\n\\nBaseline:\\n<commit SHA>\\n\\nTask:\\n<что было поручено>\\n\\nResult:\\n<что сделано>\\n\\nChanged files proposed by patch:\\n- ...\\n\\nVisual changes:\\n- ...\\n\\nPresentation transformations:\\n- ...\\nили NONE\\n\\nApproved scope exceptions used:\\n- ...\\nили NONE\\n\\nJavaScript changed:\\nYES / NO\\n\\nIf YES:\\nApproved purpose:\\n...\\n\\nBackend changes:\\nNO\\n\\nAPI changes:\\nNO\\n\\nAuthentication/security changes:\\nNO\\n\\nDependencies added:\\nNO\\n\\nTests executed:\\nNOT OWNED BY WEB DESIGNER — acceptance evidence belongs to Tech Lead / Owner\\n\\nTests modified:\\nNO / only if separately authorized in exact accepted candidate\\n\\nGitHub write operations:\\nNO, unless PUBLISH APPROVED CANDIDATE was explicitly granted\\n\\nProduction touched:\\nNO\\n\\nKnown limitations:\\n- ...\\n\\nOptional design proposals not included in patch:\\n- ...\\n\\nDeliverable:\\n<patch>\\n\\nЕсли Web Designer выполнил разрешённую publication, обязателен дополнительный блок:\\n\\nWEB DESIGN PUBLICATION HANDOFF\\n\\nTASK:\\n...\\n\\nBaseline SHA:\\n...\\n\\nBranch:\\n...\\n\\nCommit SHA:\\n...\\n\\nChanged files:\\n- ...\\n\\nDiff stat:\\n...\\n\\nExact accepted artifact match:\\nPASS\\n\\nNO EXTRAS:\\nPASS\\n\\nDraft PR:\\n#<number> / <URL>\\n\\nMERGE=NO\\nDEPLOY=NO\\n\\nPublication handoff не заменяет Owner/Tech Lead acceptance и не даёт право на merge/deploy.\\n44. Если работа не может быть завершена\\n\\nФормат:\\n\\nWEB DESIGN HANDOFF — PARTIAL / BLOCKED\\n\\nCompleted within authorized scope:\\n- ...\\n\\nBlocked part:\\n- ...\\n\\nRequired scope exception:\\n- ...\\n\\nNo unauthorized changes were included.\\n45. Критическое правило патча\\n\\nPatch не должен содержать скрытых «улучшений заодно».\\n\\nВсе изменения должны относиться либо:\\n\\nк поставленному TASK;\\nк явно утверждённому scope exception.\\n\\nВсё остальное исключается.\\n\\n46. Основной архитектурный запрет\\n\\nWeb Designer не должен превращать Browser/Admin UI в новый calculation/backend layer.\\n\\nОжидаемая модель остаётся:\\n\\nbackend / read services / analytics\\n            ↓\\n        Admin API\\n            ↓\\n          browser\\n            ↓\\n       presentation\\n47. При конфликте красоты и архитектуры\\n\\nЕсли существует выбор:\\n\\nA — хороший UI без нарушения существующего контракта;\\n\\nB — ещё более красивый UI,\\n    но для него нужно самостоятельно ломать архитектурную границу;\\n\\nвыбирается A.\\n\\nВариант B можно предложить команде как отдельное изменение.\\n\\n48. При конфликте правил и прямого поручения\\n\\nЕсли конкретный TASK от Owner / Tech Lead явно расширяет стандартные полномочия, действует TASK.\\n\\nНо только в пределах явно разрешённого изменения.\\n\\nТо есть постоянные правила задают default boundary, а утверждённый TASK может дать controlled exception.\\n\\n49. Что мы ожидаем от Web Designer\\n\\nМы хотим, чтобы Web Designer:\\n\\nсвободно мыслил визуально;\\nпредлагал улучшения;\\nне боялся менять расположение интерфейса;\\nулучшал читаемость;\\nнаходил слабые места UI;\\nпредлагал лучший responsive layout;\\nделал Admin Console цельной и профессиональной.\\n\\nМы не хотим, чтобы ограничения роли превращали его в человека, который способен только менять color: red на color: blue.\\n\\nЕсли для нормального UI нужна небольшая presentation transformation — нужно обозначить её и получить разрешение.\\n\\n50. Что команда хочет предотвратить\\n\\nГлавная цель ограничений — не мешать дизайнеру.\\n\\nЦель — не допустить ситуации:\\n\\n\\"Я переделывал карточку Traffic\\nи заодно немного изменил endpoint,\\nформулу,\\nrefresh,\\nauthentication\\nи query service,\\nпотому что так было удобнее.\\"\\n\\nТакого быть не должно.\\n\\n51. Итоговая модель полномочий\\n\\nПостоянно:\\n\\nREAD:\\nвесь repository\\n\\nPATCH:\\nAdmin HTML/CSS allowlist\\n\\nПо отдельному TASK:\\n\\nPATCH:\\nadmin_login.html\\nadmin_shell.html\\n\\nПо явному временному исключению:\\n\\nadmin.js\\nили другой конкретный необходимый файл\\n\\nBackend/security/API:\\n\\nтолько по специальному решению команды\\nи под отдельным техническим контролем\\n\\nGitHub до acceptance/publication approval:\\n\\nREAD ONLY\\n\\nGitHub после literal approval PUBLISH APPROVED CANDIDATE:\\n\\nfeature branch from exact baseline\\naccepted-candidate-only commit\\npush feature branch\\nDraft PR to main\\n\\nGitHub всё равно запрещено:\\n\\nmodify main\\nmerge\\ndeploy/release\\nforce-push/history rewrite без отдельного разрешения\\nscope expansion\\npost-acceptance extras\\n\\nTests:\\n\\nне являются ответственностью Web Designer; изменение tests требует отдельного явного разрешения в exact candidate\\n\\nDeployment:\\n\\nне выполняется Web Designer\\n\\n52. Финальное правило\\n\\nWeb Designer отвечает за presentation layer Admin Console. Он имеет свободу внутри визуальной области, но любые изменения системной логики, API, security или закрытых файлов выполняются только после явного разрешения Owner / Tech Lead.\\n\\nЕго стандартный рабочий продукт до acceptance — patch. После Owner + Tech Lead acceptance и literal разрешения PUBLISH APPROVED CANDIDATE Web Designer может выполнить только точную publication accepted artifact в feature branch + commit + push + Draft PR.\\n\\nMerge, deployment, release и production operations остаются вне полномочий Web Designer.\\n", "task_main": "# TASK-WEB-ASSET-LIBRARY-01 — Admin Web Local Asset Library — FINAL\\n\\nStatus: CLOSED / PRODUCTION PASS\\nUpdated: 2026-09-12\\n\\n## Final status\\n\\n```text\\nTASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS\\nTASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS\\n```\\n\\n## Purpose\\n\\nAdd a repository-local Admin Web icon asset library. The first production use is\\na decorative Android icon displayed before the unchanged `device_type` text.\\n\\nThe icon is presentation only. It does not change source data, API semantics,\\ndevice classification or backend behavior.\\n\\n## Initial implementation — PR #113\\n\\n```text\\nbranch=feature/web-asset-library-01\\nbase=61eac8d1b56fb2c00fe9cea751be7dced3239c64\\naccepted commit=0b3a692684d5d87ca7b96cf75c722dda7e2e8cf3\\nPR=#113\\nmerge=5d1a590d1d575eeea8148ca868b9de5183c0fff5\\nchanged files=6\\ndiff stat=+39/-1\\n```\\n\\nAndroid asset:\\n\\n```text\\napp/admin_web/static/icons/platforms/android.svg\\nSHA256=2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc\\n```\\n\\nInitial production matching used exact:\\n\\n```text\\ndevice_type === \\"Android\\"\\n```\\n\\nReal production data exposed a presentation-only defect:\\n\\n```text\\nproduction device_type=android\\n\\"android\\" !== \\"Android\\"\\n```\\n\\nBackend/API/data contracts remained correct.\\n\\n## Production FIX — PR #114\\n\\n```text\\npatch=TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION.patch\\npatch SHA256=c11bba2544124bc448f1d1a63a295dda479f0ab81cd430e2dbd6cc829509189b\\nbaseline=5d1a590d1d575eeea8148ca868b9de5183c0fff5\\nbranch=fix/web-asset-library-01-android-presentation\\naccepted commit=d207e048f0fcdec685d3bae1f8497fdbdcd611d4\\nPR=#114\\nmerge / production=043a13bc1e3aa3353e27af1859dc0bb698df4955\\nchanged files=4\\ndiff stat=+68/-23\\n```\\n\\nChanged files:\\n\\n```text\\napp/admin_web/static/admin.css\\napp/admin_web/static/admin.js\\napp/admin_web/static/icons/README.md\\ntests/admin_web/test_admin_ui_frontend.py\\n```\\n\\nFinal canonical predicate:\\n\\n```text\\ntypeof value === \\"string\\" && value.trim().toLowerCase() === \\"android\\"\\n```\\n\\nAccepted variants include `android`, `Android`, `ANDROID` and equivalents with\\nleading/trailing spaces.\\n\\nThe source text is displayed unchanged. `android` remains visually `android`.\\n\\nNo inference is permitted from hostname, MAC, vendor, SSID, AP, IP, history or\\nany other field. Non-Android values do not receive the Android icon.\\n\\n## Current presentation coverage\\n\\n```text\\nDevices list\\nDevice Detail / Identity\\nDevice Detail evidence\\nObservations when device_type is present\\n```\\n\\n## Acceptance\\n\\n```text\\npatch application=PASS\\ngit diff --check=PASS\\nbounded Admin Web tests=12/12 PASS\\ncase-insensitive Android matching=PASS\\nDevices list LAB visual=PASS\\nDevice Detail Identity LAB visual=PASS\\nDevice Detail evidence LAB visual=PASS\\nOwner visual acceptance=PASS\\n```\\n\\n## Production\\n\\n```text\\nHEAD=043a13bc1e3aa3353e27af1859dc0bb698df4955\\ntree=c2a9a01b2f8507c192fe2ef034ed4b9c850deed4\\nworktree=CLEAN\\ncaptive-portal.service=ACTIVE\\nadmin.js=HTTP 200\\nandroid.svg=HTTP 200\\nserved android.svg SHA256=2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc\\nasset identity=PASS\\nservice restart required for FIX=NO\\nOwner production visual acceptance=PASS\\n```\\n\\nOwner confirmed the icon in Devices list and Device Detail/cards while source text\\n`android` remained unchanged.\\n\\n## Permanent boundary\\n\\n```text\\nrepository-local presentation asset=YES\\nexternal runtime icon dependency=NO\\nbackend/API/data/security/business semantics changed=NO\\ndevice_type mutation=NO\\nplatform inference=NO\\n```\\n", "task_fix": "# TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION — FINAL\\n\\nStatus: CLOSED / PRODUCTION PASS\\nUpdated: 2026-09-12\\n\\n## Root cause\\n\\n```text\\nreal value=android\\ninitial predicate=exact \\"Android\\"\\n\\"android\\" !== \\"Android\\"\\n```\\n\\nThe failure was limited to presentation matching. Backend/API/data contracts were\\nnot defective.\\n\\n## Accepted FIX\\n\\n```text\\nbaseline=5d1a590d1d575eeea8148ca868b9de5183c0fff5\\npatch SHA256=c11bba2544124bc448f1d1a63a295dda479f0ab81cd430e2dbd6cc829509189b\\naccepted commit=d207e048f0fcdec685d3bae1f8497fdbdcd611d4\\nbranch=fix/web-asset-library-01-android-presentation\\nPR=#114\\nmerge=043a13bc1e3aa3353e27af1859dc0bb698df4955\\nchanged files=4\\ndiff stat=+68/-23\\n```\\n\\nCanonical predicate:\\n\\n```text\\ntypeof value === \\"string\\" && value.trim().toLowerCase() === \\"android\\"\\n```\\n\\nThe original source text remains unchanged and is rendered unchanged. No inference\\nfrom any other field is allowed.\\n\\n## Acceptance / production\\n\\n```text\\ngit diff --check=PASS\\nbounded Admin Web tests=12/12 PASS\\ncase-insensitive matching=PASS\\nOwner LAB visual acceptance=PASS\\nproduction delivery verification=PASS\\nOwner production visual acceptance=PASS\\nrestart required=NO\\nHEAD=043a13bc1e3aa3353e27af1859dc0bb698df4955\\ntree=c2a9a01b2f8507c192fe2ef034ed4b9c850deed4\\ncaptive-portal.service=ACTIVE\\n```\\n", "asset_block": "## Admin Web local asset library — production\\n\\n```text\\nTASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS\\nTASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS\\nPR #113=MERGED\\nPR #114=MERGED / PRODUCTION VERIFIED\\n```\\n\\nRepository-local presentation assets live under:\\n\\n```text\\napp/admin_web/static/icons/\\n```\\n\\nCurrent Android asset:\\n\\n```text\\nplatforms/android.svg\\nSHA256=2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc\\n```\\n\\nFinal Android presentation matching is case-insensitive:\\n\\n```text\\ntypeof value === \\"string\\" && value.trim().toLowerCase() === \\"android\\"\\n```\\n\\nThe source `device_type` text is displayed unchanged. The icon is a decorative\\npresentation cue only.\\n\\nNo platform inference is performed from hostname/MAC/vendor/SSID/AP/IP/history.\\nNon-Android values do not receive the Android icon.\\n\\nCurrent coverage includes Devices list, Device Detail identity/evidence, and\\nObservations when `device_type` is present.\\n\\nThe asset library adds no backend/API/data/security/business semantics and no\\nruntime CDN/third-party image dependency.\\n", "governance_block": "## Web Designer publication after acceptance\\n\\nThe Web Designer / Admin Console UI Designer role remains presentation-only.\\n\\nDefault flow:\\n\\n```text\\nlocal presentation candidate / PATCH\\n→ Tech Lead + Owner scope review\\n→ required test gate\\n→ visual acceptance\\n→ ACCEPTED CANDIDATE\\n```\\n\\nRepository write permission is not permanent. It is granted only after the exact\\ncandidate is accepted and Owner / Tech Lead explicitly issue:\\n\\n```text\\nPUBLISH APPROVED CANDIDATE\\n```\\n\\nThat authorization permits only:\\n\\n```text\\nfeature branch from specified baseline\\naccepted-candidate-only commit\\npush that feature branch\\nDraft PR to main\\n```\\n\\nBefore publication, exact match between accepted artifact and publication diff\\nmust be proven.\\n\\nStill forbidden without separate authorization:\\n\\n```text\\nmodify main\\nmerge\\ndeploy/release\\nforce-push/history rewrite\\npost-acceptance extras\\nscope expansion\\nbackend/API/data/security/business/system logic changes\\n```\\n\\nFor a purely presentation-only accepted candidate, a Coder is not required merely\\nto perform publication. If backend/API/data/security/system logic is touched, the\\ntask leaves this presentation-only publication path.\\n\\nPublication handoff must include TASK, baseline SHA, branch, commit SHA, changed\\nfiles, diff stat, exact accepted-artifact match, `NO EXTRAS`, Draft PR number/URL,\\n`MERGE=NO`, `DEPLOY=NO`.\\n"}')
BASE=P["base"]; TREE=P["tree"]; DATE=P["date"]; BRANCH=P["branch"]; SCOPE=sorted(P["scope"])

def cap(args,cwd,check=True):
    q=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                     encoding="utf-8",errors="replace")
    if check and q.returncode:
        if q.stdout: print(q.stdout,end="")
        if q.stderr: print(q.stderr,end="")
        raise SystemExit("STOP: command failed: "+" ".join(args))
    return q.stdout or "",q.stderr or ""

def text(args,cwd,check=True): return cap(args,cwd,check)[0]
def run(args,cwd):
    q=subprocess.run(args,cwd=cwd)
    if q.returncode: raise SystemExit("STOP: command failed: "+" ".join(args))

def norm(s): return s.replace("\r\n","\n").replace("\r","\n")
def read(p): return norm(Path(p).read_text(encoding="utf-8-sig"))
def write(p,s):
    p=Path(p); p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(norm(s),encoding="utf-8",newline="\n")

def paths(repo):
    out,_=cap(["git","status","--porcelain","--untracked-files=all"],repo)
    return sorted({x[3:].strip() for x in out.splitlines() if x})

def one(t,old,new,label):
    c=t.count(old)
    if c!=1: raise SystemExit(f"STOP: {label} matched {c} times")
    return t.replace(old,new,1)

def rx1(t,pat,repl,label,flags=0):
    r=re.compile(pat,flags); m=list(r.finditer(t))
    if len(m)!=1: raise SystemExit(f"STOP: {label} matched {len(m)} times")
    return r.sub(repl,t,count=1)

def before(t,anchor,block,label):
    if block.splitlines()[0] in t: raise SystemExit(f"STOP: {label} already applied")
    return one(t,anchor,block.rstrip()+"\n\n"+anchor,label)

def upd_date(t,path):
    if re.search(r"(?m)^Updated: \d{4}-\d{2}-\d{2}$",t):
        t=rx1(t,r"(?m)^Updated: \d{4}-\d{2}-\d{2}$",f"Updated: {DATE}",path+" date")
    return t

def upd_headers(t,path):
    rules=[
      (r"(?m)^Current-state implementation baseline: `main@[0-9a-f]{40}`$",f"Current-state implementation baseline: `main@{BASE}`"),
      (r"(?m)^Current implementation tree: `[0-9a-f]{40}`$",f"Current implementation tree: `{TREE}`"),
      (r"(?m)^Runtime implementation baseline: `main@[0-9a-f]{40}`$",f"Runtime implementation baseline: `main@{BASE}`"),
      (r"(?m)^Runtime tree: `[0-9a-f]{40}`$",f"Runtime tree: `{TREE}`"),
      (r"(?m)^Baseline: `main@[0-9a-f]{40}`$",f"Baseline: `main@{BASE}`"),
      (r"(?m)^Current repository implementation baseline: `main@[0-9a-f]{40}`$",f"Current repository implementation baseline: `main@{BASE}`"),
      (r"(?m)^Confirmed production deployed HEAD: `[0-9a-f]{40}`$",f"Confirmed production deployed HEAD: `{BASE}`"),
      (r"(?m)^Confirmed production tree: `[0-9a-f]{40}`$",f"Confirmed production tree: `{TREE}`"),
      (r"(?m)^Documentation/current-state implementation baseline: `main@[0-9a-f]{40}`$",f"Documentation/current-state implementation baseline: `main@{BASE}`"),
      (r"(?m)^Production deployed HEAD: `[0-9a-f]{40}`$",f"Production deployed HEAD: `{BASE}`"),
      (r"(?m)^Production tree: `[0-9a-f]{40}`$",f"Production tree: `{TREE}`"),
    ]
    for pat,repl in rules:
        if re.search(pat,t): t=rx1(t,pat,repl,path+" header")
    return t

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--repo",default=os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) / "Downloads" / "CaptivPortal-KB-Work")))
    ap.add_argument("--no-push",action="store_true")
    ns=ap.parse_args(); repo=Path(ns.repo)

    print("Publisher: WEB-ASSET-LIBRARY-KB-V3-EOL-FIX-2026-09-12")
    print("=== PRECHECK ===")
    if not (repo/".git").exists(): raise SystemExit(f"STOP: repo missing: {repo}")
    if paths(repo):
        print("Dirty:",*paths(repo),sep="\n  "); raise SystemExit("STOP: worktree must be clean")

    branch_now=text(["git","branch","--show-current"],repo).strip()
    if branch_now!="main":
        raise SystemExit(f"STOP: expected clean main after V1 stop, got branch: {branch_now}")

    run(["git","fetch","origin","main"],repo)
    remote=text(["git","rev-parse","origin/main"],repo).strip()
    tree=text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:",remote); print("origin tree:",tree)
    if remote!=BASE or tree!=TREE: raise SystemExit("STOP: origin/main moved; rebind package")

    run(["git","switch","main"],repo)
    run(["git","merge","--ff-only","origin/main"],repo)
    if paths(repo): raise SystemExit("STOP: main dirty after fast-forward")

    if text(["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo).strip():
        raise SystemExit("STOP: remote target branch already exists")
    local=text(["git","branch","--list",BRANCH],repo).strip()
    if local:
        if text(["git","rev-parse",BRANCH],repo).strip()!=BASE:
            raise SystemExit("STOP: local target branch advanced")
        run(["git","branch","-D",BRANCH],repo)

    print("=== ARTIFACT CONTRACT ===")
    # IMPORTANT: hash canonical Git object bytes, not Windows working-tree bytes.
    # core.autocrlf may materialize LF repository text as CRLF in the checkout.
    svg_blob,_=cap(["git","show",f"{BASE}:app/admin_web/static/icons/platforms/android.svg"],repo)
    got=hashlib.sha256(svg_blob.encode("utf-8")).hexdigest()
    print("android.svg canonical Git SHA256:",got)
    if got!=P["android_sha"]: raise SystemExit("STOP: canonical Android SVG SHA mismatch")

    # Prove the Windows working-tree difference, if any, is only checkout EOL translation.
    wt_bytes=(repo/"app/admin_web/static/icons/platforms/android.svg").read_bytes()
    wt_hash=hashlib.sha256(wt_bytes).hexdigest()
    print("android.svg working-tree SHA256:",wt_hash)
    canonical_bytes=svg_blob.encode("utf-8")
    expected_crlf_hash=hashlib.sha256(
        canonical_bytes.replace(b"\n",b"\r\n")
    ).hexdigest()
    print("android.svg expected CRLF checkout SHA256:",expected_crlf_hash)
    if wt_hash not in {got,expected_crlf_hash}:
        raise SystemExit("STOP: working-tree Android SVG differs beyond canonical LF/Windows CRLF forms")
    if wt_hash==expected_crlf_hash and wt_hash!=got:
        print("PASS: working-tree hash is exact Windows CRLF materialization of canonical Git blob")
    else:
        print("PASS: working-tree bytes equal canonical Git bytes")

    js_blob,_=cap(["git","show",f"{BASE}:app/admin_web/static/admin.js"],repo)
    if 'value.trim().toLowerCase() === "android"' not in js_blob: raise SystemExit("STOP: final Android predicate missing")
    if 'item.device_type === "Android"' in js_blob: raise SystemExit("STOP: old strict Android predicate remains")
    if "function deviceTypeValue" not in js_blob: raise SystemExit("STOP: deviceTypeValue helper missing")
    print("PASS: final Android implementation verified from canonical Git objects")

    run(["git","switch","-c",BRANCH],repo)

    for p in ["docs/agents/web-designer-role.md",
              "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md",
              "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md"]:
        if (repo/p).exists(): raise SystemExit("STOP: canonical new file already exists: "+p)

    print("=== APPLY ===")

    # README EN/RU common top identity and statuses.
    for path,arch_anchor,pending_pat,pending_repl in [
      ("README.md","## Traffic Projection lifecycle P0 — closed\n",
       r"The follow-on presentation task `TASK-WEB-DEVICE-UI-01` is \*\*IN PROGRESS / LAB\nREVIEW PENDING\*\*\.[\s\S]*?until separately accepted, merged and deployed\.",
       "The Devices presentation follow-on is now CLOSED / PRODUCTION ACTIVE through PR #110. "
       "The local Admin Web asset library and Android presentation FIX are also CLOSED / PRODUCTION PASS."),
      ("README_RU.md","## Traffic Projection lifecycle P0 — закрыт\n",
       r"Следующая presentation-layer задача `TASK-WEB-DEVICE-UI-01` имеет статус\n\*\*IN PROGRESS / LAB REVIEW PENDING\*\*\.[\s\S]*?отдельной приёмки, merge и deploy\.",
       "Presentation-layer задача `TASK-WEB-DEVICE-UI-01` теперь CLOSED / PRODUCTION ACTIVE через PR #110. "
       "Локальная библиотека Admin Web assets и Android presentation FIX также CLOSED / PRODUCTION PASS.")
    ]:
        t=read(repo/path)
        for label,val in [
          ("Repository implementation checkpoint",f"`main@{BASE}`"),
          ("Repository tree",f"`{TREE}`"),
          ("Production deployed HEAD",f"`{BASE}`"),
          ("Production tree",f"`{TREE}`")]:
            t=rx1(t,rf"(?m)^\| {re.escape(label)} \| .* \|$",f"| {label} | {val} |",path+" "+label)
        anchor="| Current Device Context | **TASK-DEVICE-CARD-01 — COMPLETE / PRODUCTION ACTIVE** |"
        repl=anchor+"\n| Device List Context | **TASK-DEVICE-LIST-CONTEXT-01 — CLOSED / PRODUCTION ACTIVE** |\n| Devices final UI | **TASK-WEB-DEVICE-UI-01 — CLOSED / PRODUCTION ACTIVE** |\n| Admin Web asset library | **TASK-WEB-ASSET-LIBRARY-01 + FIX — CLOSED / PRODUCTION PASS** |"
        t=one(t,anchor,repl,path+" status rows")
        t=rx1(t,pending_pat,pending_repl,path+" stale UI")
        t=before(t,arch_anchor,P["asset_block"],path+" asset block")
        write(repo/path,t)

    # docs/README
    path="docs/README.md"; t=upd_headers(upd_date(read(repo/path),path),path)
    row="| DEVICE-CARD-01 final production closure | `tasks/TASK-DEVICE-CARD-01-FINAL.md` |"
    repl=row+"\n| WEB-ASSET-LIBRARY-01 final production closure | `tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md` |\n| WEB-ASSET-LIBRARY-01 Android FIX closure | `tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md` |\n| Web Designer canonical role | `agents/web-designer-role.md` |"
    t=one(t,row,repl,path+" map")
    t=rx1(t,r"Follow-on UI work:\n\n```text\nTASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING\nMERGED = NO\nDEPLOYED = NO\nCURRENT PRODUCTION BEHAVIOR = NO\n```",
          "Current Devices presentation:\n\n```text\nTASK-DEVICE-LIST-CONTEXT-01 = CLOSED / PRODUCTION ACTIVE\nTASK-WEB-DEVICE-UI-01 = CLOSED / PRODUCTION ACTIVE\nPR #110 = MERGED / PRODUCTION VERIFIED\n```",path+" UI status")
    t=before(t,"## Traffic Projection lifecycle P0 closure\n",P["asset_block"],path+" asset")
    write(repo/path,t)

    # architecture/config/deployment
    path="docs/architecture.md"; t=upd_headers(upd_date(read(repo/path),path),path)
    arch="""### Admin Web local presentation assets

Admin Web uses repository-local static presentation assets under
`app/admin_web/static/icons/`.

This is a browser presentation layer only:

```text
source/API/data semantics unchanged
no runtime CDN/third-party image dependency
```

Platform icons are decorative cues and must not become a second device
classification engine. Source `device_type` remains authoritative.
"""
    t=before(t,"## 8. Admin Web\n",arch,path+" asset architecture"); write(repo/path,t)

    path="docs/configuration.md"; write(repo/path,upd_headers(upd_date(read(repo/path),path),path))

    path="docs/deployment.md"; t=upd_headers(upd_date(read(repo/path),path),path)
    dep=f"""## WEB-ASSET-LIBRARY-01 production history — 2026-09-12

Initial implementation:

```text
PR #113
accepted={PR113_HEAD}
merge={PR113_MERGE}
6 files / +39/-1
```

Real production data exposed a presentation-only case mismatch:
`device_type=android` did not satisfy the original exact `"Android"` predicate.

Production FIX:

```text
patch SHA256={FIX_PATCH_SHA}
baseline={PR113_MERGE}
accepted={PR114_HEAD}
PR #114
merge / production={BASE}
tree={TREE}
4 files / +68/-23
```

Delivery proof:

```text
captive-portal.service=ACTIVE
admin.js=HTTP 200
android.svg=HTTP 200
android.svg SHA256={ANDROID_SHA}
service restart for FIX=NOT REQUIRED
Owner production visual acceptance=PASS
```

No backend/API/data/security contract changed.
"""
    t=before(t,"## Feature activation\n",dep,path+" asset deploy"); write(repo/path,t)

    # module index
    path="docs/module-index.md"; t=upd_headers(upd_date(read(repo/path),path),path)
    anchor="| Device Current Context | current; default disabled | `app/admin_web/`, `app/current_state/read_service.py`, `app/analytics/current_guest_traffic.py` | `modules/admin-web.md`, `modules/current-state.md`, `modules/analytics.md` | reads Current State only; no new persistence | no |"
    repl=anchor+"\n| Device List Context | current; production active | `app/admin_web/device_gateway.py`, Device-list context components, Current State read service | `modules/admin-web.md` | historical registry + Current overlay; no new persistence | no |\n| Devices Web Designer presentation | current production presentation | `app/admin_web/static/admin.css`, `app/admin_web/static/admin.js` | `modules/admin-web.md`, `agents/web-designer-role.md` | none | no |\n| Admin Web local asset library | current production presentation | `app/admin_web/static/icons/` | `modules/admin-web.md` | static repository assets only | no |"
    t=one(t,anchor,repl,path+" rows")
    t=rx1(t,r"Owner-provided production checkpoint \d{4}-\d{2}-\d{2}:","Owner-provided production checkpoint 2026-09-12:",path+" date")
    t=rx1(t,r"HEAD: [0-9a-f]{40}\ntree: [0-9a-f]{40}",f"HEAD: {BASE}\ntree: {TREE}",path+" identity")
    needle="TASK-DEVICE-CARD-01 Current Device Context: COMPLETE / PRODUCTION ACTIVE"
    t=one(t,needle,needle+"\nTASK-DEVICE-LIST-CONTEXT-01: CLOSED / PRODUCTION ACTIVE\nTASK-WEB-DEVICE-UI-01: CLOSED / PRODUCTION ACTIVE\nTASK-WEB-ASSET-LIBRARY-01: CLOSED / PRODUCTION PASS\nTASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION: CLOSED / PRODUCTION PASS",path+" statuses")
    t=rx1(t,r"## Device UI follow-on\n\n```text\nTASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING\nNOT MERGED\nNOT DEPLOYED\nNOT CURRENT PRODUCTION\n```\n\nThis follow-on[\s\S]*?functional status\.",
          "## Devices UI / asset closure\n\n```text\nTASK-WEB-DEVICE-UI-01 = CLOSED / PRODUCTION ACTIVE\nTASK-WEB-ASSET-LIBRARY-01 = CLOSED / PRODUCTION PASS\nTASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION = CLOSED / PRODUCTION PASS\n```",path+" follow-on")
    write(repo/path,t)

    # admin web
    path="docs/modules/admin-web.md"; t=upd_headers(upd_date(read(repo/path),path),path)
    closure=f"""## Devices list / presentation current state

```text
TASK-DEVICE-LIST-CONTEXT-01=CLOSED / PRODUCTION ACTIVE
TASK-WEB-DEVICE-UI-01=CLOSED / PRODUCTION ACTIVE
PR #110=MERGED / PRODUCTION VERIFIED
merge={PR110_MERGE}
```

Global Online-first ordering remains backend-owned before pagination. The browser
renders server order and does not infer status semantics.

{P["asset_block"]}
"""
    t=before(t,"## Home\n",closure,path+" devices/assets")
    t=rx1(t,r"## UI/design status\n\nCurrent functional Device Detail / Traffic presentation is production-current,[\s\S]*?Current Traffic panel placement also remains production-current functional\ncomposition, not a permanently frozen final Traffic visual design\.",
          "## UI/design status\n\nDevices presentation is production-current through PR #110. "
          "The local asset library and Android presentation FIX are production-current through PR #113/#114. "
          "Presentation remains evolvable; backend/API/data/security semantics remain outside Web Designer ownership.\n\n"
          "Current Traffic panel placement remains production-current functional composition, not a permanently frozen final Traffic visual design.",path+" UI status")
    write(repo/path,t)

    # project inventory
    path="docs/project-inventory.md"; t=upd_date(read(repo/path),path)
    t=rx1(t,r"(?m)^Runtime commit: `[0-9a-f]{40}`$",f"Runtime commit: `{BASE}`",path+" commit")
    t=rx1(t,r"(?m)^Runtime tree: `[0-9a-f]{40}`$",f"Runtime tree: `{TREE}`",path+" tree")
    t=rx1(t,r"(?m)^Commit source: .*$","Commit source: merge PR #114 / Android presentation production FIX, 2026-09-12",path+" source")
    anchor="| Device Current Context | Admin Web + Current State + Current Guest Traffic | persisted Current State exact-device evidence | none | no |"
    repl=anchor+"\n| Device List Context | Admin Web + Registry/Visits + Current State | historical membership + Current presence overlay | none | no |\n| Devices final presentation | Admin Web static UI | accepted backend-provided Device fields | none | no |\n| Admin Web local asset library | `app/admin_web/static/icons/` | repository-local static presentation assets | none | no |"
    t=one(t,anchor,repl,path+" rows")
    prod=f"""## Admin Web asset library production state

```text
TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS
TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS
PR #113=MERGED
PR #114=MERGED / PRODUCTION VERIFIED
production HEAD={BASE}
production tree={TREE}
android.svg SHA256={ANDROID_SHA}
captive-portal.service=ACTIVE
Owner production visual acceptance=PASS
```

The Android cue preserves the exact source `device_type` text and does not create
a new classification source.
"""
    t=before(t,"## 13. Admin security facts\n",prod,path+" asset prod")
    t=t.replace("Follow-on:\n\n```text\nTASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING\nNOT MERGED\nNOT DEPLOYED\n```",
                "Subsequent closure:\n\n```text\nTASK-WEB-DEVICE-UI-01=CLOSED / PRODUCTION ACTIVE\nPR #110=MERGED / PRODUCTION VERIFIED\n```")
    write(repo/path,t)

    # testing
    path="docs/testing.md"; t=upd_headers(upd_date(read(repo/path),path),path)
    tests=f"""### Latest Admin Web presentation acceptance — WEB-ASSET-LIBRARY-01 + FIX

```text
TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS
TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS
PR #113 accepted={PR113_HEAD}
PR #113 merge={PR113_MERGE}
FIX patch SHA256={FIX_PATCH_SHA}
PR #114 accepted={PR114_HEAD}
PR #114 merge / production={BASE}
```

```text
patch application=PASS
git diff --check=PASS
bounded Admin Web tests=12/12 PASS
case-insensitive Android matching=PASS
Devices list LAB visual=PASS
Device Detail Identity LAB visual=PASS
Device Detail evidence LAB visual=PASS
Owner visual acceptance=PASS
production asset/API delivery verification=PASS
Owner production visual acceptance=PASS
```

The defect was presentation matching only. Backend/API/data semantics were not
changed.
"""
    anchor="### Latest Projection lifecycle P0 acceptance — TASK-TRAFFIC-PROJECTION-LIFECYCLE-CONSISTENCY-01\n"
    if anchor in t: t=before(t,anchor,tests,path+" asset tests")
    else: t=before(t,"### Latest Device acceptance evidence — TASK-DEVICE-CARD-01\n",tests,path+" asset tests")
    t=t.replace("Follow-on `TASK-WEB-DEVICE-UI-01` is not acceptance evidence for this TASK and is\nnot current production:\n\n```text\nIN PROGRESS / LAB REVIEW PENDING\nNOT MERGED\nNOT DEPLOYED\n```",
                "At DEVICE-CARD-01 acceptance time, `TASK-WEB-DEVICE-UI-01` was a separate pending follow-on. It subsequently closed through PR #110 and is current production presentation.")
    write(repo/path,t)

    # governance.
    path="docs/agents/workflow.md"; t=upd_date(read(repo/path),path); t=before(t,"## 6. Repository actions\n",P["governance_block"],path+" governance"); write(repo/path,t)
    path="docs/agents/repository-actions.md"; t=upd_date(read(repo/path),path); t=before(t,"## Protected\n",P["governance_block"],path+" governance"); write(repo/path,t)
    path="docs/agents/handoff.md"; t=upd_date(read(repo/path),path)
    hb="""### Web Designer publication handoff

When Web Designer publishes an accepted presentation-only candidate after explicit
`PUBLISH APPROVED CANDIDATE`, handoff must include:

```text
TASK:
baseline SHA:
branch:
commit SHA:
changed files:
diff stat:
exact accepted artifact match: PASS
NO EXTRAS: PASS
Draft PR: # / URL
MERGE=NO
DEPLOY=NO
```
"""
    t=before(t,"### Deployment / activation\n",hb,path+" handoff"); write(repo/path,t)

    # New canonical docs.
    write(repo/"docs/agents/web-designer-role.md",P["role_md"].rstrip()+"\n")
    write(repo/"docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md",P["task_main"].rstrip()+"\n")
    write(repo/"docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md",P["task_fix"].rstrip()+"\n")

    # Historical DEVICE-CARD file: preserve its 2026-09-09 truth, add later closure.
    path="docs/tasks/TASK-DEVICE-CARD-01-FINAL.md"; t=read(repo/path)
    t=rx1(t,r"## 19\. Separate UI/design work[\s\S]*?(?=## 20\. Final decision)",
          """## 19. Separate UI/design work — historical status and later closure

At TASK-DEVICE-CARD-01 closure, `TASK-WEB-DEVICE-UI-01` was outside that
functional candidate and was correctly pending.

Later accepted production state:

```text
TASK-DEVICE-LIST-CONTEXT-01=CLOSED / PRODUCTION ACTIVE
TASK-WEB-DEVICE-UI-01=CLOSED / PRODUCTION ACTIVE
PR #110=MERGED / PRODUCTION VERIFIED
```

Later Admin Web presentation work also closed:

```text
TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS
TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS
PR #113 / #114=MERGED
```

""",path+" section19",flags=re.M|re.S)
    t=t.replace("TASK-WEB-DEVICE-UI-01=NOT COMPLETE",
                "TASK-WEB-DEVICE-UI-01 at DEVICE-CARD-01 closure=NOT COMPLETE\nlater closure=PR #110 / CLOSED / PRODUCTION ACTIVE")
    write(repo/path,t)

    # Asset provenance README.
    path="app/admin_web/static/icons/README.md"; t=read(repo/path)
    t=one(t,
      "Production promotion of this branded asset requires the separate attribution/licensing review defined by `TASK-WEB-ASSET-LIBRARY-01`.",
      "The accepted Android asset is production-active under `TASK-WEB-ASSET-LIBRARY-01`; preserve this provenance/attribution record for future modification or replacement.",
      path+" production note")
    write(repo/path,t)

    actual=paths(repo)
    print("Changed files:")
    for p in actual: print(" ",p)
    if actual!=SCOPE:
        print("Expected:")
        for p in SCOPE: print(" ",p)
        raise SystemExit("STOP: exact KB scope mismatch")

    print("=== ASSERTIONS ===")
    checks={
      "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md":[
        "TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS",
        "TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS",
        'value.trim().toLowerCase() === "android"',P["android_sha"]],
      "docs/agents/web-designer-role.md":["PUBLISH APPROVED CANDIDATE","accepted-candidate-only commit","MERGE=NO","DEPLOY=NO"],
      "docs/agents/workflow.md":["PUBLISH APPROVED CANDIDATE","Draft PR to main"],
      "docs/modules/admin-web.md":["TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS",'value.trim().toLowerCase() === "android"'],
      "docs/deployment.md":[f"merge / production={BASE}","service restart for FIX=NOT REQUIRED"],
      "docs/testing.md":["bounded Admin Web tests=12/12 PASS","Owner production visual acceptance=PASS"],
    }
    for path,needles in checks.items():
        s=read(repo/path)
        for n in needles:
            if n not in s: raise SystemExit(f"STOP: missing assertion in {path}: {n}")

    for path in ["README.md","README_RU.md","docs/README.md","docs/module-index.md","docs/modules/admin-web.md","docs/project-inventory.md","docs/testing.md"]:
        s=read(repo/path)
        if "TASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING" in s or "STATUS=IN PROGRESS / LAB REVIEW PENDING" in s:
            raise SystemExit("STOP: stale Device UI current status remains in "+path)

    if "\nGitHub:\n\nREAD ONLY\n" in read(repo/"docs/agents/web-designer-role.md"):
        raise SystemExit("STOP: old absolute GitHub READ ONLY remains")

    for p in actual:
        if p.startswith("tests/"): raise SystemExit("STOP: tests changed by KB publisher")
        if p.startswith("app/") and p!="app/admin_web/static/icons/README.md":
            raise SystemExit("STOP: runtime app file changed by KB publisher: "+p)

    run(["git","diff","--check"],repo)
    print("PASS: exact 18-file KB scope")
    print("PASS: Asset Library + FIX production closure")
    print("PASS: Device UI status drift reconciled")
    print("PASS: Web Designer publication governance canonicalized")
    print("PASS: no runtime/test/backend/API/data/security mutation")
    print("PASS: git diff --check")

    run(["git","add","--"]+SCOPE,repo)
    run(["git","diff","--cached","--check"],repo)

    patch=Path(__file__).resolve().parent/"CaptivPortal_KB_WEB_ASSET_LIBRARY_2026-09-12.patch"
    with patch.open("wb") as fh:
        q=subprocess.run(["git","diff","--cached","--binary","--"]+SCOPE,cwd=repo,stdout=fh,stderr=subprocess.PIPE)
    if q.returncode or patch.stat().st_size<=0: raise SystemExit("STOP: patch generation failed")

    if ns.no_push:
        print("NO-PUSH: staged only"); print("Unified diff:",patch); return

    run(["git","commit","-m","docs: close Web Asset Library production state",
         "-m","Document WEB-ASSET-LIBRARY-01 and Android presentation FIX production closure, reconcile Devices UI status drift, and canonicalize Web Designer accepted-candidate publication governance."],repo)
    commit=text(["git","rev-parse","HEAD"],repo).strip()
    if paths(repo): raise SystemExit("STOP: worktree not clean after commit")

    run(["git","push","-u","origin",BRANCH],repo)

    body=f"""## Purpose

Canonical KB reconciliation for TASK-WEB-ASSET-LIBRARY-01 and its production
Android presentation FIX, plus related Devices/Web Designer status/governance drift.

## Production truth

- application / production HEAD: {BASE}
- tree: {TREE}
- PR #113: merged
- PR #114: merged / production verified
- Android asset SHA256: {P['android_sha']}
- Owner production visual acceptance: PASS

## Final presentation contract

Android device_type matching is case-insensitive:
`value.trim().toLowerCase() === "android"`.

Source text remains unchanged. No inference from other fields.

## Governance

After exact candidate acceptance and explicit `PUBLISH APPROVED CANDIDATE`, Web
Designer may publish only that accepted presentation artifact as feature branch +
commit + push + Draft PR. main/merge/deploy/release remain forbidden.

## Scope

- exactly 18 documentation/governance files
- runtime code changed: NO
- tests changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""
    pr=text(["gh","pr","create","--repo","ZaurNavi/CaptivePortal","--base","main","--head",BRANCH,
             "--title","Docs: close Web Asset Library production state","--body",body,"--draft"],repo).strip()

    print("=== FINAL ===")
    print("Branch:",BRANCH); print("Commit:",commit); print("Draft PR:",pr)
    print("Changed files: 18"); print("Runtime code changed: NO"); print("Tests changed: NO")
    print("Production changed: NO"); print("Merge performed: NO"); print("Unified diff:",patch)

if __name__=="__main__":
    main()
