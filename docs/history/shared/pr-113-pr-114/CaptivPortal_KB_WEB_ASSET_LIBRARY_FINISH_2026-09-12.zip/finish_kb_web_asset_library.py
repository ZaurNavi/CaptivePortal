from __future__ import annotations
import os, re, subprocess
from pathlib import Path

BASE='043a13bc1e3aa3353e27af1859dc0bb698df4955'
TREE='c2a9a01b2f8507c192fe2ef034ed4b9c850deed4'
BRANCH='docs/web-asset-library-production-kb-2026-09-12'
EXPECTED=['README.md', 'README_RU.md', 'app/admin_web/static/icons/README.md', 'docs/README.md', 'docs/agents/handoff.md', 'docs/agents/repository-actions.md', 'docs/agents/web-designer-role.md', 'docs/agents/workflow.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/admin-web.md', 'docs/project-inventory.md', 'docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md', 'docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md', 'docs/testing.md']
CURRENT=['README.md', 'README_RU.md', 'docs/README.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/admin-web.md', 'docs/project-inventory.md', 'docs/testing.md']

def cap(args,cwd,check=True):
    p=subprocess.run(
        args,cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        encoding="utf-8",
        errors="replace",
    )
    if check and p.returncode != 0:
        if p.stdout: print(p.stdout,end="")
        if p.stderr: print(p.stderr,end="")
        raise SystemExit("STOP: command failed: "+" ".join(args))
    return p.stdout or "", p.stderr or ""

def txt(args,cwd,check=True):
    return cap(args,cwd,check)[0]

def run(args,cwd):
    p=subprocess.run(args,cwd=cwd)
    if p.returncode != 0:
        raise SystemExit("STOP: command failed: "+" ".join(args))

def norm(s):
    return s.replace("\r\n","\n").replace("\r","\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def write(path,text):
    Path(path).write_text(norm(text),encoding="utf-8",newline="\n")

def status_paths(repo):
    out,_=cap(["git","status","--porcelain","--untracked-files=all"],repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def diff_names(repo,cached=False):
    args=["git","diff"]
    if cached:
        args.append("--cached")
    args += ["--name-only","--"]
    out,_=cap(args,repo)
    return sorted({line.strip() for line in out.splitlines() if line.strip()})

STALE_TOKENS = (
    "IN PROGRESS / LAB REVIEW PENDING",
    "MERGED=NO",
    "MERGED = NO",
    "NOT MERGED",
    "DEPLOYED=NO",
    "DEPLOYED = NO",
    "NOT DEPLOYED",
    "NOT CURRENT PRODUCTION",
    "CURRENT PRODUCTION BEHAVIOR = NO",
    "CURRENT PRODUCTION=NO",
    "ACCEPTED PRODUCTION BEHAVIOR=NO",
)

CANON_BLOCK = """```text
TASK-WEB-DEVICE-UI-01 = CLOSED / PRODUCTION ACTIVE
PR #110 = MERGED / PRODUCTION VERIFIED
```"""

FENCE_RE = re.compile(r"```text\n(?:(?!```).)*?TASK-WEB-DEVICE-UI-01(?:(?!```).)*?```", re.S)

def close_stale_device_ui_blocks(text):
    changed=False
    def repl(m):
        nonlocal changed
        block=m.group(0)
        if any(token in block for token in STALE_TOKENS):
            changed=True
            return CANON_BLOCK
        return block
    text=FENCE_RE.sub(repl,text)

    # Stale prose variants in current-state docs.
    prose_rules=[
        (
            r"The follow-on presentation task `TASK-WEB-DEVICE-UI-01` is \*\*IN PROGRESS / LAB\n"
            r"REVIEW PENDING\*\*\.[\s\S]*?until separately accepted, merged and deployed\.",
            "The Devices presentation follow-on `TASK-WEB-DEVICE-UI-01` is now **CLOSED / PRODUCTION ACTIVE** through PR #110."
        ),
        (
            r"Следующая presentation-layer задача `TASK-WEB-DEVICE-UI-01` имеет статус\n"
            r"\*\*IN PROGRESS / LAB REVIEW PENDING\*\*\.[\s\S]*?отдельной приёмки, merge и deploy\.",
            "Presentation-layer задача `TASK-WEB-DEVICE-UI-01` теперь **CLOSED / PRODUCTION ACTIVE** через PR #110."
        ),
        (
            r"Follow-on `TASK-WEB-DEVICE-UI-01` is not acceptance evidence for this TASK and is\n"
            r"not current production:",
            "At DEVICE-CARD-01 acceptance time, `TASK-WEB-DEVICE-UI-01` was a separate pending follow-on. "
            "It subsequently closed through PR #110 and is current production presentation:"
        ),
        (
            r"The follow-on `TASK-WEB-DEVICE-UI-01` is not part of this production rollout and\n"
            r"must not be represented as deployed/current until separately accepted\.",
            "At the time of that rollout, `TASK-WEB-DEVICE-UI-01` was not yet part of production. "
            "It subsequently closed through PR #110 and is now production-active."
        ),
    ]
    for pat,replacement in prose_rules:
        new,n=re.subn(pat,replacement,text,count=1)
        if n:
            changed=True
            text=new

    return text,changed

def assert_closed(path,text):
    if "TASK-WEB-DEVICE-UI-01" not in text:
        return
    # We only reject explicit current stale markers, not historical wording such as
    # "at acceptance time ... pending".
    explicit=[
        "TASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING",
        "TASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING",
        "STATUS=IN PROGRESS / LAB REVIEW PENDING",
        "CURRENT PRODUCTION BEHAVIOR = NO",
        "CURRENT PRODUCTION=NO",
        "NOT CURRENT PRODUCTION",
    ]
    for marker in explicit:
        if marker in text:
            raise SystemExit(f"STOP: explicit stale current status remains in {path}: {marker}")

def main():
    repo=Path(os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) /
            "Downloads" / "CaptivPortal-KB-Work")
    ))

    print("Finish: WEB-ASSET-LIBRARY KB publication")
    print("=== PRECHECK ===")

    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")

    branch=txt(["git","branch","--show-current"],repo).strip()
    head=txt(["git","rev-parse","HEAD"],repo).strip()
    print("branch:",branch)
    print("HEAD:",head)

    if branch != BRANCH:
        raise SystemExit("STOP: wrong branch")
    if head != BASE:
        raise SystemExit("STOP: branch HEAD moved")

    run(["git","fetch","origin","main"],repo)
    remote=txt(["git","rev-parse","origin/main"],repo).strip()
    tree=txt(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:",remote)
    print("origin tree:",tree)

    if remote != BASE or tree != TREE:
        raise SystemExit("STOP: main moved; re-review required")

    remote_branch=txt(
        ["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo
    ).strip()
    if remote_branch:
        raise SystemExit("STOP: remote publication branch already exists")

    current=status_paths(repo)
    if current != EXPECTED:
        print("Actual:")
        for p in current: print(" ",p)
        print("Expected:")
        for p in EXPECTED: print(" ",p)
        raise SystemExit("STOP: dirty scope differs from prepared KB reconciliation")
    if diff_names(repo,True):
        raise SystemExit("STOP: unexpected staged changes")

    print("PASS: exact prepared 15-file worktree")

    print("=== CLOSE REMAINING DEVICE-UI DRIFT ===")
    touched=[]
    for path in CURRENT:
        p=repo/path
        text=read(p)
        fixed,changed=close_stale_device_ui_blocks(text)
        if changed:
            write(p,fixed)
            touched.append(path)

    print("Normalized current-state files:")
    for p in touched:
        print(" ",p)

    print("=== FINAL CONTENT CHECK ===")
    for path in CURRENT:
        assert_closed(path,read(repo/path))

    required={
        "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md":[
            "TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS",
            "TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS",
            'value.trim().toLowerCase() === "android"',
            "2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc",
        ],
        "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md":[
            "Status: CLOSED / PRODUCTION PASS",
            "bounded Admin Web tests=12/12 PASS",
        ],
        "docs/agents/web-designer-role.md":[
            "PUBLISH APPROVED CANDIDATE",
            "accepted-candidate-only commit",
            "MERGE=NO",
            "DEPLOY=NO",
        ],
        "docs/agents/workflow.md":[
            "PUBLISH APPROVED CANDIDATE",
        ],
        "docs/deployment.md":[
            "PR #113",
            "PR #114",
            "service restart for FIX=NOT REQUIRED",
        ],
        "docs/testing.md":[
            "bounded Admin Web tests=12/12 PASS",
            "Owner production visual acceptance=PASS",
        ],
    }
    for path,needles in required.items():
        text=read(repo/path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: required closure evidence missing in {path}: {needle}")

    if status_paths(repo) != EXPECTED:
        raise SystemExit("STOP: unexpected file scope after normalization")

    run(["git","diff","--check"],repo)
    print("PASS: content")
    print("PASS: exact 15-file scope")
    print("PASS: git diff --check")

    print("=== COMMIT + PUSH ===")
    run(["git","add","--"]+EXPECTED,repo)
    run(["git","diff","--cached","--check"],repo)

    if diff_names(repo,True) != EXPECTED:
        raise SystemExit("STOP: staged scope mismatch")

    run([
        "git","commit",
        "-m","docs: close Web Asset Library production state",
        "-m","Document WEB-ASSET-LIBRARY-01 and Android presentation FIX production closure, reconcile Devices UI status drift, and canonicalize Web Designer accepted-candidate publication governance."
    ],repo)

    commit=txt(["git","rev-parse","HEAD"],repo).strip()
    if status_paths(repo):
        raise SystemExit("STOP: worktree not clean after commit")

    run(["git","push","-u","origin",BRANCH],repo)

    print("=== DRAFT PR ===")
    body=f"""## Purpose

Canonical KB reconciliation for TASK-WEB-ASSET-LIBRARY-01 and its production
Android presentation FIX, plus related Devices/Web Designer status/governance drift.

## Production truth

- application / production HEAD: {BASE}
- tree: {TREE}
- PR #113: merged
- PR #114: merged / production verified
- Owner production visual acceptance: PASS

## Final Android presentation contract

`value.trim().toLowerCase() === "android"`

Source `device_type` text remains unchanged. No inference from other fields.

## Web Designer governance

After exact candidate acceptance and explicit `PUBLISH APPROVED CANDIDATE`, Web
Designer may publish only the accepted presentation artifact as feature branch +
accepted-candidate-only commit + push + Draft PR.

`main`, merge, deploy and release remain prohibited.

## Scope

- exactly 15 documentation/governance files
- runtime code changed: NO
- tests changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""
    pr=txt([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main",
        "--head",BRANCH,
        "--title","Docs: close Web Asset Library production state",
        "--body",body,
        "--draft"
    ],repo).strip()

    print("=== DONE ===")
    print("Commit:",commit)
    print("Draft PR:",pr)
    print("Files: 15")
    print("MERGE=NO")
    print("DEPLOY=NO")

if __name__=="__main__":
    main()
