# CaptivPortal KB reconciliation — WEB-ASSET-LIBRARY-01

Date: 2026-09-12

## Verified live current state

```text
repository main=043a13bc1e3aa3353e27af1859dc0bb698df4955
repository tree=c2a9a01b2f8507c192fe2ef034ed4b9c850deed4
production HEAD=043a13bc1e3aa3353e27af1859dc0bb698df4955
production worktree=CLEAN
captive-portal.service=ACTIVE
```

PR history:

```text
PR #113 accepted=0b3a692684d5d87ca7b96cf75c722dda7e2e8cf3
PR #113 merge=5d1a590d1d575eeea8148ca868b9de5183c0fff5
PR #114 accepted=d207e048f0fcdec685d3bae1f8497fdbdcd611d4
PR #114 merge / production=043a13bc1e3aa3353e27af1859dc0bb698df4955
```

## Canonical status after reconciliation

```text
TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS
TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS
TASK-WEB-DEVICE-UI-01=CLOSED / PRODUCTION ACTIVE
```

## Android contract

```text
predicate=value.trim().toLowerCase() === "android"
asset SHA256=2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc
display source text unchanged
inference=NO
```

## Governance

Old absolute Web Designer GitHub READ ONLY publication wording is superseded.

After exact acceptance + literal:

```text
PUBLISH APPROVED CANDIDATE
```

Web Designer may only create feature branch, accepted-candidate-only commit, push
that branch, and create Draft PR. main/merge/deploy/release remain forbidden.

## Exact KB scope — 18 files

- `README.md`
- `README_RU.md`
- `app/admin_web/static/icons/README.md`
- `docs/README.md`
- `docs/agents/handoff.md`
- `docs/agents/repository-actions.md`
- `docs/agents/web-designer-role.md`
- `docs/agents/workflow.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/admin-web.md`
- `docs/project-inventory.md`
- `docs/tasks/TASK-DEVICE-CARD-01-FINAL.md`
- `docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md`
- `docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md`
- `docs/testing.md`

Publisher SHA256:
`c00fa5aed30d2b7498134a111d7494539b797f9d65ff182f0b1fd3dd611cefd5`

Revised standalone Web Designer role SHA256:
`4c80fb88e0325319ed6ec4e052f755c550bdaea19d07bc83f92e8afb3b26c3cf`
