from __future__ import annotations
import os,re,subprocess
from pathlib import Path

BASE='043a13bc1e3aa3353e27af1859dc0bb698df4955'
TREE='c2a9a01b2f8507c192fe2ef034ed4b9c850deed4'
BRANCH='docs/web-asset-library-production-kb-2026-09-12'
EXPECTED_V4_FILES=['README.md', 'README_RU.md', 'app/admin_web/static/icons/README.md', 'docs/README.md', 'docs/agents/handoff.md', 'docs/agents/repository-actions.md', 'docs/agents/web-designer-role.md', 'docs/agents/workflow.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/admin-web.md', 'docs/project-inventory.md', 'docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md', 'docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md', 'docs/testing.md']
CURRENT_DOCS=['README.md', 'README_RU.md', 'docs/README.md', 'docs/module-index.md', 'docs/modules/admin-web.md', 'docs/project-inventory.md', 'docs/testing.md']

def cap(args,cwd,check=True):
    p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                     encoding="utf-8",errors="replace")
    if check and p.returncode!=0:
        if p.stdout: print(p.stdout,end="")
        if p.stderr: print(p.stderr,end="")
        raise SystemExit("STOP: command failed: "+" ".join(args))
    return p.stdout or "",p.stderr or ""

def txt(args,cwd,check=True): return cap(args,cwd,check)[0]

def run(args,cwd):
    p=subprocess.run(args,cwd=cwd)
    if p.returncode!=0:
        raise SystemExit("STOP: command failed: "+" ".join(args))

def norm(s): return s.replace("\r\n","\n").replace("\r","\n")
def read(p): return norm(Path(p).read_text(encoding="utf-8-sig"))
def write(p,s): Path(p).write_text(norm(s),encoding="utf-8",newline="\n")

def status_paths(repo):
    out,_=cap(["git","status","--porcelain","--untracked-files=all"],repo)
    return sorted({x[3:].strip() for x in out.splitlines() if x})

def diff_names(repo,cached=False):
    args=["git","diff"]
    if cached: args.append("--cached")
    args+=["--name-only","--"]
    out,_=cap(args,repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def fix_current_ui_status(path,text):
    original=text

    # README EN.
    text=re.sub(
        r"The follow-on presentation task `TASK-WEB-DEVICE-UI-01` is \*\*IN PROGRESS / LAB\n"
        r"REVIEW PENDING\*\*\.[\s\S]*?until separately accepted, merged and deployed\.",
        "The Devices presentation follow-on is now **CLOSED / PRODUCTION ACTIVE** through PR #110. "
        "The local Admin Web asset library and Android presentation FIX are **CLOSED / PRODUCTION PASS**.",
        text,
        count=1,
    )

    # README RU — exact baseline wording.
    text=re.sub(
        r"Следующая presentation-layer задача `TASK-WEB-DEVICE-UI-01` имеет статус\n"
        r"\*\*IN PROGRESS / LAB REVIEW PENDING\*\*\.[\s\S]*?"
        r"отдельной приёмки, merge и deploy\.",
        "Presentation-layer задача `TASK-WEB-DEVICE-UI-01` теперь **CLOSED / PRODUCTION ACTIVE** через PR #110. "
        "Локальная библиотека Admin Web assets и Android presentation FIX также **CLOSED / PRODUCTION PASS**.",
        text,
        count=1,
    )

    # docs/README current code block.
    text=text.replace(
        """Follow-on UI work:

```text
TASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING
MERGED = NO
DEPLOYED = NO
CURRENT PRODUCTION BEHAVIOR = NO
```""",
        """Current Devices presentation:

```text
TASK-DEVICE-LIST-CONTEXT-01 = CLOSED / PRODUCTION ACTIVE
TASK-WEB-DEVICE-UI-01 = CLOSED / PRODUCTION ACTIVE
PR #110 = MERGED / PRODUCTION VERIFIED
```"""
    )

    # module-index section.
    text=re.sub(
        r"## Device UI follow-on\n\n```text\n"
        r"TASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING\n"
        r"NOT MERGED\nNOT DEPLOYED\nNOT CURRENT PRODUCTION\n```"
        r"[\s\S]*?(?=\n## )",
        """## Devices UI / asset closure

```text
TASK-WEB-DEVICE-UI-01 = CLOSED / PRODUCTION ACTIVE
TASK-WEB-ASSET-LIBRARY-01 = CLOSED / PRODUCTION PASS
TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION = CLOSED / PRODUCTION PASS
```
""",
        text,
        count=1,
    )

    # admin-web status block.
    text=text.replace(
        """TASK-WEB-DEVICE-UI-01
STATUS=IN PROGRESS / LAB REVIEW PENDING
MERGED=NO
DEPLOYED=NO
CURRENT PRODUCTION=NO""",
        """TASK-WEB-DEVICE-UI-01
STATUS=CLOSED / PRODUCTION ACTIVE
PR #110=MERGED / PRODUCTION VERIFIED"""
    )

    # project inventory follow-on.
    text=text.replace(
        """Follow-on:

```text
TASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING
NOT MERGED
NOT DEPLOYED
```""",
        """Subsequent closure:

```text
TASK-WEB-DEVICE-UI-01=CLOSED / PRODUCTION ACTIVE
PR #110=MERGED / PRODUCTION VERIFIED
```"""
    )

    # testing historical/current wording.
    text=text.replace(
        """Follow-on `TASK-WEB-DEVICE-UI-01` is not acceptance evidence for this TASK and is
not current production:

```text
IN PROGRESS / LAB REVIEW PENDING
NOT MERGED
NOT DEPLOYED
```""",
        """At DEVICE-CARD-01 acceptance time, `TASK-WEB-DEVICE-UI-01` was a separate
pending follow-on. It subsequently closed through PR #110 and is current
production presentation."""
    )

    return text, text!=original

def main():
    repo=Path(os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) /
            "Downloads" / "CaptivPortal-KB-Work")
    ))

    print("Publisher: WEB-ASSET-LIBRARY-KB-V5-RESUME-2026-09-12")
    print("=== RECOVERY PRECHECK ===")

    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")

    branch=txt(["git","branch","--show-current"],repo).strip()
    head=txt(["git","rev-parse","HEAD"],repo).strip()
    print("branch:",branch)
    print("HEAD:",head)
    if branch!=BRANCH:
        raise SystemExit("STOP: expected failed-V4 publication branch")
    if head!=BASE:
        raise SystemExit("STOP: failed-V4 branch HEAD moved")

    run(["git","fetch","origin","main"],repo)
    remote=txt(["git","rev-parse","origin/main"],repo).strip()
    tree=txt(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:",remote)
    print("origin tree:",tree)
    if remote!=BASE or tree!=TREE:
        raise SystemExit("STOP: main moved; re-review required")

    rb=txt(["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo).strip()
    if rb:
        raise SystemExit("STOP: remote publication branch already exists")

    actual=status_paths(repo)
    print("Current V4 files:")
    for p in actual: print(" ",p)

    if actual!=EXPECTED_V4_FILES:
        raise SystemExit("STOP: current worktree is not exact failed-V4 state")
    if diff_names(repo,True):
        raise SystemExit("STOP: unexpected staged changes")

    print("PASS: exact failed-V4 state")

    print("=== REPAIR STALE CURRENT-STATE WORDING ===")
    touched=[]
    for path in CURRENT_DOCS:
        p=repo/path
        text=read(p)
        fixed,changed=fix_current_ui_status(path,text)
        if changed:
            write(p,fixed)
            touched.append(path)

    print("Status-repair touched:")
    for p in touched: print(" ",p)
    if "README_RU.md" not in touched:
        raise SystemExit("STOP: expected README_RU stale block was not repaired")

    print("=== FINAL ASSERTIONS ===")

    stale_markers=[
        "TASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING",
        "TASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING",
        "STATUS=IN PROGRESS / LAB REVIEW PENDING",
        "NOT CURRENT PRODUCTION",
        "CURRENT PRODUCTION BEHAVIOR = NO",
    ]
    for path in CURRENT_DOCS:
        text=read(repo/path)
        for marker in stale_markers:
            if marker in text:
                raise SystemExit(f"STOP: stale Device UI current-state wording remains in {path}: {marker}")

    checks={
      "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md":[
        "TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS",
        "TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS",
        'value.trim().toLowerCase() === "android"',
      ],
      "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md":[
        "Status: CLOSED / PRODUCTION PASS",
        "bounded Admin Web tests=12/12 PASS",
      ],
      "docs/agents/web-designer-role.md":[
        "PUBLISH APPROVED CANDIDATE",
        "MERGE=NO",
        "DEPLOY=NO",
      ],
      "docs/agents/workflow.md":[
        "PUBLISH APPROVED CANDIDATE",
        "accepted-candidate-only commit",
      ],
      "docs/deployment.md":[
        "PR #114",
        "service restart for FIX=NOT REQUIRED",
      ],
      "docs/testing.md":[
        "bounded Admin Web tests=12/12 PASS",
        "Owner production visual acceptance=PASS",
      ],
    }

    for path,needles in checks.items():
        text=read(repo/path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: missing canonical assertion in {path}: {needle}")

    # Keep scope docs/governance only; one co-located icon README is allowed.
    actual=status_paths(repo)
    if actual!=EXPECTED_V4_FILES:
        raise SystemExit("STOP: resume changed unexpected file scope")

    for p in actual:
        if p.startswith("tests/"):
            raise SystemExit("STOP: tests changed")
        if p.startswith("app/") and p!="app/admin_web/static/icons/README.md":
            raise SystemExit("STOP: runtime app file changed")

    run(["git","diff","--check"],repo)

    print("PASS: stale Device UI current-state wording removed")
    print("PASS: Asset Library + FIX canonical closure intact")
    print("PASS: Web Designer governance intact")
    print("PASS: exact 15-file docs/governance scope")
    print("PASS: git diff --check")

    print("=== STAGE ===")
    run(["git","add","--"]+EXPECTED_V4_FILES,repo)
    if diff_names(repo,False):
        raise SystemExit("STOP: unstaged changes remain")
    if diff_names(repo,True)!=EXPECTED_V4_FILES:
        raise SystemExit("STOP: staged scope mismatch")
    run(["git","diff","--cached","--check"],repo)
    print("PASS: git diff --cached --check")

    print("=== COMMIT ===")
    run([
        "git","commit",
        "-m","docs: close Web Asset Library production state",
        "-m","Document WEB-ASSET-LIBRARY-01 and Android presentation FIX production closure, reconcile Devices UI status drift, and canonicalize Web Designer accepted-candidate publication governance."
    ],repo)
    commit=txt(["git","rev-parse","HEAD"],repo).strip()

    if status_paths(repo):
        raise SystemExit("STOP: worktree not clean after commit")

    print("=== PUSH ===")
    run(["git","push","-u","origin",BRANCH],repo)

    print("=== CREATE DRAFT PR ===")
    body=f"""## Purpose

Canonical KB reconciliation for TASK-WEB-ASSET-LIBRARY-01 and its production
Android presentation FIX, plus related Devices/Web Designer status/governance drift.

## Production truth

- application / production HEAD: {BASE}
- tree: {TREE}
- PR #113: merged
- PR #114: merged / production verified
- Owner production visual acceptance: PASS

## Final Android contract

`value.trim().toLowerCase() === "android"`

Source device_type text remains unchanged. No inference from other fields.

## Web Designer governance

After exact acceptance plus explicit `PUBLISH APPROVED CANDIDATE`, Web Designer
may publish only accepted presentation artifact as feature branch + commit + push
+ Draft PR. main/merge/deploy/release remain forbidden.

## Scope

- 15 docs/governance files
- runtime code changed: NO
- tests changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""
    pr=txt([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main",
        "--head",BRANCH,
        "--title","Docs: close Web Asset Library production state",
        "--body",body,
        "--draft"
    ],repo).strip()

    print("=== FINAL ===")
    print("Branch:",BRANCH)
    print("Commit:",commit)
    print("Draft PR:",pr)
    print("Changed files: 15")
    print("Runtime code changed: NO")
    print("Tests changed: NO")
    print("Production changed: NO")
    print("Merge performed: NO")

if __name__=="__main__":
    main()
