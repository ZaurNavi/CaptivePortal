CaptivPortal KB Traffic 00/01 + Central Lab V6 Publisher V4

Version marker:
TRAFFIC-KB-V4-2026-08-29

Root cause fixed in V4:
- docs/modules/traffic.md is new/untracked before staging;
- git grep does not search untracked files;
- therefore V3 falsely reported required text missing.

V4:
- reads every canonical/current file directly via System.IO.File.ReadAllText;
- required statements are checked with .NET String.IndexOf;
- stale single-line statements are also checked directly;
- multiline V4/current-tool regex remains direct-file based;
- tracked and untracked files are validated identically.

Retained protections:
- exact origin/main SHA and tree;
- safe recovery from prior failed attempts;
- cleanup ONLY of generated untracked docs/modules/traffic.md;
- exact 18-file docs/governance scope;
- V4 historical-context validation;
- git diff checks;
- commit/push/Draft PR only;
- no merge.

Expected main:
8f3ad59771f72c49834b1012963de6d94b9e0d18

Expected tree:
2ef8bf264a008259242cde0778d0ebd20fa94b9e

SHA256:
81c91a2b60cae93e6826937b7667cf706382ccc20ee97ed03262531863013194
