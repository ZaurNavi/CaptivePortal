# CaptivPortal KB Reconciliation — TRAFFIC-00 / TRAFFIC-01 + Central Lab V6

Date: 2026-08-29

## Exact baseline

```text
main = 8f3ad59771f72c49834b1012963de6d94b9e0d18
tree = 2ef8bf264a008259242cde0778d0ebd20fa94b9e
production HEAD = 8f3ad59771f72c49834b1012963de6d94b9e0d18
production tree = 2ef8bf264a008259242cde0778d0ebd20fa94b9e
```

## Canonicalized current Traffic state

```text
TRAFFIC-00 — DONE / MERGED / PRODUCTION / ACTIVE
TRAFFIC-01 — DONE / MERGED / PRODUCTION / ACTIVE
TRAFFIC-02-READ — NEXT / DRAFT REVIEW / IMPLEMENTATION NOT STARTED
TRAFFIC-02 — NOT STARTED
TRAFFIC-03+ — NOT STARTED
```

Production flags recorded as Owner-provided current facts:

```text
WEB_ADMIN_TRAFFIC_ENABLED=true
WEB_ADMIN_HOME_TRAFFIC_ENABLED=true
```

They remain independent feature boundaries.

## Current Traffic semantic contract

```text
Omada current AP primitives
→ Observation acquisition
→ persisted AP traffic facts
→ CurrentTrafficReadService
→ AdminQueryService
→ GET /admin/api/v1/sites/<site_id>/traffic/current
→ Traffic frontend coordinator
→ Current Network Throughput
```

No direct Admin/browser Omada path, second collector, second calculation owner or
second Traffic coordinator is documented or introduced.

Current policy remains 90s fresh / 180s stale / 60s max AP skew.

Network Traffic is AP/network Mbps evidence. Wired is primary, LAN fallback.
Radio is excluded. Backend total is canonical.

## Production acceptance evidence recorded

```text
Central Lab targeted: 66 passed
V6-fixed: PASS
strict regressions: 0
fixed-context Home ↔ Traffic equality: PASS
service active
CAPPORT 200
Omada webhook 204
Observation complete=True / error_count=0
Admin Console PASS
Traffic UI PASS
```

The 1.52/0.08/1.60 Mbps observation is preserved only as dated sample acceptance
evidence and is explicitly not a system constant.

## Rollback

Pre-Traffic checkpoint remains RETAINED.

Previous production HEAD:

```text
f5887758898b512747d2ea8bd51763389230dc2d
```

The previous production tree, `/etc/default/captive-portal`, and systemd service
definition are recorded as retained owner artifacts without inventing an omitted
tree SHA.

## Central Lab current state

Canonical Windows repository:
`C:\CaptivPortal-UI-Preview`

Support directory:
`C:\CaptivPortal-Lab`

Manual interpreter:
`C:\CaptivPortal-UI-Preview\.venv\Scripts\python.exe`

Verified:
- Python 3.10.11
- pytest 9.1.1
- dependencies through `requirements-dev.txt`
- manual pytest uses explicit cleaned `C:\CaptivPortal-Lab\tmp\<run>` basetemp

Current verified full runner:
`C:\CaptivPortal-Lab\lab-test-v6-fixed.cmd`

V4 is retained only as historical evidence.

Permanent anti-drift:
`documented gate version != automatically current gate version`.

## Test Set Maintenance Rule

After each accepted TASK/module/panel/API/read-service:
- Coder handoff lists new/changed tests + exact focused command/result.
- Tech Lead refreshes the targeted Central Lab set and cross-surface invariants.
- ordinary new pytest files do not mechanically require a full-runner edit if
  full discovery already finds them.
- runner changes only when gate/compatibility/isolation/environment contract changes.

TRAFFIC-01 current relevant set includes at minimum Foundation regressions,
`test_traffic_current.py`, `test_traffic_current_frontend.py`, related Home Traffic
regression, and fixed-context cross-surface proof.

## Files

- `.github/instructions/tests.instructions.md`
- `AGENTS.md`
- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/agents/handoff.md`
- `docs/agents/workflow.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/admin-web.md`
- `docs/modules/analytics.md`
- `docs/modules/traffic.md`
- `docs/plans/PLAN-template.md`
- `docs/project-inventory.md`
- `docs/tasks/TASK-template.md`
- `docs/testing.md`

Runtime code: NO
Test code: NO
Production actions: NO
Merge: NO

Suggested branch:
`docs/traffic00-01-production-kb-2026-08-29`

Suggested commit:
`docs: reconcile Traffic current state and Central Lab V6`

Suggested Draft PR:
`Docs: reconcile Traffic production state and Central Lab V6`
