CaptivPortal KB Traffic 00/01 + Central Lab V6 Publisher V3

Version marker:
TRAFFIC-KB-V3-2026-08-29

Fixes retained:
- exact main/tree fail-closed precheck;
- safe recovery of tracked changes;
- removal of ONLY generated untracked docs/modules/traffic.md;
- exact 18-file documentation/governance scope;
- historical/traceability files outside current scope are not blockers.

V3-specific fix:
- removed multiline git-grep V4 pattern;
- stale "Current approved tool -> V4" is checked with a .NET regex over file text;
- any remaining V4 mention in canonical/current files must have historical/previous/legacy/old context within a bounded window;
- avoids PowerShell backtick/code-fence/newline false positives.

Expected main:
8f3ad59771f72c49834b1012963de6d94b9e0d18

Expected tree:
2ef8bf264a008259242cde0778d0ebd20fa94b9e

SHA256:
779a60e5ba4e6d0d19050b374b64bff164fe0fd087755141eff67ba98a3158de
