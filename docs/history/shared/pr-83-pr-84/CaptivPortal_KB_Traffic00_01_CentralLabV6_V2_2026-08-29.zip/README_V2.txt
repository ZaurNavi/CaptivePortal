CaptivPortal KB Traffic 00/01 + Central Lab V6 Publisher V2

Visible version marker:
TRAFFIC-KB-V2-2026-08-29

Fixes:
- recovery safely removes only generated untracked docs/modules/traffic.md;
- stale/current grep is limited to the 18 canonical/current reconciliation files;
- historical/traceability docs do not block publication because they retain old state;
- all exact SHA/tree, scope, required assertions, diff checks, commit/push/Draft PR guards remain;
- merge is never performed.

Expected main:
8f3ad59771f72c49834b1012963de6d94b9e0d18

Expected tree:
2ef8bf264a008259242cde0778d0ebd20fa94b9e

SHA256:
8125033f0ba9b7be7c55db42648792f7363a84fb10c1dcf9883c7674420e89ff
