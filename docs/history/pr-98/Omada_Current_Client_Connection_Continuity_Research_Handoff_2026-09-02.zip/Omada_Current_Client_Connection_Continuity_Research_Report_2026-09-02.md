# Omada Current Client Connection Continuity — Final Research Handoff

**Project:** CaptivPortal  
**Roadmap binding:** `TASK-TRAFFIC-07-READ — Online Guest Current Rate Read Foundation`  
**Research type:** controlled evidence collection  
**Research status:** **CLOSED WITH NEGATIVE SAFETY VERDICT**  
**Implementation authorization:** **NOT GRANTED**  
**Production code/config/schema changes:** **NONE**  
**Research date:** 2026-09-01 UTC / 2026-09-02 Asia/Baku

> This report closes the conducted research work as an evidence collection task.
> It does **not** permit freezing a production continuity tolerance, because the
> mandatory reconnect-negative sample count was not completed.

---

# Executive conclusion

The research strongly characterizes normal, idle, active and physically
disconnected/frozen Omada Current Client behavior.

It does **not** satisfy the original formal evidence gate for selecting and
freezing a production same-connection continuity rule, because the TASK required
at least three controlled `NEW_CONNECTION` reconnect transitions with full
boundary-pair evidence.

Observed evidence:

```text
stable same-connection pairs: 10
idle same-connection pairs:   10
active same-connection pairs: 10
total positive pairs:         30

frozen persisted pairs:        5

true NEW_CONNECTION boundaries:
  1 recoverable for POINT estimator only

required true reconnect transitions:
  >=3

short OFF→ON experiment E1:
  NOT a new Omada connection
```

For the 30 proven same-connection pairs:

```text
max point-start difference = 1.871 s
```

One partially reconstructable true new-connection boundary produced:

```text
point-start difference = 285.624 s
```

Thus `POINT T=2s` is a **very strong provisional candidate** on the observed
dataset:

```text
same accepted:      30 / 30
observed reconnect:  0 / 1 accepted
observed false positives: 0 / 1
```

However this is **not sufficient to freeze T=2s**, because the reconnect
negative sample count required by the TASK was not completed.

The raw capture-window method without allowance rejected all 30 positive
same-connection pairs and therefore has unusably low coverage in its raw form.

Final formal result:

```text
RECOMMENDED CONTINUITY CANDIDATE:
NO SAFE METHOD PROVEN

PROVISIONAL FUTURE CANDIDATE:
POINT estimator, T=2 seconds
NOT APPROVED / NOT FROZEN

RECONNECT FALSE POSITIVES:
0 / 1 OBSERVED POINT-ONLY TRUE BOUNDARY
FORMAL ZERO NOT ESTABLISHED

CONTINUITY EVIDENCE:
FAIL — SAFE SAME-CONNECTION METHOD NOT PROVEN
```

The failure is due to **incomplete mandatory reconnect evidence**, not because
the point estimator produced a false positive in the data actually collected.

---

# A. Environment

```text
Controller:
Omada Software Controller 5.14.32.3
(version inherited from the immediately preceding verified Omada research baseline;
not re-queried by the Stage-0 continuity command)

Site:
6a64f17630da7c70d232187a

SSID:
Zefer_Parki

Test client MAC:
BE:00:7D:9B:04:2E

Primary AP:
AP-2
DC:62:79:1B:4A:68

Current State client collection interval:
60 seconds

Current State DB:
current_state.sqlite3
user_version = 1

Current State source scope hash:
76a2ba804085f6db24dfec079515d1a684a22c25a96603f99f7a32f83a5a2263

Research start:
2026-09-01T19:16:58.998Z
```

Stage 0 verified:

```text
CURRENT_STATE_ENABLED=true
CURRENT_STATE_CLIENT_INTERVAL_SECONDS=60
CURRENT_STATE_AP_INTERVAL_SECONDS=60
CURRENT_STATE_CLIENT_SSIDS_JSON=["Zefer_Parki"]
```

The relevant `current_state_cycles` / `current_client_state` schema and
`observed_at == capture_started_at` integrity relationship were verified against
production data using read-only SQLite access.

---

# B. Test procedure

## Scenario A — Stable same connection

Collected 11 new complete/success snapshots, producing:

```text
10 consecutive SAME_CONNECTION pairs
```

Phone remained on the same SSID/AP connection.

## Scenario B — Idle same connection

Collected 11 new complete/success snapshots while no traffic was intentionally
generated:

```text
10 SAME_CONNECTION_IDLE pairs
```

The dataset includes two consecutive intervals in which both traffic counters
had exactly zero delta while uptime continued to progress.

## Scenario C — Active transfer

Generated sustained download traffic and collected:

```text
10 SAME_CONNECTION_ACTIVE pairs
```

Observed counter-derived download rate:

```text
min  = 1.972 Mbps
p50  = 2.503 Mbps
p95  = 3.232 Mbps
max  = 3.628 Mbps
```

A dedicated upload-only subtest was not performed; upload traffic still had
non-zero background/control deltas throughout the download run.

## Scenario D — Physical disconnect / frozen Controller state

The phone Wi-Fi was physically disabled and intentionally left disconnected.

Direct Controller polling and persisted Current State were observed until
Controller finalization.

This scenario produced:

```text
5 persisted client-present pairs after the pre-disconnect baseline
1 subsequent complete Current State cycle with client absent
```

The first post-OFF persisted pair contained a delayed final update from the old
connection. Subsequent pairs were fully frozen.

## Scenario E — Controlled reconnect

The planned short OFF→ON experiment did **not** produce a new Omada connection.

Observed sequence:

```text
Wi-Fi OFF
~12.8 s physical interruption
Wi-Fi ON
Controller retained the same client context
uptime continued
traffic counters continued
```

Therefore E1 must be classified:

```text
SAME_CONNECTION across a brief physical radio interruption
```

not `NEW_CONNECTION`.

One real new-connection boundary can be reconstructed partially between the
fully finalized Scenario-D old connection and the later stable connection that
existed before E1. It is complete enough for the POINT estimator but not for the
capture-window estimator because the later snapshot's `capture_finished_at`
was not printed in the E1 baseline output.

The originally required minimum of three complete NEW_CONNECTION reconnect
transitions was not reached.

## AP roam

```text
AP_ROAM = NOT TESTED
```

---

# C. Dataset counts

```text
stable same connection pairs:             10
idle same connection pairs:               10
active same connection pairs:             10
all proven same-connection pairs:         30

frozen / physically disconnected pairs:    5

true NEW_CONNECTION transitions observed
with recoverable continuity evidence:       1

full reconnect-boundary pairs
for BOTH point + window estimators:         0

point-only true reconnect boundary pairs:   1

short physical OFF→ON transitions tested:   1
short OFF→ON that remained same Omada connection: 1

required full reconnect transitions:       >=3

AP roam pairs: NOT TESTED
```

---

# D. Uptime findings

Across the 30 proven same-connection pairs, observed uptime deltas were:

```text
60 s:  9 pairs
61 s: 18 pairs
62 s:  3 pairs
```

This is consistent with an integer-second / quantized Controller duration
counter combined with approximately 60-second Current State collection.

For:

```text
difference =
capture_start_elapsed_seconds
-
uptime_delta_seconds
```

across all A+B+C same-connection pairs:

```text
min = -1.871 s
p50 = -0.720 s
p95 = 0.373 s
max = 1.254 s
```

Point-start absolute difference across same-connection pairs:

```text
maximum = 1.871 s
```

Important conclusion:

```text
controller_uptime alone is not a session identifier.
```

A new connection can already have a numerically larger uptime than an old
baseline if enough wall-clock time elapsed before the first new snapshot.

Observed real new-connection point-only boundary:

```text
old connection uptime = 33
later new connection uptime = 50
```

Therefore a simplistic rule:

```text
current_uptime < baseline_uptime
```

is **not sufficient** to prove a reconnect.

---

# E. Counter findings

## SAME_CONNECTION

Download/Upload counters were monotonic over all 10 Scenario-A pairs.

## SAME_CONNECTION_IDLE

Zero traffic delta is valid during a real same connection.

Observed consecutive examples:

```text
B05:
uptime 1307 → 1367
trafficDown unchanged
trafficUp   unchanged

B06:
uptime 1367 → 1428
trafficDown unchanged
trafficUp   unchanged
```

Therefore:

```text
counter growth MUST NOT be required for continuity.
```

## SAME_CONNECTION_ACTIVE

Counters increased monotonically throughout the active download scenario.

Download rate was approximately:

```text
1.97–3.63 Mbps
```

## PHYSICALLY_DISCONNECTED / FROZEN

After the last delayed old-connection update, four subsequent persisted pairs
had:

```text
uptime_delta   = 0
download_delta = 0
upload_delta   = 0
```

Thus:

```text
active=true
+
same counters
+
same uptime
```

can represent a physically disconnected client retained by Controller.

## NEW_CONNECTION

The partially reconstructed true boundary shows:

```text
old last persisted connection:
uptime      33
trafficDown 4,929,976
trafficUp     159,359

later stable new connection:
uptime      50
trafficDown 119,948
trafficUp    68,777
```

Counters reset lower in this observed reconnect.

The dataset does **not** prove that new-connection counters can never exceed an
older connection's counters; therefore counter magnitude must not be used as
connection identity evidence.

---

# F. Frozen / disconnect findings

Physical Wi-Fi OFF mark:

```text
2026-09-01T20:09:31.806Z
```

First direct Controller poll after OFF:

```text
2026-09-01T20:09:31.808Z
active=true
uptime=33
trafficDown=4,929,976
trafficUp=159,359
```

Those exact values remained unchanged through the last observed `active=true`
poll:

```text
2026-09-01T20:14:31.093Z
+299.287 s after physical OFF
```

Controller finalization:

```text
2026-09-01T20:14:36.156Z
+304.351 s after physical OFF
active=false
connection fields cleared
```

First complete Current State cycle with the client absent:

```text
2026-09-01T20:15:23.529Z
```

Measured behavior:

```text
physical disconnect
→ Controller can retain active=true for about five minutes
→ uptime/counters can remain fully frozen
→ finalization clears current connection fields
→ next Current State cycle omits the client
```

The exact last real device-side uptime/counter change instant cannot be derived
from these 5-second research polls. The final old values were already visible
at the first direct poll after the operator OFF mark.

Therefore the defensible frozen timing statements are:

```text
frozen values observed continuously for at least:
~299.285 s while active=true

Controller active-retention after physical OFF:
304.351 s
```

---

# G. Reconnect findings

## True finalized reconnect

After Controller had finalized the old Scenario-D connection, a later stable
connection was observed before E1:

```text
old last Current State:
2026-09-01T20:14:23.152Z
uptime=33
down=4,929,976
up=159,359

later new Current State:
2026-09-01T20:19:25.776Z
uptime=50
down=119,948
up=68,777
```

Point connection-start estimates:

```text
old:
2026-09-01T20:13:50.152Z

new:
2026-09-01T20:18:35.776Z

absolute difference:
285.624 s
```

This is strong evidence of a new Controller connection context.

## Short physical OFF→ON does not necessarily create a new Omada connection

E1:

```text
T1 Wi-Fi OFF:
2026-09-01T20:19:57.680Z

T4 Wi-Fi ON:
2026-09-01T20:20:10.526Z
```

Controller retained:

```text
active=true
uptime=80
down=135,033
up=90,606
```

and later progressed:

```text
20:20:33.764Z
uptime=141
down=160,814
up=106,455

20:22:06.398Z
uptime=233
down=192,287
up=124,163
```

No reset occurred.

Therefore physical Wi-Fi interruption is not itself the product continuity
boundary. The meaningful semantic boundary for these cumulative counters is the
**Omada connection context**.

The Owner also observed product behavior consistent with this model:

- reconnecting while Controller still retains the old context can bypass a new
  captive-portal presentation;
- reconnecting after finalization produces a new portal flow.

This observation is supporting product evidence, not a substitute for the
mandatory raw reconnect-pair gate.

---

# H. Point-estimator results

Estimator:

```text
point_start =
capture_started_at - controller_uptime
```

Observed dataset:

```text
proven same pairs: 30
true reconnect point pairs evaluable: 1
```

| T (s) | Same accepted | Same rejected | Reconnect accepted | Reconnect rejected | False positives | False negatives |
|---:|---:|---:|---:|---:|---:|---:|
| 0 | 0 | 30 | 0 | 1 | 0 | 30 |
| 1 | 26 | 4 | 0 | 1 | 0 | 4 |
| 2 | 30 | 0 | 0 | 1 | 0 | 0 |
| 3 | 30 | 0 | 0 | 1 | 0 | 0 |
| 5 | 30 | 0 | 0 | 1 | 0 | 0 |
| 10 | 30 | 0 | 0 | 1 | 0 | 0 |

Separation observed:

```text
max_same_connection_point_difference =
1.871 s

min_observed_true_reconnect_point_difference =
285.624 s
```

This is a very large observed separation zone.

However:

```text
required true reconnect experiments >= 3
observed/evaluable point reconnect boundaries = 1
```

Therefore no `T` is frozen.

`T=2s` is recorded only as:

```text
PROVISIONAL CANDIDATE FOR FUTURE VALIDATION
```

not as an approved continuity rule.

---

# I. Capture-window estimator results

Raw estimator:

```text
window =
[
 capture_started_at - uptime,
 capture_finished_at - uptime
]
```

Without any allowance:

```text
same accepted:  0 / 30
same rejected: 30 / 30
false negatives: 30
```

Every Scenario A/B/C positive pair had non-overlapping raw windows.

The observed raw gaps are compatible with uptime quantization/jitter, but the
research intentionally does not invent a window expansion allowance.

Reconnect window evaluation:

```text
NOT COMPLETE
```

The one true reconnect boundary available after Scenario D lacks the later
snapshot's printed `capture_finished_at`; therefore the mandatory reconnect
window cannot be independently reconstructed from the captured handoff text.

Result:

```text
RAW WINDOW method is not useful as-is.
WINDOW + allowance is NOT PROVEN.
No allowance is recommended.
```

---

# J. Recommended continuity candidate

Formal recommendation:

```text
NO SAFE METHOD PROVEN
```

Reason:

```text
mandatory >=3 true controlled reconnect transitions were not completed
```

No production tolerance or quantization allowance may be frozen from this
research.

Strong provisional candidate for a future minimal follow-up, if the project
chooses to reopen the gate:

```text
METHOD:
POINT

PROVISIONAL threshold:
2 seconds

STATUS:
NOT APPROVED
NOT FROZEN
```

Why it is interesting:

```text
30/30 proven same pairs accepted at T=2s
1/1 observed point-only true reconnect rejected
max same difference = 1.871s
observed reconnect difference = 285.624s
```

Why it cannot be adopted yet:

```text
one reconnect boundary is not the required three-transition negative dataset.
```

---

# K. Safety verdict

Mandatory safety statement:

```text
RECONNECT FALSE POSITIVES:
0 / 1 OBSERVED POINT-ONLY TRUE RECONNECT BOUNDARY

FORMAL REQUIREMENT "ZERO FALSE POSITIVES" IS NOT PROVEN
BECAUSE THE REQUIRED >=3 CONTROLLED TRUE RECONNECT TRANSITIONS
WERE NOT COMPLETED.
```

No false positive was observed.

The required statistical/evidence gate nevertheless remains incomplete.

---

# L. Final research verdict

```text
CONTINUITY EVIDENCE:
FAIL — SAFE SAME-CONNECTION METHOD NOT PROVEN
```

Interpretation:

- the experiment produced useful and internally consistent evidence;
- normal/idle/active/frozen behavior is now well characterized;
- short Wi-Fi interruption was correctly discovered to remain the same Omada
  connection in at least one controlled test;
- point-start estimation is strongly supported as the leading candidate;
- **but no exact production tolerance is authorized by this report**.

For `TASK-TRAFFIC-07-READ FINAL`:

```text
continuity_method:
NOT FROZEN

exact tolerance:
NOT FROZEN

window allowance:
NOT FROZEN

implementation:
REMAINS BLOCKED BY THE ORIGINAL EVIDENCE GATE
if the architecture insists on a formally proven continuity classifier.
```

The research task itself may be administratively closed with this negative
result. A later project decision may either:

1. perform only the missing two additional true finalized reconnect transitions
   and re-evaluate the point candidate; or
2. redesign TRAFFIC-07 so numeric rate is emitted only where another stronger
   continuity primitive becomes available.

---

# Required handoff inventory

Included with this report:

1. Markdown research report;
2. consolidated pair dataset reconstructed from preserved scenario outputs;
3. point-estimator matrix;
4. raw-window matrix;
5. scenario timeline;
6. sanitized Controller evidence summary;
7. reconnect false-positive statement;
8. recommended continuity result;
9. limitations / untested scenarios.

## Evidence preservation note

The full raw console outputs supplied by Owner during the research session remain
the highest-fidelity evidence for:

- Scenario A raw snapshots/pairs;
- Scenario B raw snapshots/pairs;
- Scenario C raw snapshots/pairs;
- Scenario D full direct Controller polling + Current State output;
- E1 short OFF→ON Controller sequence.

The generated consolidated CSV preserves the pair-level values used by this
report. The Controller summary CSV intentionally summarizes the full direct-poll
console evidence rather than pretending to be a byte-for-byte replacement of
the original terminal capture.

---

# Limitations / untested

```text
AP roam:
NOT TESTED

dedicated upload-only active scenario:
NOT TESTED

required >=3 true NEW_CONNECTION reconnect transitions:
NOT COMPLETED

capture-window reconnect matrix:
NOT COMPLETE

Controller/AP restart counter behavior:
NOT PART OF THIS TASK

production continuity implementation:
NOT AUTHORIZED
```
