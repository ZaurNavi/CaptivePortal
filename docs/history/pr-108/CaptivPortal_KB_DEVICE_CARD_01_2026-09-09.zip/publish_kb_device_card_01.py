from __future__ import annotations
import argparse, json, os, subprocess
from pathlib import Path

PAYLOAD = json.loads('{"version": "DEVICE-CARD-01-KB-V1-2026-09-09", "base": "7df71a8e807efd74b123117e78cb8d992c190fa1", "tree": "8f1342f0a0f1e8242642161e02b2f3276e6ddf51", "branch": "docs/device-card-current-context-kb-2026-09-09", "scope": ["README.md", "README_RU.md", "docs/README.md", "docs/architecture.md", "docs/configuration.md", "docs/deployment.md", "docs/module-index.md", "docs/modules/admin-web.md", "docs/modules/analytics.md", "docs/modules/current-state.md", "docs/project-inventory.md", "docs/tasks/TASK-DEVICE-CARD-01-FINAL.md", "docs/testing.md"], "replacements": [["README.md", "| Repository implementation checkpoint | `main@e32ade378bdbfc9f8458db9c18221958f4552718` |\\n| Repository tree | `2766139c83965dcf2f80e0c8084b3fb363dbd781` |\\n| Production deployed HEAD | `e32ade378bdbfc9f8458db9c18221958f4552718` |\\n| Production tree | `2766139c83965dcf2f80e0c8084b3fb363dbd781` |", "| Repository implementation checkpoint | `main@7df71a8e807efd74b123117e78cb8d992c190fa1` |\\n| Repository tree | `8f1342f0a0f1e8242642161e02b2f3276e6ddf51` |\\n| Production deployed HEAD | `7df71a8e807efd74b123117e78cb8d992c190fa1` |\\n| Production tree | `8f1342f0a0f1e8242642161e02b2f3276e6ddf51` |"], ["README.md", "| Current State | Implemented, schema v1 |\\n| Analytics / Admin Web | Implemented |", "| Current State | Implemented, schema v1 |\\n| Current Device Context | **TASK-DEVICE-CARD-01 — COMPLETE / PRODUCTION ACTIVE** |\\n| Analytics / Admin Web | Implemented |"], ["README_RU.md", "| Repository implementation checkpoint | `main@e32ade378bdbfc9f8458db9c18221958f4552718` |\\n| Repository tree | `2766139c83965dcf2f80e0c8084b3fb363dbd781` |\\n| Production deployed HEAD | `e32ade378bdbfc9f8458db9c18221958f4552718` |\\n| Production tree | `2766139c83965dcf2f80e0c8084b3fb363dbd781` |", "| Repository implementation checkpoint | `main@7df71a8e807efd74b123117e78cb8d992c190fa1` |\\n| Repository tree | `8f1342f0a0f1e8242642161e02b2f3276e6ddf51` |\\n| Production deployed HEAD | `7df71a8e807efd74b123117e78cb8d992c190fa1` |\\n| Production tree | `8f1342f0a0f1e8242642161e02b2f3276e6ddf51` |"], ["README_RU.md", "| Current State | Реализован, schema v1 |\\n| Analytics / Admin Web | Реализованы |", "| Current State | Реализован, schema v1 |\\n| Current Device Context | **TASK-DEVICE-CARD-01 — COMPLETE / PRODUCTION ACTIVE** |\\n| Analytics / Admin Web | Реализованы |"], ["docs/README.md", "Updated: 2026-09-08\\nCurrent-state implementation baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`\\nCurrent implementation tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`", "Updated: 2026-09-09\\nCurrent-state implementation baseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`\\nCurrent implementation tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`"], ["docs/README.md", "| TRAFFIC-09 final production closure | `tasks/TASK-TRAFFIC-09-FINAL.md` |\\n| Deferred Projection maintenance request | `deferred/TRAFFIC-PROJECTION-MAINTENANCE-REINDEX.md` |", "| TRAFFIC-09 final production closure | `tasks/TASK-TRAFFIC-09-FINAL.md` |\\n| DEVICE-CARD-01 final production closure | `tasks/TASK-DEVICE-CARD-01-FINAL.md` |\\n| Deferred Projection maintenance request | `deferred/TRAFFIC-PROJECTION-MAINTENANCE-REINDEX.md` |"], ["docs/architecture.md", "Updated: 2026-09-08\\nRuntime implementation baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`\\nRuntime tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`", "Updated: 2026-09-09\\nRuntime implementation baseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`\\nRuntime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`"], ["docs/configuration.md", "Updated: 2026-09-08\\nBaseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`", "Updated: 2026-09-09\\nBaseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`"], ["docs/deployment.md", "Updated: 2026-09-08\\nCurrent repository implementation baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`\\nConfirmed production deployed HEAD: `e32ade378bdbfc9f8458db9c18221958f4552718`\\nConfirmed production tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`", "Updated: 2026-09-09\\nCurrent repository implementation baseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`\\nConfirmed production deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`\\nConfirmed production tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`"], ["docs/module-index.md", "Updated: 2026-09-08\\nRuntime implementation baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`\\nRuntime tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`", "Updated: 2026-09-09\\nRuntime implementation baseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`\\nRuntime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`"], ["docs/module-index.md", "| Admin Web | current; default disabled | `app/admin_web/` | `modules/admin-web.md` | process security state | **no** |\\n| Home Live | current; default disabled | `app/admin_web/` | `modules/admin-web.md` | none | no |", "| Admin Web | current; default disabled | `app/admin_web/` | `modules/admin-web.md` | process security state | **no** |\\n| Device Current Context | current; default disabled | `app/admin_web/`, `app/current_state/read_service.py`, `app/analytics/current_guest_traffic.py` | `modules/admin-web.md`, `modules/current-state.md`, `modules/analytics.md` | reads Current State only; no new persistence | no |\\n| Home Live | current; default disabled | `app/admin_web/` | `modules/admin-web.md` | none | no |"], ["docs/module-index.md", "Owner-provided production checkpoint 2026-09-06:\\n\\n```text\\nHEAD: e32ade378bdbfc9f8458db9c18221958f4552718\\ntree: 2766139c83965dcf2f80e0c8084b3fb363dbd781", "Owner-provided production checkpoint 2026-09-09:\\n\\n```text\\nHEAD: 7df71a8e807efd74b123117e78cb8d992c190fa1\\ntree: 8f1342f0a0f1e8242642161e02b2f3276e6ddf51"], ["docs/module-index.md", "TRAFFIC-09 Consolidated Traffic Evidence: COMPLETED / PRODUCTION ACTIVE\\n\\nWEB_ADMIN_TRAFFIC_ENABLED=true", "TRAFFIC-09 Consolidated Traffic Evidence: COMPLETED / PRODUCTION ACTIVE\\nTASK-DEVICE-CARD-01 Current Device Context: COMPLETE / PRODUCTION ACTIVE\\n\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\nWEB_ADMIN_TRAFFIC_ENABLED=true"], ["docs/modules/admin-web.md", "Updated: 2026-09-08\\nBaseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`", "Updated: 2026-09-09\\nBaseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`"], ["docs/modules/admin-web.md", "## UI/design status\\n\\nCurrent panel placement remains production-current functional composition, not a\\npermanently frozen final Traffic visual design.", "## UI/design status\\n\\nCurrent functional Device Detail / Traffic presentation is production-current,\\nbut presentation is not permanently frozen.\\n\\nSeparate follow-on work:\\n\\n```text\\nTASK-WEB-DEVICE-UI-01\\nSTATUS=IN PROGRESS / LAB REVIEW PENDING\\nMERGED=NO\\nDEPLOYED=NO\\nCURRENT PRODUCTION=NO\\n```\\n\\nThat task covers presentation-only compact Devices cards/list, human-readable\\nbytes/time/rates, status indicators and future Online-first UX. It must not be\\ndescribed as current production behavior until separately accepted.\\n\\nCurrent Traffic panel placement also remains production-current functional\\ncomposition, not a permanently frozen final Traffic visual design."], ["docs/modules/analytics.md", "Updated: 2026-09-08\\nBaseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`", "Updated: 2026-09-09\\nBaseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`"], ["docs/modules/current-state.md", "Updated: 2026-08-26\\nBaseline: `main@53f617b3ac0155d0d647e58e98309927f9a4d318`", "Updated: 2026-09-09\\nBaseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`"], ["docs/project-inventory.md", "Updated: 2026-09-08\\nBranch: `main`\\nRuntime commit: `e32ade378bdbfc9f8458db9c18221958f4552718`\\nRuntime tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`\\nCommit source: merge PR #106 / TASK-TRAFFIC-09, 2026-09-08", "Updated: 2026-09-09\\nBranch: `main`\\nRuntime commit: `7df71a8e807efd74b123117e78cb8d992c190fa1`\\nRuntime tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`\\nCommit source: merge PR #108 / TASK-DEVICE-CARD-01, 2026-09-09"], ["docs/project-inventory.md", "| Admin Web | `app/admin_web` | read services/gateways | process session state only | **no** |\\n| Home Live | Admin Web | `CurrentStateReadService` | none | no |", "| Admin Web | `app/admin_web` | read services/gateways | process session state only | **no** |\\n| Device Current Context | Admin Web + Current State + Current Guest Traffic | persisted Current State exact-device evidence | none | no |\\n| Home Live | Admin Web | `CurrentStateReadService` | none | no |"], ["docs/project-inventory.md", "- no Admin request polls Omada through this service.\\n- startup `PRAGMA quick_check` self-timeout is retryable storage contention only when the repository itself interrupted that quick_check;", "- no Admin request polls Omada through this service.\\n- exact `get_current_client()` reads can prove online/offline only from fresh complete trusted Site/SSID scope; stale/unavailable/untrusted evidence remains unknown.\\n- exact-client guest-rate evidence can be pinned to the same accepted Current State cycle without scanning the full Site population.\\n- startup `PRAGMA quick_check` self-timeout is retryable storage contention only when the repository itself interrupted that quick_check;"], ["docs/project-inventory.md", "- optional `CurrentTrafficReadService`;\\n- `HomeActivityReadService`;\\n- `HistoricalTrafficReadService`;\\n- `CompletedGuestSessionTrafficReadService`.", "- optional `CurrentTrafficReadService`;\\n- `CurrentGuestTrafficReadService`;\\n- `HomeActivityReadService`;\\n- `HistoricalTrafficReadService`;\\n- `CompletedGuestSessionTrafficReadService`."], ["docs/testing.md", "Updated: 2026-09-08\\nCentral Lab governance effective: 2026-08-27\\nDocumentation/current-state implementation baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`\\nProduction deployed HEAD: `e32ade378bdbfc9f8458db9c18221958f4552718`\\nProduction tree: `2766139c83965dcf2f80e0c8084b3fb363dbd781`", "Updated: 2026-09-09\\nCentral Lab governance effective: 2026-08-27\\nDocumentation/current-state implementation baseline: `main@7df71a8e807efd74b123117e78cb8d992c190fa1`\\nProduction deployed HEAD: `7df71a8e807efd74b123117e78cb8d992c190fa1`\\nProduction tree: `8f1342f0a0f1e8242642161e02b2f3276e6ddf51`"]], "insertions": [["README.md", "# Architecture\\n", "## Device Detail — Current Device Context\\n\\n`TASK-DEVICE-CARD-01` is complete and production-active.\\n\\nThe existing Device Detail page now keeps two deliberately different evidence\\ndomains:\\n\\n```text\\nHistorical Device Context\\n!=\\nCurrent Device Context\\n```\\n\\nHistorical device information continues to contain Identity, Latest Site\\nSnapshot, Latest Client Observation and Recent Visits.\\n\\nThe separate read-only `Current Device Context` block contains:\\n\\n```text\\nPresence\\nAuthorization\\nNetwork\\nRadio\\nController\\nCurrent Guest Traffic\\nEvidence / Freshness\\n```\\n\\nCanonical current-state rules include:\\n\\n```text\\nfresh + complete scope + present  → online\\nfresh + complete scope + absent   → offline\\nstale/unavailable/untrusted       → unknown\\n\\nstale != offline\\nunavailable != offline\\n0 Mbps != unknown/unavailable\\n```\\n\\nThe browser reads persisted application evidence only. Device Detail does not\\nadd query-time Omada, Loki, Grafana or external Analytics calls.\\n\\nThe follow-on presentation task `TASK-WEB-DEVICE-UI-01` is **IN PROGRESS / LAB\\nREVIEW PENDING**. Its compact-list/readable-format/status-indicator work is not\\ncurrent production behavior until separately accepted, merged and deployed.\\n\\n"], ["README_RU.md", "# Архитектура\\n", "## Device Detail — Current Device Context\\n\\n`TASK-DEVICE-CARD-01` завершён и production-active.\\n\\nDevice Detail теперь явно разделяет два evidence domain:\\n\\n```text\\nHistorical Device Context\\n!=\\nCurrent Device Context\\n```\\n\\nHistorical часть сохраняет Identity, Latest Site Snapshot, Latest Client\\nObservation и Recent Visits.\\n\\nОтдельный read-only блок `Current Device Context` показывает:\\n\\n```text\\nPresence\\nAuthorization\\nNetwork\\nRadio\\nController\\nCurrent Guest Traffic\\nEvidence / Freshness\\n```\\n\\nКанонические current-state правила:\\n\\n```text\\nfresh + complete scope + присутствует → online\\nfresh + complete scope + отсутствует  → offline\\nstale/unavailable/untrusted           → unknown\\n\\nstale != offline\\nunavailable != offline\\n0 Mbps != unknown/unavailable\\n```\\n\\nDevice Detail читает persisted application evidence и не добавляет query-time\\nOmada, Loki, Grafana или external Analytics calls.\\n\\nСледующая presentation-layer задача `TASK-WEB-DEVICE-UI-01` имеет статус\\n**IN PROGRESS / LAB REVIEW PENDING**. Compact list, human-readable formatting,\\nstatus indicators и Online-first UX не считаются current production behavior до\\nотдельной приёмки, merge и deploy.\\n\\n"], ["docs/README.md", "## Permanent promotion boundary\\n", "## Current Device Card state\\n\\n```text\\nTASK-DEVICE-CARD-01 = COMPLETE\\nIMPLEMENTATION = PASS\\nOWNER + TECH LEAD ACCEPTANCE = PASS\\nMERGE = COMPLETE\\nPRODUCTION DEPLOY = PASS\\nPRODUCTION ACTIVATION = PASS\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED = true\\n```\\n\\nCurrent implementation / production baseline:\\n\\n```text\\nmain = 7df71a8e807efd74b123117e78cb8d992c190fa1\\ntree = 8f1342f0a0f1e8242642161e02b2f3276e6ddf51\\n```\\n\\nDevice Detail now exposes a separate read-only `Current Device Context` over\\npersisted Current State + the accepted exact-client Current Guest Traffic\\nprojection.\\n\\nPermanent semantic boundary:\\n\\n```text\\nHistorical Device Context != Current Device Context\\nstale != offline\\nunavailable != offline\\nnumeric 0 != missing/unavailable\\n```\\n\\nFollow-on UI work:\\n\\n```text\\nTASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING\\nMERGED = NO\\nDEPLOYED = NO\\nCURRENT PRODUCTION BEHAVIOR = NO\\n```\\n\\n"], ["docs/architecture.md", "## 8. Admin Web\\n", "### Device Current Context\\n\\n`TASK-DEVICE-CARD-01` adds a separate current evidence read path to the existing\\nDevice Detail page without changing the historical Device Card contract.\\n\\nPermanent semantic split:\\n\\n```text\\nHistorical Device Context\\n- Identity\\n- Latest Site Snapshot\\n- Latest Client Observation\\n- Recent Visits\\n\\nCurrent Device Context\\n- Presence\\n- Authorization\\n- Network\\n- Radio\\n- Controller\\n- Current Guest Traffic\\n- Evidence / Freshness\\n```\\n\\nCanonical read path:\\n\\n```text\\nSite-safe Device boundary\\n→ server-side canonical MAC\\n→ CurrentStateReadService.get_current_client(...)\\n→ optional exact-client CurrentGuestTrafficReadService projection\\n→ AdminQueryService.device_current_context(...)\\n→ admin.device.current.v1\\n→ Device Detail\\n```\\n\\nEndpoint:\\n\\n```text\\nGET /admin/api/v1/sites/<site_id>/devices/<device_id>/current\\ncapability = admin.read.device\\ncontract = admin.device.current.v1\\n```\\n\\nCurrent evidence is not reconstructed from historical Device/Visit/Observation\\nfacts.\\n\\nPresence semantics:\\n\\n```text\\nfresh + complete managed scope + client present\\n→ online\\n\\nfresh + complete managed scope + client absent\\n→ offline\\n\\nstale / unavailable / invalid timestamp / untrusted current evidence\\n→ unknown\\n```\\n\\nPermanent:\\n\\n```text\\nstale != offline\\nunavailable != offline\\ninvalid timestamp != offline\\n```\\n\\nAuthorization is current-state evidence (`authorized | pending | other |\\nunknown`).\\n\\nCurrent Guest Traffic is applicable only to a current authorized guest. Traffic\\nprojection failure is local to Traffic evidence and does not erase Presence,\\nAuthorization, Network or Radio. Numeric zero is valid evidence.\\n\\n```text\\n0 Mbps != null\\n0 Mbps != unavailable\\n```\\n\\nIf Current State itself cannot be read, the Current endpoint fails in a controlled\\nway; historical Device Detail remains a separate read path.\\n\\nInvalid timestamp evidence is sanitized to semantic Unknown rather than exposed\\nas unsafe timestamp data.\\n\\nThis feature adds:\\n\\n```text\\nno query-time Omada/provider call\\nno Loki/Grafana/external Analytics browser call\\nno DB/schema/index/migration\\nno write path\\nno worker/scheduler/polling loop\\n```\\n\\n"], ["docs/configuration.md", "### Home Live\\n", "### Device Current Context\\n\\nFeature flag:\\n\\n```text\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=false\\n```\\n\\nRepository default remains safe/opt-in `false`.\\n\\nActivation dependency:\\n\\n```text\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\nrequires WEB_ADMIN_ENABLED=true\\n```\\n\\nOwner-confirmed production state on 2026-09-09:\\n\\n```text\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\n```\\n\\nThis flag controls the Current Device Context exposure/read route only. It does\\nnot start Current State, change its collectors, add persistence or modify the\\nhistorical Device Card.\\n\\nRepository default `false` must not be interpreted as production disabled.\\n\\n"], ["docs/deployment.md", "## Feature activation\\n", "## DEVICE-CARD-01 deployment / activation history\\n\\n```text\\nTASK=TASK-DEVICE-CARD-01 — Current Device Context\\nPR=#108\\nPR base=3eac6f13d5f3966574f6d1b0a10f531d988f91ec\\nimplementation commit=1a3f2b8a844f2ce1c26cbdd9e4c44d17a201ac14\\naccepted / production tree=8f1342f0a0f1e8242642161e02b2f3276e6ddf51\\nmerge / production commit=7df71a8e807efd74b123117e78cb8d992c190fa1\\nprevious production runtime=e32ade378bdbfc9f8458db9c18221958f4552718\\n```\\n\\nProduction:\\n\\n```text\\nhost=192.168.0.202\\napplication=/opt/CaptivePortal\\nservice=captive-portal.service\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\n```\\n\\nRollout preserved the normal two-step feature boundary:\\n\\n```text\\n1. fast-forward deploy to 7df71a8e807efd74b123117e78cb8d992c190fa1\\n2. start/smoke with WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=false\\n3. separate activation to WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\n```\\n\\nFinal result:\\n\\n```text\\nPRODUCTION DEPLOY=PASS\\nPRODUCTION ACTIVATION=PASS\\ncaptive-portal.service=active\\nrollback required=no\\nOwner manual Device Detail verification=PASS\\n```\\n\\nNo new DB schema, index, migration or write path was deployed by this feature.\\nNo Device Detail request-time Omada/Loki/Grafana/external Analytics path was\\nintroduced.\\n\\nCurrent Device Context production semantics include:\\n\\n```text\\nfresh complete present → online\\nfresh complete absent  → offline\\nstale/unavailable/untrusted → unknown\\ntraffic technical failure → Current State retained\\nCurrent State execution failure → Current endpoint controlled 503\\nnumeric 0 Mbps → valid value\\n```\\n\\nThe follow-on `TASK-WEB-DEVICE-UI-01` is not part of this production rollout and\\nmust not be represented as deployed/current until separately accepted.\\n\\n"], ["docs/module-index.md", "## Next Traffic item\\n", "## Device UI follow-on\\n\\n```text\\nTASK-WEB-DEVICE-UI-01 = IN PROGRESS / LAB REVIEW PENDING\\nNOT MERGED\\nNOT DEPLOYED\\nNOT CURRENT PRODUCTION\\n```\\n\\nThis follow-on is presentation-layer work and does not change the current\\nauthoritative DEVICE-CARD-01 functional status.\\n\\n"], ["docs/modules/admin-web.md", "## Home\\n", "## Device Detail — Historical vs Current\\n\\nDevice Detail keeps two independent evidence domains.\\n\\nHistorical Device context remains:\\n\\n```text\\nIdentity\\nLatest Site Snapshot\\nLatest Client Observation\\nRecent Visits\\n```\\n\\n`TASK-DEVICE-CARD-01` adds the separate read-only:\\n\\n```text\\nCurrent Device Context\\n```\\n\\nwith:\\n\\n```text\\nPresence\\nAuthorization\\nNetwork\\nRadio\\nController\\nCurrent Guest Traffic\\nEvidence / Freshness\\n```\\n\\nFeature state:\\n\\n```text\\nrepository default:\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=false\\n\\nOwner-confirmed production:\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\n```\\n\\nEndpoint:\\n\\n```text\\nGET /admin/api/v1/sites/<site_id>/devices/<device_id>/current\\n```\\n\\nSecurity / contract:\\n\\n```text\\ncapability=admin.read.device\\nDTO=admin.device.current.v1\\nDevice is resolved through existing Site-safe Device boundary\\ncanonical MAC is resolved server-side\\nquery parameters=none\\n```\\n\\nCanonical path:\\n\\n```text\\npersisted Site-safe Device identity\\n→ canonical MAC\\n→ CurrentStateReadService exact current client\\n→ optional pinned exact-client CurrentGuestTrafficReadService\\n→ AdminQueryService\\n→ strict Admin serializer\\n→ same-origin Device Detail\\n```\\n\\nNo browser/API request calls Omada, Loki, Grafana or the internal Analytics\\nBearer API.\\n\\nPresence:\\n\\n```text\\nonline  = present in fresh + complete managed Current State scope\\noffline = absent from fresh + complete managed Current State scope\\nunknown = stale/unavailable/untrusted/invalid current evidence\\n```\\n\\nHistorical evidence alone never proves `offline`.\\n\\n```text\\nstale != offline\\nunavailable != offline\\ninvalid timestamp != offline\\n```\\n\\nAuthorization values are current evidence:\\n\\n```text\\nauthorized\\npending\\nother\\nunknown\\n```\\n\\nCurrent Guest Traffic is only applicable to a current authorized guest. Pending\\nor other current clients do not receive fabricated rate data.\\n\\nTraffic failure is isolated:\\n\\n```text\\nTraffic technical failure\\n→ endpoint remains a valid Current response\\n→ Presence/Authorization/Network/Radio remain available\\n→ failure_reason is local to current_guest_traffic\\n```\\n\\nA Current State execution/read failure is different and maps to the controlled\\nCurrent endpoint failure path (`503` where source/query availability fails).\\nHistorical Device Card loading remains independent.\\n\\nNumeric zero is a valid value:\\n\\n```text\\n0 Mbps != —\\n0 Mbps != missing\\n0 Mbps != unavailable\\n```\\n\\nInvalid Current State timestamps are sanitized to safe semantics:\\n\\n```text\\nHTTP success for semantic evidence\\nPresence=unknown\\nObserved=null/—\\nAge=null/—\\nFreshness=unavailable\\nReason=invalid_timestamp\\n```\\n\\nFrontend lifecycle:\\n\\n```text\\none Current load when Device Detail opens\\nmanual Refresh supported\\nautomatic Current polling absent\\nno overlapping Current request\\nHistorical and Current load independently\\nCurrent failure does not erase Historical\\n```\\n\\n"], ["docs/modules/analytics.md", "## Completed Guest Session Traffic\\n", "## Exact-client Current Guest Traffic reuse\\n\\n`TASK-DEVICE-CARD-01` reuses the existing `CurrentGuestTrafficReadService`\\nsemantic owner for one current authorized device.\\n\\nNew exact-client projection:\\n\\n```text\\nCurrentStateReadService.read_current_guest_rate_client_evidence(...)\\n→ CurrentGuestTrafficReadService.get_current_guest_traffic_for_client(...)\\n```\\n\\nThe projection is pinned to the accepted Current State `current_cycle_id` and\\ncanonical Site/scope identity. It reads one current row plus the nearest accepted\\nbaseline row instead of materializing the Site population.\\n\\nThis is not a new Traffic semantic owner.\\n\\nPermanent:\\n\\n```text\\nsame current cycle as Device Current Context\\nauthorized current guest only\\nnumeric zero remains valid\\nno query-time Omada\\nno source write\\nno new persistence/schema\\n```\\n\\nTraffic source/integrity/deadline failures can be reported locally by Device\\nCurrent Context without invalidating otherwise trustworthy Current State facts.\\n\\n"], ["docs/modules/current-state.md", "## Dependencies\\n", "## Exact Current Device read contract\\n\\n`TASK-DEVICE-CARD-01` extends the read boundary without changing Current State\\ncollection or schema.\\n\\nCanonical exact lookup:\\n\\n```text\\nCurrentStateReadService.get_current_client(\\n    site_id,\\n    client_mac,\\n    evaluated_at_utc=...,\\n    cycle_id=optional,\\n)\\n```\\n\\nThe lookup resolves the canonical configured Site/SSID scope and only exposes a\\nclient row when the selected snapshot is:\\n\\n```text\\nresult=success\\ncomplete=true\\nfresh\\ntrusted source scope\\n```\\n\\nResult:\\n\\n```text\\nCurrentClientLookup(\\n    snapshot=CurrentSnapshotMeta,\\n    client=CurrentClientState | None,\\n)\\n```\\n\\nPresence is composed by the Admin Device Current boundary:\\n\\n```text\\nfresh complete trusted scope + matching client row\\n→ online\\n\\nfresh complete trusted scope + no matching client row\\n→ offline\\n\\nstale/unavailable/untrusted current evidence\\n→ unknown\\n```\\n\\nTherefore:\\n\\n```text\\nhistorical data alone != offline proof\\nstale != offline\\nunavailable != offline\\ninvalid timestamp != offline\\n```\\n\\nThe same TASK also adds bounded pinned evidence for one exact client rate:\\n\\n```text\\nread_current_guest_rate_client_evidence(...)\\n```\\n\\nwhich reads one accepted current cycle/client and the nearest previous accepted\\ncycle/client under the same Site/scope. It adds no Site population scan, write\\npath, schema/index or acquisition behavior.\\n\\nInvalid timestamp/source-scope evidence is sanitized/fail-safe and cannot be\\ncoerced to fresh Current State.\\n\\n"], ["docs/project-inventory.md", "Traffic Evidence endpoint:\\n", "Device Current endpoint:\\n\\n```text\\nGET /admin/api/v1/sites/<site_id>/devices/<device_id>/current\\n```\\n\\nContract:\\n\\n```text\\ncapability=admin.read.device\\nDTO=admin.device.current.v1\\nrepository default flag=false\\nOwner-confirmed production flag=true\\n```\\n\\nThe existing Site-safe Device lookup resolves the device and canonical MAC first.\\nCurrent State then provides Presence/Authorization/Network/Radio/Controller\\nevidence. Exact-client Current Guest Traffic is composed only when applicable.\\n\\nHistorical Device context remains independent and is not used to infer current\\noffline state.\\n\\n"], ["docs/project-inventory.md", "## 13. Admin security facts\\n", "## 12A. Device Current Context production state\\n\\n```text\\nTASK-DEVICE-CARD-01=COMPLETE\\nPR #108=MERGED\\nimplementation=1a3f2b8a844f2ce1c26cbdd9e4c44d17a201ac14\\nmain / production=7df71a8e807efd74b123117e78cb8d992c190fa1\\ntree=8f1342f0a0f1e8242642161e02b2f3276e6ddf51\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\nPRODUCTION DEPLOY=PASS\\nPRODUCTION ACTIVATION=PASS\\nOwner manual Device Detail verification=PASS\\n```\\n\\nNo DB schema/index/migration/write path was added.\\n\\nFollow-on:\\n\\n```text\\nTASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING\\nNOT MERGED\\nNOT DEPLOYED\\n```\\n\\n"], ["docs/testing.md", "### Latest Traffic acceptance evidence — TRAFFIC-09\\n", "### Latest Device acceptance evidence — TASK-DEVICE-CARD-01\\n\\n```text\\nTASK=TASK-DEVICE-CARD-01 — Current Device Context\\nPR=#108\\nPR base=3eac6f13d5f3966574f6d1b0a10f531d988f91ec\\nimplementation commit=1a3f2b8a844f2ce1c26cbdd9e4c44d17a201ac14\\naccepted / production tree=8f1342f0a0f1e8242642161e02b2f3276e6ddf51\\nmerge / production commit=7df71a8e807efd74b123117e78cb8d992c190fa1\\n```\\n\\nAcceptance:\\n\\n```text\\nimplementation=PASS\\nOwner + Tech Lead acceptance=PASS\\ncross-surface focused gate=178 passed\\nOfficial Windows Central Full V6=PASS\\nstrict regressions=0\\nbounded exact-read/query-plan gate=PASS\\nControlled Browser acceptance=PASS\\nproduction deploy=PASS\\nproduction activation=PASS\\nOwner manual production Web UI verification=PASS\\n```\\n\\nControlled Browser scenarios explicitly covered:\\n\\n```text\\nonline\\npending\\noffline\\nstale\\ninvalid timestamp\\nCurrent endpoint 503\\nTraffic technical failure\\nvalid numeric zero\\nmanual Refresh\\nno Current overlap\\nno automatic polling\\n```\\n\\nSemantic acceptance:\\n\\n```text\\nhistorical Device context != current Device context\\noffline requires fresh + complete managed scope\\nstale/unavailable/invalid timestamp != offline\\ntraffic failure does not erase Current State\\n0 Mbps != unavailable\\nCurrent State execution failure is controlled independently\\n```\\n\\nNo schema/index/migration/write path or query-time Omada was introduced.\\n\\nFollow-on `TASK-WEB-DEVICE-UI-01` is not acceptance evidence for this TASK and is\\nnot current production:\\n\\n```text\\nIN PROGRESS / LAB REVIEW PENDING\\nNOT MERGED\\nNOT DEPLOYED\\n```\\n\\n"]], "new_files": {"docs/tasks/TASK-DEVICE-CARD-01-FINAL.md": "# TASK-DEVICE-CARD-01 — Current Device Context — FINAL\\n\\n**Project:** CaptivPortal  \\n**Area:** Admin Console → Devices → Device Detail  \\n**Status:** `COMPLETE / PRODUCTION ACTIVE`  \\n**Updated:** 2026-09-09\\n\\n## 1. Final closure\\n\\n```text\\nTASK-DEVICE-CARD-01=COMPLETE\\nIMPLEMENTATION=PASS\\nOWNER + TECH LEAD ACCEPTANCE=PASS\\nMERGE=COMPLETE\\nPRODUCTION DEPLOY=PASS\\nPRODUCTION ACTIVATION=PASS\\n```\\n\\nProduction feature state:\\n\\n```text\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\n```\\n\\nRepository default remains:\\n\\n```text\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=false\\n```\\n\\nRepository default and production activation are separate facts.\\n\\n## 2. Git / artifact identity\\n\\n```text\\nrepository=ZaurNavi/CaptivePortal\\nPR=#108 — TASK-DEVICE-CARD-01 — Current Device Context\\nPR base=3eac6f13d5f3966574f6d1b0a10f531d988f91ec\\nimplementation commit=1a3f2b8a844f2ce1c26cbdd9e4c44d17a201ac14\\naccepted implementation tree=8f1342f0a0f1e8242642161e02b2f3276e6ddf51\\nmerge / current main / production commit=7df71a8e807efd74b123117e78cb8d992c190fa1\\nprevious production runtime=e32ade378bdbfc9f8458db9c18221958f4552718\\n```\\n\\nPR #108 is merged.\\n\\n## 3. Production\\n\\n```text\\nhost=192.168.0.202\\nrepository=/opt/CaptivePortal\\nservice=captive-portal.service\\nmain / production=7df71a8e807efd74b123117e78cb8d992c190fa1\\ntree=8f1342f0a0f1e8242642161e02b2f3276e6ddf51\\n```\\n\\nRollout:\\n\\n```text\\nprevious production=e32ade378bdbfc9f8458db9c18221958f4552718\\n→ fast-forward to 7df71a8e807efd74b123117e78cb8d992c190fa1\\n→ first smoke with feature=false\\n→ separate feature activation=true\\n→ service active\\n→ Owner manual production Device Detail verification=PASS\\n```\\n\\nRollback was not required.\\n\\n## 4. Product boundary\\n\\nThe existing Device Detail keeps historical information:\\n\\n```text\\nIdentity\\nLatest Site Snapshot\\nLatest Client Observation\\nRecent Visits\\n```\\n\\nTASK-DEVICE-CARD-01 adds a separate read-only block:\\n\\n```text\\nCurrent Device Context\\n```\\n\\nwith:\\n\\n```text\\nPresence\\nAuthorization\\nNetwork\\nRadio\\nController\\nCurrent Guest Traffic\\nEvidence / Freshness\\n```\\n\\nPermanent:\\n\\n```text\\nHistorical Device Context != Current Device Context\\n```\\n\\nHistorical facts never substitute for missing/untrusted current evidence.\\n\\n## 5. Canonical data path\\n\\n```text\\nexisting Site-safe Device boundary\\n→ resolve requested device inside Site\\n→ resolve canonical MAC server-side\\n→ CurrentStateReadService.get_current_client(...)\\n→ optional pinned exact-client CurrentGuestTrafficReadService\\n→ AdminQueryService.device_current_context(...)\\n→ strict Admin serializer\\n→ admin.device.current.v1\\n→ Device Detail\\n```\\n\\nNo Device Card request adds:\\n\\n```text\\nbrowser → Omada\\nbrowser → Loki\\nbrowser → Grafana\\nbrowser → external Analytics API\\nAdmin request → Omada\\n```\\n\\nNo new collector, DB, schema, index, migration, write path, worker or scheduler\\nwas introduced.\\n\\n## 6. Endpoint / authorization\\n\\n```text\\nGET /admin/api/v1/sites/<site_id>/devices/<device_id>/current\\n```\\n\\nCapability:\\n\\n```text\\nadmin.read.device\\n```\\n\\nDTO:\\n\\n```text\\nadmin.device.current.v1\\n```\\n\\nThe device is first resolved through the existing Site-safe Device boundary.\\nCanonical MAC identity is server-side.\\n\\nQuery parameters are not part of the v1 endpoint contract.\\n\\n## 7. Current State exact lookup\\n\\nCanonical service addition:\\n\\n```text\\nCurrentStateReadService.get_current_client(...)\\n```\\n\\nThe exact client row is exposed only from an accepted client snapshot that is:\\n\\n```text\\nresult=success\\ncomplete=true\\nfresh\\ncorrect Site\\ntrusted canonical Site/SSID source scope\\n```\\n\\nThe lookup does not use historical Device/Visit/Observation data to reconstruct\\ncurrent state.\\n\\n## 8. Presence semantics\\n\\n### Online\\n\\n```text\\nfresh + complete managed Current State scope\\n+\\nmatching current client row\\n→ presence=online\\n```\\n\\n### Offline\\n\\n```text\\nfresh + complete managed Current State scope\\n+\\ndevice is proven absent\\n→ presence=offline\\n```\\n\\nOffline requires positive absence evidence.\\n\\n### Unknown\\n\\n```text\\nstale\\nunavailable\\ninvalid timestamp\\ninvalid/untrusted source scope\\nother untrusted current evidence\\n→ presence=unknown\\n```\\n\\nPermanent:\\n\\n```text\\nstale != offline\\nunavailable != offline\\ninvalid timestamp != offline\\nhistorical absence/presence != current offline proof\\n```\\n\\n## 9. Authorization semantics\\n\\nCurrent authorization evidence is classified as:\\n\\n```text\\nauthorized\\npending\\nother\\nunknown\\n```\\n\\nThis is Current State evidence, not historical Visit/Auth evidence.\\n\\nOffline/unknown current state does not inherit an old authorization value from\\nhistory.\\n\\n## 10. Current Guest Traffic\\n\\nTraffic is applicable only to:\\n\\n```text\\npresence=online\\nauthorization=authorized\\n```\\n\\nFor current pending/other clients:\\n\\n```text\\ntraffic applicability=not_applicable\\n```\\n\\nNo fabricated rate is produced.\\n\\nExact-client traffic reuses the existing semantic owner:\\n\\n```text\\nCurrentGuestTrafficReadService\\n```\\n\\nwith a pinned same-cycle exact-client read.\\n\\nThe exact-client projection reads the current accepted row and nearest previous\\naccepted row under the same Site/scope. It does not materialize the full Site\\npopulation.\\n\\n## 11. Numeric zero\\n\\nNumeric zero is evidence:\\n\\n```text\\n0 Mbps\\n```\\n\\nIt is not:\\n\\n```text\\nN/A\\nmissing\\nunavailable\\n—\\n```\\n\\nPermanent:\\n\\n```text\\n0 != null\\n```\\n\\n## 12. Traffic failure isolation\\n\\nA technical Current Guest Traffic problem is local to the Traffic evidence.\\n\\nExamples:\\n\\n```text\\nsource_unavailable\\nintegrity_unavailable\\nquery_deadline\\n```\\n\\nRequired behavior:\\n\\n```text\\nCurrent endpoint remains a valid composed Current response\\nPresence retained\\nAuthorization retained\\nNetwork retained\\nRadio retained\\nController retained\\nTraffic failure_reason populated locally\\n```\\n\\nTraffic technical failure must not be rewritten as generic\\n`insufficient_data`.\\n\\n## 13. Current State execution failure\\n\\nIf Current State itself cannot execute/read safely:\\n\\n```text\\nCurrent endpoint → controlled source/query failure (503 where applicable)\\n```\\n\\nThe historical Device Card remains an independent path and Device Detail must\\nnot be destroyed by Current failure.\\n\\n## 14. Freshness / evidence\\n\\nCurrent Device Context exposes separate evidence including:\\n\\n```text\\nevaluated time\\nobserved time\\ncapture/age\\nfreshness\\nfreshness reason\\nmanaged Site/SSID scope\\n```\\n\\nCurrent State freshness family remains:\\n\\n```text\\nfresh\\nstale\\nunavailable\\n```\\n\\n## 15. Invalid timestamp\\n\\nUnsafe timestamp evidence is sanitized.\\n\\nCanonical semantic outcome:\\n\\n```text\\nHTTP semantic Current response remains safe\\nPresence=unknown\\nObserved=null / —\\nAge=null / —\\nFreshness=unavailable\\nReason=invalid_timestamp\\n```\\n\\nInvalid timestamps are not exposed as trusted Current evidence and never become\\noffline proof.\\n\\n## 16. Frontend lifecycle\\n\\nCurrent Device Context lifecycle:\\n\\n```text\\none load when Device Detail opens\\nmanual Refresh\\nno automatic polling\\nno overlapping Current request\\n```\\n\\nHistorical and Current parts load independently.\\n\\nCurrent failure:\\n\\n```text\\ndoes not clear/destroy historical Device context\\n```\\n\\n## 17. Acceptance\\n\\n```text\\nCross-surface focused gate=178 passed\\n\\nOfficial Windows Central Full V6=PASS\\nstrict regressions=0\\n\\nBounded exact-read/query-plan gate=PASS\\n\\nControlled Browser acceptance=PASS\\n```\\n\\nControlled Browser acceptance covered:\\n\\n```text\\nonline\\npending\\noffline\\nstale\\ninvalid timestamp\\nCurrent 503\\nTraffic failure\\nvalid zero\\nmanual Refresh\\nno Current overlap\\nno automatic polling\\n```\\n\\n## 18. Production result\\n\\n```text\\nWEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true\\ncaptive-portal.service=active\\nproduction deploy=PASS\\nproduction activation=PASS\\nOwner manual Web UI verification=PASS\\nrollback required=no\\n```\\n\\nThe feature is current production functionality.\\n\\n## 19. Separate UI/design work\\n\\n`TASK-WEB-DEVICE-UI-01` is explicitly outside this completed functional TASK.\\n\\nCurrent status:\\n\\n```text\\nTASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING\\nMERGED=NO\\nDEPLOYED=NO\\nACCEPTED PRODUCTION BEHAVIOR=NO\\n```\\n\\nIt may change presentation such as compact Devices cards/list,\\nhuman-readable bytes/time/rates, status indicators and future Online-first UX.\\n\\nUntil separately accepted and deployed, those presentation changes must not be\\ndescribed as current production behavior.\\n\\n## 20. Final decision\\n\\n```text\\nTASK-DEVICE-CARD-01=COMPLETE\\nDEVICE_CURRENT_CONTEXT=PRODUCTION ACTIVE\\nIMPLEMENTATION=PASS\\nACCEPTANCE=PASS\\nMERGE=COMPLETE\\nPRODUCTION DEPLOY=PASS\\nPRODUCTION ACTIVATION=PASS\\n\\nTASK-WEB-DEVICE-UI-01=NOT COMPLETE\\n```\\n"}}')

def run_text(args, cwd, check=True):
    p = subprocess.run(
        args, cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        encoding="utf-8",
        errors="replace",
    )
    if check and p.returncode != 0:
        if p.stdout:
            print(p.stdout, end="")
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")
    return p.stdout or ""

def run_passthrough(args, cwd):
    p = subprocess.run(args, cwd=cwd)
    if p.returncode != 0:
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")

def norm(s):
    return s.replace("\r\n", "\n").replace("\r", "\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(norm(text), encoding="utf-8", newline="\n")

def status_paths(repo):
    out = run_text(["git","status","--porcelain","--untracked-files=all"], repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE", str(Path.home())))
            / "Downloads" / "CaptivPortal-KB-Work")
    ))
    ap.add_argument("--no-push", action="store_true")
    ns = ap.parse_args()
    repo = Path(ns.repo)

    print("Publisher:", PAYLOAD["version"])
    print("=== PRECHECK ===")

    if not (repo / ".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    dirty = status_paths(repo)
    if dirty:
        print("Dirty paths:")
        for p in dirty:
            print(" ", p)
        raise SystemExit("STOP: worktree must be clean")

    run_passthrough(["git","fetch","origin","main"], repo)
    remote = run_text(["git","rev-parse","origin/main"], repo).strip()
    tree = run_text(["git","rev-parse","origin/main^{tree}"], repo).strip()
    print("origin/main:", remote)
    print("origin tree:", tree)

    if remote != PAYLOAD["base"]:
        raise SystemExit("STOP: origin/main moved; KB update must be rebound")
    if tree != PAYLOAD["tree"]:
        raise SystemExit("STOP: origin/main tree mismatch")

    run_passthrough(["git","switch","main"], repo)
    run_passthrough(["git","merge","--ff-only","origin/main"], repo)

    branch = PAYLOAD["branch"]
    remote_branch = run_text(
        ["git","ls-remote","--heads","origin",f"refs/heads/{branch}"], repo
    ).strip()
    if remote_branch:
        raise SystemExit("STOP: remote publication branch already exists")

    local = run_text(["git","branch","--list",branch], repo).strip()
    if local:
        local_sha = run_text(["git","rev-parse",branch], repo).strip()
        if local_sha != PAYLOAD["base"]:
            raise SystemExit("STOP: existing local publication branch advanced")
        run_passthrough(["git","branch","-D",branch], repo)

    run_passthrough(["git","switch","-c",branch], repo)

    print("=== ALL-ANCHOR PRECHECK ===")
    cache = {}
    for path, old, _new in PAYLOAD["replacements"]:
        text = cache.setdefault(path, read(repo / path))
        count = text.count(old)
        if count != 1:
            raise SystemExit(f"STOP: replace anchor {path} matched {count} times")
    for path, anchor, _new in PAYLOAD["insertions"]:
        text = cache.setdefault(path, read(repo / path))
        count = text.count(anchor)
        if count != 1:
            raise SystemExit(f"STOP: insert anchor {path} matched {count} times")
    for path in PAYLOAD["new_files"]:
        if (repo / path).exists():
            raise SystemExit(f"STOP: new final task already exists: {path}")
    print("PASS: all anchors validated before first write")

    print("=== APPLY ===")
    # Insertions before replacements prevents same-anchor mutation drift.
    grouped = {}
    for path, anchor, new in PAYLOAD["insertions"]:
        grouped.setdefault(path, []).append(("insert", anchor, new))
    for path, old, new in PAYLOAD["replacements"]:
        grouped.setdefault(path, []).append(("replace", old, new))

    for path, ops in grouped.items():
        text = read(repo / path)
        for kind, old, new in ops:
            if text.count(old) != 1:
                raise SystemExit(
                    f"STOP: mutation anchor drifted in {path} during {kind}"
                )
            if kind == "insert":
                text = text.replace(old, new.rstrip() + "\n\n" + old, 1)
            else:
                text = text.replace(old, new, 1)
        write(repo / path, text)

    for path, content in PAYLOAD["new_files"].items():
        write(repo / path, content.rstrip() + "\n")

    actual = status_paths(repo)
    expected = sorted(PAYLOAD["scope"])
    print("Changed files:")
    for p in actual:
        print(" ", p)
    if actual != expected:
        print("Expected:")
        for p in expected:
            print(" ", p)
        raise SystemExit("STOP: exact docs scope mismatch")

    print("=== CANONICAL ASSERTIONS ===")
    checks = {
        "docs/tasks/TASK-DEVICE-CARD-01-FINAL.md": [
            "TASK-DEVICE-CARD-01=COMPLETE",
            "WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true",
            "admin.device.current.v1",
            "stale != offline",
            "TASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING",
        ],
        "docs/modules/admin-web.md": [
            "GET /admin/api/v1/sites/<site_id>/devices/<device_id>/current",
            "capability=admin.read.device",
            "DTO=admin.device.current.v1",
            "automatic Current polling absent",
        ],
        "docs/modules/current-state.md": [
            "CurrentStateReadService.get_current_client",
            "stale != offline",
            "read_current_guest_rate_client_evidence",
        ],
        "docs/modules/analytics.md": [
            "get_current_guest_traffic_for_client",
            "same current cycle as Device Current Context",
        ],
        "docs/configuration.md": [
            "WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=false",
            "WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true",
        ],
        "docs/testing.md": [
            "cross-surface focused gate=178 passed",
            "Controlled Browser acceptance=PASS",
        ],
        "docs/deployment.md": [
            "PRODUCTION ACTIVATION=PASS",
            "Owner manual Device Detail verification=PASS",
        ],
    }
    for path, needles in checks.items():
        text = read(repo / path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(
                    f"STOP: missing canonical assertion in {path}: {needle}"
                )

    # Current-state documents must move to the DEVICE-CARD production baseline.
    current_docs = [
        "README.md",
        "README_RU.md",
        "docs/README.md",
        "docs/architecture.md",
        "docs/configuration.md",
        "docs/deployment.md",
        "docs/module-index.md",
        "docs/modules/admin-web.md",
        "docs/modules/analytics.md",
        "docs/modules/current-state.md",
        "docs/project-inventory.md",
        "docs/testing.md",
    ]
    stale = [
        "Current-state implementation baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`",
        "Runtime implementation baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`",
        "Baseline: `main@e32ade378bdbfc9f8458db9c18221958f4552718`",
        "Baseline: `main@53f617b3ac0155d0d647e58e98309927f9a4d318`",
    ]
    for path in current_docs:
        text = read(repo / path)
        for phrase in stale:
            if phrase in text:
                raise SystemExit(
                    f"STOP: stale current-state baseline remains in {path}: {phrase}"
                )

    # The separate UI task must never be accidentally promoted.
    for path in expected:
        text = read(repo / path)
        bad = [
            "TASK-WEB-DEVICE-UI-01=COMPLETE",
            "TASK-WEB-DEVICE-UI-01 = COMPLETE",
            "TASK-WEB-DEVICE-UI-01=PRODUCTION ACTIVE",
            "TASK-WEB-DEVICE-UI-01 = PRODUCTION ACTIVE",
        ]
        for phrase in bad:
            if phrase in text:
                raise SystemExit(
                    f"STOP: UI task incorrectly promoted in {path}: {phrase}"
                )

    # Docs-only boundary.
    for p in actual:
        if p.startswith("app/") or p.startswith("tests/") or p == ".env.example":
            raise SystemExit(f"STOP: runtime/test scope detected: {p}")

    run_passthrough(["git","diff","--check"], repo)

    print("PASS: exact 13-file docs scope")
    print("PASS: main/production 7df71a8 / tree 8f1342f canonicalized")
    print("PASS: TASK-DEVICE-CARD-01 COMPLETE / PRODUCTION ACTIVE")
    print("PASS: Historical != Current Device Context")
    print("PASS: Presence stale/unavailable != offline")
    print("PASS: exact-client Current Guest Traffic reuse")
    print("PASS: repository default OFF / production ON")
    print("PASS: no new DB/schema/write/provider contract")
    print("PASS: TASK-WEB-DEVICE-UI-01 remains IN PROGRESS / not production")
    print("PASS: git diff --check")

    run_passthrough(["git","add","--"] + expected, repo)
    run_passthrough(["git","diff","--cached","--check"], repo)

    # Binary-safe patch generation: bypass Windows console/code-page decoding.
    patch = Path(__file__).resolve().parent / (
        "CaptivPortal_KB_DEVICE_CARD_01_2026-09-09.patch"
    )
    with patch.open("wb") as fh:
        p = subprocess.run(
            ["git","diff","--cached","--binary","--"] + expected,
            cwd=repo,
            stdout=fh,
            stderr=subprocess.PIPE,
        )
    if p.returncode != 0:
        err = p.stderr.decode("utf-8", errors="replace")
        raise SystemExit(f"STOP: patch generation failed: {err}")
    if patch.stat().st_size <= 0:
        raise SystemExit("STOP: patch is empty")

    if ns.no_push:
        print("NO-PUSH mode: changes staged; commit/push/PR skipped")
        print("Unified diff:", patch)
        return

    run_passthrough([
        "git","commit",
        "-m","docs: reconcile DEVICE-CARD-01 production closure",
        "-m","Document Current Device Context production state, Presence/Traffic semantics, exact Current State and Current Guest Traffic read boundaries, acceptance/deployment evidence, and keep TASK-WEB-DEVICE-UI-01 explicitly in progress."
    ], repo)
    commit = run_text(["git","rev-parse","HEAD"], repo).strip()

    status = run_text(
        ["git","status","--short","--untracked-files=all"], repo
    ).strip()
    if status:
        print(status)
        raise SystemExit("STOP: worktree not clean after commit")

    run_passthrough(["git","push","-u","origin",branch], repo)

    body = f"""## Purpose

Canonical Knowledge Base reconciliation after production closure of
TASK-DEVICE-CARD-01 — Current Device Context.

## Current truth

- TASK-DEVICE-CARD-01: COMPLETE / PRODUCTION ACTIVE
- current main / production: {PAYLOAD['base']}
- production tree: {PAYLOAD['tree']}
- PR #108: merged
- WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true in production
- repository default remains false
- Owner + Tech Lead acceptance: PASS
- production deploy / activation: PASS

## Semantic boundaries

- Historical Device Context != Current Device Context
- offline requires fresh + complete managed Current State scope
- stale / unavailable / invalid timestamp != offline
- numeric 0 Mbps is valid evidence
- Traffic technical failure is local to Traffic evidence
- Current State execution failure remains a separate controlled endpoint failure
- no query-time Omada/Loki/Grafana/external Analytics
- no new DB/schema/index/migration/write path

## Follow-on UI task

TASK-WEB-DEVICE-UI-01 remains:
IN PROGRESS / LAB REVIEW PENDING / NOT MERGED / NOT DEPLOYED.

## Scope

- exactly 13 documentation files
- one new final TASK document
- application code changed: NO
- tests changed: NO
- runtime config changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""

    pr = run_text([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main",
        "--head",branch,
        "--title","Docs: reconcile DEVICE-CARD-01 production closure",
        "--body",body,
        "--draft",
    ], repo).strip()

    print("=== FINAL ===")
    print("Branch:", branch)
    print("Commit:", commit)
    print("Draft PR:", pr)
    print("Changed files:", len(expected))
    print("Application code changed: NO")
    print("Tests changed: NO")
    print("Runtime config changed: NO")
    print("Production changed: NO")
    print("Merge performed: NO")
    print("Unified diff:", patch)

if __name__ == "__main__":
    main()
