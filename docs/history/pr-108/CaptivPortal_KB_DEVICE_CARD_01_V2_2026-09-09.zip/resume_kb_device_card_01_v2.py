from __future__ import annotations
import os, subprocess
from pathlib import Path

BASE = '7df71a8e807efd74b123117e78cb8d992c190fa1'
TREE = '8f1342f0a0f1e8242642161e02b2f3276e6ddf51'
BRANCH = 'docs/device-card-current-context-kb-2026-09-09'
SCOPE = ['README.md', 'README_RU.md', 'docs/README.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/admin-web.md', 'docs/modules/analytics.md', 'docs/modules/current-state.md', 'docs/project-inventory.md', 'docs/tasks/TASK-DEVICE-CARD-01-FINAL.md', 'docs/testing.md']
CHECKS = {'docs/tasks/TASK-DEVICE-CARD-01-FINAL.md': ['TASK-DEVICE-CARD-01=COMPLETE', 'WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true', 'admin.device.current.v1', 'stale != offline', 'TASK-WEB-DEVICE-UI-01=IN PROGRESS / LAB REVIEW PENDING'], 'docs/modules/admin-web.md': ['GET /admin/api/v1/sites/<site_id>/devices/<device_id>/current', 'capability=admin.read.device', 'DTO=admin.device.current.v1', 'automatic Current polling absent'], 'docs/modules/current-state.md': ['CurrentStateReadService.get_current_client', 'stale != offline', 'read_current_guest_rate_client_evidence'], 'docs/configuration.md': ['WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=false', 'WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true']}

def run_text(args, cwd, check=True):
    p = subprocess.run(args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       encoding="utf-8", errors="replace")
    if check and p.returncode != 0:
        if p.stdout:
            print(p.stdout, end="")
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")
    return p.stdout or ""

def run_pass(args, cwd):
    p = subprocess.run(args, cwd=cwd)
    if p.returncode != 0:
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")

def names(repo, cached=False):
    args=["git","diff"]
    if cached:
        args.append("--cached")
    args += ["--name-only","--"]
    out=run_text(args,repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def untracked(repo):
    out=run_text(["git","ls-files","--others","--exclude-standard"],repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def index_text(repo,path):
    p=subprocess.run(["git","show",f":{path}"],cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode != 0:
        raise SystemExit("STOP: cannot read staged file "+path)
    return p.stdout.decode("utf-8","strict").replace("\r\n","\n").replace("\r","\n")

def main():
    repo=Path(os.environ.get("CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE",str(Path.home()))) / "Downloads" / "CaptivPortal-KB-Work")))
    print("Publisher: DEVICE-CARD-01-KB-V2-RESUME-2026-09-09")
    print("=== RECOVERY PRECHECK ===")
    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if run_text(["git","branch","--show-current"],repo).strip() != BRANCH:
        raise SystemExit("STOP: not on expected failed-V1 branch")
    if run_text(["git","rev-parse","HEAD"],repo).strip() != BASE:
        raise SystemExit("STOP: failed-V1 branch HEAD moved")

    run_pass(["git","fetch","origin","main"],repo)
    remote=run_text(["git","rev-parse","origin/main"],repo).strip()
    tree=run_text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:",remote)
    print("origin tree:",tree)
    if remote != BASE or tree != TREE:
        raise SystemExit("STOP: origin/main moved or tree mismatch")

    rb=run_text(["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo).strip()
    if rb:
        raise SystemExit("STOP: remote publication branch already exists")

    staged=names(repo,True)
    unstaged=names(repo,False)
    extra=untracked(repo)
    print("Staged files:")
    for p in staged:
        print(" ",p)
    if staged != sorted(SCOPE):
        raise SystemExit("STOP: staged scope is not exact 13-file docs scope")
    if unstaged:
        raise SystemExit("STOP: unexpected unstaged changes exist")
    if extra:
        raise SystemExit("STOP: unexpected untracked files exist")
    print("PASS: exact failed-V1 staged state")

    task="docs/tasks/TASK-DEVICE-CARD-01-FINAL.md"
    text=index_text(repo,task)

    bad = [
        "**Project:** CaptivPortal  \n",
        "**Area:** Admin Console → Devices → Device Detail  \n",
        "**Status:** `COMPLETE / PRODUCTION ACTIVE`  \n",
    ]
    for needle in bad:
        if text.count(needle) != 1:
            raise SystemExit("STOP: expected whitespace defect not found exactly once")

    trailing=[i for i,line in enumerate(text.splitlines(),1) if line.endswith(" ") or line.endswith("\t")]
    if trailing != [3,4,5]:
        raise SystemExit(f"STOP: unexpected trailing-whitespace lines: {trailing}")
    print("PASS: only expected trailing whitespace exists")

    fixed=(text
        .replace("**Project:** CaptivPortal  \n","**Project:** CaptivPortal\n",1)
        .replace("**Area:** Admin Console → Devices → Device Detail  \n","**Area:** Admin Console → Devices → Device Detail\n",1)
        .replace("**Status:** `COMPLETE / PRODUCTION ACTIVE`  \n","**Status:** `COMPLETE / PRODUCTION ACTIVE`\n",1)
    )
    (repo/task).write_text(fixed,encoding="utf-8",newline="\n")
    run_pass(["git","add","--",task],repo)
    if names(repo,False):
        raise SystemExit("STOP: repair left unstaged changes")
    print("PASS: repaired and restaged only FINAL task")

    print("=== CANONICAL ASSERTIONS ===")
    for path,needles in CHECKS.items():
        t=index_text(repo,path)
        for needle in needles:
            if needle not in t:
                raise SystemExit(f"STOP: missing staged assertion in {path}: {needle}")
    for path in SCOPE:
        t=index_text(repo,path)
        for phrase in [
            "TASK-WEB-DEVICE-UI-01=COMPLETE",
            "TASK-WEB-DEVICE-UI-01 = COMPLETE",
            "TASK-WEB-DEVICE-UI-01=PRODUCTION ACTIVE",
            "TASK-WEB-DEVICE-UI-01 = PRODUCTION ACTIVE",
        ]:
            if phrase in t:
                raise SystemExit(f"STOP: UI task incorrectly promoted in {path}")
    print("PASS: staged canonical content")

    run_pass(["git","diff","--cached","--check"],repo)
    print("PASS: git diff --cached --check")

    patch=Path(__file__).resolve().parent/"CaptivPortal_KB_DEVICE_CARD_01_2026-09-09.patch"
    with patch.open("wb") as fh:
        p=subprocess.run(["git","diff","--cached","--binary","--"]+sorted(SCOPE),
                         cwd=repo,stdout=fh,stderr=subprocess.PIPE)
    if p.returncode != 0 or patch.stat().st_size <= 0:
        raise SystemExit("STOP: patch generation failed")
    print("PASS: binary-safe patch written")

    print("=== COMMIT ===")
    run_pass([
        "git","commit",
        "-m","docs: reconcile DEVICE-CARD-01 production closure",
        "-m","Document Current Device Context production state, Presence/Traffic semantics, exact Current State and Current Guest Traffic read boundaries, acceptance/deployment evidence, and keep TASK-WEB-DEVICE-UI-01 explicitly in progress."
    ],repo)
    commit=run_text(["git","rev-parse","HEAD"],repo).strip()

    if run_text(["git","status","--short","--untracked-files=all"],repo).strip():
        raise SystemExit("STOP: worktree not clean after commit")

    print("=== PUSH ===")
    run_pass(["git","push","-u","origin",BRANCH],repo)

    print("=== CREATE DRAFT PR ===")
    body=f"""## Purpose

Canonical Knowledge Base reconciliation after production closure of TASK-DEVICE-CARD-01 — Current Device Context.

## Current truth

- TASK-DEVICE-CARD-01: COMPLETE / PRODUCTION ACTIVE
- current main / production: {BASE}
- production tree: {TREE}
- PR #108 merged
- WEB_ADMIN_DEVICE_CURRENT_CONTEXT_ENABLED=true in production
- repository default remains false
- Owner + Tech Lead acceptance: PASS
- production deploy / activation: PASS

## Follow-on UI task

TASK-WEB-DEVICE-UI-01 remains IN PROGRESS / LAB REVIEW PENDING / NOT MERGED / NOT DEPLOYED.

## Scope

- exactly 13 documentation files
- application code changed: NO
- tests changed: NO
- runtime config changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
"""
    pr=run_text([
        "gh","pr","create","--repo","ZaurNavi/CaptivePortal",
        "--base","main","--head",BRANCH,
        "--title","Docs: reconcile DEVICE-CARD-01 production closure",
        "--body",body,"--draft"
    ],repo).strip()

    print("=== FINAL ===")
    print("Branch:",BRANCH)
    print("Commit:",commit)
    print("Draft PR:",pr)
    print("Changed files: 13")
    print("Application code changed: NO")
    print("Tests changed: NO")
    print("Runtime config changed: NO")
    print("Production changed: NO")
    print("Merge performed: NO")
    print("Unified diff:",patch)

if __name__=="__main__":
    main()
