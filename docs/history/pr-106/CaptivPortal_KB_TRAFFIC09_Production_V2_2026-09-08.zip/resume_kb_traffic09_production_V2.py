from __future__ import annotations
import os, subprocess
from pathlib import Path

BASE = 'e32ade378bdbfc9f8458db9c18221958f4552718'
TREE = '2766139c83965dcf2f80e0c8084b3fb363dbd781'
BRANCH = 'docs/traffic09-production-kb-2026-09-08'
SCOPE = ['README.md', 'README_RU.md', 'docs/README.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/admin-web.md', 'docs/modules/analytics.md', 'docs/modules/traffic.md', 'docs/project-inventory.md', 'docs/tasks/TASK-TRAFFIC-09-FINAL.md', 'docs/testing.md']
CHECKS = {'docs/tasks/TASK-TRAFFIC-09-FINAL.md': ['Status: COMPLETED / PRODUCTION ACTIVE', 'TASK_TRAFFIC_09_PRODUCTION=ACTIVE', 'TASK_TRAFFIC_09_PRODUCTION_SMOKE=PASS', 'admin.traffic.evidence.v1', 'current_site_calls=20'], 'docs/modules/traffic.md': ['TRAFFIC-09 — Consolidated Traffic Evidence', 'WEB_ADMIN_TRAFFIC_EVIDENCE_ENABLED=true', 'TrafficEvidenceAggregator', 'missing / unknown / stale / insufficient / unavailable != 0'], 'docs/modules/admin-web.md': ['WEB_ADMIN_TRAFFIC_EVIDENCE_ENABLED=false', 'WEB_ADMIN_TRAFFIC_EVIDENCE_ENABLED=true', 'admin.read.overview + admin.read.devices'], 'docs/configuration.md': ['WEB_ADMIN_TRAFFIC_EVIDENCE_ENABLED=false', 'WEB_ADMIN_TRAFFIC_EVIDENCE_ENABLED=true'], 'docs/testing.md': ['### Latest Traffic acceptance evidence — TRAFFIC-09', '2921 passed, 1 skipped, 3 known baseline failures'], 'docs/deployment.md': ['TASK_TRAFFIC_09_PRODUCTION_SMOKE=PASS', 'p95=max=0.0730241s']}

def run_text(args, cwd, check=True):
    p = subprocess.run(
        args,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        encoding="utf-8",
        errors="replace",
    )
    if check and p.returncode != 0:
        if p.stdout:
            print(p.stdout, end="")
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")
    return p.stdout or ""

def run_passthrough(args, cwd):
    p = subprocess.run(args, cwd=cwd)
    if p.returncode != 0:
        raise SystemExit(f"STOP: command failed: {' '.join(args)}")

def staged_paths(repo):
    out = run_text(["git","diff","--cached","--name-only","--"], repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def unstaged_paths(repo):
    out = run_text(["git","diff","--name-only","--"], repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def untracked_paths(repo):
    out = run_text(["git","ls-files","--others","--exclude-standard"], repo)
    return sorted({x.strip() for x in out.splitlines() if x.strip()})

def index_text(repo, path):
    # Git object content is UTF-8 repository text. Decode explicitly, never via
    # Windows console code page.
    p = subprocess.run(
        ["git","show",f":{path}"],
        cwd=repo,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if p.returncode != 0:
        err = p.stderr.decode("utf-8", errors="replace")
        raise SystemExit(f"STOP: cannot read staged file {path}: {err}")
    return p.stdout.decode("utf-8", errors="strict").replace("\r\n","\n").replace("\r","\n")

def main():
    repo = Path(os.environ.get(
        "CAPTIVPORTAL_KB_REPO",
        str(Path(os.environ.get("USERPROFILE", str(Path.home()))) /
            "Downloads" / "CaptivPortal-KB-Work")
    ))
    if not (repo/".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")

    print("Publisher: TRAFFIC09-KB-V2-RESUME-2026-09-08")
    print("=== RECOVERY PRECHECK ===")

    current_branch = run_text(["git","branch","--show-current"],repo).strip()
    head = run_text(["git","rev-parse","HEAD"],repo).strip()

    if current_branch != BRANCH:
        raise SystemExit(f"STOP: expected failed-V1 branch {BRANCH}, got {current_branch}")
    if head != BASE:
        raise SystemExit(f"STOP: branch HEAD moved; expected {BASE}, got {head}")

    run_passthrough(["git","fetch","origin","main"],repo)
    remote = run_text(["git","rev-parse","origin/main"],repo).strip()
    remote_tree = run_text(["git","rev-parse","origin/main^{tree}"],repo).strip()
    print("origin/main:", remote)
    print("origin tree:", remote_tree)

    if remote != BASE:
        raise SystemExit("STOP: origin/main moved; resume artifact must be rebound")
    if remote_tree != TREE:
        raise SystemExit("STOP: origin/main tree mismatch")

    remote_branch = run_text(
        ["git","ls-remote","--heads","origin",f"refs/heads/{BRANCH}"],repo
    ).strip()
    if remote_branch:
        raise SystemExit("STOP: remote publication branch already exists")

    staged = staged_paths(repo)
    unstaged = unstaged_paths(repo)
    untracked = untracked_paths(repo)

    print("Staged files:")
    for p in staged:
        print(" ",p)

    if staged != sorted(SCOPE):
        print("Expected:")
        for p in sorted(SCOPE):
            print(" ",p)
        raise SystemExit("STOP: staged scope is not exact 13-file TRAFFIC-09 KB scope")

    if unstaged:
        print("Unstaged paths:")
        for p in unstaged:
            print(" ",p)
        raise SystemExit("STOP: unexpected unstaged changes exist")

    if untracked:
        print("Untracked paths:")
        for p in untracked:
            print(" ",p)
        raise SystemExit("STOP: unexpected untracked files exist")

    print("PASS: exact failed-V1 staged state")

    print("=== INDEX CANONICAL ASSERTIONS ===")
    for path, needles in CHECKS.items():
        text = index_text(repo,path)
        for needle in needles:
            if needle not in text:
                raise SystemExit(f"STOP: staged canonical assertion missing in {path}: {needle}")
    print("PASS: staged canonical content")

    # Historical TRAFFIC-08 final must not be staged.
    if "docs/tasks/TASK-TRAFFIC-08-FINAL.md" in staged:
        raise SystemExit("STOP: historical TRAFFIC-08 final unexpectedly staged")

    run_passthrough(["git","diff","--cached","--check"],repo)
    print("PASS: git diff --cached --check")

    print("=== WRITE PATCH AS BYTES ===")
    patch = Path(__file__).resolve().parent / "CaptivPortal_KB_TRAFFIC09_Production_2026-09-08.patch"
    with patch.open("wb") as fh:
        p = subprocess.run(
            ["git","diff","--cached","--binary","--"] + sorted(SCOPE),
            cwd=repo,
            stdout=fh,
            stderr=subprocess.PIPE,
        )
    if p.returncode != 0:
        err = p.stderr.decode("utf-8", errors="replace")
        raise SystemExit(f"STOP: staged patch generation failed: {err}")
    if patch.stat().st_size <= 0:
        raise SystemExit("STOP: staged patch is empty")
    print("PASS: binary-safe staged patch written")
    print("Patch bytes:", patch.stat().st_size)

    print("=== COMMIT ===")
    run_passthrough([
        "git","commit",
        "-m","docs: reconcile TRAFFIC-09 production closure",
        "-m","Mark Consolidated Traffic Evidence completed/production-active; record canonical product IDs, semantic-owner reuse, bounded read architecture, API/contracts, production activation/smoke, PERF and current baseline."
    ],repo)
    commit = run_text(["git","rev-parse","HEAD"],repo).strip()

    # Fail closed after commit: no residual local modifications.
    status = run_text(["git","status","--short","--untracked-files=all"],repo).strip()
    if status:
        print(status)
        raise SystemExit("STOP: worktree not clean after docs commit")

    print("=== PUSH ===")
    run_passthrough(["git","push","-u","origin",BRANCH],repo)

    print("=== CREATE DRAFT PR ===")
    body = f"""## Purpose

Canonical Knowledge Base reconciliation after production closure of TASK-TRAFFIC-09 — Consolidated Traffic Evidence.

## Current truth

- TASK-TRAFFIC-09: COMPLETED / PRODUCTION ACTIVE
- production/current implementation baseline: {BASE}
- production tree: {TREE}
- implementation commit: 6729e5bc45c810423cf739ebd8fc2685f6098a3d
- PR #106 merged
- WEB_ADMIN_TRAFFIC_EVIDENCE_ENABLED=true
- authenticated production smoke: PASS
- Owner Web UI verification: PASS
- official production-size PERF: PASS

## Scope

- exactly 13 canonical documentation files
- one new final TASK document
- application code changed: NO
- tests changed: NO
- runtime config changed: NO
- production changed by this docs PR: NO
- TRAFFIC-08 execution/final history preserved

Draft only. Merge remains Owner-controlled.
"""
    pr = run_text([
        "gh","pr","create",
        "--repo","ZaurNavi/CaptivePortal",
        "--base","main",
        "--head",BRANCH,
        "--title","Docs: reconcile TRAFFIC-09 production closure",
        "--body",body,
        "--draft",
    ],repo).strip()

    print("=== FINAL ===")
    print("Branch:",BRANCH)
    print("Commit:",commit)
    print("Draft PR:",pr)
    print("Changed files: 13")
    print("Application code changed: NO")
    print("Tests changed: NO")
    print("Runtime config changed: NO")
    print("Production changed: NO")
    print("Merge performed: NO")
    print("Unified diff:",patch)

if __name__ == "__main__":
    main()
