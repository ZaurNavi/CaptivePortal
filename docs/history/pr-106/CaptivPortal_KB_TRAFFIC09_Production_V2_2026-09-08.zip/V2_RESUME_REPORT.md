# TRAFFIC-09 KB V2 Resume Report

## V1 failure classification

`HARNESS / WINDOWS OUTPUT DECODING ERROR`

V1 completed:
- exact base/tree validation;
- all-anchor precheck;
- exact 13-file docs mutation;
- canonical assertions;
- stale-state checks;
- `git diff --check`;
- staging;
- `git diff --cached --check`.

It then attempted to capture `git diff --cached --binary` through Python
`text=True`, which used the Windows cp1251 default and failed on repository
UTF-8 bytes.

No commit, push or PR was performed.

## V2 strategy

V2 does not reapply the documentation update.

It resumes only if:
- current branch is exactly `docs/traffic09-production-kb-2026-09-08`;
- HEAD is exactly `e32ade378bdbfc9f8458db9c18221958f4552718`;
- origin/main is exactly `e32ade378bdbfc9f8458db9c18221958f4552718`;
- origin tree is exactly `2766139c83965dcf2f80e0c8084b3fb363dbd781`;
- remote publication branch is absent;
- staged paths are exactly the approved 13 docs;
- there are no unstaged or untracked changes;
- staged canonical assertions pass;
- `git diff --cached --check` passes.

Patch generation is binary-safe: stdout is written directly to a file as bytes,
so Windows console/code-page decoding is bypassed entirely.

SHA256:
`830bee887039d7d61e34c8825a53fe3bee66f7e861814f70851ec2fdd3c51efb`
