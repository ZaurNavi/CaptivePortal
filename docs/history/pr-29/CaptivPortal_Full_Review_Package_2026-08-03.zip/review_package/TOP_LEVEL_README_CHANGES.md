# Предлагаемые изменения public README

Status: exact review draft; not applied

README.md и README_RU.md сохраняют роль public overview. В оба файла предлагается добавить короткий блок после Overview/Обзор:

## Project knowledge base

- Architecture, module status and operations: docs/README.md
- Instructions for developers and coding agents: AGENTS.md
- Current main snapshot: docs/project-inventory.md

Русская версия:

## База знаний проекта

- Архитектура, статусы модулей и эксплуатация: docs/README.md
- Правила для разработчиков и coding agents: AGENTS.md
- Фактический снимок main: docs/project-inventory.md

Существующий подробный раздел Repository Structure предлагается сократить до ссылки на docs/project-inventory.md, чтобы он снова не устаревал при каждом новом модуле.

Авторитетное представление предлагаемых изменений обоих файлов находится в `README_CHANGES.patch`. Это точный unified diff относительно snapshot `main` `a44b3128d72a5ce17529db0842580571023242ee`; изменения не применялись к repository.
