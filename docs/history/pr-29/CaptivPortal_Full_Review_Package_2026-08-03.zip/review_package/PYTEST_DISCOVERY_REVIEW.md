# Предварительная проверка proposed pytest.ini

Status: completed against snapshot; proposal not applied
Checked: 2026-08-03
Repository snapshot: main a44b3128d72a5ce17529db0842580571023242ee

## Предложение

    [pytest]
    testpaths = tests

Цель — сделать `python -m pytest -q -rs` штатным gate только для настоящего test suite в `tests/`, не изменяя временные probe-файлы.

## Проверка test-like файлов вне tests/

| Путь | Классификация | Основание | Действие |
|---|---|---|---|
| omada_pending_cleanup_test.py | temporary standalone proof-of-concept | собственный module docstring объявляет независимый временный PoC; pytest не импортируется; test functions отсутствуют | keep unchanged; исключить из штатного discovery |
| tools/omada_pending_cleanup_test.py | temporary standalone proof-of-concept | идентичный временный PoC; pytest не импортируется; test functions отсутствуют | keep unchanged; исключить из штатного discovery |
| tools/pending_session_probe.py | temporary operational probe | имя не соответствует pytest discovery; module docstring описывает 2–3-day field experiment | keep unchanged; не считать test suite |

Также проверено отсутствие вне `tests/` файлов `conftest.py`, `pyproject.toml`, `setup.cfg`, `tox.ini` и существующего `pytest.ini`.

Вывод: на этом snapshot настоящих штатных тестов вне `tests/` не обнаружено. Proposed `pytest.ini` не скрывает известный штатный test module и не требует изменения probe-файлов.

## Baseline

- Ранее в ходе подготовки: `python -m pytest -q -rs` без proposed config завершился collection error из-за двух одноимённых PoC scripts.
- Ранее в ходе подготовки: `python -m pytest tests -q -rs` дал 798 passed, 1 failed; environment-specific failure suspected; normal Linux verification pending (AF_UNIX PermissionError).
- При финальной упаковке collect-only rerun не выполнен, потому что pytest отсутствует в текущем runtime. Новый успешный test claim не делается.

После merge Cleaner проверку нужно повторить: новые штатные tests должны находиться в `tests/`; если реальный test module появится вне каталога, proposed config следует пересмотреть до integration.
