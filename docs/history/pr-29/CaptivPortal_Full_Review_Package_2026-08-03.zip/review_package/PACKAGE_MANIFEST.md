# Full review package manifest

Status: complete review catalog; no repository changes applied
Prepared: 2026-08-03
Repository snapshot: main a44b3128d72a5ce17529db0842580571023242ee

Пакет содержит 49 файлов, включая этот manifest.

## Review-level files

- PACKAGE_MANIFEST.md
- REVIEW_REPORT.md
- ACCEPTANCE_MATRIX.md
- PYTEST_DISCOVERY_REVIEW.md
- TOP_LEVEL_README_CHANGES.md
- README_CHANGES.patch

## Proposed repository root and GitHub instructions

- proposed_repository/AGENTS.md
- proposed_repository/pytest.ini
- proposed_repository/scripts/check.sh
- proposed_repository/.github/copilot-instructions.md
- proposed_repository/.github/pull_request_template.md
- proposed_repository/.github/instructions/background-workers.instructions.md
- proposed_repository/.github/instructions/documentation.instructions.md
- proposed_repository/.github/instructions/logging.instructions.md
- proposed_repository/.github/instructions/omada-api.instructions.md
- proposed_repository/.github/instructions/python.instructions.md
- proposed_repository/.github/instructions/storage.instructions.md
- proposed_repository/.github/instructions/tests.instructions.md

## Proposed knowledge base

- proposed_repository/docs/README.md
- proposed_repository/docs/architecture.md
- proposed_repository/docs/project-inventory.md
- proposed_repository/docs/module-index.md
- proposed_repository/docs/testing.md
- proposed_repository/docs/logging.md
- proposed_repository/docs/deployment.md
- proposed_repository/docs/security.md
- proposed_repository/docs/api/omada-open-api.md
- proposed_repository/docs/archive/README.md
- proposed_repository/docs/archive/migration-plan.md

## Module contracts

- proposed_repository/docs/modules/authorization.md
- proposed_repository/docs/modules/portal-entry.md
- proposed_repository/docs/modules/capport.md
- proposed_repository/docs/modules/auth-telemetry.md
- proposed_repository/docs/modules/public-authorization-counter.md
- proposed_repository/docs/modules/public-traffic-counter.md
- proposed_repository/docs/modules/authorized-client-snapshot.md
- proposed_repository/docs/modules/visitor-registry.md
- proposed_repository/docs/modules/omada-webhook-receiver.md
- proposed_repository/docs/modules/omada-webhook-normalizer.md
- proposed_repository/docs/modules/pending-session-cleaner.md

## Agent workflow and templates

- proposed_repository/docs/agents/workflow.md
- proposed_repository/docs/agents/task-contract.md
- proposed_repository/docs/agents/handoff.md
- proposed_repository/docs/agents/repository-actions.md
- proposed_repository/docs/agents/model-selection.md
- proposed_repository/docs/agents/pilot-results.md
- proposed_repository/docs/tasks/TASK-template.md
- proposed_repository/docs/plans/PLAN-template.md
- proposed_repository/docs/decisions/ADR-template.md

## README delivery form

`README_CHANGES.patch` — authoritative exact diff for `README.md` and `README_RU.md` against the recorded snapshot. `TOP_LEVEL_README_CHANGES.md` explains the intent. Repository files were not modified.
