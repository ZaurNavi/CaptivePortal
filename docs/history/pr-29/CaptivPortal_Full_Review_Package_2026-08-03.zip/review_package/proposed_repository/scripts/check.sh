#!/usr/bin/env sh
set -eu

python -m pytest -q -rs
PYTHONPYCACHEPREFIX=/tmp/captivportal-pyc \
    python -m compileall -q app
git diff --check
