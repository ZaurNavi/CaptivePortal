# Инвентаризация CaptivPortal

Status: proposed snapshot
Updated: 2026-08-03
Branch: main
Commit: a44b3128d72a5ce17529db0842580571023242ee
Commit date: 2026-07-31T14:52:24+04:00

Документ описывает только указанный снимок основной ветки. Feature branches, chat claims и production state сюда не включены.

## Runtime и composition

- Единственный прямой entrypoint: run.py.
- Верхнеуровневый lifecycle/composition root: run.py.
- Flask composition factory: app/web/web.py:create_app().
- Configuration pipeline: app/config.py → app/settings.py:get_settings().
- Controller factory: app/controllers/factory.py:create_controller().
- Реализация controller: app/controllers/omada.py:OmadaProvider.
- run.py создаёт один provider и передаёт его web/auth и snapshot collector.
- В этом snapshot OmadaProvider вызывает `_get_token()` для каждого operation request; shared token cache отсутствует.
- AuthSessionManager и ThreadPoolExecutor(max_workers=4) создаются один раз на process в app/web/web.py.
- In-memory sessions, locks и workers предполагают один WSGI process.

## Подсистемы и реальные пути

| Подсистема | Код |
|---|---|
| Portal entry | app/web/portal_entry.py, app/web/web.py |
| AuthSession | app/auth/session.py |
| AuthSessionManager | app/auth/manager.py |
| AuthWorker | app/auth/worker.py |
| Omada provider | app/controllers/omada.py |
| CAPPORT | app/capport/ |
| Auth telemetry | app/auth_telemetry/ |
| Public Authorization Counter | app/portal_counter/ |
| Completed-session traffic counter | app/public_traffic/ |
| Authorized Client Snapshot Collector | app/visitor_registry/snapshot_* |
| Visitor Device Registry | app/visitor_registry/registry_* |
| Omada Webhook Receiver/Normalizer | app/integrations/omada/ |
| Pending Session Cleaner | отсутствует в app/; в main есть только временный tools/pending_session_probe.py |

## Feature flags по default config

| Setting | Default в main | Интерпретация |
|---|---:|---|
| CAPPORT_ENABLED | true | реализован и включён конфигурацией |
| PORTAL_COUNTER_ENABLED | true | реализован и включён |
| PUBLIC_TRAFFIC_COUNTER_ENABLED | true | реализован и включён |
| AUTH_TELEMETRY_ENABLED | true | реализован и включён |
| VISITOR_SNAPSHOT_ENABLED | false | implemented-disabled |
| VISITOR_REGISTRY_ENABLED | false | implemented-disabled |
| OMADA_WEBHOOK_ENABLED | false | receiver и normalizer implemented-disabled |
| Pending Cleaner flag | отсутствует | final module отсутствует в main |

Эти значения не подтверждают фактическое состояние production.

## Journals и persistence

| Назначение | Default path | Тип |
|---|---|---|
| Authorization telemetry | /opt/CaptivePortal/logs/auth_telemetry.log | JSONL telemetry |
| Authorized snapshots | /opt/CaptivePortal/logs/visitor_snapshots.log | JSONL data journal |
| Raw Omada webhook | /opt/CaptivePortal/logs/omada_webhook.log | JSONL data journal |
| Normalized Omada webhook | /opt/CaptivePortal/logs/omada_webhook_normalized.log | JSONL data journal |
| Portal counter | /opt/CaptivePortal/data/portal_counter.db | SQLite |
| Public traffic | /opt/CaptivePortal/data/public_traffic.sqlite3 | SQLite |
| Visitor registry | /opt/CaptivePortal/data/visitor_registry.sqlite3 | SQLite |
| Final cleaner journal | не подтверждён кодом main | ожидается pending_session_cleaner.log по утверждённому ТЗ |
| Temporary probe | pending_session_probe.log и JSON state | отдельный временный tool |

## Tests и tooling

- Основной test directory: tests/.
- Test groups: auth/retry, CAPPORT, telemetry, counters, portal, Omada webhook и visitor_registry.
- requirements.txt: Flask, requests, tzdata.
- requirements-dev.txt: runtime requirements + pytest.
- pyproject.toml, Makefile, setup.cfg, tox.ini, lint config и type-check config отсутствуют.
- В предлагаемом пакете pytest.ini ограничивает discovery каталогом tests/, потому что два probe-файла с одинаковым basename ломают root discovery.
- Предварительная пофайловая проверка вне tests/ нашла только omada_pending_cleanup_test.py и tools/omada_pending_cleanup_test.py. Оба объявлены temporary standalone proof-of-concept, не импортируют pytest и не содержат test functions. Иных штатных test modules или pytest config вне tests/ нет.

Baseline в изолированной среде до изменений:

- python -m pytest -q -rs: collection error из-за двух omada_pending_cleanup_test.py.
- python -m pytest tests -q -rs: 798 passed, 1 failed; environment-specific failure suspected; normal Linux verification pending (AF_UNIX PermissionError).
- python -m compileall -q app: passed с pycache вне repository.
- git diff --check: passed.

## Fail-open boundaries

- auth telemetry;
- portal counter;
- public traffic service/worker;
- webhook receiver/normalizer journals;
- authorized snapshot collector;
- visitor registry;
- будущий pending session cleaner.

Отказ этих независимых компонентов не должен останавливать основной portal authorization flow.

## Открытое противоречие token lifecycle

Current snapshot реализует token-per-request. Cleaner ТЗ требует thread-safe token cache общего OmadaProvider и concurrency tests. Противоречие не разрешено этим документом. После merge Cleaner необходимо проверить фактический код, тесты и public contracts, затем обновить inventory/architecture по решению Architect и Tech Lead.

## Startup и shutdown

Startup в run.py:

1. settings и общий OmadaProvider;
2. snapshot collector;
3. Flask app и auth components;
4. snapshot collector start;
5. visitor registry create/start;
6. public traffic worker start;
7. Flask server.

Shutdown:

1. public traffic worker;
2. auth executor;
3. snapshot collector stop_accepting и drain;
4. visitor registry stop с final scan.

## Existing documentation

README.md и README_RU.md — public overview. Технические документы находятся непосредственно в docs/ и пока не имеют единой навигации. Предлагаемая миграция описана в archive/migration-plan.md.

## Подтверждённый production metadata

- Deployment path /opt/CaptivePortal подтверждается repository docs.
- Service name captive-portal.service подтверждается repository docs.
- Сам systemd unit отсутствует в repository; его точный ExecStart и environment contract не подтверждены кодом.
- Python не загружает .env автоматически. Переменные должны поступать через process environment, например EnvironmentFile systemd.

## Риски и технический долг

1. Путь: app/config.py; тип: возможные hardcoded Omada credentials; рекомендация: создать отдельный срочный security TASK. Значения не раскрываются.
2. В Git отслеживаются __pycache__ и .pyc.
3. В Git отслеживаются backup-файлы app/config.py.bak-* и app/web/web.py.bak-*.
4. Root и tools содержат одноимённые probe test scripts, что ломает default pytest discovery.
5. Temporary pending-session probe нельзя считать реализацией final Cleaner.
6. outputs/omada-webhook-normalized.alloy — infrastructure artifact; его ownership нужно подтвердить отдельно.

Ничего из этого не удаляется документационным TASK без отдельного решения.
