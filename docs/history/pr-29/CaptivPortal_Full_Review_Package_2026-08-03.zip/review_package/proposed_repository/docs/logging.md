# Logging, telemetry и data journals

Status: proposed
Updated: 2026-08-03

## Разделение

Operational telemetry отвечает на вопрос «в каком состоянии компонент и почему он отказал». Data journal хранит устойчивые структурированные факты для последующего чтения и аналитики. Один event contract не подменяет другой.

## Общий контракт

- JSONL, UTF-8, strict JSON, одна запись на строку.
- UTC timestamp и явная schema version.
- JSON serialization с allow_nan=false.
- Полный нормализованный MAC; MAC не считается secret.
- Access Token, Client Secret, cookies, Authorization header и SSID password запрещены.
- Полный Omada override response запрещён.
- Rotation и file permissions учитываются writer и deployment.
- Event name или schema меняются вместе с tests и связанной документацией.

## Current journals

| Файл | Роль | Owner |
|---|---|---|
| auth_telemetry.log | operational authorization telemetry | app/auth_telemetry |
| visitor_snapshots.log | authorized client data journal | snapshot collector |
| omada_webhook.log | raw redacted webhook journal | webhook receiver |
| omada_webhook_normalized.log | normalized data journal | webhook normalizer |
| pending_session_cleaner.log | future cleaner audit per approved spec; не реализован в snapshot | future Cleaner |

SQLite files не являются logs.

## Coder boundary

Coder реализует корректную запись предусмотренных events и tests. Он не настраивает Grafana, не изменяет Alloy и не изменяет Loki без отдельного infrastructure TASK.

## Передача логов агенту

Передавайте временной диапазон, component, event, correlation id, MAC и ограниченное окружение ошибки. Используйте tail/journalctl с лимитом; не передавайте rotated journals или многодневный verbose output целиком.
