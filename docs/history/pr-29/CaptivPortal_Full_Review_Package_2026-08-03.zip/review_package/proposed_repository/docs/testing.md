# Testing

Status: proposed
Updated: 2026-08-03

## Ответственность

Каждый TASK указывает ровно одно значение: agent, owner, shared или not-applicable. Нельзя автоматически перекладывать тесты на агента, если owner назначен явно.

## Порядок

1. Targeted tests для изменённого контракта.
2. Full suite.
3. Compile gate.
4. Whitespace gate.

Full gate:

    python -m pytest -q -rs
    PYTHONPYCACHEPREFIX=/tmp/captivportal-pyc python -m compileall -q app
    git diff --check

pytest.ini ограничивает discovery каталогом tests/. Это исключает operational probe scripts, которые не являются suite.

Предварительная проверка snapshot main вне tests/ нашла только omada_pending_cleanup_test.py и tools/omada_pending_cleanup_test.py. Оба файла прямо объявлены temporary standalone proof-of-concept, не импортируют pytest и не содержат test functions. Иных штатных test modules, conftest или pytest config вне tests/ не найдено. Probe-файлы не изменяются.

## Stable targeted groups

    python -m pytest tests/test_auth_retry.py tests/test_portal_entry.py -q --tb=short
    python -m pytest tests/test_capport_routes.py tests/test_capport_service.py -q --tb=short
    python -m pytest tests/test_portal_counter.py -q --tb=short
    python -m pytest tests/test_public_traffic.py tests/test_public_traffic_frontend.py -q --tb=short
    python -m pytest tests/visitor_registry -q --tb=short
    python -m pytest tests/integrations/omada -q --tb=short

TASK выбирает минимально достаточную группу; не запускает все группы как targeted.

## Reporting

Указывать точную команду, passed/skipped/failed и релевантный короткий traceback. Environment limitation отделять от product defect. Несвязанный full-suite failure не исправлять; зарегистрировать owner action.

## Production gate

Feature activation требует отдельного Linux gate на целевом Python, filesystem, permissions и service topology. Локальный green suite не равен production verification.

## Baseline 2026-08-03

До предлагаемого pytest.ini root discovery блокировался одноимёнными probe scripts. tests/ дал 798 passed и один AF_UNIX PermissionError: environment-specific failure suspected; normal Linux verification pending. compileall и git diff --check прошли.
