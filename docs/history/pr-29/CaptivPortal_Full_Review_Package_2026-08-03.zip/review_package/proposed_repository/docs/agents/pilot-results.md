# Pilot materials

Status: preliminary rehearsal only; no pilot accepted
Updated: 2026-08-03
Repository snapshot: main a44b3128d72a5ce17529db0842580571023242ee

## Ограничение

В текущем snapshot repository отсутствуют предлагаемые `AGENTS.md`, `.github/copilot-instructions.md` и `.github/instructions/*.instructions.md`. Поэтому реальная загрузка, path activation и соблюдение instructions внутри repository не проверены.

Описанные ниже результаты — ручная rehearsal на внешнем review package. Они не являются финальным pilot result и не закрывают acceptance criteria.

## Pilot A — simple documentation implementation

Черновой input:

- mode: implementation;
- allowed files: proposed knowledge package only;
- reading: AGENTS.md, documentation instructions, target document;
- repository actions: forbidden;
- test responsibility: agent.

Что удалось проверить предварительно:

- короткая universal entrypoint направляет к ограниченному набору документов;
- предлагаемый scope отделяет package files от repository actions;
- запрет repository writes сформулирован явно;
- handoff требует фактических test/repository-action claims.

Что не проверено:

- фактическое обнаружение instructions coding agent внутри repository;
- path-specific activation для `.github/instructions/`;
- исполнение задачи после merge параллельных изменений;
- повторяемость на втором агенте.

Verdict: `pending repository pilot`.

## Pilot B — complex planning-only Cleaner task

Черновой input:

- mode: planning-only;
- reading: AGENTS.md, architecture.md, pending-session-cleaner.md и api/omada-open-api.md;
- code changes, Grafana/Alloy/systemd и repository writes forbidden.

Что должна проверить финальная попытка:

- shared OmadaProvider и отсутствие второго authorization mechanism;
- reconnect-only mutation;
- incomplete inventory blocks actions;
- double local AuthSession protection, preflight и audit-before-action;
- fixed-delay single-process worker с bounded shutdown;
- fail-open portal boundary;
- отсутствие чтения Visitor Registry DB;
- infrastructure actions вне scope;
- обнаружение открытого противоречия между token-per-request main и thread-safe token cache из Cleaner ТЗ без самостоятельного разрешения.

Предварительная rehearsal подтверждает, что эти ограничения присутствуют в package, но не доказывает, что реальный coding agent применит их из repository.

Verdict: `pending repository pilot`.

## Universality

Проверялся только один тип исполнителя, ChatGPT/Codex, и только против внешнего package. GitHub Copilot или второй независимый coding agent не запускался. Cross-agent universality не подтверждена.

## Обязательный rerun после approval

После появления утверждённых instructions в feature branch нужно заново выполнить оба pilots и записать:

1. platform/model/version;
2. точный TASK input;
3. автоматически обнаруженные instructions;
4. реально прочитанные files;
5. proposed actions и stop conditions;
6. совместимость output с TASK/handoff contract;
7. deviations;
8. результат второго агента.

До этого pilots нельзя называть final, passed или accepted.
