# Контракт TASK

Status: proposed
Updated: 2026-08-03

TASK — высший источник требований конкретной задачи, но не может молча отменить security и необратимые owner-only ограничения.

## Обязательные поля

- цель и требуемое поведение;
- execution mode;
- исполнитель/platform;
- capability assumptions;
- test responsibility: agent, owner, shared или not-applicable;
- текущее фактическое состояние;
- out of scope;
- 1–3 связанных документа;
- allowed и forbidden files;
- allowed, forbidden и owner-only repository actions;
- входные и выходные contracts;
- fail-open/fail-closed;
- logging, persistence, lifecycle и security;
- targeted tests и full gate;
- acceptance и stop conditions;
- handoff и PR requirements.

## Scope rule

Файл не становится разрешённым только потому, что его удобно отрефакторить. Если необходимый файл отсутствует в allowed list, агент останавливает эту часть и объясняет минимальное расширение.

## Conflicts

При конфликте TASK с кодом/архитектурой агент:

1. приводит точные факты;
2. не выбирает молча одну сторону;
3. продолжает независимые безопасные части;
4. запрашивает решение owner/architect.

## Test responsibility

- agent: агент создаёт/обновляет и запускает назначенные tests.
- owner: агент не добавляет tests, но описывает необходимые cases.
- shared: TASK делит конкретные cases/actions.
- not-applicable: TASK объясняет почему.

## Repository permissions

Implementation mode не означает автоматический commit или push. Publish permissions всегда перечисляются явно.
