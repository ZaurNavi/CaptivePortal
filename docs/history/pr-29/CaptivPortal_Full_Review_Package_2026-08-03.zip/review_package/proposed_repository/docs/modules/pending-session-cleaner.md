# Pending Client Session Cleaner

Status: development
Updated: 2026-08-03

## 1. Назначение

Безопасно завершать зависшие неавторизованные Omada client sessions через подтверждённый reconnect.

## 2. Статус

Final module отсутствует в snapshot main. Утверждён design v1.0; coder реализует его вне этого snapshot. tools/pending_session_probe.py и omada_pending_cleanup_test.py — временные research artifacts, не реализация Cleaner.

После merge статус определяется заново по main: implemented-disabled при false flag либо active только при подтверждённой activation.

## 3. Граница ответственности

Inventory active clients, strict eligibility, local auth protection, fresh preflight, guarded reconnect, verification и audit. Visitor Registry database не читается.

## 4. Входные данные

Omada active client list/cards, configured site/SSID allowlist и AuthSessionManager local protection.

## 5. Выходные данные

Scan summary, planned/completed action journal и operational telemetry.

## 6. Основные модели

Expected by approved spec: config, provider protocol extensions, candidate/action/verification models, writer и PendingClientSessionCleaner worker. Фактические names проверить после merge.

## 7. Зависимости

Shared OmadaProvider, local AuthSessionManager protection, filesystem journal и composition root.

В snapshot main shared provider работает token-per-request без cache, тогда как Cleaner ТЗ требует thread-safe token cache и один concurrent refresh. Противоречие не разрешено. После merge проверить фактический provider и concurrency tests; не создавать отдельный provider или token manager.

## 8. Fail-open

Config/provider/audit/scan failure запрещает reconnect и не останавливает portal.

## 9. Конфигурация

Feature flag default false, site, SSID allowlist, pending threshold, scan/action/time/rate limits, timeouts, retries, verification и journal path. Точные keys берутся только из merged code.

## 10. Data events

Specified: pending_session.scan.completed, pending_session.action.planned и pending_session.action.completed. Не объявлять реализованными до code/test verification.

## 11. Operational telemetry

Specified start/stop/state, scan, overlap, provider/protection/audit/rate-limit/error events.

## 12. Persistence

Future /opt/CaptivePortal/logs/pending_session_cleaner.log. Не читает visitor_registry.sqlite3. Temporary probe state не переносится автоматически.

## 13. Lifecycle

Один fixed-delay non-overlapping worker на process; создаётся в composition root; bounded interruptible shutdown. Точный startup/shutdown order проверить после merge.

## 14. Тесты

В snapshot main final module tests отсутствуют. После merge проверить disabled/enabled, pagination, strict classification, double protection, preflight, audit-before-action, token recovery, token/cache concurrency, rate limits, verification, journal, lifecycle и fail-open.

## 15. Запрещённые изменения

disconnect, DELETE client, unauth вместо reconnect; action по неполному inventory; обход local protection/audit; отдельный provider или token manager; самостоятельный cache вне shared provider; чтение Registry DB.

## 16. Связанные TASK

Pending Client Session Cleaner v1.0 — утверждённое ТЗ. Temporary probe docs не являются source of truth final module.

## 17. Связанные ADR

После merge Cleaner сначала сверить фактический token lifecycle с current main и Cleaner ТЗ. ADR нужен при принятии устойчивого изменения shared provider thread safety/cache, action policy, persistence или process topology.
