# Deployment

Status: proposed contract; production not verified in this task
Updated: 2026-08-03

## Подтверждённая основа

- Repository docs используют /opt/CaptivePortal.
- Repository docs называют service captive-portal.service.
- Сам unit file отсутствует в repository, поэтому точный ExecStart и user/group требуют проверки на target host.
- Код не загружает .env автоматически. Environment должен передаваться process manager, например systemd EnvironmentFile.

## Обязательный deploy TASK

Deploy требует target environment, owner, backup, feature flag, разрешённых команд, health checks и rollback. Coding TASK без deploy mode production не меняет.

## Порядок

1. Зафиксировать approved commit и clean working tree.
2. Создать backup изменяемых config/data согласно модулю.
3. Доставить код с новым feature disabled.
4. Установить dependencies в существующий venv.
5. Выполнить Linux gate и module-specific checks.
6. Проверить EnvironmentFile без вывода secrets.
7. Restart captive-portal.service.
8. Проверить status, endpoint health и bounded logs.
9. Отдельно включить feature.
10. Проверить module events и fail-open основного портала.

## Health checks

- service active, один application process;
- portal route и auth session endpoints отвечают;
- нет startup exception;
- shared provider не дублирован;
- background component start/stop events корректны;
- storage/journal writable с ожидаемыми permissions.

## Rollback

Сначала выключить feature в environment и restart service. Если недостаточно — вернуть approved code version и совместимый config/data backup. Migration rollback определяется отдельным PLAN.

## Shutdown

Соблюдать порядок run.py и bounded timeout. SIGTERM не должен запускать новые mutation.

## Запрет

Ручное production-изменение, которое не переносится в Git и документацию, запрещено. Alloy, Loki, Grafana, reverse proxy и systemd меняются отдельными tasks.
