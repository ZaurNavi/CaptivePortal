# Omada Open API: подтверждённый контракт

Status: proposed
Updated: 2026-08-03
Sources: current OmadaProvider и переданные live research reports

В документ включаются только подтверждённые операции. Наличие endpoint в Swagger без live-проверки не даёт права использовать его для mutation.

## OAuth

    POST /openapi/authorize/token?grant_type=client_credentials

Body содержит omadacId, client_id и client_secret. Header последующих запросов:

    Authorization: AccessToken=<token>

Значение header и credentials не логируются.

В snapshot main `a44b3128…` OmadaProvider использует token-per-request. Отдельного shared cache нет. errorCode -44112 означает истёкший token; recovery ограничен одним повторным token flow в контексте endpoint, если это предусмотрено его контрактом.

Cleaner ТЗ одновременно требует thread-safe token cache общего OmadaProvider. Это открытое противоречие, а не принятое изменение API contract. После merge Cleaner фактический lifecycle и concurrency tests должны быть проверены повторно до обновления этого документа.

## Проверка ответа

Всегда проверять отдельно:

1. network/timeout;
2. HTTP status;
3. JSON object;
4. errorCode;
5. endpoint-specific result shape.

HTTP 200 не означает успех при errorCode != 0.

## Clients

Подтверждены:

    GET  /openapi/v1/{omadacId}/sites
    GET  /openapi/v1/{omadacId}/sites/{siteId}/clients
    GET  /openapi/v1/{omadacId}/sites/{siteId}/clients/{clientMac}
    POST /openapi/v1/{omadacId}/sites/{siteId}/hotspot/clients/{clientMac}/auth
    POST /openapi/v1/{omadacId}/sites/{siteId}/hotspot/clients/{clientMac}/unauth
    POST /openapi/v1/{omadacId}/sites/{siteId}/clients/{clientMac}/reconnect

reconnect подтверждён как механизм завершения текущей pending session. disconnect и DELETE client не работали на проверенном Omada 5.14.31 и не используются Cleaner v1.

Client list пагинируется. Неполный inventory запрещает batch mutation. Fresh client card обязателен перед reconnect.

## Access points

Подтверждены live reports:

    GET /openapi/v1/{omadacId}/sites/{siteId}/devices
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/available-channel
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/general-config
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/ip-setting
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/lan-traffic-info
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/ofdma
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/override
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/power-saving
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/radio-config
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/radios
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/rf-scan-result
    GET /openapi/v1/{omadacId}/sites/{siteId}/aps/{apMac}/wired-uplink
    GET /openapi/v2/{omadacId}/sites/{siteId}/aps/{apMac}/override
    GET /openapi/v2/{omadacId}/sites/{siteId}/aps/{apMac}/rf-scan-result

Direct v1 devices/{deviceMac} не подтверждён как рабочий. Override responses могут содержать пароль SSID и не должны сохраняться целиком.

## MAC

MAC normalization находится в app/common/mac.py. Формат URL выбирается по endpoint contract; client snapshot использует hyphen format. Не реализовывать ad-hoc replace в новом модуле.

## Mutation safety

Любой новый mutation endpoint требует отдельного TASK, audit-before-action, bounded retry, protection against stale identity/session и verification. Успешный POST без подтверждения не объявляется подтверждённым результатом.
