# GitHub Copilot adapter for CaptivPortal

Status: proposed
Updated: 2026-08-03

Это только платформенный адаптер. Универсальные правила находятся в AGENTS.md и не дублируются здесь.

Перед изменением:

1. Найди и прочитай TASK.
2. Прочитай AGENTS.md.
3. Открой только документы, перечисленные в TASK.
4. Проверь фактические связанные файлы и тесты.
5. Не расширяй scope.

Если TASK отсутствует или не определяет execution mode, allowed files, repository actions либо test responsibility, сначала запроси уточнение.

Используй path-specific instructions из .github/instructions/ только для затронутых путей. Не загружай все инструкции одновременно.

В ответе не заявляй о test, commit, push, PR, merge или deploy без фактического результата. По умолчанию PR должен быть Draft; merge выполняет только owner.
