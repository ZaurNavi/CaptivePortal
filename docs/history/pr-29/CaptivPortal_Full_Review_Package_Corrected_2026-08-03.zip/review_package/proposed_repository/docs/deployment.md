# Deployment

Status: proposed contract; production not verified in this task
Updated: 2026-08-03

## Подтверждённая основа

- Repository docs используют /opt/CaptivePortal.
- Repository docs называют service captive-portal.service.
- Сам unit file отсутствует в repository, поэтому точный ExecStart и user/group требуют проверки на target host.
- Код не загружает .env автоматически. Environment должен передаваться process manager, например systemd EnvironmentFile.

## Обязательный deploy TASK

Deploy требует target environment, owner, backup, feature flag, разрешённых команд, health checks и rollback. Coding TASK без deploy mode production не меняет.

## Стадия 1: deployment с feature disabled

1. Зафиксировать approved commit и clean working tree.
2. Создать backup изменяемых config/data согласно модулю.
3. Доставить код, сохранив новый feature disabled.
4. Сравнить requirements с развёрнутой версией. Устанавливать dependencies в существующий venv только если requirements изменились.
5. Выполнить Linux gate и module-specific checks.
6. Проверить EnvironmentFile без вывода secrets и убедиться, что feature flag выключен.
7. Restart captive-portal.service.
8. Проверить service status, portal/auth endpoint health, startup logs, process topology и отсутствие запуска disabled feature.

Стадия 1 завершается отдельным health-check verdict. Она не означает разрешение activation.

## Стадия 2: отдельная activation

1. Получить разрешение на activation после успешной стадии 1.
2. Изменить feature flag в environment, не выводя secrets.
3. Обязательно restart captive-portal.service: изменение environment не применяется к уже запущенному process.
4. Повторно проверить service status, portal/auth endpoint health, startup logs и process topology.
5. Проверить module start/events, storage permissions, bounded operational logs и fail-open основного портала.
6. Зафиксировать activation verdict и готовность rollback.

## Health checks

- service active, один application process;
- portal route и auth session endpoints отвечают;
- нет startup exception;
- shared provider не дублирован;
- background component start/stop events корректны;
- storage/journal writable с ожидаемыми permissions.

## Rollback

Сначала выключить feature в environment, обязательно restart service и повторить health checks. Если недостаточно — вернуть approved code version и совместимый config/data backup. Migration rollback определяется отдельным PLAN.

## Shutdown

Соблюдать порядок run.py и bounded timeout. SIGTERM не должен запускать новые mutation.

## Запрет

Ручное production-изменение, которое не переносится в Git и документацию, запрещено. Alloy, Loki, Grafana, reverse proxy и systemd меняются отдельными tasks.
