# SECURITY-TASK-URGENT — Проверка и устранение возможных hardcoded Omada credentials

Status: urgent draft; requires Owner, Architect and Tech Lead approval

Значения credentials в этом TASK не приводятся и не должны добавляться в issue, commit, PR, logs или handoff.

## 1. Цель

Проверить возможное хранение действующих Omada credentials в tracked source, удалить секретные значения из repository и выполнить owner-controlled rotation/revocation без раскрытия значений.

## 2. Execution mode

Implementation для repository fix. Production rotation и deploy выполняются только owner в отдельно разрешённом deploy/security mode.

## 3. Исполнитель и agent platform

Назначается Tech Lead. Агент не получает production secret, если owner action может быть выполнен без его передачи.

## 4. Agent capability assumptions

Repository read/write и локальные tests. Доступ к Omada Controller, production environment и secret store не предполагается.

## 5. Test responsibility

Shared: агент отвечает за repository tests; owner — за rotation, production environment и post-rotation health checks.

## 6. Текущее состояние

В snapshot `main` `a44b3128…` review обнаружил в `app/config.py` значения, похожие на hardcoded Omada credentials. Их подлинность не устанавливалась и значения не фиксировались вне исходного файла.

## 7. Требуемое поведение

- Подтвердить тип каждого подозрительного значения без копирования в отчёт.
- Удалить действующие secrets из tracked defaults и получать их через утверждённый environment/secret mechanism.
- Сохранить non-secret configuration contract и явную обработку отсутствующих обязательных settings.
- Owner должен rotate/revoke потенциально скомпрометированные credentials и обновить production environment.
- После rotation выполнить отдельные health checks authorization flow.

## 8. Не входит в задачу

История Git, force-push, изменение Omada API behavior, общий config refactor, Cleaner, Grafana/Alloy/Loki и раскрытие secret values.

## 9. Связанные документы

- `docs/security.md`
- `docs/deployment.md`
- `docs/agents/task-contract.md`

## 10. Разрешённые файлы

- `app/config.py`
- `app/settings.py` — только если минимально необходимо для environment contract
- связанные targeted tests в `tests/`
- non-secret config/deployment documentation, если contract меняется

## 11. Запрещённые файлы и области

Production EnvironmentFile, secret stores, logs, fixtures с реальными значениями, unrelated modules и temporary probe artifacts.

## 12. Разрешённые repository actions

Read-only inspection и изменения allowed files в отдельной ветке после прямого approval. Commit/push/PR разрешаются отдельным publish approval.

## 13. Запрещённые и owner-only repository actions

Merge, history rewrite, secret rotation/revocation, production environment edit и deploy — owner-only.

## 14. Архитектурные ограничения

Сохранить pipeline `app/config.py → app/settings.py:get_settings()` и один shared `OmadaProvider`. Не создавать второй secret/config mechanism без ADR.

## 15. Входные контракты

Имена environment variables и типы settings подтверждаются фактическим current code. Secret values не являются входом агента.

## 16. Выходные контракты

Tracked source не содержит действующих credential values; runtime получает обязательные secrets из утверждённого external mechanism.

## 17. Error handling

Отсутствующее обязательное credential setting должно давать контролируемую ошибку без вывода значения. Точное startup behavior согласовать до изменения, если current code и intended behavior расходятся.

## 18. Fail-open / fail-closed

Credential validation и authorization должны быть fail-closed; диагностическое сообщение не раскрывает secret.

## 19. Logging и events

Не логировать Client Secret, Access Token, Authorization header, cookie или полный config mapping.

## 20. Persistence

Новая application persistence не создаётся. Secret не записывается в repository, JSONL или SQLite.

## 21. Lifecycle и shutdown

Изменение environment применяется только после обязательного service restart и health checks по `docs/deployment.md`.

## 22. Security

Считать потенциально опубликованное credential скомпрометированным до owner verdict. Не считать удаление строки достаточным без rotation/revocation и проверки Git exposure policy.

## 23. Targeted tests

Проверить отсутствие secret defaults, корректное чтение environment, controlled missing-setting failure и redaction сообщений. Точные test files определить по current main после refresh.

## 24. Full gate

    python -m pytest -q -rs
    PYTHONPYCACHEPREFIX=/tmp/captivportal-pyc python -m compileall -q app
    git diff --check

Дополнительно выполнить secret-pattern scan без печати совпавших значений.

## 25. Acceptance criteria

- Подозрительные действующие values отсутствуют в tracked current files.
- Tests подтверждают environment-only secret contract и безопасные errors.
- Owner подтвердил rotation/revocation и production environment update.
- После обязательного restart portal authorization health checks успешны.
- PR и handoff не содержат secret values.

## 26. Stop conditions

Остановиться при необходимости раскрыть secret, неоднозначном startup behavior, необходимости history rewrite, отсутствии owner для rotation или расширении allowed files без approval.

## 27. Handoff format

Указать изменённые пути, checks, факт owner rotation только как yes/no, health verdict и remaining risks. Значения и secret-bearing diffs не вставлять.

## 28. PR requirements

Только Draft PR после отдельного разрешения; security-safe summary; no values; merge owner-only после подтверждённой rotation и checks.
