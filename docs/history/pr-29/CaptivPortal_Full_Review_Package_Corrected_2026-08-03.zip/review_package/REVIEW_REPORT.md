# CaptivPortal knowledge base — пакет на согласование

Status: corrected package ready for Architect and Tech Lead re-review; not approved and not final
Prepared: 2026-08-03
Repository snapshot: main a44b3128d72a5ce17529db0842580571023242ee

## Результат

Подготовлен полный макет базы знаний и инструкций для coding agents вне рабочего репозитория. Рабочая копия CaptivePortal остаётся clean; branch, commit, push и PR не создавались.

Пакет решает две задачи:

1. хранит актуальную архитектурную и эксплуатационную истину;
2. сокращает AI context через короткую точку входа, TASK-driven reading и path-specific instructions.

## Что входит

- universal AGENTS.md, 119 строк;
- GitHub Copilot adapter и 7 path-specific instruction files;
- architecture, inventory, module index, tests, logging, deployment, security и Omada API;
- 11 module contracts по фактической структуре main;
- agent workflow, TASK contract, handoff, repository permissions и model selection;
- TASK, PLAN и ADR templates;
- PR template;
- archive/migration plan с пофайловой матрицей и без автоматического архивирования исследовательских Omada-отчётов;
- один check script и proposed pytest discovery config;
- предварительные материалы двух pilots и explicit cross-agent limitation;
- точный patch для README.md и README_RU.md;
- отдельная проверка test discovery вне tests/.
- отдельный срочный security TASK без раскрытия значений.

## Источник фактов

Инвентаризация сделана по коду commit a44b3128, существующим README/docs, тестам и переданным live research reports. Chat history использовалась только для внешнего статуса работ и не подменяет main.

Пакет использует две независимые модели:

- current-state truth: код → тесты → актуальная документация;
- change-intent truth: утверждённый TASK → PLAN → ADR.

TASK задаёт scope изменения, но не ставится выше фактического кода и тестов при описании текущего состояния. При конфликте агент останавливает затронутую часть и передаёт точные источники Architect/Tech Lead.

## Архитектурная истина

- Единый flow: Omada External Portal или CAPPORT login → PortalClientContext → AuthSessionManager → AuthWorker → shared OmadaProvider.
- CAPPORT не имеет отдельного authorization mechanism.
- run.py — process lifecycle/composition root; create_app() — Flask composition factory.
- Один OmadaProvider на process; в зафиксированном snapshot main token lifecycle — token per request.
- Auth sessions/workers in-memory; topology single-process.
- Visitor Registry не обращается к Omada.
- Cleaner не читает Visitor Registry database.
- Background operational modules fail-open.
- Application code/events отделены от Alloy, Loki, Grafana, systemd и deployment.

## Статусы модулей в снимке

| Модуль | Статус |
|---|---|
| Authorization, portal entry, CAPPORT | active |
| Auth telemetry, portal counter, public traffic | active |
| Authorized snapshot collector | implemented-disabled |
| Visitor Device Registry | implemented-disabled |
| Webhook receiver/normalizer | implemented-disabled |
| Pending Client Session Cleaner | development; final code отсутствует в этом main |

После merge работы кодера main будет заново инвентаризирован. Cleaner не будет повышен в status по обещанию или branch context — только по merged code, tests, flag и lifecycle.

## Открытое противоречие: token lifecycle

| Источник | Зафиксированное требование |
|---|---|
| current main `a44b3128…` | `OmadaProvider` вызывает `_get_token()` для каждого запроса; shared token cache отсутствует |
| Cleaner ТЗ, раздел «Потокобезопасность общего OmadaProvider» | требуется thread-safe token cache, не более одного concurrent refresh и concurrency tests |

Противоречие не разрешено предположением. После merge Cleaner необходимо повторно проверить фактический `OmadaProvider`, token/cache lifecycle, concurrency tests и публичные контракты. Только после этого Architect и Tech Lead определяют новый источник истины и необходимость ADR.

## Temporary cleanup artifacts

По указанию owner следующие файлы не удаляются, не переименовываются и не архивируются:

- omada_pending_cleanup_test.py;
- tools/omada_pending_cleanup_test.py;
- tools/pending_session_probe.py;
- tools/pending_session_probe_README.md.

Они отмечены как temporary research artifacts и не являются final Cleaner contract.

## Решения, требующие подтверждения

### 1. Test discovery

Рекомендация: добавить pytest.ini с testpaths = tests. Предварительная пофайловая проверка подтвердила, что вне `tests/` нет штатных test modules: найдены только два одноимённых временных standalone proof-of-concept scripts, которые не импортируют pytest и не содержат test functions. Это изменение не трогает probe-файлы, а только исключает их из штатного discovery. Альтернатива — документировать full gate как python -m pytest tests -q -rs и отказаться от exact команды ТЗ. Подробности: `PYTEST_DISCOVERY_REVIEW.md`.

### 2. Дополнительные module docs

Кроме минимального списка ТЗ добавлены portal-entry, auth-telemetry, public-traffic-counter и webhook-receiver. Иначе module index не описывал бы фактический main и агенты снова искали бы архитектуру в source.

### 3. Язык

Внутренняя база и universal rules — на русском с неизменёнными code identifiers. Platform adapter изолирован в .github. Это минимизирует двуязычное дублирование.

### 4. Existing docs

Для каждого текущего документа назначено одно действие: `keep`, `supersede` или `archive`, указан новый источник истины и причина. Исследовательские Omada-отчёты получают `keep`: curated API contract не заменяет исходное экспериментальное свидетельство. Никакого удаления или перемещения до отдельного approval.

### 5. Public README

README остаётся public overview. Добавляется короткая навигация в knowledge base; stale Repository Structure сокращается до ссылки на inventory. Точный unified diff для обоих файлов приложен как `README_CHANGES.patch`.

### 6. Security finding

Путь: `app/config.py`. Тип проблемы: возможные hardcoded Omada credentials. Отдельный срочный TASK подготовлен как `URGENT_SECURITY_TASK.md`. Значения в package не раскрываются; knowledge-base proposal код не меняет. Постоянный `docs/security.md` содержит только policy, finding из `docs/` удалён.

## Обязательные исправления текущего review

- Источники истины разделены на current-state и change-intent в `AGENTS.md`, task contract, workflow и knowledge index.
- Временное Cleaner/token-cache противоречие удалено из универсального `AGENTS.md`; конкретика остаётся в inventory и module contract.
- Copilot adapter начинается утверждёнными четырьмя строками; Code Review продолжает security/correctness/regression review без отдельного TASK и отмечает scope ambiguity.
- Omada endpoints разделены на live-tested, schema-confirmed, used by current code и unsupported/rejected.
- Deployment разделён на disabled deployment и отдельную activation; обе стадии имеют restart и health checks, dependencies устанавливаются только при изменении requirements.
- `docs/security.md` оставлен policy-only; finding ограничен этим report и отдельным urgent TASK.
- `check.sh` переходит в repository root; во всех документах и PR template используется одна compileall-команда.
- Критерии 12 и 25 оставлены `Pending correction` до повторного review; integration, pilots, финальные gates и reviews не закрыты.

## Baseline verification

| Проверка | Факт |
|---|---|
| Working repository status | clean |
| python -m pytest -q -rs | collection error: два временных файла с одним basename |
| python -m pytest tests -q -rs | 798 passed, 1 failed: environment-specific failure suspected; normal Linux verification pending (AF_UNIX PermissionError) |
| Final package pytest rerun | not run: pytest отсутствует в текущем packaging runtime; ранее зафиксированный baseline не повышается до final gate |
| PYTHONPYCACHEPREFIX=/tmp/captivportal-pyc python -m compileall -q app | passed |
| git diff --check | passed |
| Secret-like literals в review package | не найдены |
| AGENTS.md limit | 119 из 250 строк |
| Copilot adapter limit | 21 из 200 строк |

Full suite должен быть повторён в normal Linux environment после approved changes и merge Cleaner.

## Pilot status

- Материалы Simple documentation и Complex Cleaner planning-only являются только предварительной rehearsal против внешнего review package.
- В snapshot main отсутствуют предлагаемые `AGENTS.md` и `.github` instructions, поэтому их реальное repository activation ещё не проверено.
- Ни один pilot не объявлен финальным или принятым. Оба должны быть заново выполнены после появления утверждённых instructions в feature branch.
- Cross-agent universality не подтверждена: проверен только один тип исполнителя; второй агент и GitHub path activation ожидают отдельной проверки.

## Что произойдёт только после approval

1. Refresh origin/main после merge кодера.
2. Повторная инвентаризация и diff статусов, особенно Cleaner.
3. Корректировка предложенных файлов.
4. Создание отдельной feature branch.
5. Добавление только утверждённых docs/instructions/tooling.
6. Targeted/full checks в нормальном окружении.
7. Два пилота и cross-agent verification.
8. Draft PR с фактическими результатами.
9. Tech Lead review и Architect confirmation.

Merge и production deployment в эту задачу не входят без отдельного разрешения.

## Approval checklist

- [ ] Architect подтверждает architecture.md и границы модулей.
- [ ] Tech Lead подтверждает AGENTS/workflow/TASK/handoff.
- [ ] Tech Lead выбирает pytest.ini либо явный tests/ command.
- [ ] Owner подтверждает archive migration и README changes.
- [ ] Owner подтверждает, что temporary cleanup artifacts остаются без изменений.
- [ ] После merge Cleaner разрешён refresh main.
- [ ] После финального review разрешены branch и Draft PR.

Подробное состояние 58 критериев: ACCEPTANCE_MATRIX.md.
