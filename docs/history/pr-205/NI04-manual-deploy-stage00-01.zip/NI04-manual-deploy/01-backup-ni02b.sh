#!/usr/bin/env bash
# NI-04 G0: safe, low-priority online SQLite backup of NI-02B before migration.
# Run ONLY after Stage 00 is reviewed by Tech Lead. Never changes source DB/schema.
set -euo pipefail
umask 077
BASE='b1442efc434716d35e21b9e3124c3b9cd2222fbe'
ROOT='/opt/CaptivePortal'
DB="$ROOT/data/network_metadata_projection.sqlite3"
DIR="$ROOT/backups/NI04-G0-$(date -u +%Y%m%dT%H%M%SZ)-$$"
fail() { echo "NI04_STAGE01=HOLD: $*" >&2; exit 2; }
[ "$(id -un)" = admin ] || fail 'expected admin user'
[ "$(git -C "$ROOT" rev-parse HEAD)" = "$BASE" ] || fail 'production HEAD drift'
[ -z "$(git -C "$ROOT" status --porcelain --untracked-files=no)" ] || fail 'tracked production changes'
sudo -n true >/dev/null 2>&1 || fail 'sudo -n not available'
[ -f "$DB" ] || fail 'NI-02B SQLite DB missing'
[ -d "$ROOT/backups" ] && [ -w "$ROOT/backups" ] || fail 'backup dir not writable'
[ ! -e "$ROOT/data/network_service_intelligence.sqlite3" ] || fail 'materialization store already exists'
[ "$(systemctl is-active network-metadata-projection.service)" = active ] || fail 'projection service is not active'
[ "$(systemctl is-active captive-portal.service)" = active ] || fail 'portal service is not active'
worker=$(systemctl is-active network-service-recognition.service 2>/dev/null || true)
[ "$worker" != active ] || fail 'materialization worker active'
# Keep headroom >= 8 GiB after copying a full SQLite snapshot and associated WAL growth.
free_bytes=$(df -PB1 "$ROOT/data" | awk 'NR==2 {print $4}')
source_bytes=$(stat -c %s "$DB")
[ "$free_bytes" -ge $((source_bytes + 8589934592)) ] || fail 'not enough free space + 8 GiB headroom'
# Hold on persistently severe I/O pressure; do not force a busy writer to back up.
python3 - <<'PY' || exit 2
from pathlib import Path
p=Path('/proc/pressure/io')
if p.exists():
 d={line.split()[0]:dict(pair.split('=') for pair in line.split()[1:]) for line in p.read_text().splitlines()}
 some=float(d['some']['avg60']);full=float(d['full']['avg60'])
 print('IO_PRESSURE_AVG60 some=%.2f%% full=%.2f%%'%(some,full),flush=True)
 if some>=50 or full>=25:
  print('NI04_STAGE01=HOLD: sustained IO pressure too high; try off-peak',flush=True)
  raise SystemExit(2)
PY
mkdir -m 700 -- "$DIR"
printf 'BACKUP_DIRECTORY=%s\nSOURCE_DB_BYTES=%s\n' "$DIR" "$source_bytes"
export NI04_BACKUP_DIR="$DIR" NI04_BASE="$BASE" NI04_ROOT="$ROOT" NI04_DB="$DB"
# nice/ionice are deliberately optional: data correctness does not depend on their availability.
if command -v ionice >/dev/null 2>&1; then
  ionice -c3 nice -n 15 python3 - <<'PY'
import hashlib,os,sqlite3,time,pathlib,sys
source=pathlib.Path(os.environ['NI04_DB'])
target_dir=pathlib.Path(os.environ['NI04_BACKUP_DIR'])
tmp=target_dir/'network_metadata_projection.sqlite3.partial'
final=target_dir/'network_metadata_projection.sqlite3'
start=time.monotonic();last_report=start
try:
 s=sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True,timeout=3)
 s.execute('PRAGMA query_only=ON')
 if s.execute('PRAGMA user_version').fetchone()[0]!=1:raise RuntimeError('unexpected source user_version')
 names={r[0] for r in s.execute('SELECT name FROM sqlite_master WHERE type="table"')}
 if not names.isdisjoint({'projection_service_recognition_extension_meta','projection_service_recognition_feed','projection_registry_binding_change_index'}):raise RuntimeError('extension already exists')
 d=sqlite3.connect(str(tmp),timeout=3)
 d.execute('PRAGMA journal_mode=DELETE')
 def progress(status,remaining,total):
  global last_report
  elapsed=time.monotonic()-start
  if elapsed>2400:raise RuntimeError('backup exceeded 40-minute safety deadline')
  if elapsed-last_report>=15:
   print('BACKUP_PROGRESS pages_remaining=%d pages_total=%d elapsed_s=%d'%(remaining,total,int(elapsed)),flush=True)
   last_report=time.monotonic()
  if status==sqlite3.SQLITE_OK:time.sleep(.02)
 s.backup(d,pages=64,progress=progress,sleep=.1)
 d.commit();d.close();s.close()
 print('BACKUP_COPY_DONE elapsed_s=%d'%int(time.monotonic()-start),flush=True)
 v=sqlite3.connect('file:'+str(tmp)+'?mode=ro',uri=True,timeout=3)
 v.execute('PRAGMA foreign_keys=ON')
 check=v.execute('PRAGMA quick_check').fetchone()[0]
 bad_fk=v.execute('PRAGMA foreign_key_check').fetchone()
 ver=v.execute('PRAGMA user_version').fetchone()[0]
 tables={r[0] for r in v.execute('SELECT name FROM sqlite_master WHERE type="table"')}
 v.close()
 if not (check=='ok' and bad_fk is None and ver==1):raise RuntimeError('backup integrity verification failed')
 if not ('network_metadata_projection_schema' in tables and 'device_network_metadata_edges' in tables):raise RuntimeError('required core objects absent')
 if not tables.isdisjoint({'projection_service_recognition_extension_meta','projection_service_recognition_feed','projection_registry_binding_change_index'}):raise RuntimeError('unexpected extension objects')
 h=hashlib.sha256()
 with open(tmp,'rb') as f:
  while True:
   block=f.read(2*1024*1024)
   if not block:break
   h.update(block)
 digest=h.hexdigest()
 fd=os.open(tmp,os.O_RDONLY)
 try:os.fsync(fd)
 finally:os.close(fd)
 os.replace(tmp,final)
 (target_dir/'manifest.txt').write_text('NI04_STAGE01=PASS_LOCAL_BACKUP\nSOURCE_HEAD='+os.environ['NI04_BASE']+'\nSOURCE_DB='+str(source)+'\nBACKUP_DB='+str(final)+'\nSHA256='+digest+'\nUSER_VERSION=1\nQUICK_CHECK=ok\nFOREIGN_KEY_CHECK=ok\n',encoding='utf-8')
 print('BACKUP_SHA256='+digest)
 print('BACKUP_SIZE_BYTES='+str(final.stat().st_size))
 print('NI04_STAGE01=PASS_LOCAL_BACKUP (OFF_HOST_VERIFICATION_REQUIRED)',flush=True)
except BaseException as ex:
 print('NI04_STAGE01=HOLD '+type(ex).__name__+': '+str(ex),flush=True)
 try:
  if tmp.exists():tmp.unlink()
 except OSError:pass
 sys.exit(2)
PY
else
  echo 'NI04_STAGE01=HOLD: ionice utility missing; request reviewed alternative' >&2
  exit 2
fi
