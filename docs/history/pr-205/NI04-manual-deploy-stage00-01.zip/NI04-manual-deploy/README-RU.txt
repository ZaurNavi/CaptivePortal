NI-04 / Пошаговый ручной production rollout (GitHub PR #205)

Фиксированные исходные данные:
  Production host  : 192.168.0.202
  Linux user       : admin
  Existing prod HEAD: b1442efc434716d35e21b9e3124c3b9cd2222fbe
  Compatibility bridge: 36e2b462a39533c32954215e40d9097167591237
  Target merged main : f324c1e157b71802acda14a797c0e0f6747b6276

План независимых этапов:
  00. READ-ONLY preflight: базовая ревизия, sudo, службы, I/O, SQLite.
  01. Backup: низкоприоритетная транзакционно согласованная копия NI-02B,
      quick_check и foreign_key_check, SHA256. После — скачать её на ноутбук и
      сравнить SHA256; копия на том же диске НЕ является off-host backup.
  02. Bridge OFF: compatibility bridge; readers/Portal before writer.
  03. Final code OFF: точный merged commit; readers before writer.
  04. Extension: >=180s systemd timeout, установленный и проверенный bridge,
      one-time migration только через NI-02B; remove installer option.
  05. Shadow: установить отдельный worker, 24h bounded backfill, parity/coverage.
  06. Serve: отдельное решение о переключении Admin и проверка карточек.

В ЭТОМ пакете только 00 и 01. Скрипты 02-06 будут выпущены после изучения
production output; никакие непроверенные команды не нужно выполнять заранее.
Скрипты НЕ запускают друг друга. 01 НЕ запускать до ответа Tech Lead на 00.

Передача с ноутбука Windows (PuTTY saved session 'Ubunt'):
  1. Распаковать ZIP в каталог Downloads\\NI04-manual-deploy.
  2. В PowerShell:
     & 'C:\Program Files\PuTTY\plink.exe' -batch -load Ubunt 'mkdir -p /home/admin/ni04-deploy && chmod 700 /home/admin/ni04-deploy'
     & 'C:\Program Files\PuTTY\pscp.exe' -batch -load Ubunt "$HOME\Downloads\NI04-manual-deploy\00-preflight.sh" 'Ubunt:/home/admin/ni04-deploy/00-preflight.sh'
  3. PuTTY -> Ubunt, Linux prompt (НЕ PowerShell):
     cd /home/admin/ni04-deploy
     bash 00-preflight.sh 2>&1 | tee 00-preflight.log; echo "SCRIPT_EXIT=${PIPESTATUS[0]}"
  4. Прислать весь лог начиная с === NI04 STAGE 00 ... === и строку SCRIPT_EXIT.

ВНИМАНИЕ: скрипты 00 и 01 не изменяют приложение, систему служб, исходную базу
SQLite и Git. Скрипт 01 создаёт только копию DB и manifest в /opt/CaptivePortal/backups.
Не копировать DB обычным cp из активной WAL-базы. Не делать git pull,
не применять SQL ALTER, не перезапускать Portal/NI-02B до отдельного контроля.

Если 00 показывает HOLD, прислать лог, ничего не исправлять наугад.
Если 01 подтверждает локальную копию, Tech Lead даст конкретные команды для её
выгрузки на ноутбук и сравнения хешей до продолжения.
