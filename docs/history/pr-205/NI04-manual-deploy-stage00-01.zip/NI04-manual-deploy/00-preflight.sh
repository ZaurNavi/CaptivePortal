#!/usr/bin/env bash
# NI-04 / G0: read-only safety preflight; does not change app, systemd, SQLite or Git.
set -uo pipefail
umask 077
BASE='b1442efc434716d35e21b9e3124c3b9cd2222fbe'
ROOT='/opt/CaptivePortal'
DB="$ROOT/data/network_metadata_projection.sqlite3"
errors=0
hold() { printf 'HOLD: %s\n' "$1"; errors=$((errors+1)); }
line() { printf '\n=== %s ===\n' "$1"; }
line 'NI04 STAGE 00 PRE-FLIGHT (READ ONLY)'
printf 'UTC='; date -u +%Y-%m-%dT%H:%M:%SZ
printf 'USER='; id -un
printf 'HOST='; hostname
[ "$(id -un)" = admin ] || hold 'Expected SSH user admin'
[ -d "$ROOT/.git" ] || { hold 'Repository not found'; printf 'NI04_STAGE00=HOLD\n'; exit 2; }
line 'REVISION'
actual=$(git -C "$ROOT" rev-parse HEAD 2>/dev/null || echo UNKNOWN)
tree=$(git -C "$ROOT" rev-parse 'HEAD^{tree}' 2>/dev/null || echo UNKNOWN)
printf 'PRODUCTION_HEAD=%s\nPRODUCTION_TREE=%s\n' "$actual" "$tree"
[ "$actual" = "$BASE" ] || hold 'Production HEAD is not frozen NI-04 base; stop and reconcile'
if [ -n "$(git -C "$ROOT" status --porcelain --untracked-files=no 2>/dev/null)" ]; then hold 'Tracked production files modified'; fi
line 'SUDO'
if sudo -n true 2>/dev/null; then echo 'SUDO_NONINTERACTIVE=YES'; else echo 'SUDO_NONINTERACTIVE=NO'; hold 'Cannot manage privileged service operations'; fi
line 'RUNNING SERVICES'
for unit in captive-portal.service network-metadata.service network-metadata-projection.service fingerprint-sensor.service fingerprint-evidence.service traffic-projection.service; do
  state=$(systemctl is-active "$unit" 2>/dev/null || true)
  mainpid=$(systemctl show "$unit" -p MainPID --value 2>/dev/null || true)
  printf '%s state=%s main_pid=%s\n' "$unit" "$state" "${mainpid:-unknown}"
  case "$unit" in captive-portal.service|network-metadata.service|network-metadata-projection.service|fingerprint-sensor.service|fingerprint-evidence.service) [ "$state" = active ] || hold "Required service not active: $unit";; esac
done
worker_state=$(systemctl is-active network-service-recognition.service 2>/dev/null || true)
printf 'network-service-recognition.service state=%s\n' "$worker_state"
[ "$worker_state" != active ] || hold 'NI-04 worker already active; unexpected pre-migration state'
line 'NI-02B SUPERVISOR'
timeout=$(systemctl show network-metadata-projection.service -p TimeoutStartUSec --value 2>/dev/null || true)
printf 'NI02B_TIMEOUT_START=%s\n' "$timeout"
printf 'NI02B_UNIT_PATH='; systemctl show network-metadata-projection.service -p FragmentPath --value 2>/dev/null || true
line 'DISK CAPACITY'
df -hP "$ROOT/data" || hold 'df failed'
df -iP "$ROOT/data" || hold 'df inode failed'
line 'DISK IO PRESSURE'
cat /proc/pressure/io 2>/dev/null || true
line 'SQLITE SNAPSHOT METADATA (NO INTEGRITY SCAN)'
python3 - "$DB" "$ROOT/data/network_service_intelligence.sqlite3" <<'PY'
import os,sqlite3,sys
ni02,ni04=sys.argv[1:]
if not os.path.isfile(ni02):
 print('NI02B_SQLITE=MISSING');sys.exit(11)
print('NI02B_SIZE_BYTES='+str(os.stat(ni02).st_size))
try:
 con=sqlite3.connect('file:'+ni02+'?mode=ro',uri=True,timeout=1)
 con.execute('PRAGMA query_only=ON')
 print('NI02B_USER_VERSION='+str(con.execute('PRAGMA user_version').fetchone()[0]))
 names={r[0] for r in con.execute('SELECT name FROM sqlite_master WHERE type="table"')}
 expected={'projection_service_recognition_extension_meta','projection_service_recognition_feed','projection_registry_binding_change_index'}
 found=sorted(expected&names)
 print('NI02B_EXTENSION_TABLES='+str(len(found))+'/3')
 if 0<len(found)<3: print('NI02B_EXTENSION_STATUS=PARTIAL_HOLD');sys.exit(12)
 print('NI02B_EXTENSION_STATUS='+('PRESENT' if len(found)==3 else 'ABSENT'))
 row=con.execute('SELECT runtime_state FROM projection_runtime_state WHERE singleton_id=1').fetchone()
 print('NI02B_RUNTIME_STATE='+str(row[0] if row else 'NO_RUNTIME_ROW'))
 con.close()
except sqlite3.Error as exc:
 print('NI02B_METADATA_READ=FAILED ('+type(exc).__name__+')');sys.exit(13)
print('NI04_STORE='+('PRESENT' if os.path.exists(ni04) else 'ABSENT'))
if os.path.exists(ni04):sys.exit(14)
PY
rc=$?
[ "$rc" = 0 ] || hold "DB preflight returned exit code $rc"
line 'BACKUP DESTINATION'
if [ -d "$ROOT/backups" ] && [ -w "$ROOT/backups" ]; then echo 'BACKUP_DEST_WRITABLE=YES'; else hold 'Backup destination missing or not writable'; fi
line 'PRE-FLIGHT RESULT'
if [ "$errors" -ne 0 ]; then printf 'NI04_STAGE00=HOLD blockers=%s\n' "$errors"; exit 2; fi
printf 'NI04_STAGE00=PASS_READ_ONLY\n'
