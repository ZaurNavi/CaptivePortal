# TRAFFIC-08 KB Publisher V2 Recovery

V1 stopped because docs/testing.md used the same TRAFFIC-07 heading as both a replacement target and a later insertion anchor. The stop occurred before commit/push.

V2: exact base df91355a99d2561abc9c4d6d4bb6f5a968d327b3, exact tree 1161739c6b4fe90fa08928556746a5a4ea6af4cd, same 16-file docs scope, bounded failed-V1 recovery, insertions-before-replacements, all canonical assertions retained.

Publisher SHA256: `5ff4f79e62b3a9791d76a7e0aa96bc91d7682ac11749e72f0f8648976636f915`
