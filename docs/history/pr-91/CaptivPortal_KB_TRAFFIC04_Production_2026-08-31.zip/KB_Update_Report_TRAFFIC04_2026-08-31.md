# CaptivPortal KB Controlled Update — TASK-TRAFFIC-04

Prepared: 2026-08-31
Exact repository baseline: `a9cd8a9b9b9efc46bc82d315385ebbd1a3bf63b0`
Exact tree: `f53f204cf3ebf7cecf4e872ce450b4f3f4265cc9`

## Verified repository facts

Current main is merge PR #91 / `TASK-TRAFFIC-04 — Peak Load`.

```text
main: a9cd8a9b9b9efc46bc82d315385ebbd1a3bf63b0
tree: f53f204cf3ebf7cecf4e872ce450b4f3f4265cc9
publication commit: 0343ac77a1a90c2ba8bc3ce1c969b6c1593e9759
accepted candidate tree: f53f204cf3ebf7cecf4e872ce450b4f3f4265cc9
```

PR #91 records Windows Central Lab V6 PASS, Linux production-size PERF PASS and
the accepted TASK-specific P-vs-C p50 amendment from 20% to 30%.

## Owner-confirmed production state

```text
TASK-TRAFFIC-04 = CLOSED / PRODUCTION PASS
WEB_ADMIN_TRAFFIC_ENABLED=true
WEB_ADMIN_TRAFFIC_HISTORY_ENABLED=true
WEB_ADMIN_TRAFFIC_STATISTICS_ENABLED=true
WEB_ADMIN_TRAFFIC_PEAK_ENABLED=true
```

Production deploy was FROM GIT, then Peak was separately activated.
24h and 7d product acceptance both passed.

## Current roadmap after reconciliation

```text
TRAFFIC-00         DONE
TRAFFIC-01         DONE
TRAFFIC-02-READ    DONE
TRAFFIC-02         DONE
TRAFFIC-02-PERF-01 DONE
TRAFFIC-03         DONE / PRODUCTION ACTIVE
TRAFFIC-04         CLOSED / PRODUCTION PASS / ACTIVE
TRAFFIC-05         NEXT / NOT IMPLEMENTED
```

## Documentation scope

- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/architecture.md`
- `docs/configuration.md`
- `docs/deployment.md`
- `docs/module-index.md`
- `docs/modules/admin-web.md`
- `docs/modules/analytics.md`
- `docs/modules/traffic.md`
- `docs/project-inventory.md`
- `docs/testing.md`

Total: 12 files.

Historical FINAL TASK and Master Roadmap are intentionally not rewritten.
Generic acceptance-before-publication governance is not weakened.
The one-time non-reproduced 7d UI observation is preserved only as a non-blocking
production observation and is not entered as defect/debt.
