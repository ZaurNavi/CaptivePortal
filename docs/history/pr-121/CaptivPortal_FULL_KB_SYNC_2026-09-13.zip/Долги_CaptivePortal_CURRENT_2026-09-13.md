# Долги CaptivPortal — CURRENT

**Последнее обновление:** 13 сентября 2026 года  
**Current repository / production:** `3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`  
**Tree:** `8312658be3ba272998f46212d9bad76950e3867e`

Этот файл заменяет current-status слой реестра от 10.08.2026. Старый файл
сохраняется как historical debt snapshot.

## Открытые / принятые

### DEBT-P1-002 — Rotation старого Omada Client Secret

**Статус:** OPEN.

Current repository не содержит production literal credentials; Omada
configuration поступает через process environment. Старое значение Client Secret
остаётся в Git history.

Закрытие требует Owner-controlled rotation и post-restart/API acceptance.

### DEBT-P1-003 — TLS verification к Omada Controller

**Статус:** OPEN.

Repository default `VERIFY_SSL=false`; production `InsecureRequestWarning`
остается известным security/operations debt и не является регрессией последних
UI/Device Type TASK.

### DEBT-P1-004 — Дрейф базы знаний относительно current main

**Статус:** CLOSURE CANDIDATE — ожидает merge текущего полного KB sync PR.

Текущая reconciliation приводит canonical KB к:

```text
HEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
TREE=8312658be3ba272998f46212d9bad76950e3867e
DATE=2026-09-13
```

После merge документационного PR этот долг должен быть перенесён в CLOSED с
номером PR/merge SHA. До merge объявлять его CLOSED нельзя.

### DEBT-P2-001 — Отсутствие GitHub CI

**Статус:** OPEN.

Current repository по-прежнему не имеет `.github/workflows` с официальным
release gate. Windows Central Lab V7 strict остается manual official full gate.

### DEBT-P2-002 — Низкоприоритетная repository cleanup

**Статус:** NEEDS FRESH AUDIT / не закрыт этой KB sync.

Старый реестр называл `/success` и ownership Alloy artifact. Эта KB
синхронизация не подтверждает их устранение и не закрывает пункт без отдельного
source audit.

### LIMIT-001 — Single-process / process-local bounded state

**Статус:** ACCEPTED LIMITATION.

Возврат к архитектуре shared state / leader election требуется до
multi-worker/horizontal/HA deployment.

## Исторические baseline-specific долги

Старые P0/P1 пункты, привязанные к `main@ab776af` и deploy 10.08.2026, не должны
использоваться как current release gates автоматически. Они сохраняются в
историческом debt snapshot и требуют отдельной re-validation, если Owner считает
их продуктовый intent всё ещё актуальным.

## Закрытые current milestones, важные для debt context

```text
Windows compatibility baseline cleanup -> CLOSED / PR #116
Home Online Devices presentation       -> CLOSED / PR #118
Canonical Device Type foundation       -> CLOSED / PR #119
Device Type + SNR presentation         -> CLOSED / PR #120
```

Ни один из этих milestones не закрывает автоматически Secret rotation, TLS,
GitHub CI или single-process limitation.
