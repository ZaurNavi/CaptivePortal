# CaptivPortal full KB reconciliation — 2026-09-13

## Baseline before reconciliation

Last full KB publication:
- PR #117
- repository merge: `488e75aa2d1b067ee27d8fbfff778d49901d9fdf`
- documented project/runtime baseline: `c1dc3344bc778a32cdc6b0edce278ee40b287c29`
- documented tree: `0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c`

Implementation baselines after that KB sync:
- PR #118 → merge `2d87fd6d56f969492318e21c809086576b2b1ab1`
- PR #119 → merge `144c8a922b4431293fdc1d4bb57bed29a8402f6b`
- PR #120 → merge/current `3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`

## New project baseline

```text
HEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
TREE=8312658be3ba272998f46212d9bad76950e3867e
DATE=2026-09-13
```

## Repository documentation scope

Exactly 21 documentation/provenance files.

Three new FINAL records:
- `TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01-FINAL.md`
- `TASK-DEVICE-TYPE-NORMALIZATION-01-FINAL.md`
- `TASK-WEB-DEVICE-TYPE-PRESENTATION-01-FINAL.md`

## Superseded current assertions

- browser-owned raw `device_type.trim().toLowerCase()` is no longer current;
- current Android machine decision is `device_type_key === "android"`;
- Admin Web must not derive Device Type key from raw data;
- old Asset Library raw matching remains historical evidence only;
- old Admin Web baseline/current production identities are advanced to PR #120;
- old statement that already-deployed Devices presentation must not be called
  current production is removed from current module contract.

## Historical evidence preserved

Asset Library FINAL/FIX records retain their original case-insensitive raw
matching acceptance evidence and receive a dated supersession note rather than
retroactive rewriting.

## Project-level current artifacts

- `CaptivPortal_Roadmap_CURRENT_v3_2026-09-13.md`
- `CaptivPortal_Device_Card_Upgrade_Roadmap_CURRENT_2026-09-13.md`
- `Долги_CaptivePortal_CURRENT_2026-09-13.md`

`DEBT-P1-004` remains `CLOSURE CANDIDATE` until the KB publication PR merges.

## Publisher safety

The publisher:
- requires exact `origin/main=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5` / tree `8312658be3ba272998f46212d9bad76950e3867e`;
- requires a clean worktree;
- builds all 21 transformed files in a temporary directory first;
- performs semantic assertions before any repository write;
- uses no regex substitution engine;
- copies into the repo only after the whole temporary build passes;
- forbids runtime/test file scope;
- performs `git diff --check` and cached diff check;
- creates one docs branch / commit / Draft PR;
- never merges or deploys.

Publisher SHA256:
`64d8a1eaa0aab818b5a73410ba53f3a265641bf996af2878a70dea23f7d682d4`
