from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

BASE = '3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5'
TREE = '8312658be3ba272998f46212d9bad76950e3867e'
BRANCH = 'docs/full-kb-sync-device-type-2026-09-13'
DATE = '2026-09-13'
SCOPE = ['README.md', 'README_RU.md', 'app/admin_web/static/icons/README.md', 'docs/README.md', 'docs/architecture.md', 'docs/configuration.md', 'docs/deployment.md', 'docs/module-index.md', 'docs/modules/admin-web.md', 'docs/modules/analytics.md', 'docs/modules/current-state.md', 'docs/modules/observations.md', 'docs/modules/traffic.md', 'docs/modules/visitor-registry.md', 'docs/project-inventory.md', 'docs/tasks/TASK-DEVICE-TYPE-NORMALIZATION-01-FINAL.md', 'docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md', 'docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md', 'docs/tasks/TASK-WEB-DEVICE-TYPE-PRESENTATION-01-FINAL.md', 'docs/tasks/TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01-FINAL.md', 'docs/testing.md']

PR118_FINAL = '# TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01 — Home Online Devices Presentation — FINAL\n\nStatus: CLOSED / MERGED / PRODUCTION CURRENT / OWNER VISUAL PASS\nUpdated: 2026-09-13\n\n## Identity\n\n```text\nPR=#118\ntitle=TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01: improve Online Devices presentation\nbaseline=488e75aa2d1b067ee27d8fbfff778d49901d9fdf\npublication commit=892b66ad300ce9ad1b93ae4e0ce1cb235fb6c3cd\nmerge commit=2d87fd6d56f969492318e21c809086576b2b1ab1\naccepted / publication tree=346c7f1f8ad6e91f36fbd572b7c8f6e7a22add11\nchanged files=2\ndiff stat=+132/-15\n```\n\nChanged implementation files:\n\n```text\napp/admin_web/static/admin.css\napp/admin_web/static/admin.js\n```\n\n## Accepted Home Online Devices presentation\n\nThe Home Online Devices table replaced the expandable `Controller facts` detail\nwith direct compact presentation.\n\nCurrent columns established by this task:\n\n```text\nDevice / MAC\nAuth\nIP\nAP\nBand\nRSSI\nSNR\nUptime\nTraffic\n```\n\nThe task added:\n\n- Authorized / Waiting presentation tones;\n- 5 GHz / 2.4 GHz presentation tones;\n- a five-segment RSSI presentation;\n- human-readable controller uptime;\n- human-readable total controller traffic.\n\nAccepted RSSI colors:\n\n```text\ngood    #10b956\nwarning #f2c20d\ndanger  #ed3038\n```\n\nThis task did **not** introduce a Device Type contract. Device Type presentation\nwas deliberately deferred until one canonical backend/read-time normalization\ncontract existed.\n\nThat deferred dependency was later closed by:\n\n```text\nTASK-DEVICE-TYPE-NORMALIZATION-01 / PR #119\nTASK-WEB-DEVICE-TYPE-PRESENTATION-01 / PR #120\n```\n\n## Acceptance\n\n```text\nSource review=PASS\nnarrow frontend gate=4/4 PASS\nOwner visual acceptance=PASS\nWindows Central Lab V7 strict=PASS\nstrict regressions=0\nexact-artifact immutability=PASS\n```\n\nThis FINAL records the accepted PR #118 stage. The current Home contract also\nincludes the later Device Type and SNR presentation work from PR #120.\n'
PR119_FINAL = '# TASK-DEVICE-TYPE-NORMALIZATION-01 — Canonical Device Type Foundation — FINAL\n\nStatus: CLOSED / MERGED / DEPLOYED / PRODUCTION ACTIVE\nUpdated: 2026-09-13\n\n## Identity\n\n```text\nPR=#119\ntitle=TASK-DEVICE-TYPE-NORMALIZATION-01: canonical Device Type foundation\nbaseline=2d87fd6d56f969492318e21c809086576b2b1ab1\npublication commit=6597d6615af14a1dc7988cefc5a769ad51591b39\nmerge commit=144c8a922b4431293fdc1d4bb57bed29a8402f6b\naccepted / merge tree=2349838d7e524efd3fb2e0433a7111553f195e71\nchanged files=19\ndiff stat=+425/-21\n```\n\n## Canonical owner\n\n```text\napp/common/device_type.py\n\nDEVICE_TYPE_KEY_MAX_UTF8_BYTES = 128\n\nnormalize_device_type_key(source_value: object) -> str | None\n```\n\n## Canonical lexical normalization\n\nThe canonical machine key is derived from one raw source value only:\n\n```text\n1. None -> None\n2. non-string -> None\n3. strip\n4. empty -> None\n5. NUL -> None\n6. strict UTF-8 encode\n7. raw trimmed value > 128 UTF-8 bytes -> None\n8. casefold\n9. empty -> None\n10. NUL -> None\n11. strict UTF-8 encode\n12. canonical value > 128 UTF-8 bytes -> None\n13. return canonical key\n```\n\nPermanent exclusions:\n\n```text\nUnicode normalization form=NO\nsemantic alias mapping=NO\ncross-field inference=NO\nseparator collapsing=NO\ntruncation=NO\n```\n\nExamples:\n\n```text\n" Android " -> "android"\n"phone"     -> "phone"\n"É"         -> "é"\n```\n\nA decomposed `E + combining acute` is not automatically converted to composed\n`é`; there is no NFC/NFD/NFKC/NFKD normalization.\n\n## Raw vs canonical roles\n\n```text\ndevice_type     = raw/source/display evidence\ndevice_type_key = canonical machine/presentation key\n```\n\nThe raw value remains backward-compatible evidence and is not replaced by the\ncanonical key.\n\n## Read-surface enrichment\n\nThe task adds read-time canonical keys while preserving source persistence.\n\nRelevant surfaces include:\n\n- Home Current State client items: `device_type`, `device_type_key`;\n- historical Device list / identity;\n- Device Current Context current client;\n- Observation client DTO data;\n- Analytics `SafeSnapshotSummary`;\n- Visitor Registry snapshots: `device_type_key`;\n- Visitor Registry device summary: `last_known_device_type_key`.\n\nNo DB migration or backfill stores the canonical key as a new source fact.\n\n## Frontend boundary\n\nThe browser is not the normalization authority.\n\n```text\nfrontend trim/lower/casefold=FORBIDDEN\nfrontend Unicode normalization=FORBIDDEN\nfrontend Device Type inference=FORBIDDEN\n```\n\nConsumers use the server-provided canonical key for machine decisions and raw\n`device_type` for truthful display/source text.\n\n## Acceptance\n\n```text\nCoder focused tests=38 passed\ncompileall=PASS\ngit diff --check=PASS\nWindows Central Lab V7 strict=PASS\naccepted tree=2349838d7e524efd3fb2e0433a7111553f195e71\n```\n\nThe current production project later advanced through PR #120 without changing\nthis canonical normalization contract.\n'
PR120_FINAL = '# TASK-WEB-DEVICE-TYPE-PRESENTATION-01 — Device Type and SNR Presentation — FINAL\n\nStatus: CLOSED / MERGED / DEPLOYED / PRODUCTION ACCEPTANCE PASS\nUpdated: 2026-09-13\n\n## Identity\n\n```text\nPR=#120\nbaseline=144c8a922b4431293fdc1d4bb57bed29a8402f6b\npublication commit=bf40a275d64fdde44125594048eae2a67616323d\nmerge / current production HEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5\naccepted / merge / production tree=8312658be3ba272998f46212d9bad76950e3867e\nchanged files=4\ndiff stat=+154/-31\n```\n\nChanged files:\n\n```text\napp/admin_web/static/admin.css\napp/admin_web/static/admin.js\napp/admin_web/static/icons/README.md\ntests/admin_web/test_admin_ui_frontend.py\n```\n\nBackend/API/DB/security contracts were not changed by this presentation task.\n\n## Canonical Device Type presentation\n\nMachine decisions use only the canonical server-provided key:\n\n```javascript\ndevice_type_key === "android"\n```\n\nThe browser no longer normalizes raw `device_type`.\n\n```text\nfrontend trim=NO\nfrontend lowercase=NO\nfrontend casefold=NO\nfrontend Unicode normalize=NO\nfrontend inference=NO\n```\n\nRaw `device_type` remains source/display text.\n\n## Home → Online Devices\n\nA `Type` column exists immediately after `Device / MAC`.\n\nAndroid:\n\n```text\ndecision=device_type_key === "android"\nvisual=repository-local Android SVG\nconstant adjacent "Android" text=NO\n```\n\nWhen both values are absent:\n\n```text\ndevice_type_key=null\ndevice_type=null\n→ NULL\n```\n\nOther valid types display the raw source text, for example `phone`.\n\nNo classification is inferred from hostname, system name, MAC, vendor, SSID,\nAP, IP or history.\n\n## Device Card\n\nDevice Card uses `device_type_key` for presentation decisions and raw\n`device_type` for display/source text.\n\nIf a detail object owns its own `device_type_key`, that key has priority.\n\nFor `Latest Site snapshot`, `identity.device_type_key` may be used as the\npresentation key when the snapshot raw type and identity raw type refer to the\nsame Device record.\n\nThe canonical machine key is not exposed as a separate user-facing field.\n\n## Home SNR presentation\n\nSource remains `item.snr`.\n\n```text\nSNR >= 25      -> good    / #10b956\n15 <= SNR < 25 -> warning / #f2c20d\nSNR < 15       -> danger  / #ed3038\nnull           -> neutral / existing "—"\n```\n\nNo `Good / Warning / Poor` labels are added. RSSI and SNR remain independent;\nthere is no combined score and no backend classification.\n\n## CSS scope\n\nHome Online Devices geometry/presentation rules are scoped under:\n\n```css\n.live-section[aria-labelledby="devices-now-title"]\n```\n\nThey must not modify unrelated `.live-table` surfaces such as Traffic tables.\n\nAn earlier over-broad FIX-3 candidate was rejected and never applied. It is not\npart of the implementation history represented by this FINAL.\n\nThe accepted final visual state includes the later FIX-3A/FIX-3B corrections.\nA small future cosmetic header-centering refinement remains deliberately\nnon-blocking.\n\n## Acceptance\n\n```text\nOwner Visual Acceptance=PASS\nWindows Central Lab V7 strict=PASS\nStrict regressions=0\nLAB commit=b6bf602873fcf4a41e21ced6c0fe1be18ce0f483\naccepted LAB tree=8312658be3ba272998f46212d9bad76950e3867e\nmerge tree identity=PASS\n```\n\nEvidence log:\n\n```text\nC:\\CaptivPortal-Lab\\logs\\lab-test-v7-strict-20260913-114135-DETACHED.log\n```\n\n## Production acceptance\n\n```text\nHEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5\nTREE=8312658be3ba272998f46212d9bad76950e3867e\nworktree=CLEAN\ncaptive-portal.service=active\ntraffic-projection.service=active\nroot readiness=HTTP 400 expected without Omada parameters\nPRODUCTION VISUAL ACCEPTANCE=PASS\n```\n\nStatic artifact proof:\n\n```text\nadmin.js worktree/head blob=564e2a3d59d99dd02570ec6a0239720e51e460f1\nadmin.css worktree/head blob=6552ae9221eb390cef54a4fcd13207dd3bc29fc6\n```\n\nNo application restart was required because this task changed static JS/CSS\ndelivery only; the controlled checkout immediately exposed the new static files.\n'
DEVICE_TYPE_CURRENT = '## Canonical Device Type contract — current production\n\n```text\nTASK-DEVICE-TYPE-NORMALIZATION-01=CLOSED / MERGED / DEPLOYED / PRODUCTION ACTIVE\nTASK-WEB-DEVICE-TYPE-PRESENTATION-01=CLOSED / MERGED / DEPLOYED / PRODUCTION ACCEPTANCE PASS\nPR #119=MERGED\nPR #120=MERGED\ncurrent production HEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5\ncurrent production tree=8312658be3ba272998f46212d9bad76950e3867e\n```\n\nCanonical ownership:\n\n```text\nraw/source/display value = device_type\nmachine/presentation key = device_type_key\nnormalization owner       = app/common/device_type.py\n```\n\n`device_type_key` is a bounded lexical key derived with `strip()` + `casefold()`\nand strict UTF-8 validation. It does not perform Unicode normalization, semantic\nmapping, inference, separator collapsing or truncation.\n\nThe browser consumes the server-provided key. It must not derive a Device Type\nkey from raw `device_type`.\n\nAndroid presentation is therefore strictly:\n\n```javascript\ndevice_type_key === "android"\n```\n\nThe earlier browser-owned `trim().toLowerCase()` Android predicate remains\nhistorical evidence of TASK-WEB-ASSET-LIBRARY-01/FIX and is **superseded as a\ncurrent contract** by PR #119/#120.\n\nThe Android SVG remains repository-local:\n\n```text\napp/admin_web/static/icons/platforms/android.svg\nSHA256=2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc\n```\n'
HOME_CURRENT = '## Home Online Devices — current presentation\n\nThe current production Home table presents:\n\n```text\nDevice / MAC\nType\nAuth\nIP\nAP\nBand\nRSSI\nSNR\nUptime\nTraffic\n```\n\nThe `Type` column is immediately after `Device / MAC`.\n\nType presentation:\n\n```text\ndevice_type_key == "android" -> Android SVG cue\ndevice_type_key == null AND device_type == null -> NULL\notherwise -> raw device_type\n```\n\nNo Device Type inference is performed from hostname, system name, MAC, vendor,\nSSID, AP, IP or history.\n\nSNR is presentation-only:\n\n```text\n>=25      good    #10b956\n15..24    warning #f2c20d\n<15       danger  #ed3038\nnull      neutral / —\n```\n\nRSSI and SNR are independent. No combined score or backend quality\nclassification exists.\n\nHome-specific geometry and tones are scoped to:\n\n```css\n.live-section[aria-labelledby="devices-now-title"]\n```\n\nand do not redefine unrelated `.live-table` surfaces.\n'
DEVICE_CARD_CURRENT = '## Device Card Device Type — current presentation\n\nDevice Card keeps raw and canonical roles separate:\n\n```text\ndevice_type     -> source/display text\ndevice_type_key -> machine/presentation decision\n```\n\nThe frontend does not trim, lowercase, casefold, Unicode-normalize or infer\nDevice Type.\n\nA detail object that contains its own `device_type_key` owns that presentation\ndecision. `Latest Site snapshot` may use `identity.device_type_key` when the\nsnapshot raw type and identity raw type belong to the same Device record.\n\n`device_type_key` itself is not rendered as a separate user-facing field.\n'

OLD_HEAD = "c1dc3344bc778a32cdc6b0edce278ee40b287c29"
OLD_TREE = "0563f58cf2a5c961e1dedb52cfa2b4b298dd2c1c"
ANDROID_SHA = "2f2411f1f05522e90049f8cbb06105fb553057efeadf772cdcc3ae24bbc8a6cc"

def cap(args, cwd, check=True):
    p = subprocess.run(
        args, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        encoding="utf-8", errors="replace"
    )
    if check and p.returncode:
        if p.stdout: print(p.stdout, end="")
        if p.stderr: print(p.stderr, end="")
        raise SystemExit("STOP: command failed: " + " ".join(args))
    return p.stdout or "", p.stderr or ""

def run(args, cwd):
    p = subprocess.run(args, cwd=cwd)
    if p.returncode:
        raise SystemExit("STOP: command failed: " + " ".join(args))

def txt(args, cwd):
    return cap(args, cwd)[0]

def norm(s):
    return s.replace("\r\n", "\n").replace("\r", "\n")

def read(path):
    return norm(Path(path).read_text(encoding="utf-8-sig"))

def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(norm(text), encoding="utf-8", newline="\n")

def status_paths(repo):
    out, _ = cap(["git", "status", "--porcelain", "--untracked-files=all"], repo)
    return sorted({line[3:].strip() for line in out.splitlines() if line})

def diff_names(repo, cached=False):
    args = ["git", "diff"]
    if cached: args.append("--cached")
    args += ["--name-only", "--"]
    out, _ = cap(args, repo)
    return sorted({line.strip() for line in out.splitlines() if line.strip()})

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise ValueError(f"{label}: expected exactly 1 match, found {count}")
    return text.replace(old, new, 1)

def replace_line_prefix(text, prefix, new_line, label):
    lines = text.splitlines()
    hits = [i for i, line in enumerate(lines) if line.startswith(prefix)]
    if len(hits) != 1:
        raise ValueError(f"{label}: prefix {prefix!r} matched {len(hits)} lines")
    lines[hits[0]] = new_line
    return "\n".join(lines) + ("\n" if text.endswith("\n") else "")

def replace_section(text, start_heading, end_heading, replacement, label):
    start = text.find(start_heading)
    if start < 0:
        raise ValueError(f"{label}: start heading missing: {start_heading}")
    end = text.find(end_heading, start + len(start_heading))
    if end < 0:
        raise ValueError(f"{label}: end heading missing: {end_heading}")
    if text.find(start_heading, start + 1) >= 0:
        raise ValueError(f"{label}: duplicate start heading")
    return text[:start] + replacement.rstrip() + "\n\n" + text[end:]

def insert_before(text, anchor, block, label):
    if block.strip().splitlines()[0] in text:
        raise ValueError(f"{label}: block already present")
    return replace_once(text, anchor, block.rstrip() + "\n\n" + anchor, label)

def update_date(text):
    lines = text.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("Updated: "):
            lines[i] = f"Updated: {DATE}"
            return "\n".join(lines) + ("\n" if text.endswith("\n") else "")
    return text

def update_current_headers(path, text):
    mapping = {
        "Current-state implementation baseline: ": f"Current-state implementation baseline: `main@{BASE}`",
        "Current implementation tree: ": f"Current implementation tree: `{TREE}`",
        "Runtime implementation baseline: ": f"Runtime implementation baseline: `main@{BASE}`",
        "Runtime tree: ": f"Runtime tree: `{TREE}`",
        "Current repository implementation baseline: ": f"Current repository implementation baseline: `main@{BASE}`",
        "Confirmed production deployed HEAD: ": f"Confirmed production deployed HEAD: `{BASE}`",
        "Confirmed production tree: ": f"Confirmed production tree: `{TREE}`",
        "Documentation/current-state implementation baseline: ": f"Documentation/current-state implementation baseline: `main@{BASE}`",
        "Production deployed HEAD: ": f"Production deployed HEAD: `{BASE}`",
        "Production tree: ": f"Production tree: `{TREE}`",
        "Repository implementation baseline: ": f"Repository implementation baseline: `main@{BASE}`",
        "Repository tree: ": f"Repository tree: `{TREE}`",
        "Baseline: ": f"Baseline: `main@{BASE}`",
    }
    lines = text.splitlines()
    changed = False
    for i, line in enumerate(lines):
        for prefix, new_line in mapping.items():
            if line.startswith(prefix):
                # Update only top/current headers; stop scanning after first major heading body.
                if i <= 8:
                    lines[i] = new_line
                    changed = True
                break
    return "\n".join(lines) + ("\n" if text.endswith("\n") else ""), changed

def add_table_row_after(text, needle_line, new_lines, label):
    if new_lines[0] in text:
        return text
    return replace_once(text, needle_line, needle_line + "\n" + "\n".join(new_lines), label)

def build_outputs(repo):
    outputs = {}

    # README EN
    path = "README.md"
    t = read(repo / path)
    for old, new in [
        (f"| Repository implementation checkpoint | `main@{OLD_HEAD}` |", f"| Repository implementation checkpoint | `main@{BASE}` |"),
        (f"| Repository tree | `{OLD_TREE}` |", f"| Repository tree | `{TREE}` |"),
        (f"| Production deployed HEAD | `{OLD_HEAD}` |", f"| Production deployed HEAD | `{BASE}` |"),
        (f"| Production tree | `{OLD_TREE}` |", f"| Production tree | `{TREE}` |"),
    ]:
        t = replace_once(t, old, new, f"{path}: identity")
    t = add_table_row_after(
        t,
        "| Current Device Context | **TASK-DEVICE-CARD-01 — COMPLETE / PRODUCTION ACTIVE** |",
        [
            "| Home Online Devices presentation | **TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01 — CLOSED / PRODUCTION CURRENT** |",
            "| Canonical Device Type foundation | **TASK-DEVICE-TYPE-NORMALIZATION-01 — CLOSED / PRODUCTION ACTIVE** |",
            "| Device Type + SNR presentation | **TASK-WEB-DEVICE-TYPE-PRESENTATION-01 — CLOSED / PRODUCTION ACCEPTANCE PASS** |",
        ],
        path + ": status rows",
    )
    new_section = DEVICE_TYPE_CURRENT + "\n\n" + HOME_CURRENT + "\n\n" + DEVICE_CARD_CURRENT
    t = replace_section(
        t,
        "## Admin Web local asset library — current production\n",
        "## Windows strict baseline cleanup\n",
        new_section,
        path + ": replace asset/current section",
    )
    outputs[path] = t

    # README RU: same canonical engineering blocks are intentionally language-neutral.
    path = "README_RU.md"
    t = read(repo / path)
    for old, new in [
        (f"| Repository implementation checkpoint | `main@{OLD_HEAD}` |", f"| Repository implementation checkpoint | `main@{BASE}` |"),
        (f"| Repository tree | `{OLD_TREE}` |", f"| Repository tree | `{TREE}` |"),
        (f"| Production deployed HEAD | `{OLD_HEAD}` |", f"| Production deployed HEAD | `{BASE}` |"),
        (f"| Production tree | `{OLD_TREE}` |", f"| Production tree | `{TREE}` |"),
    ]:
        t = replace_once(t, old, new, f"{path}: identity")
    t = add_table_row_after(
        t,
        "| Current Device Context | **TASK-DEVICE-CARD-01 — COMPLETE / PRODUCTION ACTIVE** |",
        [
            "| Home Online Devices presentation | **TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01 — CLOSED / PRODUCTION CURRENT** |",
            "| Canonical Device Type foundation | **TASK-DEVICE-TYPE-NORMALIZATION-01 — CLOSED / PRODUCTION ACTIVE** |",
            "| Device Type + SNR presentation | **TASK-WEB-DEVICE-TYPE-PRESENTATION-01 — CLOSED / PRODUCTION ACCEPTANCE PASS** |",
        ],
        path + ": status rows",
    )
    t = replace_section(
        t,
        "## Admin Web local asset library — current production\n",
        "## Windows strict baseline cleanup\n",
        DEVICE_TYPE_CURRENT + "\n\n" + HOME_CURRENT + "\n\n" + DEVICE_CARD_CURRENT,
        path + ": replace asset/current section",
    )
    outputs[path] = t

    # icon provenance doc
    path = "app/admin_web/static/icons/README.md"
    t = read(repo / path)
    t = replace_once(
        t,
        "- Purpose: decorative cue before unchanged Android `device_type` text anywhere Admin Web renders that field, including Devices list, Device detail identity/evidence, and observations.",
        "- Purpose: repository-local Android presentation cue. Home Online Devices uses the icon without constant adjacent `Android` text; Device/observation surfaces may pair the cue with unchanged raw `device_type` display text.",
        path + ": purpose",
    )
    outputs[path] = t

    # docs/README
    path = "docs/README.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    t = replace_once(
        t,
        f"Current Traffic state at implementation baseline `main@{OLD_HEAD}`:",
        f"Current Traffic state at implementation baseline `main@{BASE}`:",
        path + ": Traffic baseline",
    )
    t = replace_once(
        t,
        f"main = {OLD_HEAD}\ntree = {OLD_TREE}",
        f"main = {BASE}\ntree = {TREE}",
        path + ": Device Card checkpoint",
    )
    map_line = "| WEB-ASSET-LIBRARY-01 Android FIX closure | `tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md` |"
    t = add_table_row_after(
        t, map_line,
        [
            "| Home Online Devices presentation closure | `tasks/TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01-FINAL.md` |",
            "| Canonical Device Type foundation closure | `tasks/TASK-DEVICE-TYPE-NORMALIZATION-01-FINAL.md` |",
            "| Device Type + SNR presentation closure | `tasks/TASK-WEB-DEVICE-TYPE-PRESENTATION-01-FINAL.md` |",
        ],
        path + ": knowledge map",
    )
    t = replace_section(
        t,
        "## Admin Web local asset library — current production\n",
        "## Current Windows full-regression contract\n",
        DEVICE_TYPE_CURRENT + "\n\n" + HOME_CURRENT + "\n\n" + DEVICE_CARD_CURRENT,
        path + ": current Device Type",
    )
    outputs[path] = t

    # architecture
    path = "docs/architecture.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    architecture_block = r"""## Canonical Device Type lexical key

Device Type keeps two deliberately different representations:

```text
device_type     = raw/source/display evidence
device_type_key = canonical machine/presentation key
```

Canonical normalization owner:

```text
app/common/device_type.py
normalize_device_type_key()
DEVICE_TYPE_KEY_MAX_UTF8_BYTES=128
```

The key is read-time lexical normalization of one source value: trim, strict
UTF-8 validation, bounded length, then `casefold()` and the same validation
again.

Permanent exclusions:

```text
Unicode normalization=NO
semantic mapping=NO
inference from other facts=NO
separator collapsing=NO
truncation=NO
```

The canonical key is additive. It does not replace stored/raw `device_type` and
does not create a device-classification layer.

Admin/Web consumers must use the server-provided key for machine decisions.
Browser-owned trim/lower/casefold/Unicode normalization/inference is forbidden.
"""
    if "## Canonical Device Type lexical key\n" not in t:
        t = insert_before(t, "## 8. Admin Web\n", architecture_block, path + ": Device Type architecture")
    outputs[path] = t

    # configuration (baseline only + explicit no-config statement)
    path = "docs/configuration.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    no_config = r"""### Device Type normalization / presentation tasks

`TASK-DEVICE-TYPE-NORMALIZATION-01` and
`TASK-WEB-DEVICE-TYPE-PRESENTATION-01` introduce no new configuration key,
feature flag, DB migration or systemd setting.
"""
    if "### Device Type normalization / presentation tasks\n" not in t:
        t = insert_before(t, "### Pending Session Cleaner\n", no_config, path + ": no-config note")
    outputs[path] = t

    # deployment
    path = "docs/deployment.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    deployment_block = r"""## Device presentation / normalization production chain — 2026-09-13

The previous full KB publication was PR #117. Three implementation baselines then
advanced before this reconciliation:

```text
PR #118 -> Home Online Devices presentation
merge=2d87fd6d56f969492318e21c809086576b2b1ab1

PR #119 -> Canonical Device Type foundation
merge=144c8a922b4431293fdc1d4bb57bed29a8402f6b
tree=2349838d7e524efd3fb2e0433a7111553f195e71

PR #120 -> Device Type + SNR presentation
merge / current production=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
tree=8312658be3ba272998f46212d9bad76950e3867e
```

PR #119 is the server/read-contract foundation. PR #120 is presentation-only
relative to that foundation.

Current production after PR #120:

```text
HEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
TREE=8312658be3ba272998f46212d9bad76950e3867e
worktree=CLEAN
captive-portal.service=active
traffic-projection.service=active
root readiness=HTTP 400 expected without Omada request parameters
Owner production visual acceptance=PASS
```

PR #120 did not require an application restart: its runtime delivery was static
JS/CSS/provenance content and controlled checkout already exposed the accepted
files.

```text
DB migration=NO
schema change=NO
configuration change=NO
feature flag change=NO
systemd unit change=NO
daemon-reload=NO
```
"""
    if "## Device presentation / normalization production chain — 2026-09-13\n" not in t:
        t = insert_before(t, "## Feature activation\n", deployment_block, path + ": deployment chain")
    outputs[path] = t

    # module index
    path = "docs/module-index.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    lines = t.splitlines()
    for i, line in enumerate(lines):
        if line.startswith("Owner-provided production checkpoint "):
            lines[i] = "Owner-provided production checkpoint 2026-09-13:"
            break
    for i, line in enumerate(lines):
        if line.startswith("HEAD: "):
            lines[i] = f"HEAD: {BASE}"
            if i + 1 < len(lines) and lines[i+1].startswith("tree: "):
                lines[i+1] = f"tree: {TREE}"
            break
    t = "\n".join(lines) + ("\n" if t.endswith("\n") else "")
    asset_row = next((line for line in t.splitlines() if line.startswith("| Admin Web local asset library |")), None)
    if asset_row is None:
        raise ValueError(path + ": Admin Web asset row missing")
    t = add_table_row_after(
        t, asset_row,
        [
            "| Canonical Device Type lexical key | current production foundation | `app/common/device_type.py` + read serializers/services | `architecture.md`, `modules/current-state.md`, `modules/observations.md`, `modules/visitor-registry.md`, `modules/analytics.md` | read-time additive key; raw persistence unchanged | no |",
            "| Home Online Devices presentation | current production presentation | `app/admin_web/static/admin.css`, `app/admin_web/static/admin.js` | `modules/admin-web.md` | none | no |",
            "| Device Type + SNR presentation | current production presentation | `app/admin_web/static/admin.css`, `app/admin_web/static/admin.js` | `modules/admin-web.md` | none | no |",
        ],
        path + ": module rows",
    )
    outputs[path] = t

    # Admin Web module
    path = "docs/modules/admin-web.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    combined = r"""## Devices / Device Type / Home presentation — current state

```text
TASK-DEVICE-LIST-CONTEXT-01=CLOSED / PRODUCTION ACTIVE
TASK-WEB-DEVICE-UI-01=CLOSED / PRODUCTION ACTIVE
TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01=CLOSED / PRODUCTION CURRENT
TASK-DEVICE-TYPE-NORMALIZATION-01=CLOSED / PRODUCTION ACTIVE
TASK-WEB-DEVICE-TYPE-PRESENTATION-01=CLOSED / PRODUCTION ACCEPTANCE PASS
PR #110 / #118 / #119 / #120=MERGED
```

Global Online-first remains backend-owned before pagination.

""" + DEVICE_TYPE_CURRENT + "\n\n" + DEVICE_CARD_CURRENT + "\n\n" + HOME_CURRENT
    t = replace_section(
        t,
        "## Devices presentation and local assets — current state\n",
        "## Home\n",
        combined,
        path + ": current presentation section",
    )
    # Remove now-contradictory old UI/design paragraph by replacing only its stale sentence.
    stale = "That task covers presentation-only compact Devices cards/list, human-readable\nbytes/time/rates, status indicators and future Online-first UX. It must not be\ndescribed as current production behavior until separately accepted."
    current = "That task is historical/current production foundation for the Devices presentation. Later Home and Device Type presentation work is tracked separately by PR #118/#120 and is also production-current."
    if stale in t:
        t = t.replace(stale, current, 1)
    outputs[path] = t

    # Current State module
    path = "docs/modules/current-state.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    block = r"""## Device Type read contract

Current State persistence retains raw `device_type` evidence.

Admin/Home Current State client serialization now exposes both:

```text
device_type
device_type_key
```

`device_type_key` is derived at read/serialization time by
`app/common/device_type.py`; collection, schema and raw stored meaning are not
changed.

Home presentation must consume the key directly and must not re-normalize the raw
value in JavaScript.
"""
    if "## Device Type read contract\n" not in t:
        t = insert_before(t, "## Dependencies\n", block, path + ": Device Type read contract")
    outputs[path] = t

    # Observations module
    path = "docs/modules/observations.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    block = r"""## Device Type read enrichment

Observation storage continues to preserve raw `device_type` and the independent
`connect_device_type` fact.

Client Observation read DTO data adds:

```text
device_type_key
```

derived from raw `device_type` by the central lexical normalizer.

The key is read-time enrichment only. It does not rewrite persisted historical
evidence and it must never be inferred from `system_name`,
`connect_device_type`, MAC/vendor or other fields.
"""
    if "## Device Type read enrichment\n" not in t:
        t = insert_before(t, "## Maintenance\n", block, path + ": Device Type enrichment")
    outputs[path] = t

    # Registry module
    path = "docs/modules/visitor-registry.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    block = r"""## Device Type read enrichment

Visitor Registry persistence remains raw/source-oriented.

Read boundaries now add:

```text
snapshot.device_type_key
device summary.last_known_device_type_key
```

These values are derived from the corresponding raw `device_type` /
`last_known_device_type` through the central lexical normalizer.

No migration/backfill changes the stored source value.
"""
    if "## Device Type read enrichment\n" not in t:
        t = insert_before(t, "## Relationship to Visit Lifecycle\n", block, path + ": Device Type enrichment")
    outputs[path] = t

    # Analytics module
    path = "docs/modules/analytics.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    block = r"""## Device Type read contract

Analytics remains read-only and preserves raw source semantics.

`SafeSnapshotSummary` exposes both:

```text
device_type
device_type_key
```

The canonical key is derived from the raw source value only through
`app/common/device_type.py`.

Analytics does not classify Device Type from hostname, system name, MAC, vendor,
SSID, AP, IP or unrelated evidence.
"""
    if "## Device Type read contract\n" not in t:
        t = insert_before(t, "## Services\n", block, path + ": Device Type read contract")
    outputs[path] = t

    # Traffic module: current project identity only; semantics unaffected.
    path = "docs/modules/traffic.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    outputs[path] = t

    # project inventory
    path = "docs/project-inventory.md"
    t = update_date(read(repo / path))
    t = replace_line_prefix(t, "Runtime commit: ", f"Runtime commit: `{BASE}`", path + ": runtime commit")
    t = replace_line_prefix(t, "Runtime tree: ", f"Runtime tree: `{TREE}`", path + ": runtime tree")
    t = replace_line_prefix(
        t, "Commit source: ",
        "Commit source: merge PR #120 / Device Type and SNR presentation, 2026-09-13",
        path + ": commit source",
    )
    block = r"""## Device Type / Home presentation current state

```text
TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01=CLOSED / PRODUCTION CURRENT
TASK-DEVICE-TYPE-NORMALIZATION-01=CLOSED / PRODUCTION ACTIVE
TASK-WEB-DEVICE-TYPE-PRESENTATION-01=CLOSED / PRODUCTION ACCEPTANCE PASS
PR #118 / #119 / #120=MERGED
```

Canonical split:

```text
device_type=raw/source/display
device_type_key=central canonical machine key
owner=app/common/device_type.py
```

Read-time key exposure now spans Current State/Admin Home, historical Device
surfaces, Device Current Context, Observation/Analytics evidence and Visitor
Registry summaries/snapshots.

Current Home Online Devices includes Type plus the accepted Auth/Band/RSSI
presentation from PR #118 and SNR/Type presentation from PR #120.

No browser-owned Device Type normalization/inference is current architecture.
"""
    if "## Device Type / Home presentation current state\n" not in t:
        t = insert_before(t, "## Windows test baseline / production closure\n", block, path + ": current state")
    outputs[path] = t

    # testing
    path = "docs/testing.md"
    t = update_date(read(repo / path))
    t, _ = update_current_headers(path, t)
    latest = r"""### Latest Device Type / Home presentation acceptance — PR #118 / #119 / #120

PR #118:

```text
Home Online Devices presentation=PASS
narrow frontend gate=4/4 PASS
Owner visual acceptance=PASS
Central Lab V7 strict=PASS
strict regressions=0
```

PR #119:

```text
TASK-DEVICE-TYPE-NORMALIZATION-01=CLOSED
Coder focused tests=38 PASS
compileall=PASS
git diff --check=PASS
Central Lab V7 strict=PASS
accepted tree=2349838d7e524efd3fb2e0433a7111553f195e71
```

PR #120:

```text
Owner Visual Acceptance=PASS
Central Lab V7 strict=PASS
strict regressions=0
LAB commit=b6bf602873fcf4a41e21ced6c0fe1be18ce0f483
accepted / merge tree=8312658be3ba272998f46212d9bad76950e3867e
production visual acceptance=PASS
```

The older `case-insensitive Android matching=PASS` evidence below belongs to the
historical WEB-ASSET-LIBRARY/FIX acceptance. It does **not** define the current
browser contract after PR #119/#120.

Current browser contract:

```text
Android machine decision=device_type_key === "android"
raw browser trim/lower/casefold normalization=NO
```
"""
    if "### Latest Device Type / Home presentation acceptance — PR #118 / #119 / #120\n" not in t:
        t = insert_before(
            t,
            "### Latest Admin Web presentation acceptance — WEB-ASSET-LIBRARY-01 + FIX\n",
            latest,
            path + ": acceptance section",
        )
    outputs[path] = t

    # Historical Asset Library task notes
    for path in [
        "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md",
        "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md",
    ]:
        t = read(repo / path)
        marker = "## Later Device Type architecture supersession — 2026-09-13"
        if marker not in t:
            t = t.rstrip() + r"""

## Later Device Type architecture supersession — 2026-09-13

The raw browser-owned case-insensitive Android predicate documented above remains
valid **historical acceptance evidence for this earlier task**.

It is no longer the current machine-decision contract.

Later accepted work:

```text
TASK-DEVICE-TYPE-NORMALIZATION-01 / PR #119
TASK-WEB-DEVICE-TYPE-PRESENTATION-01 / PR #120
```

established:

```text
device_type     = raw/source/display evidence
device_type_key = server-provided canonical machine key
Android decision = device_type_key === "android"
```

Current Admin Web must not reconstruct the key from raw `device_type`.
""" + "\n"
        outputs[path] = t

    # New canonical FINALs
    outputs["docs/tasks/TASK-WEB-HOME-ONLINE-DEVICE-PRESENTATION-01-FINAL.md"] = PR118_FINAL.rstrip() + "\n"
    outputs["docs/tasks/TASK-DEVICE-TYPE-NORMALIZATION-01-FINAL.md"] = PR119_FINAL.rstrip() + "\n"
    outputs["docs/tasks/TASK-WEB-DEVICE-TYPE-PRESENTATION-01-FINAL.md"] = PR120_FINAL.rstrip() + "\n"

    if sorted(outputs) != SCOPE:
        missing = sorted(set(SCOPE) - set(outputs))
        extra = sorted(set(outputs) - set(SCOPE))
        raise ValueError(f"output scope mismatch: missing={missing}, extra={extra}")
    return outputs

def assert_outputs(outputs):
    current_docs = [
        "README.md", "README_RU.md", "docs/README.md", "docs/modules/admin-web.md",
    ]
    old_predicate = 'value.trim().toLowerCase() === "android"'
    for path in current_docs:
        if old_predicate in outputs[path]:
            raise ValueError(f"{path}: stale raw Android predicate remains current")
        if "device_type_key" not in outputs[path]:
            raise ValueError(f"{path}: device_type_key current contract missing")

    for path in [
        "README.md", "README_RU.md", "docs/README.md", "docs/architecture.md",
        "docs/deployment.md", "docs/module-index.md", "docs/modules/admin-web.md",
        "docs/modules/analytics.md", "docs/modules/traffic.md", "docs/project-inventory.md",
        "docs/testing.md",
    ]:
        if BASE not in outputs[path]:
            raise ValueError(f"{path}: current HEAD missing")

    for path in [
        "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FINAL.md",
        "docs/tasks/TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION-FINAL.md",
    ]:
        if old_predicate not in outputs[path]:
            raise ValueError(f"{path}: historical raw predicate unexpectedly removed")
        if "Later Device Type architecture supersession — 2026-09-13" not in outputs[path]:
            raise ValueError(f"{path}: supersession note missing")

    if "rejected FIX-3" in outputs["docs/tasks/TASK-WEB-DEVICE-TYPE-PRESENTATION-01-FINAL.md"].lower():
        # Wording intentionally says an earlier over-broad candidate was rejected; the exact rejected
        # patch must not be represented as implementation. This check is only to keep the task text explicit.
        pass

    if 'device_type_key === "android"' not in outputs["docs/tasks/TASK-WEB-DEVICE-TYPE-PRESENTATION-01-FINAL.md"]:
        raise ValueError("PR120 FINAL: canonical Android predicate missing")
    if "Unicode normalization=NO" not in outputs["docs/architecture.md"]:
        raise ValueError("architecture: Unicode normalization exclusion missing")
    if "last_known_device_type_key" not in outputs["docs/modules/visitor-registry.md"]:
        raise ValueError("registry: last_known_device_type_key missing")
    if "device_type_key" not in outputs["docs/modules/current-state.md"]:
        raise ValueError("current-state: key contract missing")
    if "device_type_key" not in outputs["docs/modules/observations.md"]:
        raise ValueError("observations: key contract missing")
    if "device_type_key" not in outputs["docs/modules/analytics.md"]:
        raise ValueError("analytics: key contract missing")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--repo",
        default=os.environ.get(
            "CAPTIVPORTAL_KB_REPO",
            str(Path(os.environ.get("USERPROFILE", str(Path.home()))) /
                "Downloads" / "CaptivPortal-KB-Work")
        ),
    )
    ap.add_argument("--no-push", action="store_true")
    ns = ap.parse_args()
    repo = Path(ns.repo)

    print("Publisher: FULL-KB-SYNC-DEVICE-TYPE-2026-09-13")
    print("=== PRECHECK ===")
    if not (repo / ".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if status_paths(repo):
        print("Dirty paths:", *status_paths(repo), sep="\n  ")
        raise SystemExit("STOP: worktree must be clean")

    run(["git", "fetch", "origin", "main"], repo)
    remote = txt(["git", "rev-parse", "origin/main"], repo).strip()
    remote_tree = txt(["git", "rev-parse", "origin/main^{tree}"], repo).strip()
    print("origin/main:", remote)
    print("origin tree:", remote_tree)
    if remote != BASE or remote_tree != TREE:
        raise SystemExit("STOP: origin/main moved; fresh reconciliation required")

    run(["git", "switch", "main"], repo)
    run(["git", "merge", "--ff-only", "origin/main"], repo)
    if status_paths(repo):
        raise SystemExit("STOP: main dirty after fast-forward")

    if txt(["git", "ls-remote", "--heads", "origin", f"refs/heads/{BRANCH}"], repo).strip():
        raise SystemExit("STOP: remote publication branch already exists")
    local = txt(["git", "branch", "--list", BRANCH], repo).strip()
    if local:
        sha = txt(["git", "rev-parse", BRANCH], repo).strip()
        if sha != BASE:
            raise SystemExit("STOP: existing local publication branch has moved")
        run(["git", "branch", "-D", BRANCH], repo)

    print("=== TRANSACTIONAL BUILD (NO REPO WRITES) ===")
    try:
        outputs = build_outputs(repo)
        assert_outputs(outputs)
    except Exception as exc:
        raise SystemExit(f"STOP BEFORE WRITE: {exc}")

    with tempfile.TemporaryDirectory(prefix="captivportal-kb-sync-") as tmp:
        tmpdir = Path(tmp)
        for path, content in outputs.items():
            write(tmpdir / path, content)
        # Re-read the temp tree to prove UTF-8 serialization before touching repo.
        for path in SCOPE:
            _ = read(tmpdir / path)

        print("PASS: all 21 transformed documents built in temporary tree")
        print("PASS: semantic assertions before repository write")

        run(["git", "switch", "-c", BRANCH], repo)
        for path in SCOPE:
            target = repo / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(tmpdir / path, target)

    actual = status_paths(repo)
    print("Changed files:")
    for path in actual:
        print(" ", path)
    if actual != SCOPE:
        raise SystemExit("STOP: exact 21-file documentation scope mismatch after transactional copy")

    # Runtime/test guard.
    for path in actual:
        if path.startswith("tests/"):
            raise SystemExit("STOP: test file changed by KB sync")
        if path.startswith("app/") and path != "app/admin_web/static/icons/README.md":
            raise SystemExit("STOP: runtime app file changed by KB sync")

    run(["git", "diff", "--check"], repo)
    print("PASS: git diff --check")
    print("PASS: implementation/tests/runtime unchanged")
    print("PASS: exact 21-file repo documentation/provenance scope")

    print("=== STAGE ===")
    run(["git", "add", "--"] + SCOPE, repo)
    if diff_names(repo, False):
        raise SystemExit("STOP: unstaged changes remain")
    if diff_names(repo, True) != SCOPE:
        raise SystemExit("STOP: staged scope mismatch")
    run(["git", "diff", "--cached", "--check"], repo)
    print("PASS: git diff --cached --check")

    patch = Path(__file__).resolve().parent / "CaptivPortal_FULL_KB_SYNC_DEVICE_TYPE_2026-09-13.patch"
    with patch.open("wb") as fh:
        q = subprocess.run(
            ["git", "diff", "--cached", "--binary", "--"] + SCOPE,
            cwd=repo, stdout=fh, stderr=subprocess.PIPE
        )
    if q.returncode or not patch.exists() or patch.stat().st_size == 0:
        raise SystemExit("STOP: patch generation failed")

    if ns.no_push:
        print("NO-PUSH: exact documentation diff staged; no commit/push/PR")
        print("Patch:", patch)
        return

    print("=== COMMIT ===")
    run([
        "git", "commit",
        "-m", "docs: sync Device Type and Home presentation current state",
        "-m", "Reconcile the canonical KB from PR #117 through PR #118/#119/#120, document device_type_key authority and current Home/Device Card presentation contracts, preserve historical asset acceptance, and update the project baseline to main@3dc85735."
    ], repo)
    commit = txt(["git", "rev-parse", "HEAD"], repo).strip()
    if status_paths(repo):
        raise SystemExit("STOP: worktree not clean after commit")

    print("=== PUSH ===")
    run(["git", "push", "-u", "origin", BRANCH], repo)

    print("=== DRAFT PR ===")
    body = f"""## Purpose

Full canonical KB synchronization after three implementation baselines that
followed the previous KB merge PR #117.

## Baselines

Previous documented project baseline:
- HEAD {OLD_HEAD}
- TREE {OLD_TREE}

Current repository / production baseline:
- HEAD {BASE}
- TREE {TREE}

Covered implementation stages:
- PR #118 Home Online Devices presentation
- PR #119 Canonical Device Type foundation
- PR #120 Device Type and SNR presentation

## Current Device Type contract

- raw/source/display: `device_type`
- canonical machine key: `device_type_key`
- owner: `app/common/device_type.py`
- browser raw normalization/inference: forbidden
- Android machine decision: `device_type_key === "android"`

## Scope

- exactly 21 documentation/provenance files
- three new FINAL TASK records
- runtime implementation changed: NO
- tests changed: NO
- DB/schema/config/flags changed: NO
- production changed by this docs PR: NO
- historical Asset Library acceptance preserved with explicit supersession note

Draft only. Merge remains Owner-controlled.
"""
    pr = txt([
        "gh", "pr", "create",
        "--repo", "ZaurNavi/CaptivePortal",
        "--base", "main",
        "--head", BRANCH,
        "--title", "Docs: full KB sync for Device Type and Home presentation",
        "--body", body,
        "--draft",
    ], repo).strip()

    print("=== DONE ===")
    print("Branch:", BRANCH)
    print("Commit:", commit)
    print("Changed docs:", len(SCOPE))
    print("Draft PR:", pr)
    print("Implementation/tests/runtime changed: NO")
    print("MERGE=NO")
    print("DEPLOY=NO")
    print("Patch:", patch)

if __name__ == "__main__":
    main()
