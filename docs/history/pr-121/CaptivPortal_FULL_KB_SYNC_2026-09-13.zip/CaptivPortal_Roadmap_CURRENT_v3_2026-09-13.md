# CaptivPortal — актуальная дорожная карта проекта v3

**Тип документа:** постоянная проектная дорожная карта  
**Статус:** CURRENT  
**Версия:** 3.0  
**Дата актуализации:** 13 сентября 2026 года  
**Проект:** CaptivPortal  
**Current repository / production baseline:** `main@3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`  
**Tree:** `8312658be3ba272998f46212d9bad76950e3867e`

## 1. Source-of-truth

Эта версия заменяет CURRENT-статус roadmap v2 от 11.08.2026. Roadmap v2
сохраняется как historical planning evidence.

Current-state truth:

```text
current code
→ current tests
→ current canonical KB
→ this roadmap
```

Historical TASK/FINAL/acceptance остаются evidence и не переписываются задним
числом.

## 2. Завершённая platform staircase

К текущему baseline завершены и используются:

```text
Captive Authorization / CAPPORT
Pending Session Cleaner
Authorized Snapshot
Visitor Registry
Observation Foundation
Current State
Visit Lifecycle v2
Analytics Foundation + production read runtime
Web Foundation / Admin Web
Traffic Section through TASK-TRAFFIC-09
Traffic Projection lifecycle P0 recovery
Device Current Context
Device List Context / Devices presentation
Admin Web local asset library
Windows Central Lab V7 strict baseline
Home Online Devices presentation
Canonical Device Type foundation
Device Type + SNR presentation
```

Последняя цепочка UI/Device Type:

```text
PR #118 Home Online Devices presentation
→ PR #119 Canonical Device Type foundation
→ PR #120 Device Type + SNR presentation
```

## 3. Canonical Device Type direction

```text
device_type     = raw/source/display evidence
device_type_key = canonical lexical machine key
owner           = app/common/device_type.py
```

The key is lexical normalization only. No semantic alias mapping, no inference
from hostname/system/MAC/vendor/SSID/AP/IP/history, and no Unicode normalization
form.

Future richer device classification, if required, is a separate layer/TASK and
must not mutate this source/key contract.

## 4. Current Admin Web / Home direction

Home Online Devices now has direct Auth/Band/RSSI/SNR/Uptime/Traffic
presentation and a Type column.

Current Type decisions consume `device_type_key`; browser-owned raw
normalization is not architecture.

Device Card Stage 1 / Current Device Context is complete and production-active.

## 5. Current Traffic direction

Traffic is production-active through `TASK-TRAFFIC-09`.
No next Traffic TASK is canonical until Owner / Tech Lead separately assigns it.

Observation remains authoritative historical source; Traffic Projection remains
derived/rebuildable and fail-closed on divergence.

## 6. Remaining planned product stages

Still future unless separately accepted:

```text
DEVICE-CARD-02 — Visit Detail & Visit Traffic
DEVICE-CARD-03 — Device History
DEVICE-CARD-04 — Device Summary / Intelligence
universal Access Policy / Credential Layer
QR credential/access first implementation
real second-Site rollout
Multi-Site ADR
Tenant / customer account / RBAC evolution
subscriptions / entitlements / billing
```

## 7. Permanent architecture boundaries

```text
Acquisition != Analytics
Observation/Registry/Visit/Current State own persisted facts
Analytics is read-only
Admin Web does not query Omada directly
Grafana/Loki remain engineering observability
visitor auth != Admin auth
Site != Tenant
single-process remains accepted until a scaling ADR
```

## 8. Parallel technical debt

Still current unless a separate accepted action closes it:

- rotation of the old Omada Client Secret;
- TLS verification / current `VERIFY_SSL=false` debt;
- GitHub CI/release-gate absence;
- low-priority repository cleanup;
- single-process accepted limitation.

The old `DEBT-P1-004 — KB drift` is a closure candidate of the current full KB
sync and becomes CLOSED only when the synchronization PR is merged.

## 9. Immediate project rule

Do not derive the next implementation TASK from this roadmap by assumption.
Owner / Tech Lead must explicitly approve the next TASK and pin the exact current
`origin/main` before execution.
