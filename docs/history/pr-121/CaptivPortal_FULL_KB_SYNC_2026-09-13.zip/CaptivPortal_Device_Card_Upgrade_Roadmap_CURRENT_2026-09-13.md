# CaptivPortal — Device Card Upgrade Roadmap v1 — Current Update

**Status:** CURRENT ROADMAP / STAGE 1 COMPLETE  
**Updated:** 2026-09-13  
**Project baseline:** `main@3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`  
**Tree:** `8312658be3ba272998f46212d9bad76950e3867e`

This document updates the status layer of the original Device Card Upgrade
Roadmap v1. The original roadmap remains historical architecture evidence.

## Stage status

```text
STAGE 1 — Current Status / DEVICE-CARD-01
COMPLETE / MERGED / PRODUCTION ACTIVE

STAGE 2 — Visit Details
PLANNED

STAGE 3 — Observed Traffic per Visit
PLANNED

STAGE 4 — Snapshot History
PLANNED

STAGE 5 — Observation History
PLANNED

STAGE 6 — Device Summary / Intelligence
PLANNED
```

## Stage 1 current contract

Device Detail has independent historical and current domains.

Current Device Context uses persisted Current State and, when applicable,
Current Guest Traffic evidence.

Permanent semantics:

```text
fresh complete scope + present -> online
fresh complete scope + absent  -> offline
stale/unavailable/untrusted    -> unknown
historical data alone != offline proof
```

## Device Type update after Stage 1

Later accepted work added the canonical Device Type foundation across Device
read surfaces.

```text
raw/display = device_type
machine key = device_type_key
owner       = app/common/device_type.py
```

Device Card uses `device_type_key` only for machine/presentation decisions and
keeps raw `device_type` as source/display text.

Frontend normalization/inference is not allowed.

For `Latest Site snapshot`, `identity.device_type_key` may be used as the
presentation key when both raw values belong to the same Device record.

The key itself is not shown as an independent user-facing field.

## Current production presentation

PR #120 is production-accepted.

Android:

```text
device_type_key === "android"
→ repository-local Android SVG
```

Unknown valid types retain raw display text.

No semantic classification is inferred from hostname, system name, MAC, vendor,
SSID, AP, IP or history.

## Remaining roadmap

The completion of Stage 1 and Device Type presentation does not implicitly
complete Stages 2–6. Each future stage requires a separate exact-baseline TASK,
acceptance gates and Owner-authorized production delivery.
