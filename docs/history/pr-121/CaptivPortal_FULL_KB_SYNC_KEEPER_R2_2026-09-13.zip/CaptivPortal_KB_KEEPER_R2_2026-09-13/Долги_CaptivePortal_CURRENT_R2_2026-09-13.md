# Долги CaptivPortal — CURRENT R2

**Последнее обновление:** 13 сентября 2026  
**Repository/current production checkpoint for this reconciliation:** `3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`  
**Tree:** `8312658be3ba272998f46212d9bad76950e3867e`

## OPEN

### DEBT-P1-002 — Rotation старого Omada Client Secret

**Статус:** OPEN.

Current tree не содержит production literal credentials; остаточное действие —
Owner-controlled rotation/revocation старого secret, если это ещё не выполнено.
Не записывать secret в KB.

### DEBT-P1-003 — TLS verification к Omada Controller

**Статус:** OPEN.

Repository default `VERIFY_SSL=false`. Закрытие требует отдельного security /
operations TASK с доверенной certificate chain и focused acceptance.

### DEBT-P1-004 — Дрейф базы знаний относительно current main

**Статус:** CLOSURE CANDIDATE.

R2 подготовлен против:

```text
HEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
TREE=8312658be3ba272998f46212d9bad76950e3867e
```

До фактического merge documentation PR этот долг не CLOSED.

### DEBT-P2-001 — Отсутствие GitHub CI

**Статус:** OPEN / SOURCE-CONFIRMED ON CURRENT MAIN.

`.github` содержит Copilot instructions/instructions и PR template, но
`.github/workflows` отсутствует.

Manual Central Lab remains a project gate; CI addition requires a separate
infrastructure TASK.

### DEBT-P2-002 — Низкоприоритетная repository cleanup

**Статус:** OPEN / SOURCE-CONFIRMED ON CURRENT MAIN.

Fresh source audit confirms both previously named items still exist:

```text
app/web/web.py
  GET /success compatibility route

outputs/omada-webhook-normalized.alloy
  tracked repository artifact
```

R2 does not call either item a defect requiring deletion. Architect/Tech Lead
must separately decide compatibility-route ownership and Alloy artifact
ownership/removal.

### LIMIT-001 — Single-process / process-local bounded state

**Статус:** ACCEPTED LIMITATION.

Shared state / leader election / persistent guards become mandatory design work
before multi-worker, horizontal scaling or HA.

## KB inventory correction — not a new debt

R2 found current repository capabilities that were underrepresented in current
KB:

```text
Home System Health (PR #74)
Home AP-24H + fixes (PR #78-#80)
Home AP-24H telemetry (PR #81)
```

They are documentation-sync corrections, not newly discovered runtime defects.
Production feature flags are not inferred from repository defaults.

## Recently closed milestones relevant to this sync

```text
TASK-TEST-BASELINE-CLEANUP-01 -> CLOSED / PR #116
Home Online Devices presentation -> CLOSED / PR #118
Canonical Device Type foundation -> CLOSED / PR #119
Device Type + SNR presentation -> CLOSED / PR #120
```
