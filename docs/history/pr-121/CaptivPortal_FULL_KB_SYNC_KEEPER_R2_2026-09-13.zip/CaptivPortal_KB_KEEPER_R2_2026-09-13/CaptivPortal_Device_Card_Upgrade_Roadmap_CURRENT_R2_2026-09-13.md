# CaptivPortal Device Card Upgrade Roadmap — CURRENT R2

**Date:** 2026-09-13  
**Baseline:** `main@3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`

## Current status

```text
DEVICE-CARD-01 / Current Device Context = COMPLETE / PRODUCTION ACTIVE
Device List Context                       = CLOSED / PRODUCTION ACTIVE
Devices presentation                      = CLOSED / PRODUCTION ACTIVE
Canonical Device Type foundation          = CLOSED / PRODUCTION ACTIVE
Device Type presentation                  = CLOSED / PRODUCTION ACCEPTANCE PASS
```

Current Device Detail preserves:

```text
Historical Device Context != Current Device Context
stale != offline
unavailable != offline
0 != missing/unavailable
```

## Device Type contract now available to future stages

```text
device_type     = raw/source/display evidence
device_type_key = canonical lexical machine/presentation key
```

The key is produced centrally by `app/common/device_type.py` and is not inferred
in the browser. It may be reused by future Device Card presentation where the
read contract exposes it.

It is **not** a richer semantic device-classification model.

## Remaining stages

### DEVICE-CARD-02 — Visit Detail & Visit Traffic

Future. Must preserve Visit Lifecycle source semantics and keep Network Traffic
separate from completed guest-session Traffic.

### DEVICE-CARD-03 — Device History

Future. Must consume persisted Site-safe history/read contracts; no browser or
request-time Omada reconstruction.

### DEVICE-CARD-04 — Device Summary / Intelligence

Future. New scores/classifications/inferences require an explicit semantic owner
and cannot be hidden inside `device_type_key` or presentation code.

## R2 review note

No missing Device Card implementation stage was discovered beyond the already
known Stage 1 closure. R2 therefore does not invent a new Device Card TASK; it
only binds future stages to the accepted Device Type boundary.
