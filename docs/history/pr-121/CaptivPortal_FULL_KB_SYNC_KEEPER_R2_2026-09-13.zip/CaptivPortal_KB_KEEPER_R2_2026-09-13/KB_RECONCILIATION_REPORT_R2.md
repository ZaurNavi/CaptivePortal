# CaptivPortal full Knowledge Base reconciliation — Keeper R2

**Date:** 2026-09-13  
**Review type:** full repository/current-KB reconciliation + review of previous Keeper candidate  
**Repository:** `ZaurNavi/CaptivePortal`  
**Exact baseline:** `main@3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`  
**Tree:** `8312658be3ba272998f46212d9bad76950e3867e`

## 1. Decision

Previous Keeper candidate is **NOT rejected**. Its core Device Type / PR #118–#120
reconciliation is correct and is reused as the R2 foundation.

R2 is required because the review found:

1. one information-loss bug in the previous publisher;
2. two real merged Home subsystems underrepresented by current canonical KB;
3. two repository debts that can now be source-confirmed rather than left as
   “needs fresh audit”;
4. one current role document that was reviewed and correctly requires no change.

## 2. Exact current baseline verified

```text
HEAD=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
TREE=8312658be3ba272998f46212d9bad76950e3867e
current merge=PR #120
```

Implementation chain since the previous KB merge PR #117:

```text
PR #118 -> merge 2d87fd6d56f969492318e21c809086576b2b1ab1
PR #119 -> merge 144c8a922b4431293fdc1d4bb57bed29a8402f6b
PR #120 -> merge 3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
```

## 3. Previous Keeper work accepted without semantic change

The following parts were checked against current code/PR evidence and are kept:

- `app/common/device_type.py` is the canonical owner;
- `DEVICE_TYPE_KEY_MAX_UTF8_BYTES=128`;
- normalization is trim -> strict UTF-8/bound -> casefold -> strict UTF-8/bound;
- no Unicode normalization form;
- no semantic mapping/inference/separator collapsing/truncation;
- raw `device_type` and canonical `device_type_key` have separate roles;
- PR #119 read-surface enrichment is additive/read-time;
- PR #120 Android decision is only `device_type_key === "android"`;
- Home Type column, NULL/raw behavior and Device Card key precedence are correct;
- SNR thresholds and presentation-only semantics are correct;
- Home CSS scoping and rejected broad FIX-3 handling are correct;
- historical Asset Library FINAL/FIX documents should retain their original raw
  matching evidence with an explicit supersession note.

## 4. R2 correction — Asset Library information-loss bug

The previous publisher replaced the entire current section:

```text
## Admin Web local asset library — current production
...
## Windows strict baseline cleanup
```

with only Device Type/Home/Device Card blocks.

That would remove still-valid current information:

- `TASK-WEB-ASSET-LIBRARY-01` closure;
- `TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION` closure;
- PR #113/#114 provenance;
- local Android asset path;
- accepted Android SVG SHA256.

R2 restores/preserves that section and changes only its **current machine
predicate** to the PR #119/#120 contract:

```javascript
device_type_key === "android"
```

The old raw `trim().toLowerCase()` predicate remains only inside historical TASK
evidence, not current docs.

Affected current docs protected by R2 assertions:

```text
README.md
README_RU.md
docs/README.md
docs/modules/admin-web.md
```

## 5. R2 addition — Home System Health missing from current KB inventory

Current repository contains the merged Home System Health implementation:

```text
PR #74
merge=f458df3b360bba89e9965a1edfdcc0d3af2f201c
repository default WEB_ADMIN_HOME_HEALTH_ENABLED=false
```

Current code includes:

```text
app/admin_web/home_health.py
app/admin_web/home_health_config.py
app/admin_web/home_health_serialization.py
runtime/query/routes/templates/tests integration
Observation bounded health reads
```

The current `module-index.md` did not enumerate this subsystem and
`docs/configuration.md` did not document the `WEB_ADMIN_HOME_HEALTH_*` group.

R2 adds current routing/architecture/configuration/inventory documentation.

Important: R2 does **not** infer that production currently has the feature flag
ON. Repository default and live production state remain separate truths.

## 6. R2 addition — Home AP-24H underrepresented

Current repository contains:

```text
PR #78 Home AP-24H                         MERGED
PR #79 rolling-duration partition fix      MERGED
PR #80 frontend activation dataset fix     MERGED
PR #81 AP-24H operational telemetry        MERGED
```

Repository defaults:

```text
WEB_ADMIN_HOME_AP_24H_ENABLED=false
WEB_ADMIN_HOME_AP_24H_TELEMETRY_ENABLED=false
```

Canonical current meaning:

```text
Current State + Observation persisted evidence
-> Site-scoped rolling 24h AP read model
-> 96 x 15-minute buckets
-> no request-time Omada
-> no new AP24 persistence owner
```

Telemetry is a separate optional/fail-open worker over the existing read contract
and uses the existing Authorization Telemetry sink.

The old KB only mentioned AP-24H tersely and documented telemetry configuration,
but did not enumerate the product read model in module inventory or the main
AP-24H config group. R2 fixes this.

Again, current production flag values are not invented by repository inspection.

## 7. R2 debt audit

### GitHub CI

Source audit confirms `.github/workflows` is absent at current main.

```text
DEBT-P2-001=OPEN / CONFIRMED
```

### Low-priority repository cleanup

Source audit confirms both historical cleanup items still exist:

```text
app/web/web.py -> GET /success compatibility route
outputs/omada-webhook-normalized.alloy -> tracked artifact
```

Therefore:

```text
DEBT-P2-002=OPEN / CONFIRMED ON main@3dc85735
```

R2 does not decide whether either item should be removed. That remains a
separate architecture/cleanup TASK.

## 8. Web Designer role audit

`docs/agents/web-designer-role.md` was reviewed.

It is already current, presentation/backend/security boundaries remain valid,
and it does not define the stale raw Android predicate as a current machine
contract.

```text
R2 action=NO CHANGE REQUIRED
```

## 9. Repository publication scope

R2 keeps the previous exact 21-file documentation/provenance scope. No runtime
or tests are modified.

The R2 wrapper builds the previous Keeper's safe transactional output first,
then applies additional reconciliation corrections and stronger assertions.

Safety properties:

- exact `origin/main` HEAD/tree gate;
- clean worktree gate;
- temporary full build before repository writes;
- current Asset Library provenance assertion;
- stale current raw Android predicate assertion;
- Home Health/AP-24H presence assertions;
- exact documentation scope;
- no runtime/test scope;
- `git diff --check` + staged diff check;
- Draft PR only;
- never merge/deploy.

## 10. Publication status

```text
PREPARED=YES
GIT COMMIT/PUSH/PR=NOT PERFORMED BY THIS REVIEW
MERGE=NO
DEPLOY=NO
DEBT-P1-004=still CLOSURE CANDIDATE until KB PR merge
```
