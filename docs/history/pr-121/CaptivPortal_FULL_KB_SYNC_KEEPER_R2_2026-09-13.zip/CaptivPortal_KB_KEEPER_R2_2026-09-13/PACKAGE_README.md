# CaptivPortal KB Keeper R2 package

Use this package as the reviewed replacement for the earlier
`CaptivPortal_FULL_KB_SYNC_2026-09-13.zip` preparation.

## Recommended entry points

1. `KB_RECONCILIATION_REPORT_R2.md` — what was checked, accepted, corrected and added.
2. `MANIFEST_R2.json` — exact baseline/scope/safety metadata.
3. `publish_full_kb_sync_keeper_r2.py` — R2 publisher entry point.
4. `publish_full_kb_sync_device_type.py` — previous Keeper's safe base transformer, used by R2.
5. Current external project artifacts:
   - `CaptivPortal_Roadmap_CURRENT_v3_1_2026-09-13.md`
   - `CaptivPortal_Device_Card_Upgrade_Roadmap_CURRENT_R2_2026-09-13.md`
   - `Долги_CaptivePortal_CURRENT_R2_2026-09-13.md`

## Publication boundary

No Git commit, push, PR, merge or deployment has been performed by this package.

The R2 publisher requires exact:

```text
origin/main=3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5
origin/main^{tree}=8312658be3ba272998f46212d9bad76950e3867e
```

If main moves, stop and reconcile again instead of publishing stale docs.

For review-only materialization use:

```text
python publish_full_kb_sync_keeper_r2.py --repo <clean-repo-path> --no-push
```

This creates/stages the exact documentation candidate and emits a patch without
commit/push/PR.
