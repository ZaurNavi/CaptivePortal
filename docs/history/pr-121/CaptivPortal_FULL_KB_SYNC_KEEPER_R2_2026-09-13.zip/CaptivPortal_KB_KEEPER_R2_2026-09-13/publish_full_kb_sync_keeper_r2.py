from __future__ import annotations

import argparse
import importlib.util
import shutil
import subprocess
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE_SCRIPT = HERE / "publish_full_kb_sync_device_type.py"
spec = importlib.util.spec_from_file_location("kb_base", BASE_SCRIPT)
if spec is None or spec.loader is None:
    raise SystemExit("STOP: base publisher module cannot be loaded")
kb = importlib.util.module_from_spec(spec)
spec.loader.exec_module(kb)

BASE = kb.BASE
TREE = kb.TREE
DATE = kb.DATE
SCOPE = kb.SCOPE
OLD_HEAD = kb.OLD_HEAD
OLD_TREE = kb.OLD_TREE
ANDROID_SHA = kb.ANDROID_SHA
BRANCH = "docs/full-kb-sync-keeper-r2-2026-09-13"

ASSET_LIBRARY_CURRENT = f'''## Admin Web local asset library — current production

```text
TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS
TASK-WEB-ASSET-LIBRARY-01-FIX-ANDROID-PRESENTATION=CLOSED / PRODUCTION PASS
PR #113=MERGED
PR #114=MERGED / PRODUCTION VERIFIED
current production HEAD={BASE}
current production tree={TREE}
```

The repository-local Android asset remains:

```text
app/admin_web/static/icons/platforms/android.svg
SHA256={ANDROID_SHA}
```

The Asset Library tasks remain valid provenance/history for introducing and
fixing that asset. Their former raw browser predicate is historical acceptance
evidence only.

Current machine decision after PR #119/#120:

```javascript
device_type_key === "android"
```

Raw `device_type` remains source/display evidence. Current Admin Web does not
trim/lower/casefold/Unicode-normalize or infer Device Type in the browser.
'''

HOME_SYSTEMS_CURRENT = '''## Home operational read models — current repository contracts

Two implemented Home subsystems were underrepresented in the previous current KB
inventory and are explicitly restored here.

### Home System Health

```text
TASK-HOME-HEALTH-01 implementation=MERGED
PR #74 merge=f458df3b360bba89e9965a1edfdcc0d3af2f201c
repository default WEB_ADMIN_HOME_HEALTH_ENABLED=false
```

Home System Health is a read-only Admin composition over existing bounded
runtime/read evidence. It has no request-time Omada probe, Health DB, repair
worker or log scan. Its top-level product states are `operational`, `degraded`,
`unavailable`, `unknown`; `initializing`/`stale` are reason semantics.

This KB sync does **not** infer the current production value of
`WEB_ADMIN_HOME_HEALTH_ENABLED`; production enabled-state remains host-verified
unless separately evidenced.

### Home AP-24H

```text
TASK-HOME-AP-24H-01 implementation=MERGED
PR #78 merge=042f8e4c5f3c6205cec1823322688e1bf3805a57
PR #79 duration-partition fix=MERGED
PR #80 frontend dataset activation fix=MERGED
TASK-HOME-AP-24H-TELEMETRY-01 / PR #81=MERGED
repository default WEB_ADMIN_HOME_AP_24H_ENABLED=false
repository default WEB_ADMIN_HOME_AP_24H_TELEMETRY_ENABLED=false
```

Home AP-24H is a Site-scoped rolling 24-hour read model over persisted Current
State + Observation evidence: 96 x 15-minute buckets, no query-time Omada and no
new persistence owner. Operational telemetry reuses the existing Authorization
Telemetry sink and is separately feature-gated/fail-open.

Historical PR evidence shows production-acceptance work occurred during AP-24H
fixes, but this KB sync does not invent a current host flag value. Current
production enablement must be asserted only from host/Owner evidence.
'''

HOME_CONFIG = '''### Home System Health

Prefix: `WEB_ADMIN_HOME_HEALTH_*`.

Repository defaults:

```text
WEB_ADMIN_HOME_HEALTH_ENABLED=false
WEB_ADMIN_HOME_HEALTH_REFRESH_SECONDS=60
WEB_ADMIN_HOME_HEALTH_REQUEST_TIMEOUT_SECONDS=30
WEB_ADMIN_HOME_HEALTH_AUTH_EVIDENCE_MAX_AGE_SECONDS=86400
```

The feature is Admin-only/read-only and fails open relative to guest
authorization. Repository default `false` is not evidence of production
disablement.

### Home AP-24H

Repository defaults:

```text
WEB_ADMIN_HOME_AP_24H_ENABLED=false
WEB_ADMIN_HOME_AP_24H_REFRESH_SECONDS=120
WEB_ADMIN_HOME_AP_24H_REQUEST_TIMEOUT_SECONDS=30
```

The read model is bounded/read-only over persisted Current State + Observation
facts. It adds no query-time Omada path, DB or collector.
'''

HOME_ARCH = '''## Home operational read models

Home contains multiple independent product-safe read models; they are not a
second acquisition plane.

```text
Home System Health
→ Admin composition of existing bounded runtime/read evidence
→ no request-time Omada probe / Health DB / repair worker

Home AP-24H
→ Current State + Observation persisted evidence
→ rolling 24h / 96 x 15-minute buckets
→ no new persistence or query-time Omada

Home AP-24H telemetry
→ existing AP-24H read contract
→ existing Authorization Telemetry sink
→ separately feature-gated / fail-open
```

Repository defaults keep these optional Home surfaces disabled. Production
feature-state is operational evidence, not inferred from repository defaults.
'''

HOME_INVENTORY = '''## Home operational implementation inventory

```text
Home System Health:
  PR #74=MERGED
  code=app/admin_web/home_health.py + config/serialization/runtime/routes/UI/tests
  repository default=disabled
  production enabled-state=not inferred by this inventory

Home AP-24H:
  PR #78=MERGED
  PR #79 duration-partition fix=MERGED
  PR #80 frontend activation dataset fix=MERGED
  code=app/admin_web/home_ap_24h* + Admin query/route/UI/tests
  repository default=disabled
  production enabled-state=host/Owner evidence

Home AP-24H telemetry:
  PR #81=MERGED
  repository default=disabled
  sink=existing Authorization Telemetry
```
'''

HOME_TEST_HISTORY = '''### Home operational implementation evidence — repository inventory correction

The current repository also contains earlier merged Home subsystems that were
underrepresented in the current KB inventory:

```text
PR #74  Home System Health                    MERGED
PR #78  Home AP-24H                           MERGED
PR #79  AP-24H duration-partition fix         MERGED
PR #80  AP-24H frontend activation fix        MERGED
PR #81  AP-24H operational telemetry          MERGED
```

Their historical PR test/acceptance evidence remains valid. This reconciliation
only restores current documentation routing; it does not invent current
production feature-flag values.
'''


def insert_before(text: str, anchor: str, block: str, label: str) -> str:
    if block.strip().splitlines()[0] in text:
        return text
    return kb.replace_once(text, anchor, block.rstrip() + "\n\n" + anchor, label)


def add_rows_after_prefix(text: str, prefix: str, rows: list[str], label: str) -> str:
    if all(row in text for row in rows):
        return text
    line = next((x for x in text.splitlines() if x.startswith(prefix)), None)
    if line is None:
        raise ValueError(f"{label}: row prefix missing: {prefix}")
    return kb.add_table_row_after(text, line, rows, label)


def build_outputs_r2(repo: Path) -> dict[str, str]:
    outputs = kb.build_outputs(repo)

    # R2 correction #1: restore current Asset Library provenance that the R1
    # transformer accidentally removed while replacing the stale raw predicate.
    for path in ["README.md", "README_RU.md", "docs/README.md", "docs/modules/admin-web.md"]:
        t = outputs[path]
        t = insert_before(
            t,
            "## Canonical Device Type contract — current production\n",
            ASSET_LIBRARY_CURRENT,
            path + ": restore current Asset Library section",
        )
        outputs[path] = t

    # Root README subsystem inventory should expose real merged Home read models.
    for path in ["README.md", "README_RU.md"]:
        t = outputs[path]
        rows = [
            "| Home System Health | ✅ Current, default disabled | Product-safe system health read model; production flag host-verified |",
            "| Home AP-24H | ✅ Current, default disabled | Rolling 24h AP state/quality read model |",
            "| Home AP-24H telemetry | ✅ Current, default disabled | Structured operational telemetry over the AP-24H read contract |",
        ]
        # README_RU uses the same first-column token, so prefix matching is stable.
        t = add_rows_after_prefix(t, "| Home Activity |", rows, path + ": Home subsystem rows")
        t = insert_before(t, "## Windows strict baseline cleanup\n", HOME_SYSTEMS_CURRENT, path + ": Home systems current")
        outputs[path] = t

    # KB index page gets the same current implementation correction.
    t = outputs["docs/README.md"]
    t = insert_before(t, "## Current Windows full-regression contract\n", HOME_SYSTEMS_CURRENT, "docs/README: Home systems current")
    outputs["docs/README.md"] = t

    # Architecture current-state correction.
    t = outputs["docs/architecture.md"]
    t = insert_before(t, "## 8. Admin Web\n", HOME_ARCH, "architecture: Home operational read models")
    outputs["docs/architecture.md"] = t

    # Configuration had AP24 telemetry but omitted Home Health and the AP24
    # product feature itself.
    t = outputs["docs/configuration.md"]
    t = insert_before(t, "### Home AP-24H telemetry\n", HOME_CONFIG, "configuration: Home feature groups")
    outputs["docs/configuration.md"] = t

    # Module index inventory + current evidence.
    t = outputs["docs/module-index.md"]
    rows = [
        "| Home System Health | current; default disabled | `app/admin_web/home_health*.py` + bounded source read evidence | `modules/admin-web.md` | none | no request-time Omada |",
        "| Home AP-24H | current; default disabled | `app/admin_web/home_ap_24h*.py` | `modules/admin-web.md` | reads Current State + Observation; no new persistence | no |",
        "| Home AP-24H telemetry | current; default disabled | `app/admin_web/home_ap_24h_telemetry.py` | `modules/admin-web.md` | existing Authorization Telemetry sink | no |",
    ]
    t = add_rows_after_prefix(t, "| Home Activity |", rows, "module-index: Home rows")
    marker = "TASK-TEST-BASELINE-CLEANUP-01: FINAL ACCEPTED / MERGED / DEPLOYED / PRODUCTION PASS"
    if marker in t and "TASK-HOME-HEALTH-01: MERGED / repository default disabled" not in t:
        t = t.replace(
            marker,
            marker
            + "\nTASK-HOME-HEALTH-01: MERGED / repository default disabled / production flag host-verified"
            + "\nTASK-HOME-AP-24H-01 + fixes: MERGED / repository default disabled / production flag host-verified"
            + "\nTASK-HOME-AP-24H-TELEMETRY-01: MERGED / repository default disabled",
            1,
        )
    outputs["docs/module-index.md"] = t

    # Admin module: R1 deleted the asset subsection; above restored it. Also
    # replace the terse Home sentence with truthful current repository contracts.
    t = outputs["docs/modules/admin-web.md"]
    old_home = (
        "Home Live reads Current State. Home Traffic reads Current Traffic. Home Activity\n"
        "reads Visit Lifecycle analytics. Home AP-24H reuses existing persisted/read contracts."
    )
    new_home = '''Home Live reads Current State. Home Traffic reads Current Traffic. Home Activity
reads Visit Lifecycle analytics.

### System Health

Home System Health is implemented through the Admin read/composition boundary and
uses existing runtime/read evidence only. Repository default is disabled; this
document does not infer the current production flag value.

### Home AP-24H

Home AP-24H is implemented as a rolling 24-hour read model over Current State +
Observation evidence (96 x 15-minute buckets). AP-24H telemetry is separately
feature-gated and uses existing Authorization Telemetry. Repository defaults for
both AP-24H and its telemetry are disabled; production flags remain host-verified.'''
    if old_home in t:
        t = t.replace(old_home, new_home, 1)
    elif "### System Health\n" not in t:
        raise ValueError("admin-web: expected Home paragraph missing")
    outputs["docs/modules/admin-web.md"] = t

    # Project inventory and Testing get explicit traceability rather than relying
    # on implicit code presence.
    t = outputs["docs/project-inventory.md"]
    t = insert_before(t, "## Windows test baseline / production closure\n", HOME_INVENTORY, "project-inventory: Home inventory")
    outputs["docs/project-inventory.md"] = t

    t = outputs["docs/testing.md"]
    t = insert_before(
        t,
        "### Latest Device Type / Home presentation acceptance — PR #118 / #119 / #120\n",
        HOME_TEST_HISTORY,
        "testing: Home implementation evidence",
    )
    outputs["docs/testing.md"] = t

    return outputs


def assert_outputs_r2(outputs: dict[str, str]) -> None:
    kb.assert_outputs(outputs)

    for path in ["README.md", "README_RU.md", "docs/README.md", "docs/modules/admin-web.md"]:
        if "TASK-WEB-ASSET-LIBRARY-01=CLOSED / PRODUCTION PASS" not in outputs[path]:
            raise ValueError(f"{path}: current Asset Library provenance lost")
        if ANDROID_SHA not in outputs[path]:
            raise ValueError(f"{path}: Android asset SHA provenance lost")
        if 'value.trim().toLowerCase() === "android"' in outputs[path]:
            raise ValueError(f"{path}: stale raw Android predicate is still current")

    for path in [
        "README.md", "README_RU.md", "docs/README.md", "docs/modules/admin-web.md",
        "docs/module-index.md", "docs/project-inventory.md",
    ]:
        if "Home System Health" not in outputs[path]:
            raise ValueError(f"{path}: Home System Health inventory missing")
        if "Home AP-24H" not in outputs[path]:
            raise ValueError(f"{path}: Home AP-24H inventory missing")

    if "### Home System Health\n" not in outputs["docs/configuration.md"]:
        raise ValueError("configuration: Home System Health config missing")
    if "### Home AP-24H\n" not in outputs["docs/configuration.md"]:
        raise ValueError("configuration: Home AP-24H config missing")
    if "## Home operational read models\n" not in outputs["docs/architecture.md"]:
        raise ValueError("architecture: Home operational read models missing")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--repo",
        default=str(Path.home() / "Downloads" / "CaptivPortal-KB-Work"),
    )
    ap.add_argument("--no-push", action="store_true")
    ns = ap.parse_args()
    repo = Path(ns.repo)

    print("Publisher: FULL-KB-SYNC-KEEPER-R2-2026-09-13")
    print("=== PRECHECK ===")
    if not (repo / ".git").exists():
        raise SystemExit(f"STOP: repo missing: {repo}")
    if kb.status_paths(repo):
        raise SystemExit("STOP: worktree must be clean")

    kb.run(["git", "fetch", "origin", "main"], repo)
    remote = kb.txt(["git", "rev-parse", "origin/main"], repo).strip()
    remote_tree = kb.txt(["git", "rev-parse", "origin/main^{tree}"], repo).strip()
    print("origin/main:", remote)
    print("origin tree:", remote_tree)
    if remote != BASE or remote_tree != TREE:
        raise SystemExit("STOP: origin/main moved; fresh reconciliation required")

    kb.run(["git", "switch", "main"], repo)
    kb.run(["git", "merge", "--ff-only", "origin/main"], repo)
    if kb.status_paths(repo):
        raise SystemExit("STOP: main dirty after fast-forward")

    if kb.txt(["git", "ls-remote", "--heads", "origin", f"refs/heads/{BRANCH}"], repo).strip():
        raise SystemExit("STOP: remote publication branch already exists")
    local = kb.txt(["git", "branch", "--list", BRANCH], repo).strip()
    if local:
        sha = kb.txt(["git", "rev-parse", BRANCH], repo).strip()
        if sha != BASE:
            raise SystemExit("STOP: existing local publication branch has moved")
        kb.run(["git", "branch", "-D", BRANCH], repo)

    print("=== TRANSACTIONAL BUILD (NO REPO WRITES) ===")
    try:
        outputs = build_outputs_r2(repo)
        assert_outputs_r2(outputs)
    except Exception as exc:
        raise SystemExit(f"STOP BEFORE WRITE: {exc}")

    with tempfile.TemporaryDirectory(prefix="captivportal-kb-sync-r2-") as tmp:
        tmpdir = Path(tmp)
        for path, content in outputs.items():
            kb.write(tmpdir / path, content)
        for path in SCOPE:
            _ = kb.read(tmpdir / path)

        print(f"PASS: all {len(SCOPE)} transformed documents built in temporary tree")
        print("PASS: R2 semantic assertions before repository write")

        kb.run(["git", "switch", "-c", BRANCH], repo)
        for path in SCOPE:
            target = repo / path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(tmpdir / path, target)

    actual = kb.status_paths(repo)
    if actual != SCOPE:
        raise SystemExit(f"STOP: exact documentation scope mismatch: {actual}")
    for path in actual:
        if path.startswith("tests/"):
            raise SystemExit("STOP: test file changed by KB sync")
        if path.startswith("app/") and path != "app/admin_web/static/icons/README.md":
            raise SystemExit("STOP: runtime app file changed by KB sync")

    kb.run(["git", "diff", "--check"], repo)
    kb.run(["git", "add", "--"] + SCOPE, repo)
    if kb.diff_names(repo, False):
        raise SystemExit("STOP: unstaged changes remain")
    if kb.diff_names(repo, True) != SCOPE:
        raise SystemExit("STOP: staged scope mismatch")
    kb.run(["git", "diff", "--cached", "--check"], repo)

    patch = HERE / "CaptivPortal_FULL_KB_SYNC_KEEPER_R2_2026-09-13.patch"
    with patch.open("wb") as fh:
        q = subprocess.run(
            ["git", "diff", "--cached", "--binary", "--"] + SCOPE,
            cwd=repo, stdout=fh, stderr=subprocess.PIPE,
        )
    if q.returncode or not patch.exists() or patch.stat().st_size == 0:
        raise SystemExit("STOP: patch generation failed")

    if ns.no_push:
        print("NO-PUSH: exact documentation diff staged; no commit/push/PR")
        print("Patch:", patch)
        return

    kb.run([
        "git", "commit",
        "-m", "docs: full KB reconciliation after PR 120",
        "-m", (
            "Reconcile canonical current docs through main@3dc85735, preserve the "
            "Admin Web asset provenance while superseding raw Android matching, "
            "document device_type_key authority, restore Home Health/AP-24H to "
            "the current inventory, and add PR #118/#119/#120 closure records."
        ),
    ], repo)
    commit = kb.txt(["git", "rev-parse", "HEAD"], repo).strip()
    if kb.status_paths(repo):
        raise SystemExit("STOP: worktree not clean after commit")

    kb.run(["git", "push", "-u", "origin", BRANCH], repo)

    body = f'''## Purpose

Full canonical KB reconciliation after review by the new Knowledge Base Keeper.

## Exact baseline

- HEAD `{BASE}`
- TREE `{TREE}`

## Covered current changes

- PR #118 Home Online Devices presentation
- PR #119 Canonical Device Type foundation
- PR #120 Device Type + SNR presentation

## Additional inventory corrections found during full repository review

- preserve current Admin Web local asset library provenance instead of deleting
  that section while superseding its historical raw Android predicate;
- restore merged Home System Health (PR #74) to current KB routing;
- restore Home AP-24H + fixes/telemetry (PR #78-#81) to current KB routing;
- do not infer current production feature flags from repository defaults.

## Scope

- exactly {len(SCOPE)} documentation/provenance files
- runtime implementation changed: NO
- tests changed: NO
- DB/schema/config values changed: NO
- production changed by this docs PR: NO

Draft only. Merge remains Owner-controlled.
'''
    pr = kb.txt([
        "gh", "pr", "create",
        "--repo", "ZaurNavi/CaptivePortal",
        "--base", "main",
        "--head", BRANCH,
        "--title", "Docs: full KB reconciliation through PR #120",
        "--body", body,
        "--draft",
    ], repo).strip()

    print("=== DONE ===")
    print("Branch:", BRANCH)
    print("Commit:", commit)
    print("Changed docs:", len(SCOPE))
    print("Draft PR:", pr)
    print("MERGE=NO")
    print("DEPLOY=NO")
    print("Patch:", patch)


if __name__ == "__main__":
    main()
