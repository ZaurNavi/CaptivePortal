# CaptivPortal — актуальная дорожная карта проекта v3.1

**Статус:** CURRENT / Keeper R2 review  
**Дата:** 13 сентября 2026  
**Repository / production checkpoint supplied for this sync:** `main@3dc85735ddf5d05dd20733d15dfe1c22c9c4fde5`  
**Tree:** `8312658be3ba272998f46212d9bad76950e3867e`

## 1. Current platform staircase

Реализованные repository capabilities:

```text
Captive Authorization / CAPPORT
Pending Session Cleaner
Authorized Snapshot
Visitor Registry
Observation Foundation
Current State
Visit Lifecycle v2
Analytics Foundation + protected read runtime
Admin Web / Web Foundation
Home Live
Home Traffic
Home Activity
Home System Health                 MERGED / repository default disabled
Home AP-24H                        MERGED / repository default disabled
Home AP-24H operational telemetry  MERGED / repository default disabled
Traffic Section through TRAFFIC-09
Traffic Projection lifecycle P0 recovery
Device Current Context
Device List Context / Devices presentation
Admin Web local asset library
Windows Central Lab V7 strict baseline
Home Online Devices presentation
Canonical Device Type foundation
Device Type + SNR presentation
```

Repository default `false` for optional Home features is not treated as proof of
current production disablement. Live feature state remains Owner/host evidence.

## 2. Latest Device Type / presentation chain

```text
PR #118 Home Online Devices presentation
-> PR #119 Canonical Device Type foundation
-> PR #120 Device Type + SNR presentation
```

Current Device Type contract:

```text
device_type     = raw/source/display
device_type_key = bounded canonical lexical key
owner           = app/common/device_type.py
```

No semantic classification or cross-field inference belongs in this key.

## 3. Home direction

Home is not one monolithic backend. Current product/read-model families are
independent:

```text
Home Live       -> Current State
Home Traffic    -> CurrentTrafficReadService / persisted Observation
Home Activity   -> Visit Lifecycle analytics
System Health   -> bounded existing runtime/read evidence
Home AP-24H     -> Current State + Observation read-only evidence
```

System Health and AP-24H do not create alternate Omada acquisition paths.

## 4. Traffic direction

Traffic is implemented through `TASK-TRAFFIC-09`.

```text
Observation = authoritative historical source
Traffic Projection = derived/rebuildable read model
Admin/Browser -> no direct Omada historical calculation
```

No successor Traffic TASK is canonical until separately approved.

## 5. Device Card roadmap

```text
Stage 1 / DEVICE-CARD-01 Current Device Context = COMPLETE / PRODUCTION ACTIVE
Stage 2 / DEVICE-CARD-02 Visit Detail & Visit Traffic = FUTURE
Stage 3 / DEVICE-CARD-03 Device History = FUTURE
Stage 4 / DEVICE-CARD-04 Device Summary / Intelligence = FUTURE
```

Current Device Type key is reusable presentation/read evidence. It must not be
silently promoted into a richer device-classification engine.

## 6. Future product stages

Still future unless separately accepted:

```text
universal Access Policy / Credential Layer
QR credential/access first implementation
real second-Site rollout
Multi-Site ADR
Tenant/customer identity/RBAC
subscriptions/entitlements/billing
richer device classification (separate semantic layer if needed)
```

## 7. Permanent boundaries

```text
Acquisition != Analytics
persisted facts have explicit owners
Analytics is read-only
Admin Web does not query Omada directly for product reads
Grafana/Loki = engineering observability
visitor auth != Admin auth
Site != Tenant
single-process accepted until scaling ADR
repository defaults != live production state
```

## 8. Parallel debt

Still current unless separately closed:

- old Omada Client Secret rotation;
- TLS verification / `VERIFY_SSL=false` debt;
- KB drift until this reconciliation is actually merged;
- GitHub CI/release-gate absence — source-confirmed;
- low-priority repository cleanup (`/success`, tracked Alloy artifact) — source-confirmed;
- single-process accepted limitation.

## 9. Next-task rule

Roadmap order is not implementation authorization. Owner/Tech Lead must select
the next TASK and re-pin exact `origin/main` before coding.
