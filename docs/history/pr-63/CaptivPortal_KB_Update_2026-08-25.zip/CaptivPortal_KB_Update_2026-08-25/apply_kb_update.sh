#!/usr/bin/env bash
set -euo pipefail

EXPECTED="dfc62b43712301b05baf9f6e5dd843e13eaa9fc7"
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
TARGET="${1:-}"

if [ -z "$TARGET" ]; then
  echo "Usage: $0 /path/to/CaptivePortal" >&2
  exit 2
fi

cd "$TARGET"
git rev-parse --is-inside-work-tree >/dev/null

ACTUAL="$(git rev-parse HEAD)"
if [ "$ACTUAL" != "$EXPECTED" ]; then
  echo "STOP: expected HEAD $EXPECTED" >&2
  echo "actual HEAD: $ACTUAL" >&2
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "STOP: working tree is not clean" >&2
  git status --short >&2
  exit 1
fi

while IFS= read -r -d '' src; do
  rel="${src#"$SCRIPT_DIR/files/"}"
  dst="$TARGET/$rel"
  mkdir -p "$(dirname "$dst")"
  cp -- "$src" "$dst"
done < <(find "$SCRIPT_DIR/files" -type f -print0)

echo "Applied KB files to working tree."
echo
git status --short
echo
git diff --check
echo
echo "No commit/push/merge was performed."
