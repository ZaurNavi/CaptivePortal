# Coordination note for the active coder

The Knowledge Base update is documentation-only and is based on:

`main@dfc62b43712301b05baf9f6e5dd843e13eaa9fc7`

If your current implementation TASK already started from this same SHA, **do not change your implementation baseline merely because the KB commit will later move `main` forward**.

Continue the current implementation from the fixed baseline.

Before final integration:
1. compare/rebase/merge against the then-current `main` according to team policy;
2. absorb documentation-only KB changes;
3. if Tech Lead reports a specific newly documented current-code contract that affects your TASK, treat that finding separately.

The KB package itself changes no runtime code, test code, schema or feature flag.
