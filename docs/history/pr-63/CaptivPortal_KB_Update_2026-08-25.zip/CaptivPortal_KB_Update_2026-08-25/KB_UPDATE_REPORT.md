# CaptivPortal KB current-state update — implementation package

TASK result: **PASS WITH FINDINGS / READY TO APPLY**

Baseline:
- branch: `main`
- commit: `dfc62b43712301b05baf9f6e5dd843e13eaa9fc7`
- baseline confirmed before package build: 2026-08-25

## Why this package exists

The connected GitHub integration allowed repository reads but returned HTTP 403 for branch creation and Git object writes. Therefore `main` was intentionally not touched.

This package contains complete replacement/new documentation files plus an apply script. The script performs no commit, push, PR or merge.

## Updated files

- `README.md`
- `README_RU.md`
- `docs/README.md`
- `docs/project-inventory.md`
- `docs/architecture.md`
- `docs/module-index.md`
- `docs/testing.md`
- `docs/logging.md`
- `docs/security.md`
- `docs/deployment.md`
- `docs/agents/workflow.md`
- `docs/api/omada-open-api.md`
- `docs/archive/migration-plan.md`
- `docs/modules/capport.md`
- `docs/modules/visitor-registry.md`
- `docs/modules/pending-session-cleaner.md`

## Created files

- `docs/configuration.md`
- `docs/modules/visit-lifecycle.md`
- `docs/modules/observations.md`
- `docs/modules/current-state.md`
- `docs/modules/analytics.md`
- `docs/modules/admin-web.md`

## Major contradictions resolved in package

1. `ab776af` no longer appears as current architecture baseline.
2. Root READMEs no longer classify Visit/Observation/Analytics/Admin as future.
3. `AGENTS.md` testing responsibility is reflected in `docs/testing.md` and agent workflow.
4. Current State Foundation (`a864dfa`) is separated historically from Home Live (`dafbc40`).
5. Observation and Current State are explicitly different populations/semantics.
6. Current Traffic is documented as persisted AP Observation interpretation, not WAN/guest traffic.
7. Admin browser is separated from internal Analytics bearer API.
8. Visit writer coordination and schema v2 are documented.
9. Omada curated API evidence incorporates the 2026-08-14/15 controlled client-control research.
10. Home Activity is change-intent only at this baseline.

## Repository-only unknowns

Production flags, EnvironmentFile, current DB health/counts, service health, current controller reachability, Grafana/Loki health and exact full-suite status cannot be proved from repository-only inspection.

## No-code confirmation

Runtime code changed: **NO**  
Tests changed: **NO**  
Production touched: **NO**  
GitHub `main` touched: **NO**

## Apply

Create/check out a documentation branch at the exact baseline, place this bundle beside the repository and run:

```bash
bash apply_kb_update.sh /path/to/CaptivePortal
```

Then review:

```bash
cd /path/to/CaptivePortal
git status --short
git diff --check
git diff -- README.md README_RU.md docs
```

The script refuses to apply if HEAD is not the exact approved baseline.
