# CaptivPortal Home Device Type Icon Pack v1

Target repository directory:

```text
app/admin_web/static/icons/device-types/
```

This archive mirrors the intended repository path. The Coder may copy the
`app/` tree from this package into the repository.

## Included SVG assets

```text
type-smartphone.svg
type-laptop.svg
type-tablet.svg
type-desktop.svg
type-tv.svg
type-printer.svg
type-camera.svg
type-router.svg
type-iot.svg
type-wearable.svg
type-game-console.svg
type-generic-device.svg
type-unknown.svg
type-pending.svg
```

## Frozen visual semantics already approved by Owner

- `type-unknown.svg`
  - completed classification attempt / could not determine device type
  - visually communicates "undetermined"

- `type-pending.svg`
  - no ready Type result yet / determination still pending
  - visually distinct from `unknown`

## Important implementation note

The final implementation contract will define the authoritative canonical
`Fingerprint device_class` → SVG mapping.

The Coder MUST NOT invent frontend inference, normalize raw strings, or guess
which icon belongs to an unsupported Type value.

These assets are presentation resources only. They do not change Fingerprint
classification semantics.

Existing Android Platform asset remains separate at:

```text
app/admin_web/static/icons/platforms/android.svg
```

Do not move or replace that Platform asset as part of this icon pack.
